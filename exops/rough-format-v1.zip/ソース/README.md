# ラフのソース

画像描画/のreview.htmlは、HTML/CSS/JSで1280×624の作例を描くための元データです。実アプリへのAPI呼出しや保存は行いません。元の作例から相対素材パスだけを同梱用に修正しています。

画像の一覧を作り直す場合：フォーマットのルートで`python3 ソース/ギャラリー生成.py`。

描画から画像を作り直す場合：Node.jsのPlaywrightを使い、`node ソース/画像を書き出す.cjs`。Playwrightを別の場所へ導入している場合は環境変数`ROUGH_PLAYWRIGHT_MODULE`へそのモジュールのパス、既存のChromiumを使う場合は`ROUGH_BROWSER_PATH`へ実行ファイルを指定できます。閲覧にはこの準備は不要です。

編集時は画像描画/review.jsとreview.css、tokens.css、frames.jsを確認します。各画面の説明はルートのflow-definitions.json、一連の説明はflow-routes.jsonです。画像だけを差し替えて説明を放置しないでください。新しい対象は本書の作例を上書きせず、作業用コピーで作成します。

元資料：EX OPSのSRC-028、注文管理内35画像。採用QR本体や製品コードの複製ではありません。採用済み素材を使っていますが、この作例の配置と金融フロー自体は未採用です。
