# -*- coding: utf-8 -*-
"""Generate a server-free image gallery from frames and explained routes."""
from pathlib import Path
import json,html,re,struct
D=Path(__file__).resolve().parent.parent;esc=html.escape
frames=json.loads((D/'flow-definitions.json').read_text());flows=json.loads((D/'flow-routes.json').read_text())
for f in frames:
 for key in ['id','title','description','trigger','connection','back']:assert f.get(key),f"Missing {key}: {f}"
 p=D/'frames'/(f['id']+'.png');assert p.is_file(),p
 assert struct.unpack('>II',p.read_bytes()[16:24])==(1280,624),p
ids={f['id'] for f in frames}
for flow in flows:
 for frame in re.findall(r'\b[A-Z]\d{2}\b',flow['route']):assert frame in ids,frame
style='''*{box-sizing:border-box}body{margin:0;background:white;color:#171717;font:16px/1.65 Arial,"Hiragino Kaku Gothic ProN",sans-serif}main{max-width:1420px;margin:auto;padding:24px}h1{font-size:25px;margin:0 0 10px}h2{font-size:22px;margin:25px 0 12px}a{color:#2563eb}nav{display:flex;gap:18px;flex-wrap:wrap}.intro,.flows,article{background:white;border:1px solid #d4d8dc;border-radius:7px}.intro,.flows{padding:22px;margin-bottom:20px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}article{overflow:hidden}article img{display:block;width:100%;height:auto;border-bottom:1px solid #d4d8dc}article>div{padding:14px 18px}article h3{font-size:18px;margin:0 0 6px}article p{font-size:14px;margin:7px 0}.flows li{margin:15px 0}.flows p{margin:4px 0}.native{display:block;width:1280px;height:624px;max-width:none;margin:12px auto}@media(max-width:850px){.grid{grid-template-columns:1fr}main{padding:12px}}'''
links=lambda route:re.sub(r'\b([A-Z]\d{2})\b',lambda m:f'<a href="pages/{m[1]}.html">{m[1]}</a>',esc(route))
flowhtml='<ol>'+''.join('<li><b>'+esc(f['title'])+'</b><p>'+esc(f['explanation'])+'</p>'+links(f['route'])+'</li>' for f in flows)+'</ol>'
intro='<section class="intro"><h1>ラフ作成フォーマット｜画像＋操作フロー方式</h1><p>個別画像と、開始→操作→結果・例外→戻りの説明をセットで確認します。</p><p>同梱の作例はEX OPS注文管理の未採用ラフ'+str(len(frames))+'枚。各1280×624。方式の保存と画像の採用は別です。</p><nav><a href="ラフ作成マニュアル.md">作成マニュアル</a><a href="ソース/README.md">ソースと再出力</a><a href="ソース/画像描画/review.html">描画元の見本</a><a href="design-tokens.json">作例の色・文字・寸法</a></nav></section>'
cards='<div class="grid">'+''.join('<article id="'+f['id']+'"><a href="pages/'+f['id']+'.html"><img src="frames/'+f['id']+'.png" width="1280" height="624" loading="lazy" alt="'+esc(f['title'])+'"></a><div><h3>'+f['id']+' '+esc(f['title'])+'</h3><p>'+esc(f['description'])+'</p><a href="pages/'+f['id']+'.html">原寸と操作説明</a> · <a href="frames/'+f['id']+'.png">PNG</a></div></article>' for f in frames)+'</div>'
(D/'index.html').write_text('<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ラフ作成フォーマット｜画像＋操作フロー方式</title><style>'+style+'</style><main>'+intro+'<section class="flows"><h2>スタートからエンドまで</h2>'+flowhtml+'</section>'+cards+'</main></html>')
P=D/'pages';P.mkdir(exist_ok=True)
for i,f in enumerate(frames):
 prev=frames[max(0,i-1)]['id'];nex=frames[min(len(frames)-1,i+1)]['id']
 (P/(f['id']+'.html')).write_text('<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(f['id']+' '+f['title'])+'</title><style>'+style+'</style><main><h1>'+esc(f['id']+' '+f['title'])+'</h1><nav><a href="../index.html#'+f['id']+'">画像一覧へ</a><a href="'+prev+'.html">前の画像</a><a href="'+nex+'.html">次の画像</a></nav></main><img class="native" src="../frames/'+f['id']+'.png" width="1280" height="624" alt="'+esc(f['title'])+'"><main><p>'+esc(f['description'])+'</p><p><b>入口・操作：</b>'+esc(f['trigger'])+'</p><p><b>接続・保存：</b>'+esc(f['connection'])+'</p><p><b>取消・失敗・戻り先：</b>'+esc(f['back'])+'</p></main></html>')
print(f"Generated {len(frames)} image pages, {len(flows)} explained routes; no server required for viewing")
