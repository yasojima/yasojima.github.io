(() => {
 'use strict';
 const $=s=>document.querySelector(s),frames=window.orderReviewFrames;
 const money=c=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(c/100);
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const ico=n=>`<img class="ico" src="assets/icons/${n}.svg" alt="">`;
 const btn=(label,go,cls='',extra='')=>{if(/戻る|戻す|キャンセル/.test(label)&&!/(blue|red)/.test(cls))cls=cls.replace(/primary/g,'')+' secondary';return `<button type="button" class="btn ${cls}" ${go?`data-go="${go}"`:''} ${extra}>${esc(label)}</button>`;};
 const action=(label,act,cls='',extra='')=>`<button type="button" class="btn ${cls}" data-act="${act}" ${extra}>${esc(label)}</button>`;
 const close=(go)=>`<button class="close" type="button" data-go="${go}" aria-label="閉じる">${ico('close')}</button>`;
 const productNames=['クロワッサン','バゲット','シナモンロール','サワードウ','バターロール','チョコクロワッサン','アーモンドクロワッサン','ベーグル','あんパン','クリームパン','メロンパン','フォカッチャ','ブリオッシュ','くるみパン','オリーブパン','全粒粉食パン','レーズンブレッド','アップルデニッシュ','カスタードと季節のいちごをたっぷり使った手づくりデニッシュ','ハーブとローストガーリックの長時間発酵カンパーニュ'];
 const prices=[400,500,450,800,350,550,550,400,300,350,350,600,450,500,500,700,650,550,650,800];
 const products=productNames.map((name,id)=>({id,name,unit:prices[id]}));
 const original=[{id:9,qty:1},{id:10,qty:2},{id:11,qty:3},{id:12,qty:1}];
 let st,current='O00',quarter=3,calendarYear=2026,drag=null,qrOrigin=null;
 const defaults=()=>({api:'connected',partial:true,transport:'ok',providerName:'A社（確認用）',rate:'2.90',fixed:'0.30',quoteQty:1,sourceProduct:9,sourceQty:1,exchanged:false,status:'incoming',many:false,guest:false,refunded:false,scroll:[0,0,0],viewDate:'2026-10-29',unknown:false,swapTarget:null,role:'owner',refundState:'idle',refundKind:'full',refundedCents:0,extraReceivedCents:0,refundAttempts:0,operationId:null,differencePaidConfirmed:false,profileScroll:0,navScroll:0,historyIndex:0});

 function formatDay(day){const d=new Date(day+'T12:00:00Z');return day.slice(5).replace('-','/')+'（'+['日','月','火','水','木','金','土'][d.getUTCDay()]+'）';}
 function baseItems(){return st.many?Array.from({length:20},(_,i)=>({id:(15+i)%20,qty:[3,1,2][i%3]})):original.map(v=>({...v}));}
 function preset(id){
  if(['D02','D03'].includes(id))st.many=true;
  if(id==='C03')st.guest=true;
  if(id==='C04')st.historyIndex=1;
  if(id==='E02')st.swapTarget=4;
  if(id==='E03'){st.exchanged=true;st.swapTarget=4;st.exchanges=[{source:9,target:4,qty:1}];}
  if(['E05','E14'].includes(id))st.swapTarget=0;
  if(['E06','E07','E08','E09','E10','E11','E12','E13'].includes(id))st.swapTarget=8;
  if(['S01','S03','D05'].includes(id))st.status='ready';
  if(['S04','D04'].includes(id))st.status='completed';
  if(id==='X03')st.unknown=true;
  if(id==='X04')st.refunded=true;
  if(id==='F02')st.viewDate='2026-11-12';
  if(id==='T01'){st.providerName='';st.rate='';st.fixed='';st.api='disconnected';}
  if(['T03','E07','V03'].includes(id))st.api='disconnected';
  if(['T04','M02','E08','V02','V06'].includes(id))st.api='unavailable';
  if(id==='T05'){st.transport='error';st.api='disconnected';}
  if(['T06','E12'].includes(id))st.partial=false;
  if(['E09','E10','E11','V04','V07','V08'].includes(id)){
   st.refundState=['E10','V07'].includes(id)?'unknown':['E11','V08'].includes(id)?'failed':'pending';
   st.refundKind=id.startsWith('E')?'exchange':'full';st.operationId='rough-maple-6004-refund-001';st.refundAttempts=1;
  }
  if(id==='V07'){st.api='unavailable';}
  if(id==='V05'){st.refundState='succeeded';st.refundKind='full';st.refunded=true;st.refundedCents=3300;}
  if(id==='E13'){st.refundState='succeeded';st.refundKind='exchange';st.refundedCents=50;st.exchanged=true;st.exchanges=[{source:9,target:8,qty:1}];}
  if(id==='E14'){st.extraReceivedCents=50;st.exchanged=true;st.exchanges=[{source:9,target:0,qty:1}];}
 }
 function items(){let list=baseItems();for(const x of st.exchanges||[]){const i=list.findIndex(v=>v.id===x.source&&v.qty>=x.qty);if(i<0)continue;const v=list[i];list.splice(i,1,...(v.qty>x.qty?[{...v,qty:v.qty-x.qty}]:[]),{id:x.target,qty:x.qty,kind:'交換後'});}return list;}
 function effectiveAPI(){return st.transport==='error'?'disconnected':st.api;}
 function hasUnresolvedRefund(){return ['pending','unknown'].includes(st.refundState);}
 function refundMode(){return hasUnresolvedRefund()?'api':effectiveAPI()==='unavailable'?'external':'api';}
 function refundAllowed(partial=false){return effectiveAPI()==='connected'&&st.role==='owner'&&(!partial||st.partial)&&!hasUnresolvedRefund()&&st.refundState!=='succeeded';}
 function header(title,{profile=false,mini=false,back='O00',date=!profile&&!mini,status=!profile&&!mini,day=st.viewDate,statusLabel=statusText(),reference=''}={}){
  return `<header class="dialog-heading"><h1>${title}</h1>${date?`<time class="heading-date">${formatDay(day)}</time>`:''}${status?`<span class="state-tag header-state">${statusLabel}</span>`:''}${reference?`<span class="heading-reference">${reference}</span>`:''}<div class="dialog-tools">${close(back)}</div></header>`;
 }
 function times(){return `<div class="context-times"><span><small>注文</small>${st.many?'07:55':'07:45'}</span><i>｜</i><span><small>受取</small>${st.many?'08:25–10:25':'08:15–10:15'}</span>${st.status!=='incoming'?`<span class="last-time"><small>${st.status==='ready'?'準備完了':'完了'}</small>${st.status==='ready'?'09:20':'09:25'}</span>`:''}</div>`;}
 function identity(){return `<div class="identity"><strong class="number">#${number()}</strong><strong class="name">${customer()}</strong></div>`;}
 function dialog(title,body,footer='',opts={}){return `<div class="shade"></div><section class="dialog ${opts.className||''}" role="dialog" aria-modal="true" aria-label="${title}">${header(title,opts)}${opts.noContext?'':`<div class="detail-metadata">${identity()}${times()}</div>`}<div class="content">${body}</div>${footer?`<footer class="footer">${footer}</footer>`:''}</section>`;}
 function updateScrollHints(){const nav=$('.side-primary'),wrap=$('.nav-scroll-wrap');if(!nav||!wrap)return;wrap.classList.toggle('has-above',nav.scrollTop>1);wrap.classList.toggle('has-below',nav.scrollTop+nav.clientHeight<nav.scrollHeight-1);}

 const lineSum=a=>a.reduce((n,v)=>n+products[v.id].unit*v.qty,0);
 const uniqueTypes=a=>new Set(a.map(v=>v.id)).size;
 const number=()=>st.many?'6006':'6004';
 const customer=()=>st.many?'Lucas Thompson':st.guest?'Alex Parker':'Liam Wilson';
 const boardFrame=()=>st.viewDate!=='2026-10-29'?'F02':st.status==='completed'?'S04':'O00';
 const statusText=()=>({incoming:'未処理・注文内容',ready:'お渡し待機中',completed:'お渡し完了'}[st.status]);
 const baseTotal=()=>lineSum(baseItems());
 const feeOnline=()=>Math.round(baseTotal()*.029+30);
 function brand(){return `<div class="brand" aria-label="EX OPS"><svg class="emblem" viewBox="370 300 530 475" aria-hidden="true"><image href="assets/ex-ops-logo.png" width="1254" height="1254"/></svg><svg class="wordmark" viewBox="150 799 950 180" aria-hidden="true"><image href="assets/ex-ops-logo.png" width="1254" height="1254"/></svg></div>`;}

 function renderSidebar(){
  const nav=[['orders','注文管理'],['sales','売上｜決済｜返金'],['customers','顧客管理'],['products','商品管理'],['allergens','アレルギー管理'],['news','新着｜販促'],['store','店舗基本設定'],['design','デザイン設定'],['guide','返金の取扱い']];
  const activeKey=current.startsWith('T')?'store':current.startsWith('M')?'guide':current.startsWith('V')?'sales':'orders';
  $('#sidebar').innerHTML=`<button class="scan-main" data-act="qr">${ico('scan')}<span>QR読み取り</span></button><div class="nav-scroll-wrap"><nav class="side-primary">${nav.map(([icon,label],i)=>`<button class="nav-item ${activeKey===icon?'active':''}" ${i===0?'data-go="O00"':'title="今回の対象外の参照メニューです"'}>${ico(icon==='guide'?'orders':icon)}<span class="nav-label">${label}</span>${i===0?`<span class="badge">${st.status==='incoming'&&!st.refunded?39:38}</span>`:''}</button>${i===0&&!/^[TMV]/.test(current)?`<div class="side-date"><button data-act="date-prev" aria-label="前日の受取予約">‹</button><button class="date-value" data-go="F01">${formatDay(st.viewDate)}</button><button data-act="date-next" aria-label="翌日の受取予約">›</button></div>`:''}`).join('')}</nav></div><nav class="side-utility">${brand()}<button class="nav-item" title="今回は設定画面を変更しません">${ico('settings')}<span class="nav-label">アカウント設定</span></button><button class="nav-item" title="この見本からログアウトは行いません">${ico('logout')}<span class="nav-label">ログアウト</span></button></nav>`;
  $('.side-primary').scrollTop=st.navScroll||0;updateScrollHints();requestAnimationFrame(updateScrollHints);
 }
 function salesHost(){return `<div class="page-title"><h1>売上｜決済｜返金</h1></div><div class="sales-tabs"><span>決済履歴</span><b>返金リクエスト</b></div><section class="settings-panel"><h2>返金リクエスト</h2><p>注文 #6004　Liam Wilson　${formatDay('2026-10-29')}　$33.00</p><p class="settings-intro">対象の注文と金額を確認して返金手続きを進めます。</p></section>`;}

 function ticket(id,name,summary,types,status='incoming',active=false){
  const num=id,changed=active&&st.status!=='incoming';
  const product=active?items().slice(0,3).map(v=>products[v.id].name+' ×'+v.qty).join('・')+(items().length>3?'…':''):summary;
  return `<article class="ticket" data-ticket="${num}"><div class="ticket-top"><strong class="ticket-number">#${num}</strong><div class="ticket-times"><span><small>注文</small>${active?'07:45':'08:05'} <small>｜受取</small>${active?'08:15–10:15':'08:35–10:35'}</span>${status!=='incoming'?`<span class="terminal"><small>${status==='ready'?'準備完了':'完了'}</small>${status==='ready'?(active?'09:20':'09:13'):'09:25'}</span>`:''}</div></div><button class="ticket-name" ${active?'data-go="C01"':'title="参照カード：操作は#6004で確認"'}>${name}</button><button class="ticket-products" ${active?`data-go="${st.status==='completed'?'D04':st.status==='ready'?'D05':'D01'}"`:types===20?'data-go="D02"':'title="参照カード：操作は#6004で確認"'}><span>${product}</span><b>全${active?uniqueTypes(items()):types}種類 ›</b></button>${status==='completed'?'':`<div class="ticket-actions ${status==='incoming'?'single':''}"><button ${st.viewDate!=='2026-10-29'||st.unknown||st.refunded||hasUnresolvedRefund()?'disabled':''} ${active?`data-act="${status==='incoming'?'ready':'handoff'}"`:'title="参照カード：操作は#6004で確認"'}>${status==='incoming'?'準備完了':'お渡し完了'}</button>${status==='ready'?`<button class="return" ${active?'data-act="return"':'title="参照カード"'}>戻す</button>`:''}</div>`}</article>`;
 }
 function renderBoard(){
  $('#board').className='';
  if(current.startsWith('T')){$('#board').className='page-mode';$('#board').innerHTML=settings();return;}
  if(current.startsWith('M')){$('#board').className='page-mode';$('#board').innerHTML=guide();return;}

  if(current.startsWith('V')){$('#board').className='page-mode';$('#board').innerHTML=salesHost();return;}
  const active=ticket(number(),customer(),'',uniqueTypes(items()),st.status,true),future=st.viewDate!=='2026-10-29';
  const incoming=[ticket('6005','Mia Johnson','ブリオッシュ ×2・くるみパン ×3・オリーブパン…',10),ticket('6006','Lucas Thompson','全粒粉食パン ×3・レーズンブレッド ×1…',20),ticket('6010','Mason Johnson','ベーグル ×1・あんパン ×2…',4)];
  if(st.status==='incoming'&&!st.refunded)incoming.unshift(active);
  const ready=[ticket('6008','Ethan Davis','バゲット ×2・シナモンロール ×3…',10,'ready'),ticket('6009','Sophia Wilson','バターロール ×3・チョコクロワッサン ×1…',17,'ready'),ticket('6007','Ava Miller','カスタードと季節のいちごをたっぷり…',2,'ready')];
  if(st.status==='ready'&&!st.refunded)ready.unshift(active);
  const done=[ticket('6002','Noah Miller','サワードウ ×2・バターロール ×3',2,'completed'),ticket('6003','Olivia Davis','アーモンドクロワッサン ×3・ベーグル ×1…',3,'completed')];
  if(st.status==='completed'&&!st.refunded)done.unshift(active);
  const columns=[['未処理・注文内容',future?3:st.status==='incoming'&&!st.refunded?39:38,incoming,''],['お渡し待機中',future?0:st.status==='ready'?9:8,ready,''],['お渡し完了',future?0:st.status==='completed'?3:2,done,'done']];
  $('#board').innerHTML=columns.map(([title,count,list,cls],i)=>`<section class="order-column ${cls}"><header class="column-head"><h2>${title}</h2><div class="sorts"><span>古い順</span><span>新しい順</span></div><span class="count">${count}</span></header><div class="order-list">${future&&i>0?'<p class="empty-list">注文がありません</p>':list.join('')}</div></section>`).join('');
 }

 function detail(){
  const list=items(),total=baseTotal()-st.refundedCents+st.extraReceivedCents,can=st.status!=='completed'&&st.viewDate==='2026-10-29'&&!st.refunded&&!st.unknown&&!hasUnresolvedRefund()&&st.refundState!=='failed';
  const productRows=list.map((v,i)=>`<div class="product-row ${v.kind?'changed':''}"><div class="product-name"><span>${products[v.id].name}</span>${v.kind?`<small class="row-tag">${v.kind}</small>`:''}</div>${can&&!v.kind?`<button class="row-swap" data-line="${i}" data-go="E01">商品の交換</button>`:'<span></span>'}<span class="number">${v.qty}個</span><span class="number">${money(products[v.id].unit)}</span><span class="number">${money(products[v.id].unit*v.qty)}</span></div>`).join('');
  const panels=`<div class="detail-grid"><section class="panel"><div class="panel-scroll product-scroll" tabindex="0" aria-label="商品一覧"><div class="product-head"><span>商品名</span><span></span><span class="number">個数</span><span class="number">料金</span><span class="number">小計</span></div>${productRows}</div><div class="product-total">${uniqueTypes(list)}種類・合計${list.reduce((n,v)=>n+v.qty,0)}個</div></section><section class="panel"><div class="section-head">支払済み合計</div><div class="panel-scroll money-body" tabindex="0" aria-label="支払と履歴"><div class="grand-total">${money(total)}</div><div class="money-line"><span>オンライン支払済み</span><strong>${money(baseTotal())}</strong></div>${st.refundedCents?`<div class="money-line"><span>返金済み</span><strong class="refund-negative">−${money(st.refundedCents)}</strong></div>`:''}${st.extraReceivedCents?`<div class="money-line"><span>商品交換の差額受取</span><strong>${money(st.extraReceivedCents)}</strong></div>`:''}<hr><h3>決済手数料</h3><div class="money-line"><span>オンライン<small>確認用の概算</small></span><strong>${money(feeOnline())}</strong></div><div class="money-line net"><span>差引後・概算</span><strong>${money(total-feeOnline())}</strong></div>${st.exchanged?`<div class="history-note"><b>商品の交換　09:10</b><br>${products[st.sourceProduct].name} ×${st.quoteQty} → ${products[st.swapTarget??4].name} ×${st.quoteQty}<br>差額 ${money(Math.abs(exchangeDelta()||0))}</div>`:''}</div></section></div>`;
  return `<div class="shade"></div><section class="dialog detail-dialog" role="dialog" aria-modal="true" aria-label="注文内容">${header('注文内容',{back:boardFrame(),date:true})}<p class="one-line-help">${can?'商品の交換は各商品から選べます。':'完了した注文の内容を確認できます。'}</p><div class="detail-metadata">${identity()}${times()}</div><div class="content">${panels}</div></section>`;
 }

 function customerHistory(){return [{day:'2026-10-29',number:number(),items:items(),total:baseTotal(),status:statusText()},...Array.from({length:29},(_,i)=>{const d=new Date(Date.UTC(2026,9,28-i));const a=i<18?[{id:3,qty:1}]:i<28?[{id:0,qty:3}]:[{id:1,qty:2}];return {day:d.toISOString().slice(0,10),number:String(5900-i),items:a,total:lineSum(a),status:'お渡し完了'};})];}
 function customerSummaryStrip(leftLabel,leftValue,rightLabel,rightValue){
  const email=st.many?'member06@example.com':st.guest?'alex@example.com':'member04@example.com',phone=st.many?'+1 202-555-0105':'+1 202-555-0103';
  return `<div class="customer-strip"><div class="customer-identity"><div class="customer-name">${customer()} ${st.guest?'<span class="pill">未登録</span>':''}</div><div class="contacts"><a href="mailto:${email}">${ico('mail')}${email}</a><span>${ico('phone')}${phone}</span></div></div><div class="customer-stats"><div class="stat"><small>${leftLabel}</small><strong>${leftValue}</strong></div><div class="stat"><small>${rightLabel}</small><strong>${rightValue}</strong></div></div></div>`;
 }
 function profile(){
  const guest=st.guest,list=guest?customerHistory().slice(0,1):customerHistory(),total=list.reduce((n,v)=>n+v.total,0);
  const body=customerSummaryStrip(guest?'今回の購入':'購入回数',list.length+(guest?'件':'回'),guest?'今回の金額':'累計購入額',money(total))+`<div class="customer-history" tabindex="0" aria-label="購入履歴"><table class="history-table"><colgroup><col style="width:18%"><col style="width:17%"><col style="width:45%"><col style="width:20%"></colgroup><thead><tr><th>オンライン注文日</th><th>注文番号</th><th>商品</th><th>合計金額</th></tr></thead><tbody>${list.map((h,i)=>`<tr><td>${formatDay(h.day)}</td><td>#${h.number}</td><td><button class="history-products" data-history="${i}" title="注文した商品の全件を確認"><span>${h.items.slice(0,3).map(v=>products[v.id].name+' ×'+v.qty).join('・')}${h.items.length>3?'…':''}</span><b>全${uniqueTypes(h.items)}種類 ›</b></button></td><td>${money(h.total)}</td></tr>`).join('')}</tbody></table></div>`;
  return dialog('顧客情報',body,'',{profile:true,noContext:true,back:boardFrame()});
 }
 function historyDetail(){
  const h=customerHistory()[st.historyIndex||0],qty=h.items.reduce((n,v)=>n+v.qty,0);
  const body=customerSummaryStrip('商品数',uniqueTypes(h.items)+'種類・'+qty+'個','合計金額',money(h.total))+`<div class="customer-history" tabindex="0" aria-label="購入明細"><table class="history-table purchase-table"><colgroup><col style="width:55%"><col style="width:15%"><col style="width:15%"><col style="width:15%"></colgroup><thead><tr><th>商品名</th><th>個数</th><th>料金</th><th>小計</th></tr></thead><tbody>${h.items.map(v=>`<tr><td>${products[v.id].name}</td><td>${v.qty}個</td><td>${money(prices[v.id])}</td><td>${money(prices[v.id]*v.qty)}</td></tr>`).join('')}</tbody></table></div>`;
  return dialog('購入明細',body,'',{noContext:true,back:'C01',day:h.day,statusLabel:h.status,reference:'#'+h.number});
 }

 function exchangeDelta(){return st.swapTarget===null?null:(prices[st.swapTarget]-prices[st.sourceProduct])*st.quoteQty;}
 function swap(){
  const empty=current==='E04',selected=st.swapTarget!==null,delta=exchangeDelta(),before=prices[st.sourceProduct]*st.quoteQty,after=selected?prices[st.swapTarget]*st.quoteQty:null;
  const kind=empty?'交換できる商品がありません':delta===null?'交換後の商品を選択してください':delta===0?'交換前の商品と同額':delta>0?'交換前の商品より料金が高い':'交換前の商品より料金が低い';
  const options=empty?'<option>交換できる商品がありません</option>':`<option value="" disabled ${!selected?'selected':''}>交換後の商品を選択</option>${products.filter(p=>p.id!==st.sourceProduct).map(p=>`<option value="${p.id}" ${p.id===st.swapTarget?'selected':''}>${p.name}</option>`).join('')}`;
  let footer='',guidance='',extra='',label='交換を承認',allowed=selected&&!empty&&st.role==='owner';
  if(delta>0){label='差額の受取を確認して承認';allowed=allowed&&st.differencePaidConfirmed;guidance='交換による差額は、店頭のレジで受け取ります。';extra=`<label class="difference-confirm"><input id="difference-paid" type="checkbox" ${st.differencePaidConfirmed?'checked':''}>レジで差額 ${money(delta)} を受け取りました。</label>`;}
  if(delta<0){label='返金して交換を承認';allowed=refundAllowed(true);guidance=effectiveAPI()==='connected'?(st.partial?'元のオンライン決済へ差額を返金します。':'この店舗では一部返金を利用できません。'):effectiveAPI()==='unavailable'?'決済会社の管理画面から返金手続きを行います。':'現在、返金処理を利用できません。接続の復旧後に再開してください。';}
  if(delta<0&&refundMode()==='external'){label='交換を承認';allowed=false;guidance='決済会社の画面で返金する手続きが必要です。手順の確定まで交換は保留します。';}
  if(st.refundState==='pending'){label='結果を確認';allowed=true;guidance='返金処理中です。結果を確認してから交換を確定します。';}
  if(st.refundState==='unknown'){label='同じ返金の結果を確認';allowed=true;guidance='返金の結果を確認できていません。別の返金は行わず、この処理を確認します。';}
  if(st.refundState==='failed'){label='返金結果を確認';allowed=true;guidance='返金は完了していません。交換は確定せず、結果を確認します。';}
  const body=`<div class="swap-grid"><section class="swap-panel"><h2>交換前の商品</h2><div class="field"><label>商品名</label><div class="read-value">${products[st.sourceProduct].name}</div></div><div class="swap-quantity"><div class="field"><label for="swap-qty">個数</label><input id="swap-qty" type="number" min="1" max="${st.sourceQty}" value="${st.quoteQty}" ${hasUnresolvedRefund()?'disabled':''}></div><div class="field"><label>料金</label><div class="read-value">${money(before)}</div></div></div></section><div class="swap-arrow">›</div><section class="swap-panel"><h2>交換後の商品</h2><div class="field"><label for="swap-product">商品名</label><select id="swap-product" ${empty||hasUnresolvedRefund()?'disabled':''}>${options}</select></div><div class="swap-quantity"><div class="field"><label>個数</label><div class="read-value">${st.quoteQty}</div></div><div class="field"><label>料金</label><div class="read-value">${after===null?'—':money(after)}</div></div></div></section></div><div class="exchange-calculation"><div class="difference-single ${delta!==null&&delta<0?'refund-negative':''}"><span>${delta!==null&&delta<0?'返金':'差額'}</span><strong>${delta===null?'—':(delta<0?'−':'')+money(Math.abs(delta))}</strong></div>${extra}<div class="exchange-outcome"><strong>${kind}</strong><span>${guidance||(selected?'新しい請求・返金はありません。':'料金は指定した個数分の合計です。')}</span></div></div>`;
  const act=hasUnresolvedRefund()||st.refundState==='failed'?'refund-result':delta<0&&refundMode()==='external'?'external-guide':'exchange-approve';
  footer=btn('キャンセル','D01')+action(label,act,'primary',allowed?'':'disabled');
  return dialog('商品の交換',body,footer,{back:'D01',className:'swap-dialog'});
 }
 function commitExchange(){st.exchanged=true;(st.exchanges||=[]).push({source:st.sourceProduct,target:st.swapTarget,qty:st.quoteQty});}
 function beginRefund(kind){
  if(st.role!=='owner'||hasUnresolvedRefund()||st.refundState==='succeeded'||!refundAllowed(kind==='exchange'))return;
  const amount=kind==='exchange'?Math.abs(exchangeDelta()||0):baseTotal()-st.refundedCents;
  if(!Number.isSafeInteger(amount)||amount<=0||amount>baseTotal()-st.refundedCents)return;
  st.refundKind=kind;st.refundAmountCents=amount;st.operationId=st.operationId||'rough-maple-6004-refund-001';st.refundAttempts=(st.refundAttempts||0)+1;st.refundState='pending';
  move(kind==='exchange'?'E09':'V04');
 }
 function finishRefund(){
  if(!st.operationId||!['pending','unknown','failed'].includes(st.refundState))return;
  st.refundState='succeeded';
  if(st.refundKind==='exchange'){st.refundedCents+=Math.abs(exchangeDelta());commitExchange();move('E13');}
  else{st.refundedCents+=st.refundAmountCents||baseTotal()-st.refundedCents;st.refunded=true;move('V05');}
 }

 function refund(){
  const mode=refundMode(),api=effectiveAPI(),pending=hasUnresolvedRefund(),done=st.refundState==='succeeded';
  const target=st.refundKind==='exchange'?Math.abs(exchangeDelta()||0):st.refundAmountCents||(done?st.refundedCents:baseTotal()-st.refundedCents);
  if(current==='V06'){
   const body=`<div class="external-instructions"><h2>決済会社の管理画面で手続きします。</h2><ol><li>元の決済を注文番号・決済情報で確認します。</li><li>対象の金額で返金手続きを行います。</li><li>結果を確認してから、注文の処理を進めます。</li></ol><div class="external-reference"><span>注文 #${number()}</span><strong>返金対象 ${money(target)}</strong></div><p>手続きの完了後、返金結果を確認してください。</p></div>`;
   const origin=st.externalOrigin||'V02';
   return dialog('返金手続きの案内',body,btn('前の画面に戻る',origin,'primary'),{back:origin,className:'refund-dialog refund-external',statusLabel:'外部手続き'});
  }
  let title='返金内容',lead='対象の注文と金額をご確認ください。',primary='返金を承認',act='refund-approve',disabled=!refundAllowed(false);
  if(mode==='external'){lead='この店舗では、決済会社の管理画面から返金手続きを行います。';primary='返金手続きの案内';act='external-guide';disabled=st.role!=='owner';}
  else if(api!=='connected'){lead='現在、返金を実行できません。復旧後に再開してください。';}
  if(st.refundState==='pending'){title='返金処理中';lead='返金の結果を確認しています。';primary='結果を確認';act='refund-result';disabled=false;}
  if(st.refundState==='unknown'){title='返金結果を確認';lead='結果を確認できていません。同じ処理を確認し、別の返金は行いません。';primary='同じ返金の結果を確認';act='refund-result';disabled=false;}
  if(st.refundState==='failed'){title='返金は未完了';lead='返金が完了していません。元の処理結果を確認してください。';primary='返金結果を確認';act='refund-result';disabled=false;}
  if(done){title='返金完了';lead='返金処理の完了を確認しました。';primary='注文管理に戻る';act='return-orders';disabled=false;}
  const body=`<p class="refund-lead">${lead}</p><div class="refund-layout"><section class="refund-panel"><h2>対象の注文</h2><div class="refund-fact"><span>注文番号</span><strong>#${number()}</strong></div><div class="refund-fact"><span>お客様</span><strong>${customer()}</strong></div><div class="refund-fact"><span>オンライン注文日</span><span>${formatDay('2026-10-29')}　07:45</span></div><div class="refund-fact"><span>オンライン決済額</span><strong>${money(baseTotal())}</strong></div><div class="refund-fact"><span>決済方法</span><span>オンライン決済</span></div></section><section class="refund-panel"><h2>${mode==='external'?'外部での返金手続き':'返金内容'}</h2><div class="refund-amount"><span>${done?'返金済み金額':'返金対象額'}</span><strong>${money(target)}</strong></div><div class="refund-fact"><span>処理の状態</span><strong>${done?'返金完了':pending?st.refundState==='unknown'?'結果不明':'処理中':st.refundState==='failed'?'未完了':mode==='external'?'外部手続き':api==='connected'?'承認前':'現在実行できません'}</strong></div>${mode==='external'||(api==='connected'&&!pending)?`<p class="refund-footnote">${mode==='external'?'手続きの完了と結果の照合が必要です。':'元のオンライン決済へ返金します。お客様への反映時期は決済方法により異なります。'}</p>`:''}</section></div>`;
  return dialog(title,body,done?'':action(primary,act,'primary',disabled?'disabled':''),{back:'O00',className:'refund-dialog refund-'+mode,statusLabel:done?'返金済み':'返金申請'});
 }

 function apiBadge(){const api=effectiveAPI();return `<span class="api-status ${api}"><i></i>${{connected:'接続済み',disconnected:'未接続',unavailable:'利用不可'}[api]}</span>`;}
 const unavailableText='ご契約内容、またはご利用中の決済サービスの対応条件により、返金APIを接続できません。返金は決済会社の管理画面からお手続きください。';
 function settings(){return `<div class="page-title"><h1>店舗基本設定｜オンライン決済設定</h1>${btn('返金の取扱い','M01','text')}</div><div class="settings-layout"><section class="settings-panel"><h2>オンライン決済設定</h2><p class="settings-intro">決済会社の契約内容に合わせて設定します。</p><div class="setting-row"><label for="provider-name">決済会社名</label><input id="provider-name" value="${esc(st.providerName)}" placeholder="利用中の決済会社名"></div><div class="setting-row"><label>決済手数料</label><div class="online-fees"><div><label for="fee-rate">料率（％）</label><input id="fee-rate" type="number" min="0" max="100" step="0.01" value="${esc(st.rate)}" placeholder="未設定"></div><div><label for="fee-fixed">固定額（USD/件）</label><input id="fee-fixed" type="number" min="0" step="0.01" value="${esc(st.fixed)}" placeholder="未設定"></div></div></div><p class="settings-hint">実際の手数料を取得できる場合は、実績を優先します。</p><div class="setting-row api-row"><label>返金API</label><div class="api-cell">${apiBadge()}${effectiveAPI()==='unavailable'?`<p class="api-unavailable-note">${unavailableText}</p>`:''}${st.transport==='error'?'<p class="api-transient-note">通信障害により未接続です。再接続後に確認してください。</p>':''}</div></div><div class="setting-row"><label>対応範囲</label><span>${effectiveAPI()==='connected'?(st.partial?'全額返金・一部返金':'全額返金のみ'):'確認待ち'}</span></div><div class="setting-row"><label>確認結果</label><span>${st.providerName?'確認用の架空データ':'未確認'}</span></div><div class="setting-actions">${action('接続を確認','check-connection','primary')}${action('直前の変更を戻す','undo-setting','',st.undoSnapshot?'':'disabled')}</div><p class="settings-status" role="status">${st.saveError?st.saveError:st.saved?'変更を確認用メモリーへ自動保存しました。':st.checked?'確認用データの接続状態を表示しています。':'実サービスへの接続は行いません。'}</p></section><section class="settings-panel connection-help"><h2>返金APIについて</h2><ul><li><b>接続済み</b>：必要な接続条件を確認できています。</li><li><b>未接続</b>：設定が未完了、または一時的に接続が切れています。</li><li><b>利用不可</b>：契約や対応方式により利用できません。</li></ul><div class="info-block"><h3>接続の確認と、返金は別の操作です。</h3><p>この画面の確認だけで、返金や新しい決済は実行しません。</p></div><div class="info-block"><h3>返金画面の扱い</h3><p>接続済みはAPI対応画面、未接続は同じ画面で実行を保留、利用不可は外部手続き用の画面へ自動で切り替わります。</p></div>${btn('返金画面を確認',st.settingsOrigin&&st.settingsOrigin.startsWith('E')?st.settingsOrigin:'V01','slim primary')}${btn('返金の取扱いを見る','M01','slim')}</section></div>`;}
 function guide(){return `<div class="page-title"><h1>返金の取扱い</h1>${btn('オンライン決済設定を確認','T02','slim primary')}</div><p class="guide-example-note">A社・B社・C社は、仕組みを説明するための架空の例です。実際の対応は、ご契約内容と確認結果で判断します。</p><div class="guide-cards"><section><h2>A社の例</h2><strong>全額・一部返金に対応</strong><ul><li>元の決済へ返金を依頼します。</li><li>処理結果を確認して履歴へ反映します。</li></ul></section><section><h2>B社の例</h2><strong>返金できる範囲に条件</strong><ul><li>全額のみ、または一部返金に制限がある例です。</li><li>対応方法を確認してから手続きします。</li></ul></section><section><h2>C社の例</h2><strong>決済会社の画面で手続き</strong><ul><li>EX OPSからの返金APIを利用しない例です。</li><li>外部での処理結果を確認します。</li></ul></section></div><section class="guide-bottom"><div><h2>金額と手数料</h2><ul><li>お客様へ返す金額と、店舗が負担する手数料は別です。</li><li>元の手数料が返るか、返金時に費用がかかるかは契約を確認します。</li></ul></div><div><h2>返金の結果</h2><ul><li>承認・受付だけでは、返金完了とは限りません。</li><li>返金完了から、お客様の口座への反映まで時間がかかる場合があります。</li></ul></div></section>`;}

 function handoff(){return `<div class="shade"></div><section class="dialog mini" role="dialog" aria-modal="true" aria-label="作業を完了しますか？">${header('作業を完了しますか？',{mini:true,back:'S01'})}<p>元に戻せません。</p><footer class="footer">${action('はい','complete','blue')}${btn('いいえ','S01','red')}</footer></section>`;}

 function exception(){const data={X01:['最新の注文内容を確認してください','別のスタッフが、この注文を更新しています。','古い内容を上書きせず、最新の状態を確認します。','最新の内容を確認','D01'],X02:['通信が切れています','入力内容を残して、操作を保留しています。','再接続後に最新の状態を確認してから再開します。','最新の内容を確認','D01'],X03:['処理の結果を確認しています','新しい操作を作らず、同じ処理の結果を照会します。','返金の再実行や、交換の確定は行いません。','商品の交換へ戻る','E02'],X04:['返金済みのため、お渡しできません','全額返金が確認された場合の表示例です。','売上と顧客の履歴は残ります。','一覧に戻る','O00']}[current];return dialog('注文の確認',`<div class="exception"><div class="alert-icon">${ico('warning')}</div><h2>${data[0]}</h2><p>${data[1]}<br>${data[2]}</p></div>`,btn(data[3],data[4],'primary'),{noContext:true,back:current==='X04'?'O00':'D01'});}

 function calendar(){
  const months=Array.from({length:3},(_,j)=>quarter*3+j),year=calendarYear;
  const body=`<div class="calendar-toolbar"><button data-act="quarter-prev" aria-label="前の3か月">‹</button><strong>${year}年　${months[0]+1}〜${months[2]+1}月</strong><button data-act="quarter-next" aria-label="次の3か月">›</button></div><div class="calendar-three">${months.map(m=>{
   const first=new Date(Date.UTC(year,m,1)).getUTCDay(),length=new Date(Date.UTC(year,m+1,0)).getUTCDate();
   return `<section class="month"><h2>${m+1}月</h2><div class="days">${['日','月','火','水','木','金','土'].map((w,i)=>`<span class="weekday ${i===0?'sun':i===6?'sat':''}">${w}</span>`).join('')}${'<span></span>'.repeat(first)}${Array.from({length},(_,i)=>{const d=i+1,weekday=(first+i)%7,date=`${year}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,n=date==='2026-10-29'?49:date==='2026-11-12'?3:(d%5===0?d%7+1:0);return `<button class="day ${date==='2026-10-29'?'today':''} ${date===st.viewDate?'selected':''} ${weekday===0?'sun':weekday===6?'sat':''}" data-date="${date}">${d}${n?`<small>${n}件</small>`:''}</button>`;}).join('')}</div></section>`;
  }).join('')}</div><div class="carry-link"><p>予約件数は、受取日ごとの確認用サンプルです。</p>${btn('前日以前の未完了 2件','F03','slim')}</div>`;
  return dialog('受取日を選択',body,action('本日へ戻る','today','primary'),{profile:true,noContext:true,back:'O00',qr:false});
 }

 function carry(){const body=`<p class="hint">前日以前に受取予定だった未完了注文です。現在は閲覧専用で確認します。</p><div class="panel"><table class="carry-table"><thead><tr><th>受取日</th><th>注文番号</th><th>お客様</th><th>状態</th><th>受取</th></tr></thead><tbody><tr><td>10/28</td><td>#5982</td><td class="name">Olivia Brown</td><td>未処理</td><td>16:00–18:00</td></tr><tr><td>10/28</td><td>#5990</td><td class="name">Ethan Miller</td><td>お渡し待機中</td><td>17:00–19:00</td></tr></tbody></table></div>`;return dialog('前日以前の未完了',body,'',{profile:true,noContext:true,back:'F01',qr:false});}

 function draw(){
  renderSidebar();renderBoard();document.querySelectorAll('.order-list').forEach((e,i)=>e.scrollTop=st.scroll[i]||0);let body='';
  if(current==='C04')body=historyDetail();
  else if(current.startsWith('C'))body=profile();
  else if(current.startsWith('D')||['E03','E13','E14'].includes(current))body=detail();
  else if(current.startsWith('E'))body=swap();
  else if(current.startsWith('V'))body=refund();
  else if(current==='S03')body=handoff();
  else if(current.startsWith('X'))body=exception();
  else if(current==='F01')body=calendar();else if(current==='F03')body=carry();
  $('#modal-root').innerHTML=body;$('#board').inert=!!body;$('#sidebar').inert=!!body;
  if(current==='C02')$('.customer-history').scrollTop=1900;
  else if(current==='C01')$('.customer-history').scrollTop=st.profileScroll||0;
  if(current==='D03')$('.product-scroll').scrollTop=1800;
 }
 function show(id,preserve=false){
  const f=frames.find(v=>v.id===id);if(!f)throw Error('Unknown frame '+id);
  if(!preserve){st=defaults();preset(id);if(id==='F01'){quarter=3;calendarYear=2026;}}
  current=id;draw();$('#frame-select').value=id;$('#frame-title').textContent=id+'　'+f.title;
  for(const [sel,key] of [['#frame-description','description'],['#frame-trigger','trigger'],['#frame-connection','connection'],['#frame-return','back']])$(sel).textContent=f[key];
  const url=new URL(location.href);url.searchParams.set('frame',id);history.replaceState(null,'',url);return id;
 }
 const move=id=>{document.querySelectorAll('.order-list').forEach((e,i)=>st.scroll[i]=e.scrollTop);if($('.side-primary'))st.navScroll=$('.side-primary').scrollTop;return show(id,true);};
 function captureFields(){if($('#provider-name'))st.providerName=$('#provider-name').value;if($('#fee-rate'))st.rate=$('#fee-rate').value;if($('#fee-fixed'))st.fixed=$('#fee-fixed').value;}
 function act(a){captureFields();
  if(a==='exchange-approve'){
   if(st.role!=='owner'||st.swapTarget===null||hasUnresolvedRefund()||st.refundState==='succeeded')return;
   const delta=exchangeDelta();
   if(delta<0){beginRefund('exchange');return;}
   if(delta>0&&!st.differencePaidConfirmed)return;
   commitExchange();if(delta>0)st.extraReceivedCents+=delta;move(delta>0?'E14':'E03');
  }
  else if(a==='refund-approve')beginRefund('full');
  else if(a==='refund-result')finishRefund();
  else if(a==='external-guide'){st.externalOrigin=current;st.refundKind=current.startsWith('E')?'exchange':'full';move('E08');}
  else if(a==='return-orders')move('O00');
  else if(a==='ready'){if(st.refunded||hasUnresolvedRefund())return;st.status='ready';move('S01');}
  else if(a==='return'){st.status='incoming';move('S02');}
  else if(a==='handoff'){if(st.refunded||hasUnresolvedRefund())return;move('S03');}
  else if(a==='complete'){if(st.refunded||hasUnresolvedRefund())return;st.status='completed';move('S04');}
  else if(a==='undo-setting'&&st.undoSnapshot){Object.assign(st,st.undoSnapshot);st.undoSnapshot=null;st.saved=false;draw();}
  else if(a==='check-connection'){st.checked=true;if(st.api!=='unavailable'&&st.providerName){st.api='connected';st.transport='ok';}draw();}
  else if(a==='today'){st.viewDate='2026-10-29';move('O00');}
  else if(a==='date-prev'||a==='date-next'){const d=new Date(st.viewDate+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+(a==='date-prev'?-1:1));st.viewDate=d.toISOString().slice(0,10);move(st.viewDate==='2026-10-29'?'O00':'F02');}
  else if(a==='quarter-prev'||a==='quarter-next'){quarter+=a==='quarter-prev'?-1:1;if(quarter<0){quarter=3;calendarYear--;}if(quarter>3){quarter=0;calendarYear++;}draw();}
  else if(a==='qr'){$('#modal-root').innerHTML=`<div class="shade"></div><section class="dialog" role="dialog" aria-label="QR読み取り">${header('QR読み取り',{profile:true,back:current})}<div class="content"><div class="exception"><h2>採用済みの共通QRへ接続</h2><p>元の業務画面を保持して、共通の読取画面へ進む入口です。</p><p>QR本体はこの作例に含めません。元プロジェクトの採用資料を参照します。</p></div></div></section>`;$('#board').inert=true;$('#sidebar').inert=true;}
 }
 document.addEventListener('click',e=>{
  const history=e.target.closest('[data-history]');if(history){st.profileScroll=$('.customer-history').scrollTop;st.historyIndex=Number(history.dataset.history);move('C04');return;}
  const go=e.target.closest('[data-go]');if(go){captureFields();if(go.dataset.line!==undefined){const v=items()[Number(go.dataset.line)];st.sourceProduct=v.id;st.sourceQty=v.qty;st.quoteQty=1;st.swapTarget=null;st.differencePaidConfirmed=false;st.refundState='idle';}if(go.dataset.go==='D02')st.many=true;if(go.dataset.go==='T02')st.settingsOrigin=current;move(go.dataset.go);return;}
  const a=e.target.closest('[data-act]');if(a){act(a.dataset.act);return;}
  const date=e.target.closest('[data-date]');if(date){st.viewDate=date.dataset.date;move(st.viewDate==='2026-10-29'?'O00':'F02');}
 });
 document.addEventListener('change',e=>{
  if(e.target.id==='swap-product'){st.swapTarget=Number(e.target.value);st.differencePaidConfirmed=false;const delta=exchangeDelta();move(delta===0?'E02':delta>0?'E05':effectiveAPI()==='unavailable'?'E08':effectiveAPI()==='disconnected'?'E07':!st.partial?'E12':'E06');}
  if(e.target.id==='swap-qty'){st.quoteQty=Math.max(1,Math.min(st.sourceQty,Number(e.target.value)||1));st.differencePaidConfirmed=false;draw();}
  if(e.target.id==='difference-paid'){st.differencePaidConfirmed=e.target.checked;draw();}
 });
 document.addEventListener('focusin',e=>{if(['provider-name','fee-rate','fee-fixed'].includes(e.target.id))st.beforeEdit={providerName:st.providerName,rate:st.rate,fixed:st.fixed};});
 document.addEventListener('change',e=>{if(!['provider-name','fee-rate','fee-fixed'].includes(e.target.id))return;captureFields();const a=st.rate.trim(),b=st.fixed.trim();if((!!a!==!!b)||[a,b].some(v=>v&&!/^\d+(?:\.\d{1,2})?$/.test(v))||(a&&Number(a)>100)){st.saveError='料率と固定額を確認してください。';st.saved=false;}else{st.saveError='';st.undoSnapshot=st.beforeEdit;st.saved=true;}draw();});
 document.addEventListener('input',captureFields);
 document.addEventListener('scroll',e=>{if(e.target.matches?.('.side-primary')){st.navScroll=e.target.scrollTop;updateScrollHints();}},{capture:true});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('.dialog .close'))$('.dialog .close').click();});
 $('#frame-select').innerHTML=frames.map(f=>`<option value="${f.id}">${f.id} ${f.title}</option>`).join('');$('#frame-select').addEventListener('change',e=>show(e.target.value));
 $('#previous').addEventListener('click',()=>show(frames[Math.max(0,frames.findIndex(v=>v.id===current)-1)].id));$('#next').addEventListener('click',()=>show(frames[Math.min(frames.length-1,frames.findIndex(v=>v.id===current)+1)].id));$('#restart').addEventListener('click',()=>show('O00'));
 window.orderReview={frames,show,get current(){return current;},get state(){return JSON.parse(JSON.stringify(st));},totals(){return {online:baseTotal(),paid:baseTotal()-st.refundedCents+st.extraReceivedCents,types:uniqueTypes(items()),qty:items().reduce((n,v)=>n+v.qty,0),delta:exchangeDelta()};},setConnection(p){if(p.api!==undefined){if(!['connected','disconnected','unavailable'].includes(p.api))throw Error('invalid fixture');st.api=p.api;}if(p.transport!==undefined)st.transport=p.transport;if(p.partial!==undefined)st.partial=p.partial;if(p.role!==undefined)st.role=p.role;draw();},get refundView(){return {mode:refundMode(),status:effectiveAPI(),operationId:st.operationId,attempts:st.refundAttempts};}};
 if(new URLSearchParams(location.search).get('capture')==='1')document.documentElement.classList.add('capture');show(new URLSearchParams(location.search).get('frame')||'O00');
})();

// Scene composition for PNG export only; no product state or API changes.
(()=>{function align(){for(const f of document.querySelectorAll('.dialog .footer')){const p=f.querySelector('.btn.primary,.btn.blue');if(p&&f.children.length>1)f.prepend(p);}}const show=window.orderReview.show;window.orderReview.show=(...a)=>{const result=show(...a);align();return result;};document.addEventListener('click',()=>queueMicrotask(align),true);align();})();
