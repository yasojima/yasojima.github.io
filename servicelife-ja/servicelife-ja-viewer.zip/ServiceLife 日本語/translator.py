"""Read batches of English UI text from the local viewer, and return Japanese."""
import json
import re
import sys
from pathlib import Path

folder = Path(__file__).resolve().parent
bundle_libs = folder / "vendor"
if bundle_libs.is_dir():
    sys.path.insert(0, str(bundle_libs))
import ctranslate2
import sentencepiece

protected_value = re.compile(
    r"https?://[^\s<>]+|[\w.+-]+@[\w.-]+\.\w+"
    r"|(?<!\w)(?:[$€£]\s*)?\d+(?:[.,:/-]\d+)*(?:\s*%)?(?!\w)"
)

def business_sentence(text):
    balance = re.fullmatch(r"The outstanding balance is ([$€£][\d,.]+) for (\d+) invoices\.", text, flags=re.I)
    if balance:
        return "請求書" + balance[2] + "件の未入金額は、合計" + balance[1] + "です。"
    contact = re.fullmatch(r"Contact (\S+@\S+) at (\d{1,2}:\d{2})\.", text, flags=re.I)
    if contact:
        return contact[2] + "に" + contact[1] + "へご連絡ください。"
    return None


def run_model(strings, tokenizer, engine):
    batches, owners = [], []
    positions = [[] for _ in strings]
    for index, string in enumerate(strings):
        for sentence in re.split(r"(?<=[.!?])\s+(?=[A-Z])|[\r\n]+", string):
            special = business_sentence(sentence)
            if special:
                positions[index].append(special)
                continue
            tokens = tokenizer.encode(sentence, out_type=str)
            for offset in range(0, len(tokens), 160):
                batches.append(tokens[offset:offset + 160])
                owners.append((index, len(positions[index])))
                positions[index].append("")
    if batches:
        results = engine.translate_batch(batches, beam_size=3, max_batch_size=24,
                                         max_decoding_length=260, repetition_penalty=1.12)
        for (owner, pos), result in zip(owners, results):
            positions[owner][pos] = tokenizer.decode(result.hypotheses[0]).strip()
    return ["".join(parts) for parts in positions]


def restore_values(source, result, tokenizer, engine):
    # Re-translate around literal amounts, times and identifiers if the model
    # changed or dropped one. The reservation's numbers take precedence.
    values = list(protected_value.finditer(source))
    result = re.sub(r"([$€£])\s+(?=\d)", r"\1", result)
    if not values or all(result.count(m.group()) >= source.count(m.group()) for m in values):
        return result
    parts, start = [], 0
    for value in values:
        parts.append(source[start:value.start()])
        start = value.end()
    parts.append(source[start:])
    texts = [part if re.search("[A-Za-z]{2}", part) else "" for part in parts]
    translated = run_model(texts, tokenizer, engine)
    restored = []
    for i, part in enumerate(parts):
        restored.append(translated[i] or part.strip())
        if i < len(values):
            restored.append(values[i].group())
    return "".join(restored)


def main():
    root = folder / "model" if bundle_libs.is_dir() else folder / ".runtime" / "model"
    tokenizer = sentencepiece.SentencePieceProcessor(model_file=str(root / "sentencepiece.model"))
    engine = ctranslate2.Translator(str(root / "model"), device="cpu", compute_type="int8",
                                    inter_threads=1, intra_threads=4)
    for line in sys.stdin:
        try:
            strings = json.loads(line)
            translated = run_model(strings, tokenizer, engine)
            response = [restore_values(s, t, tokenizer, engine) for s, t in zip(strings, translated)]
        except Exception as error:
            print(str(error), file=sys.stderr, flush=True)
            response = None
        print(json.dumps(response, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
