#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
root="$(pwd)"
runtime="$root/.runtime"
bundle="$root/ServiceLife 日本語.app"
desktop_bin="$bundle/Contents/MacOS/ServiceLifeViewer"
resources="$bundle/Contents/Resources"
mkdir -p "$runtime" "$bundle/Contents/MacOS"
if ! "$runtime/py/bin/python" -c 'import ctranslate2, sentencepiece' 2>/dev/null; then
    /usr/bin/python3 -m venv "$runtime/py"
    "$runtime/py/bin/python" -m pip --disable-pip-version-check install --only-binary=:all: \
        'ctranslate2==4.5.0' 'sentencepiece==0.2.0' 'numpy==1.26.4'
fi
if [[ ! -f "$runtime/model/.ready" ]]; then
    "$runtime/py/bin/python" - <<'PY'
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

runtime = Path(".runtime")
archive = runtime / "translate-en_ja-1_1.argosmodel"
digest = "16300cc4eaa85320520cabcf433b63d01be40ef6966251de72043a083408f716"
if not archive.is_file() or hashlib.sha256(archive.read_bytes()).hexdigest() != digest:
    with tempfile.NamedTemporaryFile(dir=runtime, delete=False) as output:
        temp = Path(output.name)
    try:
        subprocess.run(["/usr/bin/curl", "-fsSL", "--retry", "2", "-o", str(temp),
                        "https://argos-net.com/v1/translate-en_ja-1_1.argosmodel"], check=True)
        if hashlib.sha256(temp.read_bytes()).hexdigest() != digest:
            raise RuntimeError("翻訳モデルの照合に失敗しました。")
        os.replace(temp, archive)
    finally:
        temp.unlink(missing_ok=True)
dest = runtime / "model"
with zipfile.ZipFile(archive) as z:
    for name in ("sentencepiece.model", "model/model.bin", "model/shared_vocabulary.txt", "README.md"):
        target = dest / name
        target.parent.mkdir(exist_ok=True, parents=True)
        with z.open("en_ja/" + name) as source, target.open("wb") as output:
            shutil.copyfileobj(source, output)
(dest / ".ready").touch()
archive.unlink()
PY
fi
mkdir -p "$resources"
resigned=0
if [[ ! -d "$resources/vendor" || ! -f "$resources/model/.ready" ]]; then
    vendor="$resources/vendor"
    mkdir -p "$vendor"
    libs="$("$runtime/py/bin/python" -c 'import sysconfig; print(sysconfig.get_paths()["purelib"])')"
    for part in "$libs"/ctranslate2* "$libs"/sentencepiece* "$libs"/numpy* "$libs"/yaml "$libs"/PyYAML* "$libs"/pyyaml*; do
        [[ ! -e "$part" ]] || /bin/cp -R "$part" "$vendor/"
    done
    /bin/cp -R "$runtime/model/." "$resources/model"
    resigned=1
fi
for source_file in translator.py localize.js charts.js 用語.tsv; do
    if ! /usr/bin/cmp -s "$source_file" "$resources/$source_file"; then
        /bin/cp "$source_file" "$resources/$source_file"
        resigned=1
    fi
done
if [[ ! -x "$desktop_bin" || Viewer.swift -nt "$desktop_bin" || Info.plist -nt "$bundle/Contents/Info.plist" ]]; then
    sdk="$(/usr/bin/xcrun --sdk macosx --show-sdk-path)"
    os_version="$(/usr/bin/sw_vers -productVersion | /usr/bin/cut -d. -f1)"
    compatible_sdk="/Library/Developer/CommandLineTools/SDKs/MacOSX${os_version}.sdk"
    if [[ -d "$compatible_sdk" ]]; then sdk="$compatible_sdk"; fi
    /usr/bin/xcrun swiftc -swift-version 5 -O -sdk "$sdk" -module-cache-path "$runtime/swift-cache" \
        Viewer.swift -o "$runtime/ServiceLifeViewer"
    /bin/cp Info.plist "$bundle/Contents/Info.plist"
    /bin/mv "$runtime/ServiceLifeViewer" "$desktop_bin"
    resigned=1
fi
if [[ "$resigned" == 1 ]]; then /usr/bin/codesign --force --sign - "$bundle" >/dev/null; fi
if [[ "${1:-}" != "--prepare" ]]; then /usr/bin/open "$bundle"; fi
