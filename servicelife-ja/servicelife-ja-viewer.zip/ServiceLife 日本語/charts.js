// Chart.js draws labels as pixels. Translate its drawing and measurement text
// consistently, keeping its dataset, amounts, tooltips and hit targets intact.
if (location.origin !== "https://demo.servicelife.app" || !window.CanvasRenderingContext2D) return;
const normalize=s=>s.trim().replace(/\s+/g," ").toLowerCase();
const glossary=new Map(Object.entries(terms).map(([a,b])=>[normalize(a),b]));
const cache=new Map(), waiting=new Map(), sent=new Set();
const months=["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"];
const weekdays=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const daysJa=["日","月","火","水","木","金","土"];
let timer=0;
function requestWords() {
    timer=0;
    for (const [canvas,words] of waiting) {
        if (!canvas.isConnected) { waiting.delete(canvas);continue; }
        const group=Array.from(words).slice(0,20);
        if (!group.length) { waiting.delete(canvas);continue; }
        group.forEach(s=>{ words.delete(s); sent.add(s); });
        canvas.setAttribute("data-sl-ja-chart-request",JSON.stringify(group));
        canvas.dispatchEvent(new Event("sl-ja-chart-request",{bubbles:true}));
        if (!words.size) waiting.delete(canvas);
    }
    if (waiting.size) timer=setTimeout(requestWords,80);
}
function label(text,canvas) {
    if (typeof text!=="string" || !/[a-z]/i.test(text)) return text;
    const key=normalize(text);
    if (glossary.has(key)) return glossary.get(key);
    if (cache.has(text)) return cache.get(text);
    const d=weekdays.findIndex(day=>key===day.toLowerCase());
    if (d!==-1) return daysJa[d];
    const m=text.match(/^([A-Za-z]{3,9})(?:\s+(\d{1,2})(?:,\s*(\d{4}))?|\s+(\d{4}))?$/);
    if (m && months.includes(m[1].slice(0,3).toLowerCase())) {
        const n=months.indexOf(m[1].slice(0,3).toLowerCase())+1;
        return (m[4]||m[3] ? (m[4]||m[3])+"年" : "")+n+"月"+(m[2] ? Number(m[2])+"日" : "");
    }
    const colon=text.match(/^(.+?)(:\s*[\d$%., \-]+)$/);
    if (colon && glossary.has(normalize(colon[1]))) return glossary.get(normalize(colon[1]))+colon[2].replace(":","：");
    if (text.length<2 || text.length>220 || /^[\d$.,:% /+-]+[KMB]?$/i.test(text) || /@|https?:\/\//i.test(text)) return text;
    if (canvas?.isConnected && !sent.has(text)) {
        if (!waiting.has(canvas)) waiting.set(canvas,new Set());
        waiting.get(canvas).add(text);
        if (!timer) timer=setTimeout(requestWords,65);
    }
    return text;
}
document.addEventListener("sl-ja-chart-response",e=>{
    const canvas=e.target;
    if (!(canvas instanceof HTMLCanvasElement)) return;
    try {
        const pairs=JSON.parse(canvas.getAttribute("data-sl-ja-chart-response")||"[]");
        for (const [en,ja] of pairs) if (typeof en==="string" && typeof ja==="string") cache.set(en,ja);
        document.querySelectorAll("canvas").forEach(c=>window.Chart?.getChart?.(c)?.update("none"));
    } catch {}
});
for (const name of ["fillText","strokeText","measureText"]) {
    const original=CanvasRenderingContext2D.prototype[name];
    CanvasRenderingContext2D.prototype[name]=function(text,...args) {
        return original.call(this,label(text,this.canvas),...args);
    };
}
