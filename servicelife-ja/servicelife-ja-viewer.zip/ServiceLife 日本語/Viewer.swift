import AppKit
import WebKit

private let host = "demo.servicelife.app"
private let root = Bundle.main.resourceURL!

// A single serial worker owns the text-model process and its message framing.
final class LocalTranslator {
    private let queue = DispatchQueue(label: "jp.exops.reference.translation")
    private var process: Process?
    private var writer: FileHandle?
    private var reader: FileHandle?
    private var buffer = Data()
    private var cache = [String: String]()

    private func start() throws {
        if process?.isRunning == true { return }
        let process = Process(), input = Pipe(), output = Pipe()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/python3")
        process.arguments = ["-I", "-B", "-u", root.appendingPathComponent("translator.py").path]
        process.standardInput = input
        process.standardOutput = output
        try process.run()
        self.process = process
        writer = input.fileHandleForWriting
        reader = output.fileHandleForReading
        buffer.removeAll()
    }

    private func translate(_ strings: [String]) throws -> [String] {
        if cache.count > 30000 { cache.removeAll(keepingCapacity: true) }
        let missing = strings.filter { cache[$0] == nil }
        if !missing.isEmpty {
            try start()
            guard let writer = writer, let reader = reader else { throw CocoaError(.fileReadUnknown) }
            var request = try JSONEncoder().encode(missing)
            request.append(10)
            try writer.write(contentsOf: request)
            while !buffer.contains(10) {
                let bytes = reader.availableData
                if bytes.isEmpty { throw CocoaError(.fileReadUnknown) }
                buffer.append(bytes)
            }
            let index = buffer.firstIndex(of: 10)!
            let answers = try JSONDecoder().decode([String].self, from: buffer[..<index])
            buffer.removeSubrange(...index)
            guard answers.count == missing.count else { throw CocoaError(.fileReadCorruptFile) }
            for (source, answer) in zip(missing, answers) { cache[source] = answer }
        }
        return strings.map { cache[$0] ?? $0 }
    }

    func submit(_ strings: [String], completion: @escaping ([String]?, String?) -> Void) {
        queue.async {
            do {
                let result = try self.translate(strings)
                DispatchQueue.main.async { completion(result, nil) }
            } catch {
                self.writer?.closeFile()
                if self.process?.isRunning == true { self.process?.terminate() }
                self.process = nil
                DispatchQueue.main.async { completion(nil, "追加の文章を翻訳できませんでした。") }
            }
        }
    }
}

final class Viewer: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandlerWithReply {
    private var window: NSWindow!
    private var web: WKWebView!
    private let status = NSTextField(labelWithString: "")
    private let world = WKContentWorld.world(name: "EXOPS Japanese reader")
    private let translator = LocalTranslator()

    func applicationDidFinishLaunching(_ notification: Notification) {
        let menu = NSMenu()
        let appItem = NSMenuItem()
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "ServiceLife 日本語を終了", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu
        menu.addItem(appItem)
        let editItem = NSMenuItem(title: "編集", action: nil, keyEquivalent: "")
        let editMenu = NSMenu(title: "編集")
        for (name, action, key) in [("コピー", "copy:", "c"), ("ペースト", "paste:", "v"), ("すべてを選択", "selectAll:", "a")] {
            editMenu.addItem(withTitle: name, action: Selector(action), keyEquivalent: key)
        }
        editItem.submenu = editMenu
        menu.addItem(editItem)
        NSApp.mainMenu = menu

        let config = WKWebViewConfiguration()
        config.userContentController.addScriptMessageHandler(self, contentWorld: world, name: "translateEnglish")
        do {
            let terms = try String(contentsOf: root.appendingPathComponent("用語.tsv"), encoding: .utf8)
            var dictionary = [String: String]()
            for row in terms.split(whereSeparator: \.isNewline) {
                let fields = row.split(separator: "\t", maxSplits: 1)
                if fields.count == 2 { dictionary[String(fields[0])] = String(fields[1]) }
            }
            let json = String(decoding: try JSONEncoder().encode(dictionary), as: UTF8.self)
            let script = try String(contentsOf: root.appendingPathComponent("localize.js"), encoding: .utf8)
            let source = "(function(terms){\n" + script + "\n})(" + json + ");"
            config.userContentController.addUserScript(WKUserScript(source: source, injectionTime: .atDocumentStart,
                                                                    forMainFrameOnly: false, in: world))
            let charts = try String(contentsOf: root.appendingPathComponent("charts.js"), encoding: .utf8)
            let chartSource = "(function(terms){\n" + charts + "\n})(" + json + ");"
            config.userContentController.addUserScript(WKUserScript(source: chartSource, injectionTime: .atDocumentStart,
                                                                    forMainFrameOnly: false, in: .page))
        } catch {
            let alert = NSAlert(error: error)
            alert.messageText = "日本語表示に必要なファイルを開けませんでした。"
            alert.runModal()
            NSApp.terminate(nil)
            return
        }
        web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = self
        web.uiDelegate = self
        web.allowsBackForwardNavigationGestures = true
        let toolbar = NSStackView()
        toolbar.orientation = .horizontal
        toolbar.spacing = 8
        toolbar.edgeInsets = NSEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
        for (label, command) in [("戻る", #selector(back)), ("進む", #selector(forward)),
                                 ("業務管理", #selector(manager)), ("予約カレンダー", #selector(calendar))] {
            toolbar.addArrangedSubview(NSButton(title: label, target: self, action: command))
        }
        status.textColor = .secondaryLabelColor
        status.font = .systemFont(ofSize: 12)
        toolbar.addArrangedSubview(status)
        let container = NSView()
        for child in [toolbar as NSView, web as NSView] {
            child.translatesAutoresizingMaskIntoConstraints = false
            container.addSubview(child)
        }
        NSLayoutConstraint.activate([
            toolbar.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            toolbar.topAnchor.constraint(equalTo: container.topAnchor),
            toolbar.trailingAnchor.constraint(lessThanOrEqualTo: container.trailingAnchor),
            web.topAnchor.constraint(equalTo: toolbar.bottomAnchor),
            web.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            web.bottomAnchor.constraint(equalTo: container.bottomAnchor)
        ])
        let space = NSScreen.main?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1440, height: 900)
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: min(1520, space.width - 30), height: min(960, space.height - 60)),
                          styleMask: [.titled, .closable, .resizable, .miniaturizable], backing: .buffered, defer: false)
        window.minSize = NSSize(width: 440, height: 360)
        window.title = "ServiceLife 日本語"
        window.contentView = container
        window.center()
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        calendar()
    }

    @objc func back() { if web.canGoBack { web.goBack() } }
    @objc func forward() { if web.canGoForward { web.goForward() } }
    @objc func manager() { openPath("/business-manager/") }
    @objc func calendar() { openPath("/calendar/") }
    private func openPath(_ path: String) { web.load(URLRequest(url: URL(string: "https://" + host + path)!)) }
    func application(_ application: NSApplication, open urls: [URL]) {
        guard urls.contains(where: { $0.absoluteString == "servicelife-ja://open" }) else { return }
        // The public link restores the existing window, preserving the current page and role.
        window?.deminiaturize(nil)
        window?.makeKeyAndOrderFront(nil)
        application.activate(ignoringOtherApps: true)
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage,
                               replyHandler: @escaping (Any?, String?) -> Void) {
        guard message.frameInfo.securityOrigin.host == host, message.frameInfo.securityOrigin.protocol == "https",
              let texts = message.body as? [String], texts.count <= 30, texts.allSatisfy({ $0.utf8.count <= 24000 }) else {
            replyHandler(nil, "この画面では利用できません。")
            return
        }
        translator.submit(texts) { result, error in
            self.status.stringValue = error ?? ""
            replyHandler(result, error)
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard action.targetFrame?.isMainFrame != false, let url = action.request.url else {
            decisionHandler(.allow); return
        }
        if url.scheme == "https", url.host == host {
            decisionHandler(.allow)
        } else {
            if action.navigationType == .linkActivated, ["https", "http", "mailto", "tel"].contains(url.scheme ?? "") {
                NSWorkspace.shared.open(url)
            }
            decisionHandler(.cancel)
        }
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if action.request.url?.host == host { webView.load(action.request) }
        return nil
    }
    private func dialog(_ text: String, completion: @escaping (NSAlert) -> Void) {
        translator.submit([text]) { result, _ in
            let alert = NSAlert()
            alert.messageText = "ServiceLife"
            alert.informativeText = result?.first ?? text
            completion(alert)
        }
    }
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        dialog(message) { alert in
            alert.addButton(withTitle: "閉じる")
            alert.beginSheetModal(for: self.window) { _ in completionHandler() }
        }
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        dialog(message) { alert in
            alert.addButton(withTitle: "続行")
            alert.addButton(withTitle: "キャンセル")
            alert.beginSheetModal(for: self.window) { response in completionHandler(response == .alertFirstButtonReturn) }
        }
    }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        dialog(prompt) { alert in
            let input = NSTextField(frame: NSRect(x: 0, y: 0, width: 320, height: 24))
            input.stringValue = defaultText ?? ""
            alert.accessoryView = input
            alert.addButton(withTitle: "確定")
            alert.addButton(withTitle: "キャンセル")
            alert.beginSheetModal(for: self.window) { response in completionHandler(response == .alertFirstButtonReturn ? input.stringValue : nil) }
        }
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { status.stringValue = "" }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { status.stringValue = "読み込みエラー　" + error.localizedDescription }
    }
}

let app = NSApplication.shared
let viewer = Viewer()
app.setActivationPolicy(.regular)
app.delegate = viewer
app.run()
