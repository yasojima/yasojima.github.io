// Runs in a private WebKit content world on the official public demo.
if (location.protocol !== "https:" || location.hostname !== "demo.servicelife.app") return;

const jp = /[\u3040-\u30ff\u3400-\u9fff]/;
const hasEnglish = /[A-Za-z]{2}/;
const normal = s => s.trim().replace(/\s+/g, " ").replace(/[’‘]/g, "'")
    .replace(/[‐‑]/g, "-").toLowerCase();
const dict = new Map(Object.entries(terms).map(([s, ja]) => [normal(s), ja]));
const dayNames = {sun:"日",mon:"月",tue:"火",wed:"水",thu:"木",fri:"金",sat:"土"};
const fullDays = {sunday:"日曜日",monday:"月曜日",tuesday:"火曜日",wednesday:"水曜日",thursday:"木曜日",friday:"金曜日",saturday:"土曜日"};
const monthNames = ["january","february","march","april","may","june","july","august","september","october","november","december"];
const mo = key => monthNames.findIndex(x => x.slice(0, 3) === key.toLowerCase().slice(0, 3)) + 1;
const serviceNames = ["Bed Bug Treatment","General Pest Control","Mosquito Treatment","Quarterly Maintenance","Rodent Control","Termite Inspection","Termite Treatment","Wildlife Removal"];
const standardServices = new RegExp("^("+serviceNames.join("|")+")\\s*\\((\\d+)\\s*(?:m|min|mins|minutes)\\)$","i");
const visitServices = new Set(serviceNames.map(normal));
const clockPattern = /\b(\d{1,2}):(\d{2})(:\d{2})?\s*(am|pm)\b/gi;
const clock24 = s => s.replace(clockPattern,(_,h,m,sec,period)=>
    String(Number(h)%12 + (period.toLowerCase()==="pm"?12:0)) + ":" + m + (sec||""));
function dateText(value) {
    const s=value.trim();
    const date=s.match(/^(?:(Sun(?:day)?|Mon(?:day)?|Tue(?:sday)?|Wed(?:nesday)?|Thu(?:rsday)?|Fri(?:day)?|Sat(?:urday)?),?\s+)?([a-z]{3,9})\s+(\d{1,2})(?:,\s*(\d{4}))?(?:,?\s+(\d{1,2}:\d{2}(?::\d{2})?\s*[AP]M))?$/i);
    if (!date || !mo(date[2])) return null;
    return (date[4]?date[4]+"年":"")+mo(date[2])+"月"+Number(date[3])+"日"+(date[1]?"（"+dayNames[date[1].slice(0,3).toLowerCase()]+"）":"")+(date[5]?" "+clock24(date[5]):"");
}
function displayPattern(s) {
    let m;
    if ((m=s.match(/^(?:Next:|次の訪問先：)\s*(.+?)(?: at (\d{1,2}:\d{2}\s*[AP]M))?$/i)))
        return "次の訪問先："+m[1]+(m[2]?"（"+clock24(m[2])+"）":"");
    if ((m=s.match(/^(?:last|updated|last updated)\s*:\s*(.*)$/i)) && dateText(m[1])) return "最終："+dateText(m[1]);
    if ((m=s.match(/^(?:Updated:?\s+)(\d{1,2}:\d{2}(?::\d{2})?\s*[AP]M)$/i))) return "最終更新 "+clock24(m[1]);
    if ((m=s.match(/^(.+?)\s*[·•—]\s*(.+)$/)) && visitServices.has(normal(m[1]))) return dict.get(normal(m[1]))+" ・ "+(dateText(m[2])||m[2]);
    if ((m=s.match(/^(.+?)\s+-\s+(.+)$/)) && visitServices.has(normal(m[2]))) return m[1]+" ・ "+dict.get(normal(m[2]));
    if ((m=s.match(/^(\d{2}:\d{2})-(\d{2}:\d{2})\s+\((\d+)min\)(?:\s+(\d+)min from prev)?\s+Score:\s*([\d.]+)$/i)))
        return m[1]+"〜"+m[2]+"（"+m[3]+"分）"+(m[4]?"・直前の現場から"+m[4]+"分":"")+"・評価 "+m[5]+"点";
    if ((m=s.match(/^Score:\s*([\d.]+)(?:\s*·\s*🚗\s*(\d+)min from prev)?$/i))) return "評価 "+m[1]+"点"+(m[2]?"・直前の現場から車で"+m[2]+"分":"");
    if ((m=s.match(/^(\d+) open slots\s*·\s*Avg Score:\s*([\d.]+)$/i))) return "空き枠"+m[1]+"件・平均評価"+m[2]+"点";
    if ((m=s.match(/^(\d+) stops\s*·\s*mean spread (—|[\d.]+) mi$/i))) return "訪問先"+m[1]+"件・平均距離 "+(m[2]==="—"?"算出対象外":m[2]+"マイル");
    if ((m=s.match(/^(\d+)min\s*·\s*🚗\s*(\d+)m←$/))) return "空き"+m[1]+"分・直前の現場から車で"+m[2]+"分";
    if ((m=s.match(/^(\d+(?:\.\d+)?)\s*pts$/i))) return m[1]+"点";
    if ((m=s.match(/^(\d+)([dhm]) ago$/i))) return m[1]+({d:"日",h:"時間",m:"分"}[m[2].toLowerCase()])+"前";
    if ((m=s.match(/^(\d+)[–-](\d+) days$/i)))return m[1]+"〜"+m[2]+"日";
    if ((m=s.match(/^(\d+)% of responses$/i)))return "回答全体の"+m[1]+"％";
    if ((m=s.match(/^·\s*(\$[\d,.]+)\/yr$/i)))return "・年間 "+m[1];
    if ((m=s.match(/^booked (\d{4})-(\d{2})-(\d{2})$/i)))return m[1]+"年"+Number(m[2])+"月"+Number(m[3])+"日 予約済み";
    if ((m=s.match(/^Page (\d+) of (\d+)(?:\s*—\s*([\d,]+) total)?$/i)))return "全"+m[2]+"ページ中"+m[1]+"ページ"+(m[3]?"（全"+m[3]+"件）":"");
    if ((m=s.match(/^Step (\d+) of (\d+)$/i)))return "手順"+m[1]+"／"+m[2];
    if ((m=s.match(/^Open job card for (.+)$/i)))return m[1]+"様の作業詳細を開く";
    if ((m=s.match(/^Driving directions to (.+)$/i)))return m[1]+"までの車の経路を見る";
    if ((m=s.match(/^([A-Za-z]{3}) (\d{1,2})\/(\d{1,2})$/)) && dayNames[m[1].toLowerCase()])return m[2]+"月"+m[3]+"日（"+dayNames[m[1].toLowerCase()]+"）";
    if ((m=s.replace(/^\((.+)\)$/,"$1").match(/^(.+?)\s*[–→]\s*(.+?)(?:,\s*(\d{4}))?$/)) && dateText(m[1]) && dateText(m[2])){
        const range=(m[3]?m[3]+"年":"")+dateText(m[1])+"〜"+dateText(m[2]);
        return s.startsWith("(")?"（"+range+"）":range;
    }
    const stamp=dateText(s.replace(/\s*·$/,""));
    if(stamp)return stamp+(s.endsWith("·")?"・":"");
    if (/^\d{1,2}:\d{2}(?::\d{2})?\s*[ap]m(?:\s*[-–]\s*\d{1,2}:\d{2}\s*[ap]m)?$/i.test(s))return clock24(s).replace(/\s*[-–]\s*/,"〜");
    if (/^-?[\d.]+,\s*-?[\d.]+\s*[•·]\s*\d/.test(s))return clock24(s);
    return null;
}

function known(s) {
    const k = normal(s);
    if (dict.has(k)) return dict.get(k);
    const formatted=displayPattern(s);
    if(formatted)return formatted;
    const lines = s.split(/\\n|\r?\n/);
    if (lines.length >= 2) {
        const entry = lines[0].match(/^(.+?)\s+—\s+(.+)$/);
        if (entry && dict.has(normal(entry[2]))) {
            lines[0] = entry[1] + " — " + dict.get(normal(entry[2]));
            return lines.map(l=>l.replace(/^Arrival window:\s*/i,"到着予定の時間帯：")).join("\n");
        }
    }
    const bare = k.replace(/\s*(?:\*|:|\.{3}|…)\s*$/, "");
    if (dict.has(bare)) return dict.get(bare) + (k.endsWith("*") ? "（必須）" : /(?:\.{3}|…)$/.test(k) && bare === "loading" ? "…" : "");
    let m = s.match(standardServices);
    if (m) return dict.get(normal(m[1])) + "（" + m[2] + "分）";
    m = s.match(/^Rebalancing two stops between (.+?) and (.+?) cuts about (\d+) minutes? of drive time tomorrow[—\s-]+no arrival windows move\.\s*Net: one extra job.s worth of capacity\.$/i);
    if (m) return m[1]+"と"+m[2]+"の訪問先を2件調整すると、明日の移動時間を約"+m[3]+"分短縮できます。お客様に案内した到着時間帯はそのままで、もう1件訪問できる余裕が生まれます。";
    m = s.match(/^A warranty re-treat ticket has breached its SLA at escalation level (\d+)\. Recommend assigning it today and texting the customer a same-day ETA\.$/i);
    if (m) return "保証に基づく再施工の依頼が、優先対応レベル"+m[1]+"で対応期限を過ぎています。本日中に担当者を決め、到着予定時刻をお客様にSMSでお知らせすることを提案します。";
    m = s.match(/^Warranty callback breached SLA\s*[—-]\s*(.+)$/i);
    if (m) return "保証対応の折り返し期限を超過 — "+m[1];
    m = s.match(/^Rebook SMS to (.+)$/i);
    if (m) return m[1]+"様に再予約のご案内をSMSで送る";
    m = s.match(/^Send payment link to (.+)$/i);
    if (m) return m[1]+"様に決済リンクを送る";
    m = s.match(/^Hi (.+?)[,—]\s*this is (.+?)[.。]\s*(.*)$/i);
    if (m && !m[3].trim()) return m[1]+"様、"+m[2]+"です。";
    m = k.match(/^(\d{1,2})(?::(\d{2}))?\s*(am|pm)$/);
    if (m) return String((Number(m[1]) % 12) + (m[3] === "pm" ? 12 : 0)) + ":" + (m[2] || "00");
    m = k.match(/^max travel:\s*(\d+)\s*min$/);
    if (m) return "移動時間の上限：" + m[1] + "分";
    m = s.match(/^(\d[\d,]*)\s+(appointments?|customers?|invoices?|tickets?|results?|payments?)$/i);
    if (m) return m[1] + (/^customer/i.test(m[2]) ? "名の顧客" : "件");
    m = k.match(/^(\d+(?:\.\d+)?)\s*(m|min|mins|minutes?|h|hr|hrs|hours?|days?|weeks?|months?|slots?|techs?|jobs?|stops?|visits?)$/);
    if (m) {
        const unit = /^(m|min|mins|minutes?)$/.test(m[2]) ? "分" : /^h/.test(m[2]) ? "時間" :
            /day/.test(m[2]) ? "日" : /week/.test(m[2]) ? "週間" : /month/.test(m[2]) ? "か月" :
            /slot/.test(m[2]) ? "枠" : /tech/.test(m[2]) ? "名" : /visit|stop/.test(m[2]) ? "件の訪問" : "件";
        return m[1] + unit;
    }
    if (fullDays[k]) return fullDays[k];
    if (dayNames[k]) return dayNames[k];
    if (monthNames.some(x => x === k || x.slice(0,3) === k)) return mo(k) + "月";
    m = k.match(/^(sun|mon|tue|wed|thu|fri|sat),?\s+([a-z]{3,9})\s+(\d{1,2})(?:,\s*(\d{4}))?$/);
    if (m && mo(m[2])) return (m[4] ? m[4] + "年" : "") + mo(m[2]) + "月" + Number(m[3]) + "日（" + dayNames[m[1]] + "）";
    m = k.match(/^([a-z]{3,9})\s+(\d{1,2})(?:,\s*(\d{4}))?$/);
    if (m && mo(m[1])) return (m[3] ? m[3] + "年" : "") + mo(m[1]) + "月" + Number(m[2]) + "日";
    m = k.match(/^([a-z]{3,9})\s+(\d{4})$/);
    if (m && mo(m[1])) return m[2] + "年" + mo(m[1]) + "月";
    m = s.match(/^(.+?)\s*\((\d+)\)$/);
    if (m && dict.has(normal(m[1]))) return dict.get(normal(m[1])) + "（" + m[2] + "）";
    m = k.match(/^showing\s+([\d,]+)[–-]([\d,]+)\s+of\s+([\d,]+)$/);
    if (m) return "全" + m[3] + "件中 " + m[1] + "～" + m[2] + "件";
    m = k.match(/^of\s+([\d,]+)$/);
    if (m) return "／全" + m[1] + "ページ";
    m = s.match(/^([\p{Extended_Pictographic}\uFE0F\uE000-\uF8FF]+\s*)(.*)$/u);
    if (m && m[2] && dict.has(normal(m[2]))) return m[1] + dict.get(normal(m[2]));
    return null;
}

// Data such as names, identifiers and prices must continue to match the source.
const businessData = /^(?:https?:\/\/|mailto:|tel:|[\w.+-]+@)|^\d[\d-]*\s+(?:[A-Z][\w.'-]*\s+){0,6}(?:St|Street|Rd|Road|Dr|Drive|Way|Blvd|Boulevard|Ave|Avenue|Ln|Lane|Pike|Cir|Court|Ct|Plaza|Hwy)\b/i;
const idOnly = /^(?:[A-Z\d_#./:+*%=$() -]+|[\da-f]{8}-(?:[\da-f]{4}-){3}[\da-f]{12}|[A-Z]{2,}[-\d]+)$/;
const timeOnly = /^\d{1,2}:\d{2}(?:\s*[ap]m)?(?:\s*[-–]\s*\d{1,2}:\d{2}(?:\s*[ap]m)?)?$/i;
const dataCols = /^(?:customer|customer name|technician|assigned technician|staff member|email|phone|address|service address|location|contact name|company name|user id|reference number)$/;
const originals = new WeakMap();
const recordedNames = new Set();
const optionData = /(?:^|[-_ ])(?:tech|technician|customer|staff|contact|assignee|employee)(?:$|[-_ ])/i;
const commonData = new Set(["ServiceLife","Evergreen Pest Solutions (Demo)","FullCalendar","Google","Google Maps","Stripe","Square","Visa","Mastercard"]);
function dataContext(el, s) {
    if (commonData.has(s) || recordedNames.has(s) || businessData.test(s) || timeOnly.test(s) ||
        /^(?:#[\w-]+|[A-Za-z]+\d+[-\w]*|\d+[\d,.]*(?:\s*(?:am|pm))?)$/i.test(s)) return true;
    if (el.matches("#techChips .tc, .rv-hdr .cell, .tech-info .tn") ||
        (el.matches(".rv-appt .ad") && el.previousElementSibling?.classList.contains("ad"))) {
        if (s.length < 120) recordedNames.add(s);
        return true;
    }
    if (idOnly.test(s) && !/\b[A-Z]{2,}\s+[A-Z]{2,}\b/.test(s) && s.length < 40) return true;
    if (el.tagName === "OPTION") {
        const select = el.closest("select");
        if (select && optionData.test([select.id,select.name,select.getAttribute("aria-label")].join(" ")) &&
            /^[\p{L}.'-]+(?:\s+[\p{L}.'-]+){0,4}$/u.test(s) && !/^(?:all|choose|no |select|assign|auto|any)/i.test(s)) {
            recordedNames.add(s); return true;
        }
    }
    const td = el.closest("td");
    if (td && td.cellIndex >= 0) {
        const th = td.closest("table")?.tHead?.rows[0]?.cells[td.cellIndex];
        if (th) {
            const label = originals.get(th) || th.textContent;
            if (dataCols.test(normal(label))) {
                if (s.length < 100) recordedNames.add(s);
                return true;
            }
        }
    }
    return false;
}

const ignored = "script,style,noscript,template,code,pre,kbd,textarea,input,[contenteditable]:not([contenteditable=false]),[data-sl-ja-annotation],.notranslate";
const attributes = ["placeholder","title","aria-label","alt","data-original-title","data-bs-title"];
const work = new Map(), learned = new Map(), deferred = new Map(), notes = new WeakMap();
let processing = false, refreshTimer = 0, flushTimer = 0;
function visible(el) {
    if (!el.isConnected) return false;
    if (el.tagName === "OPTION") el = el.closest("select") || el;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && r.bottom > -120 && r.top < innerHeight + 200;
}
function preserveSpace(src, value) {
    return (src.match(/^\s*/)[0]) + value + (src.match(/\s*$/)[0]);
}
function technicianLabel(s, el) {
    // The demo can swap in this screen before updating the browser URL.
    if (!document.getElementById("techList")) return null;
    if (s === "Active" && el.matches("#kActive + .lbl")) return "対象スタッフ数";
    if (s === "En Route" && el.matches("#kOnRoute + .lbl, #filterStatus option[value='on_route']")) return "訪問予定・移動中";
    if (s === "Idle" && el.matches("#filterStatus option[value='idle']")) return dict.get("idle / off duty");
    if (s === "Live —" && el.matches(".last-update")) return "一覧の最終更新";
    const marker = s.match(/^(.+) — (On Job|En Route|Idle|Off Duty|Running Late|On Time)$/i);
    if (marker && el.closest("#techMap")) return marker[1] + " — " + dict.get(normal(marker[2]));
    return null;
}
function translate(source, el, setter, isCurrent) {
    const s = source.trim();
    if (!s || !el || !el.isConnected) return;
    if (normal(s)==="name" && el.closest("th,label") &&
        /^\/(?:equipment|inventory|job-types|territories|pricebook|marketing|contracts|canned-responses|settings|licenses)\//.test(location.pathname)) {
        setter(preserveSpace(source,"名称")); return;
    }
    let direct = technicianLabel(s,el);
    if (normal(s)==="ok" && el.matches(".lbl") && ["/maintenance/","/transcription-health/"].includes(location.pathname)) direct="正常";
    if (normal(s)==="owner" && !/^\/customers\/.+/.test(location.pathname)) direct="オーナー";
    if (normal(s)==="partial" && location.pathname==="/transcription-health/") direct="一部成功";
    direct ||= known(s);
    if (direct) { setter(preserveSpace(source,direct)); return; }
    if (!hasEnglish.test(s)) return;
    if (dataContext(el,s) || (jp.test(s) && !/[A-Za-z]{3,}(?:\s+[A-Za-z]{3,})+/.test(s))) return;
    if (s.length > 10000 || /^[\s\d$.%():/\-–,]+$/.test(s)) return;
    if (learned.has(s)) {
        const result = learned.get(s);
        if (result && result !== s) setter(preserveSpace(source,result));
        return;
    }
    const target = {el, put(result){ if (el.isConnected && isCurrent() && result && s !== result) setter(preserveSpace(source,result)); }};
    if (!visible(el)) {
        // A select or dialog may be hidden until the user opens it.
        if (!deferred.has(el)) deferred.set(el,new Map());
        deferred.get(el).set(s,target);
        return;
    }
    enqueue(s,target);
}
function enqueue(s,target) {
    if (learned.has(s)) { target.put(learned.get(s)); return; }
    if (!work.has(s)) work.set(s,[]);
    work.get(s).push(target);
    if (!processing && !flushTimer) flushTimer = setTimeout(flush,12);
}
async function flush() {
    flushTimer = 0;
    if (processing || !work.size) return;
    processing = true;
    const items = Array.from(work.keys()).slice(0,20);
    const jobs = items.map(k=>work.get(k));
    items.forEach(k=>work.delete(k));
    let ok = false;
    try {
        const results = await window.webkit.messageHandlers.translateEnglish.postMessage(items);
        results.forEach((result,i)=>{
            const src = items[i];
            // Some English product and proper names intentionally survive translation.
            const clean = result?.trim() || src;
            learned.set(src,clean);
            for (const target of jobs[i]) target.put(clean);
        });
        ok = true;
    } catch {
        items.forEach((s,i)=>{ if (!work.has(s)) work.set(s,[]); work.get(s).push(...jobs[i].filter(x=>x.el.isConnected)); });
    } finally {
        processing = false;
        if (work.size) flushTimer = setTimeout(flush,ok ? 8 : 2500);
    }
}
const written = new WeakMap();
function textNode(node) {
    const el = node.parentElement;
    if (!el || el.closest(ignored) || el.closest("option")) return;
    const src = node.data;
    if (written.get(node) === src || !/[A-Za-z]/.test(src)) return;
    if (el.tagName === "TH" && !originals.has(el)) originals.set(el,el.textContent);
    translate(src,el,value=>{
        if (value === src || node.data !== src) return;
        written.set(node,value);
        node.data=value;
    },()=>node.data===src);
}
let lastAttributes = new WeakMap();
function attribute(el,key) {
    const src=el.getAttribute(key);
    if (!src || lastAttributes.get(el)?.get(key)===src) return;
    translate(src,el,value=>{
        if (src===value || el.getAttribute(key)!==src) return;
        if (!lastAttributes.has(el)) lastAttributes.set(el,new Map());
        lastAttributes.get(el).set(key,value);
        el.setAttribute(key,value);
    },()=>el.getAttribute(key)===src);
}
const optionSource = new WeakMap();
function option(el) {
    const text=el.textContent.trim(), label=el.getAttribute("label");
    const previous=optionSource.get(el);
    if (previous && previous.text===text && previous.label===label) return;
    const src=previous && previous.label===label && previous.text!==text ? text : (label || text);
    const selectedFrom=el.value;
    const current=()=>el.value===selectedFrom && el.textContent.trim()===text;
    translate(src,el,value=>{
        if (!current() || value===label) return;
        // Setting the display label leaves form values and the site's own textContent intact.
        optionSource.set(el,{text,label:value});
        el.label=value;
    },current);
}
function note(el) {
    if (el.dataset.slJaTyped || !el.value || !hasEnglish.test(el.value) || el.matches(":focus") ||
        !/note|access|instruction|comment|message|description|draft|sms|template|body|feedback/i.test([el.name,el.id,el.placeholder].join(" "))) return;
    const src=el.value;
    if (notes.get(el)?.source===src) return;
    if (window.SL_VIEW) {
        // Only the read-only exported demo can display its sample draft directly in Japanese.
        const sample=known(src.trim());
        if (sample && !sEquals(src,sample)) el.value=sample;
        return;
    }
    translate(src,el,value=>{
        if (el.value!==src || sEquals(src,value)) return;
        const prior=notes.get(el);
        const result=prior?.element || document.createElement("div");
        result.dataset.slJaAnnotation="true";
        result.style.cssText="font:inherit;font-size:.93em;white-space:pre-wrap;line-height:1.5;margin:.25em 0 .55em";
        result.textContent="日本語訳　"+value.trim();
        if (!result.isConnected) el.after(result);
        notes.set(el,{source:src,element:result});
    },()=>el.value===src);
}
function sEquals(a,b) { return a.trim()===b.trim(); }
function localizeSampleField(el) {
    if (!window.SL_VIEW || el.dataset.slJaTyped) return;
    if (el.matches("#i-unit,#fUnit") && el.value==="each") el.value="個";
    if (location.pathname==="/settings/" && el.disabled && el.value==="starter") el.value="スタータープラン";
}
function element(el) {
    if (!el || el.nodeType!==1 || el.closest("[data-sl-ja-annotation]")) return;
    if (el.tagName==="OPTION") { option(el); return; }
    for (const key of attributes) if (el.hasAttribute(key)) attribute(el,key);
    if (el.tagName==="TEXTAREA") note(el);
    if (el.tagName==="INPUT") localizeSampleField(el);
    if (el.tagName==="INPUT" && ["button","submit","reset"].includes(el.type) && el.value) {
        // Submitted controls may use value as a business code; only change unnamed display buttons.
        if (!el.name) attribute(el,"value");
        else if (!el.title) {
            const src=el.value;
            translate(src,el,v=>{ if (el.value===src) el.title=v; },()=>el.value===src);
        }
    }
}
function scan(rootNode) {
    if (!rootNode?.isConnected) return;
    if (rootNode.nodeType===Node.TEXT_NODE) { textNode(rootNode); return; }
    if (rootNode.nodeType!==Node.ELEMENT_NODE || rootNode.closest("script,style,template,noscript,[data-sl-ja-annotation]")) return;
    element(rootNode);
    const walker=document.createTreeWalker(rootNode,NodeFilter.SHOW_ELEMENT|NodeFilter.SHOW_TEXT,{
        acceptNode(n) {
            if (n.nodeType===1 && n.matches("script,style,template,noscript,code,pre,[contenteditable=true],[data-sl-ja-annotation]")) return NodeFilter.FILTER_REJECT;
            return NodeFilter.FILTER_ACCEPT;
        }
    });
    let n;
    while ((n=walker.nextNode())) {
        if (n.nodeType===Node.TEXT_NODE) textNode(n); else element(n);
    }
}
function reveal() {
    refreshTimer=0;
    if (window.SL_VIEW) document.querySelectorAll("input#i-unit,input#fUnit").forEach(localizeSampleField);
    for (const [el,items] of deferred) {
        if (!el.isConnected) { deferred.delete(el); continue; }
        if (!visible(el)) continue;
        for (const [s,t] of items) enqueue(s,t);
        deferred.delete(el);
    }
    document.querySelectorAll("textarea").forEach(t=>{
        const prior=notes.get(t);
        if (prior && prior.source!==t.value) { prior.element.remove();notes.delete(t); }
        if (visible(t) && !t.dataset.slJaTyped) note(t);
    });
}
function queueReveal() { if (!refreshTimer) refreshTimer=setTimeout(reveal,90); }
function start() {
    document.documentElement.lang="ja";
    const originalLanguage=document.querySelector('form[data-testid="language-switcher"]');
    if (originalLanguage) {
        const caption=document.createElement("span");
        caption.textContent="日本語表示";
        caption.title="ServiceLifeの英語デモをこのビューアで日本語表示しています";
        caption.dataset.slJaAnnotation="true";
        caption.style.cssText="font:inherit;font-size:11px;white-space:nowrap";
        originalLanguage.replaceChildren(caption);
    }
    document.addEventListener("sl-ja-chart-request",async e=>{
        const canvas=e.target;
        if (canvas.tagName!=="CANVAS") return;
        try {
            const strings=JSON.parse(canvas.getAttribute("data-sl-ja-chart-request")||"[]");
            if (!Array.isArray(strings) || !strings.length || strings.length>20 || strings.some(s=>typeof s!=="string" || s.length>220)) return;
            const results=await window.webkit.messageHandlers.translateEnglish.postMessage(strings);
            canvas.setAttribute("data-sl-ja-chart-response",JSON.stringify(strings.map((s,i)=>[s,results[i]||s])));
            canvas.dispatchEvent(new Event("sl-ja-chart-response",{bubbles:true}));
        } catch {}
    });
    scan(document.documentElement);
    const currentMenu=Array.from(document.querySelectorAll("a[href]")).find(a=>
        a.host===location.host && a.pathname===location.pathname && !a.hash && a.textContent.trim());
    if (currentMenu) document.title=currentMenu.textContent.trim() + "｜ServiceLife 日本語";
    const observer=new MutationObserver(changes=>{
        for (const ch of changes) {
            if (ch.type==="childList") {
                for (const node of ch.addedNodes) scan(node);
                if (ch.target.tagName==="OPTION") option(ch.target);
            } else if (ch.type==="characterData") {
                if (ch.target.parentElement?.tagName==="OPTION") option(ch.target.parentElement);
                else textNode(ch.target);
            } else if (ch.attributeName==="label" && ch.target.tagName==="OPTION") option(ch.target);
            else if (attributes.includes(ch.attributeName)) attribute(ch.target,ch.attributeName);
            else if (ch.attributeName==="value" && ch.target.tagName==="INPUT") element(ch.target);
        }
        queueReveal();
    });
    observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true,
        attributeFilter:[...attributes,"label","value","class","style","hidden","open"]});
    addEventListener("scroll",queueReveal,true);
    addEventListener("resize",queueReveal);
    addEventListener("click",queueReveal,true);
    addEventListener("change",queueReveal,true);
    addEventListener("input",e=>{
        if (e.isTrusted && e.target.matches("textarea,input#i-unit,input#fUnit")) {
            e.target.dataset.slJaTyped="true";
            notes.get(e.target)?.element.remove();notes.delete(e.target);
        }
    },true);
    // Form .value assignments by the application do not create a DOM mutation.
    setInterval(()=>{ if (!document.hidden) reveal(); },1800);
    queueReveal();
}
if (document.readyState==="loading") document.addEventListener("DOMContentLoaded",start,{once:true});
else start();
