const RD_API = '/api/v1/routing/density/clusters/';
const csrf = () => document.cookie.match(/csrftoken=([^;]+)/)?.[1] || '';

function rdToday(){
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
}

async function rdFetch(){
  const date = document.getElementById('rdDate').value || rdToday();
  const radius = document.getElementById('rdRadius').value || '1.5';
  const url = `${RD_API}?date=${encodeURIComponent(date)}&radius_miles=${encodeURIComponent(radius)}`;
  const r = await fetch(url, {credentials: 'same-origin', headers: {'X-CSRFToken': csrf(), 'Accept': 'application/json'}});
  if(!r.ok) throw new Error('density fetch failed: ' + r.status);
  return await r.json();
}

function rdFmtTime(iso){
  if(!iso) return '—';
  try { return new Date(iso).toLocaleTimeString('en-US', {hour: 'numeric', minute: '2-digit'}); }
  catch(e){ return iso; }
}

const RD_STATUS_LABELS = {
  scheduled: 'Scheduled', confirmed: 'Confirmed', reminded: 'Reminded',
  en_route: 'En Route', arrived: 'Arrived', in_progress: 'In Progress',
  completed: 'Completed', invoiced: 'Invoiced', cancelled: 'Cancelled',
  no_show: 'No Show', rescheduled: 'Rescheduled',
};

function rdRender(data){
  const sub = document.getElementById('rdSubtitle');
  sub.textContent = `${data.clusters.length} cluster${data.clusters.length===1?'':'s'} on ${data.date} · radius ${data.radius_miles} mi`;
  const summary = document.getElementById('rdSummary');
  const totalStops = data.clusters.reduce((n,c)=>n+c.size,0);
  const sizes = data.clusters.map(c=>c.size).filter(n=>n>0);
  const biggest = sizes.length ? Math.max(...sizes) : 0;
  summary.innerHTML = [
    {label:'Clusters', value:data.clusters.length},
    {label:'Total stops', value:totalStops},
    {label:'Biggest cluster', value:biggest},
  ].map(s=>`<div class="rd-stat"><div class="label">${s.label}</div><div class="value">${s.value}</div></div>`).join('');

  const wrap = document.getElementById('rdClusters');
  if(!data.clusters.length){
    wrap.innerHTML = '<div class="rd-empty"><i class="fas fa-calendar-day"></i><div>No appointments scheduled for this date.</div></div>';
    return;
  }
  wrap.innerHTML = data.clusters.map((c, idx)=>{
    const open = idx === 0 ? '' : '';
    const order = c.appointments.map((a,i)=>{
      const recurPill = (a.recurrence && a.recurrence !== 'none')
        ? `<span class="rd-pill recur">${a.recurrence}</span>` : '';
      return `<tr>
        <td>${i+1}</td>
        <td>${rdFmtTime(a.start_datetime)}</td>
        <td><strong>${rdEsc(a.customer_name)}</strong></td>
        <td>${rdEsc(a.address)}</td>
        <td>${rdEsc(a.technician_name||'—')}</td>
        <td><span class="rd-pill">${rdEsc(RD_STATUS_LABELS[a.status] || a.status || '')}</span> ${recurPill}</td>
      </tr>`;
    }).join('');
    const meta = c.cluster_id === 'ungeocoded'
      ? `<span class="meta">no geocode</span>
         <button type="button" class="btn btn-outline" style="font-size:11px;padding:3px 10px;margin-left:8px" onclick="rdGeocodeRetry(this)">
           <i class="fas fa-location-crosshairs"></i> Retry geocode
         </button>`
      : `<span class="meta">${c.size} stops · mean spread ${c.mean_pairwise_miles ?? '—'} mi</span>`;
    const heading = c.cluster_id === 'ungeocoded'
      ? 'Ungeocoded'
      : 'Cluster ' + c.cluster_id.replace('cluster-','#');
    return `<section class="rd-cluster" data-cluster-id="${c.cluster_id}">
      <header class="rd-cluster-head"><h3><i class="fas fa-map-marker-alt"></i> ${heading}</h3>${meta}</header>
      <div class="rd-cluster-body">
        <table class="rd-stop-list" data-cluster-stops>
          <thead><tr><th>#</th><th>Time</th><th>Customer</th><th>Address</th><th>Tech</th><th>Status</th></tr></thead>
          <tbody>${order}</tbody>
        </table>
      </div>
    </section>`;
  }).join('');
}

function rdEsc(s){
  return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

async function rdGeocodeRetry(btn){
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Geocoding…';
  const date = document.getElementById('rdDate').value || rdToday();
  try {
    const r = await fetch(`/api/v1/routing/density/geocode-missing/?date=${encodeURIComponent(date)}`, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {'X-CSRFToken': csrf(), 'Accept': 'application/json'},
    });
    if (!r.ok) throw new Error('geocode request failed: ' + r.status);
    const d = await r.json();
    btn.innerHTML = `<i class="fas fa-check"></i> ${d.geocoded} geocoded`;
    if (d.geocoded > 0) setTimeout(rdRefresh, 800);
  } catch(e) {
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-location-crosshairs"></i> Retry geocode';
    alert('Geocoding failed: ' + e.message);
  }
}

async function rdRefresh(){
  const wrap = document.getElementById('rdClusters');
  wrap.innerHTML = '<div class="rd-loader"><i class="fas fa-spinner fa-spin"></i> Loading clusters…</div>';
  try {
    const data = await rdFetch();
    rdRender(data);
  } catch(e) {
    wrap.innerHTML = '<div class="rd-empty"><i class="fas fa-triangle-exclamation"></i><div>'+rdEsc(e.message)+'</div></div>';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if(!document.getElementById('rdDate').value){
    document.getElementById('rdDate').value = rdToday();
  }
  rdRefresh();
});