(function(){
  const $=id=>document.getElementById(id);
  const jobTypes=JSON.parse($('jobTypesData').textContent||'[]');
  const cadences=JSON.parse($('cadenceData').textContent||'[]');
  const getCsrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
  let slots=[], chosenSlot=null, custType='residential';

  // Populate selects
  $('job_type_id').innerHTML='<option value="">Select a service…</option>'+
    jobTypes.map(j=>`<option value="${j.id}" data-dur="${j.duration}">${j.name}</option>`).join('');
  $('cadence_template_id').innerHTML='<option value="">One-time — no plan</option>'+
    cadences.map(c=>`<option value="${c.id}" data-rec="${c.recurring_fee}" data-init="${c.initial_fee}">${c.name}</option>`).join('');

  // Customer type toggle
  $('typeSeg').addEventListener('click',e=>{
    const b=e.target.closest('button[data-type]'); if(!b)return;
    custType=b.dataset.type;
    [...$('typeSeg').children].forEach(x=>x.classList.toggle('on',x===b));
    $('companyWrap').style.display=custType==='commercial'?'block':'none';
  });

  // Cadence -> prefill fees
  $('cadence_template_id').addEventListener('change',()=>{
    const o=$('cadence_template_id').selectedOptions[0];
    const has=!!$('cadence_template_id').value;
    $('feeRow').style.display=has?'grid':'none';
    if(has){
      if(!$('recurring_fee').value) $('recurring_fee').value=o.dataset.rec||'';
      if(!$('initial_fee').value) $('initial_fee').value=o.dataset.init||'';
    }
  });

  function showErr(msg){ const e=$('errBox'); e.textContent=msg; e.style.display='block'; }
  function clearErr(){ $('errBox').style.display='none'; }

  // Find slots
  $('findBtn').addEventListener('click',async()=>{
    clearErr();
    const jt=$('job_type_id').value, addr=$('service_address').value.trim();
    if(!jt) return showErr('Pick a job type first.');
    if(!addr) return showErr('Enter the service address first.');
    $('findBtn').textContent='Finding times…'; $('findBtn').disabled=true;
    const qs=new URLSearchParams({job_type_id:jt,address:addr,
      city:$('service_city').value,state:$('service_state').value,zip:$('service_zip').value});
    try{
      const r=await fetch('/api/v1/tech-funnel/slots/?'+qs,{headers:{'Accept':'application/json'},credentials:'same-origin'});
      const d=await r.json();
      if(!r.ok) throw new Error(d.error||('HTTP '+r.status));
      slots=d.slots||[]; chosenSlot=null; $('submitBtn').disabled=true;
      renderSlots();
    }catch(e){ showErr('Could not load times: '+e.message); }
    finally{ $('findBtn').textContent='Find available times'; $('findBtn').disabled=false; }
  });

  function renderSlots(){
    const box=$('slotList');
    if(!slots.length){ box.innerHTML='<div class="slots-empty">No open times found for that address in the next 10 days.</div>'; return; }
    box.innerHTML=slots.map((s,i)=>`
      <div class="slot" data-i="${i}">
        <div>
          <div class="d">${fmtDate(s.date)}</div>
          <div class="w">${s.label||''}</div>
        </div>
        <div class="t">${s.technician_name||''}</div>
      </div>`).join('');
    box.querySelectorAll('.slot').forEach(el=>el.addEventListener('click',()=>{
      box.querySelectorAll('.slot').forEach(x=>x.classList.remove('on'));
      el.classList.add('on');
      chosenSlot=slots[+el.dataset.i];
      $('submitBtn').disabled=false;
    }));
  }
  function fmtDate(iso){
    try{ return new Date(iso+'T00:00:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'}); }
    catch(e){ return iso; }
  }

  // Submit
  $('leadForm').addEventListener('submit',async e=>{
    e.preventDefault(); clearErr();
    if(!$('first_name').value.trim()||!$('last_name').value.trim()) return showErr('First and last name are required.');
    if(!$('email').value.trim()&&!$('phone').value.trim()) return showErr('Add a phone or email so we can send the sign links.');
    if(!chosenSlot) return showErr('Pick an available time.');
    const payload={
      first_name:$('first_name').value.trim(), last_name:$('last_name').value.trim(),
      company_name:$('company_name').value.trim(), customer_type:custType,
      phone:$('phone').value.trim(), email:$('email').value.trim(),
      lead_source:$('lead_source').value,
      service_address:$('service_address').value.trim(), service_city:$('service_city').value.trim(),
      service_state:$('service_state').value.trim()||'PA', service_zip:$('service_zip').value.trim(),
      job_type_id:$('job_type_id').value, slot:chosenSlot,
      cadence_template_id:$('cadence_template_id').value,
      recurring_fee:$('recurring_fee').value, initial_fee:$('initial_fee').value,
      want_cc_auth:$('want_cc_auth').checked,
    };
    $('submitBtn').textContent='Working…'; $('submitBtn').disabled=true;
    try{
      const r=await fetch('/api/v1/tech-funnel/create/',{method:'POST',credentials:'same-origin',
        headers:{'Content-Type':'application/json','X-CSRFToken':getCsrf(),'Accept':'application/json'},
        body:JSON.stringify(payload)});
      const d=await r.json();
      if(!r.ok) throw new Error(d.error||('HTTP '+r.status));
      showSuccess(d);
    }catch(e){ showErr('Could not create lead: '+e.message); $('submitBtn').textContent='Create & book'; $('submitBtn').disabled=false; }
  });

  function showSuccess(d){
    const a=d.appointment, sent=d.sent||{};
    const chans=[]; if(sent.email)chans.push('email'); if(sent.sms)chans.push('text');
    const docs=(d.contracts||[]).length;
    const sc=$('successCard');
    sc.innerHTML=`<h3>✓ ${d.customer_name||'Lead'} created</h3>`+
      (a?`<div class="line"><strong>Booked:</strong> ${a.date}, ${a.window||a.time} with ${a.technician}</div>`:'')+
      (docs?`<div class="line"><strong>Sent to sign:</strong> ${docs} document(s)${chans.length?' via '+chans.join(' + '):' — no contact on file, share the link from the office'}</div>`:'')+
      `<div class="line" style="margin-top:10px"><a href="#" id="anotherBtn">+ Add another lead</a></div>`;
    sc.style.display='block';
    $('leadForm').style.display='none';
    window.scrollTo({top:0,behavior:'smooth'});
    $('anotherBtn').addEventListener('click',ev=>{ev.preventDefault();location.reload();});
    loadRecent();
  }

  // Recent leads — show ONLY milestones actually reached (a greyed "Signed"
  // chip reads as done, so we render just the green ones; nothing = New).
  function renderRecent(leads){
    const box=$('recentList');
    if(!leads.length){ box.innerHTML='<div class="slots-empty">No leads yet — add your first above.</div>'; return; }
    box.innerHTML=leads.map(l=>{
      const done=[];
      if(l.booked) done.push('Booked');
      if(l.plan_sent) done.push('Plan sent');
      if(l.signed) done.push('Signed');
      if(l.card_on_file) done.push('Card on file');
      const chips=done.length
        ? done.map(c=>`<span class="chip on">${c}</span>`).join('')
        : '<span class="chip off">New</span>';
      return `<div class="lead-row">
        <div class="n">${l.name}</div>
        <div class="m">${l.created}${l.booked?' · '+l.appt_label:''}</div>
        <div>${chips}</div>
      </div>`;
    }).join('');
  }
  async function loadRecent(){
    try{
      const r=await fetch('/api/v1/tech-funnel/my-leads/',{headers:{'Accept':'application/json'},credentials:'same-origin'});
      const d=await r.json(); renderRecent(d.leads||[]);
    }catch(e){}
  }
  renderRecent(JSON.parse($('recentData').textContent||'[]'));
})();