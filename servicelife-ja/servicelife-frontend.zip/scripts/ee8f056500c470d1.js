(function(){
  if (window.__cbpSwipeNav) return; window.__cbpSwipeNav = true;
  function mobile(){ return window.matchMedia('(max-width: 768px)').matches; }
  function navTargets(){ return window.SL_VIEW.menuRoutes; }
  function currentIndex(hrefs){
    var path=window.SL_VIEW.route;
    var i=hrefs.indexOf(path); if(i>=0) return i;
    var best=-1, bl=-1;
    hrefs.forEach(function(h,idx){
      var hp=h.split('?')[0].replace(/\/$/,'')||'/';
      if(hp!=='/' && path.indexOf(hp)===0 && hp.length>bl){ best=idx; bl=hp.length; }
    });
    return best;
  }
  var x0=null,y0=null,t0=0;
  document.addEventListener('touchstart', function(e){
    if(!mobile()||e.touches.length!==1){ x0=null; return; }
    var t=e.target;
    if(t.closest && t.closest('input,textarea,select,[contenteditable],canvas,[data-noswipe],.cbp-noswipe,.chat-scroll,.modal,[role="dialog"]')){ x0=null; return; }
    if(document.querySelector('.sidebar.cbp-open')){ x0=null; return; } // drawer open — leave it
    var tt=e.touches[0]; x0=tt.clientX; y0=tt.clientY; t0=Date.now();
  }, {passive:true});
  document.addEventListener('touchend', function(e){
    if(x0===null) return;
    var tt=(e.changedTouches&&e.changedTouches[0]); if(!tt){ x0=null; return; }
    var dx=tt.clientX-x0, dy=tt.clientY-y0, dt=Date.now()-t0; x0=null;
    if(dt>800) return;
    if(Math.abs(dx)<70 || Math.abs(dx)<Math.abs(dy)*2) return; // clear horizontal swipe only
    var hrefs=navTargets(); if(hrefs.length<2) return;
    var i=currentIndex(hrefs);
    if(i<0) i = dx<0 ? -1 : hrefs.length; // land on an end when current page isn't a nav item
    var ni = dx<0 ? i+1 : i-1;            // swipe left = next menu, swipe right = previous
    if(ni<0 || ni>=hrefs.length) return;  // clamp, no wrap
    if(hrefs[ni]) window.SL_VIEW.go(hrefs[ni]);
  }, {passive:true});
})();