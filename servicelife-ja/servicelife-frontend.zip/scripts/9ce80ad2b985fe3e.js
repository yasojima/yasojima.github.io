(function(){
  var table = document.getElementById('alTable');
  if (!table) return;
  table.addEventListener('click', function(ev){
    var row = ev.target.closest('tr.al-row');
    if (!row) return;
    var id = row.getAttribute('data-row-id');
    var diff = document.getElementById('al-diff-' + id);
    if (!diff) return;
    var open = diff.style.display !== 'none';
    diff.style.display = open ? 'none' : 'table-row';
    row.classList.toggle('al-open', !open);
  });
})();