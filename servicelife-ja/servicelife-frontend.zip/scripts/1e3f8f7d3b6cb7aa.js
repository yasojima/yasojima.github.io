const API='/api/v1';const api=async u=>(await fetch(API+u,{credentials:'same-origin'})).json();
function fmtDate(s){return s?new Date(s).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}):'\u2014'}
async function load(){
  try{const d=await api('/scheduling/job-logs/?ordering=-created_at');const items=d.results||d;
    const tb=document.getElementById('tableBody');
    tb.innerHTML=items.length?items.map(j=>`<tr><td>${fmtDate(j.created_at)}</td><td>${j.customer_name||'\u2014'}</td><td>${j.service_type||j.title||'Service'}</td><td><span class="badge badge-${j.status==='completed'?'green':'blue'}">${(j.status||'').replace(/_/g,' ')}</span></td><td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${j.notes||'\u2014'}</td></tr>`).join(''):'<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--text-light)">No job logs yet</td></tr>'}catch(e){console.error(e)}}
document.addEventListener('DOMContentLoaded',load);