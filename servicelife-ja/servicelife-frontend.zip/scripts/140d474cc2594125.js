/* Vehicle register inside the original maintenance screen and its navigation. */
document.addEventListener("DOMContentLoaded", () => {
  const api = window.SL_VIEW.fleet;
  const root = document.getElementById("fleet");
  const find = selector => root.querySelector(selector);
  const dialog = find("#fleet-dialog"), body = find("#fleet-dialog-body"), search = find("#fleet-search");
  const esc = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const norm = value => String(value).normalize("NFKC").replace(/[\s-]/g,"").toLowerCase();
  const buckets = [
    ["all","すべての期限","total"], ["overdue","期限超過","overdue"], ["m1","1か月以内","due"],
    ["m3","1か月超〜3か月","soon"], ["m6","3か月超〜6か月","nohist"], ["done","更新完了","sched"]
  ];
  const bucketClass = {overdue:"overdue", m1:"due", m3:"soon", m6:"nohist", done:"sched", later:"ok"};
  let filter = "all", query = {}, sort = "due", direction = 1, selected = null, mode = "", saving = false;
  const cars = () => api.state.vehicles || [];
  const carByKey = key => cars().find(car => car.key === Number(key));
  function feedback(message) {
    find("#fleet-feedback").textContent = message;
    find("#fleet-feedback").hidden = !message;
  }
  function badge(term) {
    let label = "未完了";
    if (term.done) label = "更新完了";
    else if (term.bucket === "overdue") label = "期限超過";
    else if (!term.days) label = "本日期限";
    return '<span class="badge b-' + bucketClass[term.bucket] + '">' + label + '</span>';
  }
  function remaining(term) {
    if (term.done) return "完了記録あり";
    if (term.days < 0) return Math.abs(term.days) + "日超過";
    return term.days === 0 ? "今日" : "残り" + term.days + "日";
  }
  function sortValue(row) {
    if (sort === "model") return row.car.maker + " " + row.car.model;
    return row.car[sort] ?? row.term[sort];
  }
  function render() {
    const entries = cars().flatMap(car => car.terms.map(term => ({car, term})));
    const matches = entries.filter(({car,term}) => {
      const searchable = [car.id, car.plate, car.model, car.maker].some(value => norm(value).includes(norm(query.q || "")));
      return searchable && (!query.from || term.due >= query.from) && (!query.to || term.due <= query.to);
    });
    for (const [code] of buckets) {
      const button = find('[data-bucket="' + code + '"]');
      const count = code === "all" ? matches.length : matches.filter(row => row.term.bucket === code).length;
      button.querySelector(".val").innerHTML = count + "<small>件</small>";
      button.classList.toggle("active", code === filter);
      button.setAttribute("aria-pressed", String(code === filter));
    }
    const rows = matches.filter(row => filter === "all" || row.term.bucket === filter);
    rows.sort((a,b) => direction * String(sortValue(a)).localeCompare(String(sortValue(b)), "ja", {numeric:true})
      || a.car.key - b.car.key);
    for (const th of root.querySelectorAll("th:has([data-sort])")) {
      if (th.firstElementChild.dataset.sort === sort) th.setAttribute("aria-sort", direction === 1 ? "ascending" : "descending");
      else th.removeAttribute("aria-sort");
    }
    find("#fleet-result").textContent = new Set(rows.map(row => row.car.key)).size + "台・" + rows.length + "件の期限";
    find("#fleet-rows").innerHTML = rows.map(({car,term}) => `<tr>
      <td data-label="車両ID"><button class="fleet-id" type="button" data-car="${car.key}">${esc(car.id)}</button></td>
      <td data-label="メーカー・車種"><span><b>${esc(car.model)}</b><span class="fleet-secondary">${esc(car.maker)}</span></span></td>
      <td data-label="ナンバー">${esc(car.plate)}</td><td data-label="対象の期限">${esc(term.kind)}</td>
      <td data-label="開始日">${esc(term.start)}</td>
      <td data-label="期限日"><span class="${term.bucket === "overdue" ? "fleet-overdue" : ""}">${esc(term.due)}
      <small class="fleet-secondary">${remaining(term)}</small></span></td>
      <td data-label="更新状況">${badge(term)}</td></tr>`).join("");
    find("#fleet-empty").hidden = Boolean(rows.length) || Boolean(api.state.error);
    find("#fleet-register").hidden = !api.canEdit;
    find("#fleet-register").disabled = Boolean(api.state.error);
    feedback(api.state.error || "");
  }
  function openDialog(title) {
    find("#fleet-dialog-title").textContent = title;
    if (!dialog.open) dialog.showModal();
  }
  function facts(items) {
    return '<dl class="fleet-facts">' + items.map(([label, value]) =>
      '<div><dt>' + esc(label) + '</dt><dd>' + esc(value || "未記録") + '</dd></div>').join("") + '</dl>';
  }
  function details(key) {
    const car = carByKey(key);
    if (!car) { feedback("指定された車両を確認できませんでした。"); api.select(null); return; }
    selected = car.key; mode = "details"; api.select(car.key);
    body.innerHTML = facts([["車両ID", car.id], ["ナンバー", car.plate], ["メーカー", car.maker], ["車種", car.model]]) +
      car.terms.map(term => `<section class="fleet-section">
        <div class="fleet-term-title"><h3>${esc(term.kind)}</h3>${badge(term)}</div>
        ${facts([["対象期間", term.start + " ～ " + term.due], ["期限まで", remaining(term)],
          ["最終点検・更新日", term.checked], ["今回の点検・更新", term.done ? "完了" : "完了の記録なし"]])}
        <dl class="fleet-milestones">${term.milestones.map(m => "<div><dt>期限の" + m.months +
          "か月前</dt><dd>" + esc(m.date) + "</dd></div>").join("")}</dl>
        ${term.done && api.canEdit ? '<div class="fleet-dialog-actions"><button type="button" class="fleet-button" data-next="' + esc(term.id) + '">次の期限を登録</button></div>' : ""}
        ${term.bucket === "overdue" ? '<p class="fleet-note fleet-overdue">期限を過ぎています。実施済みの場合は完了を記録してください。</p>' : ""}
      </section>`).join("") +
      (api.canEdit ? '<div class="fleet-dialog-actions"><a class="fleet-button" href="/expenses/?vehicle='+car.key+'">この車両の経費</a><button type="button" class="fleet-button primary" data-edit>車両・期限を編集</button></div>' : "");
    openDialog("車両の詳細");
  }
  function input(label, name, value, type = "text", attrs = "") {
    return `<label>${label}<input type="${type}" name="${name}" value="${esc(value)}" ${attrs}></label>`;
  }
  function fieldset(term = {}) {
    return `<fieldset class="fleet-edit-term" data-term="${esc(term.id || "")}" data-last-check="${esc(term.checked || "")}"><legend>点検・更新期限</legend>
      <div class="fleet-fields">
        ${input("期限の種類","kind",term.kind,"text",'required maxlength="70" placeholder="例：定期点検、登録更新"')}
        ${input("最終点検・更新日","checked",term.checked,"date",'max="' + api.state.day + '"' + (term.done ? " required" : ""))}
        ${input("開始日","start",term.start || api.state.day,"date","required")}
        ${input("期限日","due",term.due,"date","required")}
        <label class="fleet-check"><input type="checkbox" name="done" ${term.done ? "checked" : ""}>点検・更新を完了</label>
        ${!term.id ? '<button type="button" class="fleet-button quiet" data-discard>この入力欄を取り消す</button>' : ""}
      </div></fieldset>`;
  }
  function edit(car) {
    if (!api.canEdit) return;
    mode = "edit"; selected = car?.key || null;
    body.innerHTML = `<form id="fleet-edit" data-revision="${car?.revision || 0}">
      <div class="fleet-fields">${input("メーカー","maker",car?.maker,"text",'required maxlength="70"')}
        ${input("車種","model",car?.model,"text",'required maxlength="70"')}
        ${input("ナンバー","plate",car?.plate,"text",'required maxlength="40"')}</div>
      <div id="fleet-terms">${(car?.terms || [{}]).map(fieldset).join("")}</div>
      <button type="button" class="fleet-button" data-add-term>＋ 期限を追加</button>
      <p class="fleet-note">試用データはこのブラウザに保存されます。</p>
      <p class="fleet-form-error" role="alert"></p>
      <div class="fleet-dialog-actions"><button type="button" class="fleet-button" data-cancel>キャンセル</button>
      <button type="submit" class="fleet-button primary">保存する</button></div></form>`;
    updateDiscard();
    openDialog(car ? car.id + " の車両・期限を編集" : "車両を登録");
    body.querySelector("input")?.focus();
  }
  function updateDiscard() {
    const terms = body.querySelectorAll("[data-term]");
    for (const b of body.querySelectorAll("[data-discard]")) b.hidden = terms.length === 1;
  }
  function filterSearch() {
    query = Object.fromEntries(new FormData(search));
    render();
  }
  function validateRange() {
    const {from,to} = search.elements;
    to.setCustomValidity(from.value && to.value && to.value < from.value ? "終了日は開始日以降を指定してください。" : "");
  }
  find("#fleet-counts").innerHTML = buckets.map(([key,label,cls]) =>
    `<button type="button" class="mx-kpi k-${cls}" data-bucket="${key}"><span class="val"></span><span class="lbl">${label}</span></button>`).join("");
  root.addEventListener("click", event => {
    const button = event.target.closest("button");
    if (!button || saving) return;
    if (button.type === "submit" && button.form) {
      // The demo iframe is sandboxed. Validate locally and run its local form handler.
      event.preventDefault();
      if (button.form.reportValidity()) button.form.dispatchEvent(new Event("submit",{bubbles:true,cancelable:true}));
    } else if (button.dataset.bucket) { filter = button.dataset.bucket; render(); }
    else if (button.dataset.sort) {
      direction = sort === button.dataset.sort ? -direction : 1; sort = button.dataset.sort; render();
    } else if (button.dataset.car) details(button.dataset.car);
    else if (button.id === "fleet-register") edit(null);
    else if (button.hasAttribute("data-edit")) edit(carByKey(selected));
    else if (button.hasAttribute("data-next")) {
      const car = carByKey(selected), previous = car.terms.find(term => term.id === button.dataset.next);
      edit(car);
      find("#fleet-terms").insertAdjacentHTML("beforeend", fieldset({kind:previous.kind, checked:previous.checked}));
      updateDiscard();find("#fleet-terms").lastElementChild.querySelector('[name="due"]').focus();
    }
    else if (button.matches(".fleet-close")) dialog.close();
    else if (button.hasAttribute("data-cancel")) { if (selected) details(selected); else dialog.close(); }
    else if (button.hasAttribute("data-add-term")) {
      find("#fleet-terms").insertAdjacentHTML("beforeend", fieldset());
      updateDiscard();find("#fleet-terms").lastElementChild.querySelector("input").focus();
    } else if (button.hasAttribute("data-discard")) { button.closest("fieldset").remove();updateDiscard(); }
  });
  root.addEventListener("keydown", event => {
    if (event.key !== "Enter" || event.isComposing || !event.target.matches('input[type=text],input[type=search]')) return;
    event.preventDefault(); event.target.form?.querySelector('[type="submit"]')?.click();
  });
  search.addEventListener("input", validateRange);
  search.addEventListener("submit", event => {
    event.preventDefault(); validateRange();
    if (search.reportValidity()) { filterSearch(); api.refresh().catch(error => feedback(error.message)); }
  });
  search.addEventListener("reset", event => {
    event.preventDefault();
    for (const input of search.querySelectorAll("input")) input.value = "";
    filter = "all"; validateRange();filterSearch();
  });
  body.addEventListener("change", event => {
    if (event.target.name !== "done") return;
    const group = event.target.closest("fieldset"), date = group.querySelector('[name="checked"]');
    date.required = event.target.checked;
    if (date.required && (!date.value || date.value === group.dataset.lastCheck)) date.value = api.state.day;
  });
  body.addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.target;
    if (saving || form.id !== "fleet-edit") return;
    const terms = [...form.querySelectorAll("[data-term]")].map(set => {
      const field = name => set.querySelector('[name="' + name + '"]');
      return {id:set.dataset.term,kind:field("kind").value,checked:field("checked").value,
        start:field("start").value,due:field("due").value,done:field("done").checked};
    });
    const data = new FormData(form);
    const draft = {key:selected,revision:Number(form.dataset.revision),maker:data.get("maker"),
      model:data.get("model"),plate:data.get("plate"),terms};
    saving = true; form.querySelector('[type="submit"]').disabled = true;
    try {
      const key = await api.save(draft);
      details(key);
      window.SL_VIEW.note("車両情報を保存しました。");
    } catch (error) { form.querySelector(".fleet-form-error").textContent = error.message; }
    finally { saving = false;form.querySelector('[type="submit"]').disabled = false; }
  });
  dialog.addEventListener("cancel", event => { if (saving) event.preventDefault(); });
  dialog.addEventListener("close", () => { selected = null;mode = "";api.select(null); });
  document.addEventListener("fleet-updated", () => {
    render();
    if (dialog.open && mode === "details" && selected) details(selected);
  });
  render();
  if (api.vehicle) details(api.vehicle);
}, {once:true});