const CD_ID = document.getElementById('cdRoot').dataset.customerId;
// Square Web Payments SDK creds + this customer's resolved sales-tax rate
// (customer location -> office fallback) for the Take Payment modal.
window.SQUARE_APP_ID = "";
window.SQUARE_LOCATION_ID = "";
window.SQUARE_ENV = "production";
const CD_TAX_RATE = parseFloat("0") || 0;
const CD_TAX_JURIS = "";

// BUG-012 (FE half): edit pencil + soft-delete affordances.
// Edit pencil navigates to the list page with #edit=<id>; that page's
// DOMContentLoaded handler reads the hash and auto-opens the edit modal.
// F-011: hash (not ?edit=) keeps the customer UUID out of the HTTP request
// URL and the Referer header — fragments are client-side only.
// Delete uses cbpConfirm — soft-delete (B's ca9b9aa) means the row is
// recoverable, so a single confirm is appropriate.
function cdEdit(){
  if (!CD_ID) return;
  window.location.href = '/customers/#edit=' + encodeURIComponent(CD_ID);
}
async function cdDelete(){
  if (!CD_ID) return;
  // Warn on ANY deletion.
  if (!await cbpConfirm('Delete this customer? They will be hidden from default lists. Recoverable by an admin.')) return;
  await cbpSubmit(document.getElementById('cdDeleteBtn'), async () => {
    const csrf = (document.cookie.match(/csrftoken=([^;]+)/)||[])[1] || '';
    const doDelete = (confirm) => fetch(
      '/api/v1/customers/' + CD_ID + '/' + (confirm ? '?confirm=1' : ''),
      { method: 'DELETE', credentials: 'same-origin', headers: { 'X-CSRFToken': csrf } }
    );
    try {
      let r = await doDelete(false);
      // Active-service guardrail: server returns 409 with an impact summary.
      // Warn specifically, then only proceed if the operator confirms again.
      if (r.status === 409) {
        let e = null; try { e = await r.json(); } catch (_) {}
        if (e && e.requires_confirmation) {
          if (!await cbpConfirm('⚠️ ' + (e.warning || 'This customer has active service.') + ' Delete anyway?')) return;
          r = await doDelete(true);
        }
      }
      if (!r.ok) {
        let e = null; try { e = await r.json(); } catch (_) {}
        const msg = e && (e.detail || e.warning) ? (e.detail || e.warning) : ('HTTP ' + r.status);
        if (typeof toast === 'function') toast('Could not delete: ' + msg, 'error');
        else alert('Could not delete: ' + msg);
        return;
      }
      window.location.href = '/customers/';
    } catch (e) {
      if (e && e.name === 'AbortError') throw e;
      if (typeof toast === 'function') toast('Network error — please try again', 'error');
      else alert('Network error');
    }
  });
}
const LEAD_SOURCE_LABELS = {
  referral:'Customer Referral', repeat:'Repeat Customer', google:'Google / Search',
  yelp:'Yelp', facebook:'Facebook', instagram:'Instagram', nextdoor:'Nextdoor',
  home_advisor:'HomeAdvisor', angi:'Angi', door_hanger:'Door Hanger / Flyer',
  truck_signage:'Truck Signage', direct_mail:'Direct Mail', radio:'Radio', tv:'TV',
  event:'Event / Trade Show', partner:'Partner / Property Manager',
  walk_in:'Walk-in', other:'Other'
};
const API = '/api/v1';
// Chunk 2 (prepay): expose role for UI gating; the server is still
// authoritative on writes — this just hides the editor from roles that
// shouldn't be flipping the per-customer prepay override.
const CD_USER_ROLE = "company_admin";
const PREPAY_OVERRIDE_CAN_EDIT = ['company_admin', 'billing_rep'].includes(CD_USER_ROLE);
const NOTE_CAN_EDIT = ['company_admin', 'billing_rep', 'csr'].includes(CD_USER_ROLE);
let CD_CUSTOMER_ID = null;
const PREPAY_OVERRIDE_LABELS = {
  'default': 'Use Tenant Default',
  'always':  'Always Pre-Charge',
  'never':   'Never Pre-Charge',
};
const csrf = () => (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';

async function apiFetch(path, method='GET', body=null) {
  return fetch(API + path, {
    method, credentials:'same-origin',
    headers:{'X-CSRFToken':csrf(),'Content-Type':'application/json'},
    body: body ? JSON.stringify(body) : null
  });
}
async function apiJson(path, method='GET', body=null) {
  const r = await apiFetch(path, method, body);
  if (!r.ok) throw new Error(`${r.status}`);
  return r.json();
}
function toast(msg, kind='success') {
  const e = document.getElementById('cdToast');
  e.textContent = msg;
  e.className = 'toast ' + kind + ' show';
  setTimeout(() => { e.className = 'toast ' + kind; }, 2800);
}
function fmtDate(s) {
  if (!s) return '--';
  const d = new Date(s);
  const tz = window._tenantTz || 'America/New_York';
  return d.toLocaleDateString('en-US', { timeZone:tz, year:'numeric', month:'short', day:'numeric' });
}
function fmtDateTime(s) {
  if (!s) return '--';
  const d = new Date(s);
  const tz = window._tenantTz || 'America/New_York';
  return d.toLocaleDateString('en-US', { timeZone:tz, month:'short', day:'numeric', year:'numeric' }) + ' ' +
         d.toLocaleTimeString('en-US', { timeZone:tz, hour:'numeric', minute:'2-digit' });
}
function fmtMoney(n) {
  if (n === null || n === undefined || n === '') return '--';
  const num = parseFloat(n);
  if (isNaN(num)) return '--';
  return '$' + num.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}
function escHtml(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// ===== Tabs =====
const cdLoadedPanes = new Set(['overview']);
function cdSwitchTab(name) {
  document.querySelectorAll('.cd-tab').forEach(t => t.classList.toggle('active', t.dataset.pane === name));
  document.querySelectorAll('.cd-pane').forEach(p => p.classList.remove('active'));
  document.getElementById('pane' + name.charAt(0).toUpperCase() + name.slice(1)).classList.add('active');
  if (!cdLoadedPanes.has(name)) {
    cdLoadedPanes.add(name);
    if (name === 'timeline') loadTimeline();
    if (name === 'appointments') loadAppointments();
    if (name === 'comms') loadComms();
    if (name === 'invoices') loadInvoices();
    if (name === 'payments') loadPayments();
    if (name === 'tickets') loadTickets();
    if (name === 'preferences') loadPreferences();
    if (name === 'billing') loadBillingCard();
    if (name === 'documents') loadDocuments();
  }
}

// ===== Payments (Square) — read-only history =====
async function loadPayments() {
  const pane = document.getElementById('panePayments');
  if (!pane) return;
  try {
    const data = await apiJson(`/customers/${CD_ID}/square-payments/`);
    const pmts = data.payments || [];
    const s = data.summary || {};
    const cntEl = document.getElementById('cntPay');
    if (cntEl) cntEl.textContent = s.count || 0;
    if (!pmts.length) {
      pane.innerHTML = '<div style="padding:24px 16px;text-align:center;color:var(--text-light);font-size:13.5px;background:#fafafa;border:1px dashed var(--border);border-radius:6px">No Square payments on file for this customer.</div>';
      return;
    }
    const money = n => '$' + Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
    const fmtDate = iso => { if(!iso) return '--'; const d=new Date(iso); return isNaN(d)?'--':d.toLocaleDateString('en-US',{year:'numeric',month:'short',day:'numeric'}); };
    const badge = st => {
      const u=(st||'').toUpperCase();
      const color = u==='COMPLETED' ? '#1b7f4d' : (u==='FAILED'||u==='CANCELED') ? '#c62828' : '#8a6d00';
      const bg    = u==='COMPLETED' ? '#e6f4ec' : (u==='FAILED'||u==='CANCELED') ? '#fbe9e7' : '#fff6e0';
      return `<span class="badge" style="color:${color};background:${bg}">${escHtml(u||'--')}</span>`;
    };
    const totalRefunded = Math.max(0, (s.completed_total||0) - (s.completed_net_total||0));
    const head = `<div style="display:flex;gap:18px;flex-wrap:wrap;margin:2px 0 14px;font-size:13px;color:var(--text-light)">`
      + `<span><strong style="color:var(--text)">${s.completed_count||0}</strong> completed</span>`
      + `<span><strong style="color:var(--text)">${money(s.completed_total)}</strong> collected</span>`
      + (totalRefunded>0 ? `<span style="color:#c62828"><strong style="color:#c62828">${money(totalRefunded)}</strong> refunded</span>`
          + `<span><strong style="color:var(--text)">${money(s.completed_net_total)}</strong> net</span>` : '')
      + `<span>last payment <strong style="color:var(--text)">${fmtDate(s.last_payment_date)}</strong></span></div>`;
    const rows = pmts.map(p => {
      const card = p.card_brand ? `${escHtml(p.card_brand)} &bull;&bull;${escHtml(p.last4||'')}` : escHtml(p.source||'--');
      const rcpt = p.receipt_url ? `<a href="${escHtml(p.receipt_url)}" target="_blank" rel="noopener" title="View Square receipt"><i class="fas fa-receipt"></i></a>` : '';
      const amtCell = (p.refunded>0)
        ? `<td style="font-weight:600">${money(p.amount)}`
            + `<div style="font-size:11px;color:#c62828;font-weight:600">&minus;${money(p.refunded)} refunded</div>`
            + `<div style="font-size:11px;color:var(--text-light);font-weight:400">net ${money(p.amount-p.refunded)}</div></td>`
        : `<td style="font-weight:600">${money(p.amount)}</td>`;
      const refBadge = (p.refunded>0)
        ? ` <span class="badge" style="color:#c62828;background:#fbe9e7">${(p.refunded>=p.amount)?'REFUNDED':'PARTIAL REFUND'}</span>`
        : '';
      return `<tr><td>${fmtDate(p.date)}</td>${amtCell}<td>${badge(p.status)}${refBadge}</td><td>${card}</td><td style="color:var(--text-light)">${escHtml(p.location||'')}</td><td style="text-align:center">${rcpt}</td></tr>`;
    }).join('');
    pane.innerHTML = head + `<table class="cd-table"><thead><tr><th>Date</th><th>Amount</th><th>Status</th><th>Card</th><th>Location</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
  } catch (e) {
    const msg = (e && e.message) || '';
    if (/403/.test(msg)) {
      const tab = document.querySelector('.cd-tab[data-pane="payments"]');
      if (tab) tab.style.display = 'none';
      pane.innerHTML = '';
      return;
    }
    pane.innerHTML = '<div style="color:#c62828;padding:14px">Could not load payments: ' + escHtml(msg||'error') + '</div>';
  }
}

let CUSTOMER = null;

async function loadCustomer() {
  try {
    const c = await apiJson(`/customers/${CD_ID}/`);
    CUSTOMER = c;
    renderHeader(c);
    renderOverview(c);
  } catch (e) {
    document.getElementById('cdName').textContent = 'Customer not found';
    document.getElementById('cdMeta').innerHTML = '<span style="color:#c62828">' + escHtml(e.message) + '</span>';
  }
}

function renderHeader(c) {
  const fn = (c.first_name || '').trim();
  const ln = (c.last_name || '').trim();
  const initials = ((fn[0] || '') + (ln[0] || '')).toUpperCase() || '?';
  document.getElementById('cdAvatar').textContent = initials;
  const displayName = c.display_name || `${fn} ${ln}`.trim() || c.company_name || 'Unnamed';
  document.getElementById('cdName').textContent = displayName;
  const meta = [];
  if (c.phone) meta.push(`<span><i class="fas fa-phone" style="font-size:10px"></i> <a href="tel:${escHtml(c.phone)}">${escHtml(c.phone)}</a></span>`);
  if (c.email) meta.push(`<span><i class="fas fa-envelope" style="font-size:10px"></i> <a href="mailto:${escHtml(c.email)}">${escHtml(c.email)}</a></span>`);
  if (c.full_service_address) meta.push(`<span><i class="fas fa-map-marker-alt" style="font-size:10px"></i> ${escHtml(c.full_service_address)}</span>`);
  if (c.customer_type) meta.push(`<span style="text-transform:capitalize"><i class="fas fa-user-tag" style="font-size:10px"></i> ${escHtml(c.customer_type)}</span>`);
  document.getElementById('cdMeta').innerHTML = meta.join('');
  const flags = [];
  if (c.is_prospect) flags.push('<span class="cd-flag flag-info">PROSPECT</span>');
  if (c.has_kids_pets) flags.push('<span class="cd-flag flag-warn">Kids / Pets</span>');
  if (c.sms_opted_out) flags.push('<span class="cd-flag flag-mute">SMS opted out</span>');
  if (c.do_not_call) flags.push('<span class="cd-flag flag-bad">DO NOT CALL</span>');
  if (c.do_not_email) flags.push('<span class="cd-flag flag-bad">DO NOT EMAIL</span>');
  if (c.exempt_from_auto_booking) flags.push('<span class="cd-flag flag-mute">no auto-book</span>');
  if (c.tax_exempt) flags.push('<span class="cd-flag flag-info">TAX EXEMPT</span>');
  document.getElementById('cdFlags').innerHTML = flags.join('');
  document.getElementById('cdActions').style.display = '';
}

function ovRow(label, val) {
  const empty = !val || val === '--';
  return `<div class="ov-row"><div class="ov-lbl">${escHtml(label)}</div><div class="ov-val${empty?' empty':''}">${empty ? '--' : val}</div></div>`;
}

// === Pre-Charge override (chunk 2 of prepay-admin-ui) ===========================
//
// 'default' is the typical state — defer to tenant.prepay_enabled.
// 'always' force-opts-in (still requires card on file + price + residential).
// 'never' opts out regardless of tenant setting. Read-only for non-billing roles.
// Pre-charge status badge (handoff 16.8 chunk 3). Same visual contract as
// appointments.html. 'not_due' renders empty so the appointment row stays
// uncluttered when prepay isn't enabled or hasn't fired yet.
function prechargeBadge(s){
  if (!s || s === 'not_due') return '';
  const cfg = {
    skipped:        {bg:'#eceff1', fg:'#546e7a', icon:'fa-minus-circle',  label:'Pre-charge skipped'},
    succeeded:      {bg:'#e8f5e9', fg:'#2e7d32', icon:'fa-check-circle',  label:'Pre-charged'},
    failed:         {bg:'#ffebee', fg:'#c62828', icon:'fa-exclamation-triangle', label:'Pre-charge failed'},
    auto_cancelled: {bg:'#fce4ec', fg:'#ad1457', icon:'fa-ban',           label:'Auto-cancelled (pre-charge failed)'},
  }[s];
  if (!cfg) return '';
  return `<span title="${cfg.label}" style="display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:10px;background:${cfg.bg};color:${cfg.fg};font-size:10.5px;font-weight:600;margin-left:4px"><i class="fas ${cfg.icon}"></i>${cfg.label.replace('Pre-charge ','').replace('Pre-charged','Charged')}</span>`;
}

function renderPrepayOverride(c) {
  const cur = c.prepay_override || 'default';
  if (!PREPAY_OVERRIDE_CAN_EDIT) {
    // Badge only — no editor for csr/sales_rep/accountant/etc.
    const badge = cur === 'always' ? 'flag-good' :
                  cur === 'never'  ? 'flag-bad'  : 'flag-mute';
    return `<span class="cd-flag ${badge}">${escHtml(PREPAY_OVERRIDE_LABELS[cur] || cur)}</span>`;
  }
  // Editable <select>. The change handler is wired after innerHTML write
  // (see renderOverview).
  const opts = ['default','always','never'].map(v =>
    `<option value="${v}"${v===cur?' selected':''}>${escHtml(PREPAY_OVERRIDE_LABELS[v])}</option>`
  ).join('');
  return `<select id="cdPrepayOverride" data-prev="${cur}" style="font-size:12.5px;padding:3px 6px;border:1px solid var(--border);border-radius:4px;background:#fff">${opts}</select>`;
}

async function cdSavePrepayOverride(ev) {
  const sel = ev.target;
  const newVal = sel.value;
  const original = sel.dataset.prev || 'default';
  // Confirm 'never' since it permanently exempts the customer until manually changed.
  if (newVal === 'never' && original !== 'never') {
    if (!confirm('Setting this customer to "Never Pre-Charge" will exempt them from automatic billing for ALL future appointments until you change it back. Proceed?')) {
      sel.value = original;
      return;
    }
  }
  sel.disabled = true;
  try {
    const r = await apiFetch(`/customers/${CD_ID}/`, 'PATCH', {prepay_override: newVal});
    if (!r.ok) {
      const err = await r.json().catch(() => ({}));
      throw new Error(err.detail || err.error || ('Save failed (' + r.status + ')'));
    }
    sel.dataset.prev = newVal;
    toast('Pre-Charge setting saved', 'success');
  } catch (e) {
    sel.value = original;
    toast(e.message || 'Save failed', 'error');
  } finally {
    sel.disabled = false;
  }
}

function renderOverview(c) {
  const contact = [];
  contact.push(ovRow('Name', escHtml(`${c.first_name || ''} ${c.last_name || ''}`.trim() || c.display_name || '--')));
  contact.push(ovRow('Company', escHtml(c.company_name || '--')));
  contact.push(ovRow('Phone', c.phone ? `<a href="tel:${escHtml(c.phone)}">${escHtml(c.phone)}</a>` : '--'));
  contact.push(ovRow('Email', c.email ? `<a href="mailto:${escHtml(c.email)}">${escHtml(c.email)}</a>` : '--'));
  contact.push(ovRow('Customer type', escHtml(c.customer_type || '--')));
  // Slice P2: surface the rollup ParentAccount as a hyperlink. Empty when
  // the customer isn't linked to a property-management parent.
  if (c.parent_account_id && c.parent_account_name) {
    contact.push(ovRow(
      'Parent account',
      `<a href="/parent-accounts/${escHtml(c.parent_account_id)}/">${escHtml(c.parent_account_name)}</a>`,
    ));
  }
  contact.push(ovRow('Created', fmtDate(c.created_at)));
  const lsLabel = c.lead_source ? (LEAD_SOURCE_LABELS[c.lead_source] || c.lead_source) : '';
  const lsDisplay = lsLabel + (c.lead_source_detail ? ' <span style="color:var(--text-light)">(' + escHtml(c.lead_source_detail) + ')</span>' : '');
  contact.push(ovRow('Lead source', lsDisplay));
  document.getElementById('ovContact').innerHTML = contact.join('');
  document.getElementById('ovService').innerHTML = ovRow('Address', escHtml(c.full_service_address || c.full_address || '--'));
  const billing = [];
  billing.push(ovRow('Billing address', escHtml(c.full_billing_address || '-- (same as service)')));
  billing.push(ovRow('Billing contact', escHtml(c.billing_contact_name || '--')));
  billing.push(ovRow('Pre-Charge', renderPrepayOverride(c)));
  document.getElementById('ovBilling').innerHTML = billing.join('');
  // Wire the change handler AFTER innerHTML is set; the <select> doesn't
  // exist before this point.
  const sel = document.getElementById('cdPrepayOverride');
  if (sel) sel.addEventListener('change', cdSavePrepayOverride);
  renderCustomerNote(c);
}

function cdFmtNoteTime(iso){ try{ return new Date(iso).toLocaleString([], {month:'short',day:'numeric',year:'numeric',hour:'2-digit',minute:'2-digit'}); }catch(e){ return ''; } }
function cdNoteMeta(by, at){
  if(!by && !at) return '';
  return 'Edited' + (by ? ' by ' + by : '') + (at ? ' \u00b7 ' + cdFmtNoteTime(at) : '');
}
function renderCustomerNote(c){
  CD_CUSTOMER_ID = c.id;
  const cur = c.notes || '';
  document.getElementById('ovNotes').textContent = cur || '--';
  document.getElementById('ovNotesMeta').textContent = cdNoteMeta(c.rep_notes_updated_by_name, c.rep_notes_updated_at);
  const eb = document.getElementById('ovNotesEdit');
  if (eb) eb.style.display = NOTE_CAN_EDIT ? '' : 'none';
}
function cdEditNote(){
  const cur = document.getElementById('ovNotes').textContent;
  document.getElementById('ovNotesInput').value = (cur === '--' ? '' : cur);
  document.getElementById('ovNotesEditor').style.display = '';
  document.getElementById('ovNotesEdit').style.display = 'none';
  document.getElementById('ovNotesInput').focus();
}
function cdCancelNote(){
  document.getElementById('ovNotesEditor').style.display = 'none';
  document.getElementById('ovNotesEdit').style.display = NOTE_CAN_EDIT ? '' : 'none';
  document.getElementById('ovNotesStatus').textContent = '';
}
function cdSaveNote(){
  const val = document.getElementById('ovNotesInput').value;
  const st = document.getElementById('ovNotesStatus');
  st.textContent = 'Saving...';
  fetch('/notes/update/', {
    method:'POST',
    headers:{'X-CSRFToken':csrf(),'Content-Type':'application/json'},
    body: JSON.stringify({target:'customer', id: CD_CUSTOMER_ID, rep_notes: val})
  }).then(function(r){ return r.json().catch(function(){ return {}; }); }).then(function(d){
    if (d && d.ok){
      const f = (d.fields && d.fields.rep_notes) || null;
      document.getElementById('ovNotes').textContent = (f ? f.text : val) || '--';
      if (f && f.meta){ document.getElementById('ovNotesMeta').textContent = cdNoteMeta(f.meta.by, f.meta.at); }
      cdCancelNote();
    } else {
      st.textContent = (d && d.error) ? ('Error: ' + d.error) : 'Save failed';
    }
  }).catch(function(){ st.textContent = 'Save failed'; });
}

// ===== Timeline =====
// SMS6: intent chip CSS class table. Mirrors the inbox renderIntentChip() so
// the timeline renders identical chips for inbound SMS classifier output.
const _CD_INTENT_CHIP_CLASSES = {
  confirm: 'intent-chip-confirm',
  reschedule: 'intent-chip-reschedule',
  cancel: 'intent-chip-cancel',
  complaint: 'intent-chip-complaint',
  payment: 'intent-chip-payment',
  question: 'intent-chip-question',
  stop: 'intent-chip-other',
  other: 'intent-chip-other',
};
function _cdRenderIntentChip(ev) {
  // Override badge when an intent_override_to is present.
  if (ev.intent_override_to) {
    const ovrCls = _CD_INTENT_CHIP_CLASSES[ev.intent_override_to] || 'intent-chip-other';
    const origCls = _CD_INTENT_CHIP_CLASSES[ev.intent || 'other'] || 'intent-chip-other';
    let tip = 'Overridden';
    if (ev.intent_overridden_by_name) tip += ' by ' + ev.intent_overridden_by_name;
    if (ev.intent_overridden_at) tip += ' on ' + (new Date(ev.intent_overridden_at)).toLocaleString();
    if (ev.intent_override_reason) tip += ': ' + ev.intent_override_reason;
    return (
      ` <span class="intent-chip-override" title="${escHtml(tip)}">` +
      `<span class="intent-chip ${ovrCls}">${escHtml(ev.intent_override_to)}</span>` +
      (ev.intent ? `<span class="intent-chip ${origCls} intent-chip-original">${escHtml(ev.intent)}</span>` : '') +
      `</span>`
    );
  }
  if (!ev.intent) return '';
  const cls = _CD_INTENT_CHIP_CLASSES[ev.intent] || 'intent-chip-other';
  let title = 'Classifier intent: ' + ev.intent;
  if (typeof ev.intent_confidence === 'number') {
    title += ' (confidence ' + Math.round(ev.intent_confidence * 100) + '%)';
  }
  if (ev.intent_rationale) title += ' — ' + ev.intent_rationale;
  return ` <span class="intent-chip ${cls}" title="${escHtml(title)}">${escHtml(ev.intent)}</span>`;
}

// F-008: Timeline pagination. Default fetches 100; "Load more" bumps the
// limit to 500. The badge keeps showing the absolute total from /counts/
// (set by loadTabCounts), so the operator can see how much is hidden.
let _tlLimit = 100;
async function loadTimeline() {
  const pane = document.getElementById('paneTimeline');
  try {
    const data = await apiJson(`/customers/${CD_ID}/timeline/?limit=${_tlLimit}`);
    const events = data.events || data || [];
    if (!events.length) {
      pane.innerHTML = '<div class="cd-empty">No activity yet for this customer.</div>';
      return;
    }
    const html = ['<ul class="tl-list">'];
    for (const ev of events) {
      // SMS6: classified-inbound rows carry intent fields → render chip beside the title.
      const intentChip = (ev.type === 'sms_classified' || ev.intent || ev.intent_override_to)
        ? _cdRenderIntentChip(ev) : '';
      // Treat sms_classified rows visually like message rows (envelope/sms icon).
      const iconClass = ev.type === 'sms_classified' ? 'message' : escHtml(ev.type);
      html.push(`<li class="tl-item">
        <div class="tl-icon ${iconClass}"><i class="fas ${escHtml(ev.icon || 'fa-circle')}"></i></div>
        <div class="tl-body">
          <div class="tl-row1">
            <div class="tl-title">${escHtml(ev.title || '')}${intentChip}</div>
            <div class="tl-date">${fmtDateTime(ev.date)}</div>
          </div>
          ${ev.detail ? `<div class="tl-detail">${escHtml(ev.detail)}</div>` : ''}
        </div>
      </li>`);
    }
    html.push('</ul>');
    // Footer: "Showing N of T" + Load more if there's more to fetch.
    const badge = document.getElementById('cntTimeline');
    const total = badge ? parseInt(badge.textContent, 10) : NaN;
    const shown = events.length;
    const moreOnServer = !!data.has_more || (Number.isFinite(total) && total > shown);
    if (moreOnServer && _tlLimit < 500) {
      html.push(`<div style="text-align:center;margin-top:14px;padding-top:10px;border-top:1px solid #f1f1f1">
        <div style="font-size:12px;color:var(--text-light);margin-bottom:6px">Showing ${shown}${Number.isFinite(total) ? ' of '+total : ''}</div>
        <button type="button" class="cd-act" onclick="cdLoadMoreTimeline()"><i class="fas fa-chevron-down"></i> Load more</button>
      </div>`);
    } else if (Number.isFinite(total) && total > shown) {
      html.push(`<div style="text-align:center;margin-top:14px;padding-top:10px;border-top:1px solid #f1f1f1;font-size:12px;color:var(--text-light)">
        Showing ${shown} of ${total} (older events truncated)
      </div>`);
    }
    pane.innerHTML = html.join('');
  } catch (e) {
    pane.innerHTML = '<div class="cd-empty">Could not load timeline.</div>';
  }
}
function cdLoadMoreTimeline() {
  _tlLimit = 500;
  loadTimeline();
}

// ===== Appointments =====
async function loadAppointments() {
  const pane = document.getElementById('paneAppointments');
  try {
    const data = await apiJson(`/scheduling/appointments/?customer=${CD_ID}&page_size=200`);
    const items = data.results || data || [];
    // Use the DRF paginator's total count so the badge matches reality even
    // when there are more appointments than the page_size (F-018).
    document.getElementById('cntAppt').textContent = data.count !== undefined ? data.count : items.length;
    if (!items.length) {
      pane.innerHTML = '<div class="cd-empty">No appointments yet.<br><br><button type="button" class="cd-act primary" onclick="openBookAppt()"><i class="fas fa-calendar-plus"></i> Book first appointment</button></div>';
      return;
    }
    const STATUS_BADGE = {scheduled:'b-blue', confirmed:'b-green', in_progress:'b-orange', completed:'b-gray', cancelled:'b-red', no_show:'b-red'};
    const rows = items.map(a => {
      const stCls = STATUS_BADGE[a.status] || 'b-gray';
      const dt = fmtDateTime(a.start_datetime);
      const dur = a.duration_minutes ? a.duration_minutes + 'm' : '--';
      const tech = a.technician_name || a.assigned_technician_name || '--';
      const jt = a.job_type_name || a.title || 'Appointment';
      const _canSend = (a.status === 'completed') && ['company_admin','csr'].includes(CD_USER_ROLE);
      const _actCell = _canSend ? `<button type="button" class="cd-act" onclick="sendTreatmentReport('${a.id}', this)" title="Email + text the treatment report to the customer"><i class="fas fa-file-medical"></i> Send report</button>` : '';
      return `<tr><td>${escHtml(dt)}</td><td>${escHtml(jt)}</td><td>${escHtml(tech)}</td><td>${escHtml(dur)}</td><td><span class="badge ${stCls}">${escHtml((a.status||'').replace(/_/g,' '))}</span>${prechargeBadge(a.precharge_status)}</td><td>${_actCell}</td></tr>`;
    }).join('');
    pane.innerHTML = `<table class="cd-table"><thead><tr><th>When</th><th>Type</th><th>Technician</th><th>Duration</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
  } catch (e) {
    pane.innerHTML = '<div class="cd-empty">Could not load appointments.</div>';
  }
}

async function sendTreatmentReport(apptId, btn) {
  if (!confirm('Send the treatment report to this customer now (email + SMS)?')) return;
  const orig = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
  try {
    const jlR = await apiFetch(`/scheduling/job-logs/?appointment=${apptId}`);
    const jlD = jlR && jlR.ok ? await jlR.json() : null;
    const jl = jlD && (jlD.results || jlD || [])[0];
    if (!jl) { toast('No job log / report exists for this visit.'); btn.disabled = false; btn.innerHTML = orig; return; }
    const r = await apiFetch(`/scheduling/job-logs/${jl.id}/deliver-treatment-report/`, 'POST', {});
    const d = r ? await r.json().catch(() => ({})) : {};
    if (r && r.ok) {
      const via = d.sent_via || [];
      if (via.length) { toast('Treatment report sent via ' + via.join(' + ')); }
      else if ((d.skipped || []).length) { toast('Not sent (' + d.skipped.join(', ') + ')'); }
      else { toast('No email or phone on file for this customer.'); }
      btn.innerHTML = '<i class="fas fa-check"></i> Sent';
    } else {
      toast((d && (d.detail || d.error)) || 'Send failed.'); btn.disabled = false; btn.innerHTML = orig;
    }
  } catch (e) { toast('Network error.'); btn.disabled = false; btn.innerHTML = orig; }
}

// ===== Communications =====
// F-009: Pull a generous page (200 each) and surface the per-source DRF count
// so the badge + footer reflect reality. Earlier hardcoded page_size=30
// silently truncated to 60 even when the badge said 79.
let _commsPageSize = 200;
async function loadComms() {
  const pane = document.getElementById('paneComms');
  try {
    const [callsResp, msgsResp] = await Promise.all([
      apiFetch(`/communications/call-logs/?customer=${CD_ID}&page_size=${_commsPageSize}`),
      apiFetch(`/communications/messages/?customer=${CD_ID}&page_size=${_commsPageSize}`).catch(() => ({ ok:false }))
    ]);
    let calls = [], callsTotal = 0;
    if (callsResp && callsResp.ok) {
      const d = await callsResp.json();
      calls = d.results || d || [];
      callsTotal = (typeof d.count === 'number') ? d.count : calls.length;
    }
    let msgs = [], msgsTotal = 0;
    if (msgsResp && msgsResp.ok) {
      const d = await msgsResp.json();
      msgs = d.results || d || [];
      msgsTotal = (typeof d.count === 'number') ? d.count : msgs.length;
    }
    const merged = [];
    for (const c of calls) merged.push({
      _date: c.call_datetime || c.called_at,
      title: `${(c.direction||'').toUpperCase()} call -- ${(c.outcome||'').replace(/_/g,' ')}`,
      detail: (c.duration_seconds ? Math.round(c.duration_seconds/60)+'m -- ' : '') + (c.notes || ''),
      icon: 'fa-phone'
    });
    for (const m of msgs) merged.push({
      _date: m.created_at || m.sent_at,
      title: `${(m.direction||'').toUpperCase()} ${m.channel === 'email' ? 'EMAIL' : 'SMS'}${m.subject ? ': '+m.subject : ''}`,
      detail: (m.body || '').slice(0, 200),
      icon: m.channel === 'email' ? 'fa-envelope' : 'fa-sms'
    });
    merged.sort((a,b) => new Date(b._date) - new Date(a._date));
    // Badge now reflects calls + messages totals (matches what the tab actually
    // displays). Previously /counts/.communications was just the message count.
    const totalBoth = callsTotal + msgsTotal;
    document.getElementById('cntComm').textContent = totalBoth || merged.length;
    if (!merged.length) {
      pane.innerHTML = '<div class="cd-empty">No calls, SMS, or email logged for this customer.</div>';
      return;
    }
    const rows = merged.map(x => `<tr><td style="white-space:nowrap"><i class="fas ${x.icon}" style="margin-right:5px;color:var(--text-light)"></i>${fmtDateTime(x._date)}</td><td>${escHtml(x.title)}</td><td>${escHtml(x.detail || '')}</td></tr>`).join('');
    let footer = '';
    const shown = merged.length;
    if (totalBoth > shown) {
      if (_commsPageSize < 1000) {
        footer = `<div style="text-align:center;margin-top:14px;padding-top:10px;border-top:1px solid #f1f1f1">
          <div style="font-size:12px;color:var(--text-light);margin-bottom:6px">Showing ${shown} of ${totalBoth}</div>
          <button type="button" class="cd-act" onclick="cdLoadMoreComms()"><i class="fas fa-chevron-down"></i> Load more</button>
        </div>`;
      } else {
        footer = `<div style="text-align:center;margin-top:14px;padding-top:10px;border-top:1px solid #f1f1f1;font-size:12px;color:var(--text-light)">
          Showing ${shown} of ${totalBoth} (older communications truncated)
        </div>`;
      }
    }
    pane.innerHTML = `<table class="cd-table"><thead><tr><th>When</th><th>Type</th><th>Detail</th></tr></thead><tbody>${rows}</tbody></table>${footer}`;
  } catch (e) {
    pane.innerHTML = '<div class="cd-empty">Could not load communications.</div>';
  }
}
function cdLoadMoreComms() {
  _commsPageSize = 1000;
  loadComms();
}

// ===== Invoices =====
async function loadInvoices() {
  const pane = document.getElementById('paneInvoices');
  try {
    const data = await apiJson(`/billing/invoices/?customer=${CD_ID}&page_size=50`);
    const items = data.results || data || [];
    document.getElementById('cntInv').textContent = items.length;
    if (!items.length) {
      pane.innerHTML = '<div class="cd-empty">No invoices yet.</div>';
      return;
    }
    const ST = {paid:'b-green', sent:'b-blue', draft:'b-gray', overdue:'b-red', void:'b-gray', partial:'b-orange'};
    const rows = items.map(i => {
      const stCls = ST[i.status] || 'b-gray';
      return `<tr><td>${escHtml(i.invoice_number || i.id)}</td><td>${fmtDate(i.issue_date || i.created_at)}</td><td>${fmtMoney(i.total)}</td><td>${fmtMoney(i.balance_due)}</td><td><span class="badge ${stCls}">${escHtml((i.status||'').replace(/_/g,' '))}</span></td><td>${(parseFloat(i.balance_due) > 0) ? `<button type="button" class="cd-act" onclick="openTakePay('${i.id}', '${i.balance_due}')" style="padding:4px 9px;font-size:11.5px"><i class="fas fa-dollar-sign"></i> Pay</button>` : ''}</td></tr>`;
    }).join('');
    pane.innerHTML = `<table class="cd-table"><thead><tr><th>Invoice #</th><th>Date</th><th>Total</th><th>Balance</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
  } catch (e) {
    pane.innerHTML = '<div class="cd-empty">Could not load invoices (CSR may not have access).</div>';
  }
}

// ===== Tickets =====
async function loadTickets() {
  const pane = document.getElementById('paneTickets');
  try {
    const data = await apiJson(`/tickets/tickets/?customer=${CD_ID}&page_size=50`);
    const items = data.results || data || [];
    document.getElementById('cntTkt').textContent = items.length;
    if (!items.length) {
      pane.innerHTML = '<div class="cd-empty">No tickets yet.<br><br><button type="button" class="cd-act" onclick="openNewTicket()"><i class="fas fa-ticket-alt"></i> Open ticket</button></div>';
      return;
    }
    const ST = {open:'b-blue', in_progress:'b-orange', pending:'b-gray', resolved:'b-green', closed:'b-gray', escalated:'b-red'};
    const PR = {urgent:'b-red', high:'b-orange', medium:'b-blue', low:'b-gray'};
    const rows = items.map(t => `<tr><td>#${escHtml(t.ticket_number || t.id)}</td><td>${escHtml(t.subject)}</td><td>${escHtml((t.category||'').replace(/_/g,' '))}</td><td><span class="badge ${PR[t.priority]||'b-gray'}">${escHtml(t.priority||'')}</span></td><td><span class="badge ${ST[t.status]||'b-gray'}">${escHtml((t.status||'').replace(/_/g,' '))}</span></td><td>${fmtDate(t.created_at)}</td></tr>`).join('');
    pane.innerHTML = `<table class="cd-table"><thead><tr><th>#</th><th>Subject</th><th>Category</th><th>Priority</th><th>Status</th><th>Opened</th></tr></thead><tbody>${rows}</tbody></table>`;
  } catch (e) {
    pane.innerHTML = '<div class="cd-empty">Could not load tickets.</div>';
  }
}

// ===== Preferences =====
// F-PREFS-2: read/edit CustomerPreference (preferred day/time windows + techs).
// Edit is gated to company_admin on both server and client; CSR sees read-only.
const PREF_CAN_EDIT = ['company_admin', 'developer', 'csr'].includes(CD_USER_ROLE);
// F-PREFS-3: 'Send link' is broader — csr, technician, billing_rep, plus the
// existing admin roles. Mirrors _SEND_LINK_ROLES on the server.
const PREF_CAN_SEND_LINK = ['company_admin', 'csr', 'technician',
    'billing_rep', 'tech_manager', 'senior_tech', 'developer'].includes(CD_USER_ROLE);
const DAY_ORDER = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday'];

let _prefData = null;       // last-fetched preference from server
let _adtData = null;        // AppointmentDayTime vocabulary (fetched once)
let _techsData = null;      // active technicians list (fetched once)

async function loadPreferences() {
  const pane = document.getElementById('panePreferences');
  try {
    const d = await apiJson(`/customers/${CD_ID}/preference/`);
    _prefData = d.preference;
    renderPreferencePane(_prefData);
  } catch (e) {
    pane.innerHTML = '<div class="cd-empty">Could not load preferences.</div>';
  }
}

function renderPreferencePane(pref) {
  const pane = document.getElementById('panePreferences');
  if (!pref) {
    const buttonsHtml = `
      <div style="margin-top:12px;text-align:center;display:flex;gap:8px;justify-content:center;flex-wrap:wrap">
        ${PREF_CAN_EDIT ? `<button type="button" class="cd-act primary" onclick="openPrefModal()"><i class="fas fa-plus"></i> Set Preferences</button>` : ''}
        ${PREF_CAN_SEND_LINK ? `<button type="button" class="cd-act" onclick="openSendPrefLinkModal()"><i class="fas fa-paper-plane"></i> Send Preference Link</button>` : ''}
      </div>`;
    pane.innerHTML = `<div class="cd-empty">No scheduling preferences recorded yet.</div>` + buttonsHtml;
    return;
  }

  // Group times by day for display
  const byDay = {};
  for (const t of (pref.preferred_times || [])) {
    if (!byDay[t.day]) byDay[t.day] = [];
    byDay[t.day].push(t.time_range);
  }
  const dayRows = DAY_ORDER
    .filter(d => byDay[d])
    .map(d => `<div class="ov-row"><div class="ov-lbl" style="text-transform:capitalize">${escHtml(d)}</div><div class="ov-val">${byDay[d].map(escHtml).join(', ')}</div></div>`)
    .join('');

  const techRows = (pref.preferred_technicians || [])
    .map(t => `<span class="cd-flag flag-info"><i class="fas fa-user-hard-hat" style="margin-right:4px;font-size:9px"></i>${escHtml(t.name)}</span>`)
    .join(' ') || '<span class="ov-val empty">Any technician</span>';

  const statusBadge = pref.status === 'completed'
    ? '<span class="cd-flag flag-good">Confirmed</span>'
    : '<span class="cd-flag flag-mute">Pending</span>';

  const editBtn = PREF_CAN_EDIT
    ? `<button type="button" class="cd-act" style="margin-top:14px;margin-right:8px" onclick="openPrefModal()"><i class="fas fa-pen"></i> Edit Preferences</button>`
    : '';
  const sendLinkBtn = PREF_CAN_SEND_LINK
    ? `<button type="button" class="cd-act" style="margin-top:14px" onclick="openSendPrefLinkModal()"><i class="fas fa-paper-plane"></i> Send Preference Link</button>`
    : '';

  pane.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;margin-bottom:14px">
      <div><span class="cd-section-title" style="border:none;margin:0;padding:0">Scheduling Preferences</span>
        <div style="margin-top:6px">${statusBadge}</div>
      </div>
      ${editBtn}${sendLinkBtn}
    </div>
    <div class="ov-grid">
      <div>
        <div class="cd-section-title">Preferred Day / Time Windows</div>
        ${dayRows || '<div class="ov-row"><div class="ov-val empty">No preferred windows set</div></div>'}
      </div>
      <div>
        <div class="cd-section-title">Preferred Technicians</div>
        <div style="padding:7px 0">${techRows}</div>
      </div>
    </div>
    ${pref.updated_at ? `<div style="margin-top:14px;font-size:11.5px;color:var(--text-light)">Last updated: ${fmtDateTime(pref.updated_at)}</div>` : ''}
  `;
}

async function _ensureAdtAndTechs() {
  const [adtR, techsR] = await Promise.all([
    _adtData ? Promise.resolve(_adtData) : apiJson('/appointment-day-times/'),
    _techsData ? Promise.resolve(_techsData) : apiJson('/technicians/?page_size=200'),
  ]);
  _adtData = adtR;
  _techsData = techsR;
}

async function openPrefModal() {
  document.getElementById('prefErr').textContent = '';
  document.getElementById('prefTimesGrid').innerHTML = '<span style="color:var(--text-light);font-size:12px">Loading...</span>';
  document.getElementById('prefTechsGrid').innerHTML = '<span style="color:var(--text-light);font-size:12px">Loading...</span>';
  document.getElementById('prefModal').classList.add('open');

  try {
    await _ensureAdtAndTechs();
  } catch (e) {
    document.getElementById('prefErr').textContent = 'Could not load preference options.';
    return;
  }

  const selTimeIds = new Set((_prefData && _prefData.preferred_time_ids) || []);
  const selTechIds = new Set((_prefData && _prefData.preferred_technician_ids) || []);

  // Build time checkboxes grouped by day
  const adtItems = (_adtData.results || []);
  const byDay = {};
  for (const t of adtItems) {
    if (!byDay[t.day]) byDay[t.day] = [];
    byDay[t.day].push(t);
  }
  let timesHtml = '';
  for (const day of DAY_ORDER) {
    if (!byDay[day]) continue;
    timesHtml += `<div style="grid-column:1/-1;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;color:var(--text-light);margin-top:6px;padding-top:4px;border-top:1px solid #f0f0f0">${escHtml(byDay[day][0].day_display)}</div>`;
    for (const t of byDay[day]) {
      const chk = selTimeIds.has(t.id) ? 'checked' : '';
      timesHtml += `<label style="display:flex;align-items:center;gap:6px;font-size:12.5px;cursor:pointer;padding:2px 0"><input type="checkbox" value="${escHtml(t.id)}" ${chk} data-pref-time> ${escHtml(t.time_range)}</label>`;
    }
  }
  document.getElementById('prefTimesGrid').innerHTML = timesHtml || '<span style="color:var(--text-light);font-size:12px">No time windows configured.</span>';

  // Build tech checkboxes
  const techs = (_techsData.results || _techsData || []);
  let techsHtml = techs.map(t => {
    const name = t.name || (t.first_name ? `${t.first_name} ${t.last_name}`.trim() : t.id);
    const chk = selTechIds.has(t.id) ? 'checked' : '';
    return `<label style="display:flex;align-items:center;gap:6px;font-size:12.5px;cursor:pointer;padding:2px 0"><input type="checkbox" value="${escHtml(t.id)}" ${chk} data-pref-tech> ${escHtml(name)}</label>`;
  }).join('');
  document.getElementById('prefTechsGrid').innerHTML = techsHtml || '<span style="color:var(--text-light);font-size:12px">No active technicians.</span>';

  document.getElementById('prefStatus').value = (_prefData && _prefData.status) || 'pending';
}

function closePrefModal() { document.getElementById('prefModal').classList.remove('open'); }

// ===== F-PREFS-3 — Send preference-update link modal =====
let _splChannel = null;     // 'sms' | 'email' | null
let _splCustInfo = null;    // {phone, email} cached after first open

async function _ensureCustInfoForLink() {
  if (_splCustInfo) return _splCustInfo;
  // Pull phone/email from the customer detail API. We reuse the
  // existing read endpoint that the page already calls on load.
  try {
    const d = await apiJson(`/customers/${CD_ID}/`);
    const c = d.customer || d;
    _splCustInfo = {
      phone: (c.phone || '').trim(),
      email: (c.email || '').trim(),
    };
  } catch (e) {
    _splCustInfo = { phone: '', email: '' };
  }
  return _splCustInfo;
}

async function openSendPrefLinkModal() {
  document.getElementById('splErr').textContent = '';
  document.getElementById('splSendBtn').disabled = true;
  _splChannel = null;

  const opts = document.getElementById('splChannelOpts');
  opts.innerHTML = '<span style="color:var(--text-light);font-size:12px">Loading...</span>';
  document.getElementById('sendPrefLinkModal').classList.add('open');

  const info = await _ensureCustInfoForLink();
  const optHtml = [];
  if (info.phone) {
    optHtml.push(`<label class="cd-flag flag-info" style="padding:10px 12px;cursor:pointer;font-size:13px;display:flex;align-items:center;gap:6px">
      <input type="radio" name="splCh" value="sms" onchange="_splPickChannel('sms')">
      <span><i class="fas fa-comment-sms"></i> SMS to ${escHtml(info.phone)}</span>
    </label>`);
  } else {
    optHtml.push(`<div class="cd-flag flag-mute" style="padding:10px 12px;font-size:13px;opacity:.6"><i class="fas fa-comment-sms"></i> SMS (no phone on file)</div>`);
  }
  if (info.email) {
    optHtml.push(`<label class="cd-flag flag-info" style="padding:10px 12px;cursor:pointer;font-size:13px;display:flex;align-items:center;gap:6px">
      <input type="radio" name="splCh" value="email" onchange="_splPickChannel('email')">
      <span><i class="fas fa-envelope"></i> Email to ${escHtml(info.email)}</span>
    </label>`);
  } else {
    optHtml.push(`<div class="cd-flag flag-mute" style="padding:10px 12px;font-size:13px;opacity:.6"><i class="fas fa-envelope"></i> Email (no email on file)</div>`);
  }
  opts.innerHTML = optHtml.join('');
}

function _splPickChannel(ch) {
  _splChannel = ch;
  document.getElementById('splSendBtn').disabled = false;
}

function closeSendPrefLinkModal() {
  document.getElementById('sendPrefLinkModal').classList.remove('open');
}

async function submitSendPrefLink() {
  const err = document.getElementById('splErr');
  err.textContent = '';
  if (!_splChannel) {
    err.textContent = 'Pick a channel first.';
    return;
  }
  const btn = document.getElementById('splSendBtn');
  btn.disabled = true; btn.textContent = 'Sending...';
  try {
    const r = await apiFetch(`/customers/${CD_ID}/send-preference-link/`, 'POST', {
      channel: _splChannel,
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      err.textContent = d.error || 'Send failed.';
      btn.disabled = false; btn.textContent = 'Send Link';
      return;
    }
    const resp = await r.json();
    closeSendPrefLinkModal();
    toast(`Preference link sent via ${resp.channel} to ${resp.recipient}`);
  } catch (e) {
    err.textContent = 'Network error.';
    btn.disabled = false; btn.textContent = 'Send Link';
  } finally {
    btn.textContent = 'Send Link';
  }
}

async function submitPreferences() {
  const err = document.getElementById('prefErr');
  err.textContent = '';
  const timeIds = [...document.querySelectorAll('[data-pref-time]:checked')].map(el => el.value);
  const techIds = [...document.querySelectorAll('[data-pref-tech]:checked')].map(el => el.value);
  const status = document.getElementById('prefStatus').value;
  const btn = document.getElementById('prefSaveBtn');
  btn.disabled = true; btn.textContent = 'Saving...';
  try {
    const r = await apiFetch(`/customers/${CD_ID}/preference/`, 'POST', {
      preferred_time_ids: timeIds,
      preferred_technician_ids: techIds,
      status,
    });
    if (!r.ok) {
      const d = await r.json().catch(() => ({}));
      err.textContent = d.error || Object.values(d).flat().join(', ') || 'Save failed.';
      return;
    }
    const resp = await r.json();
    _prefData = resp.preference;
    renderPreferencePane(_prefData);
    closePrefModal();
    toast('Preferences saved');
  } catch (e) {
    err.textContent = 'Network error.';
  } finally {
    btn.disabled = false; btn.textContent = 'Save Preferences';
  }
}

// ===== Billing Policy tab (PRD §11.3) =====
// Fetches the server-rendered billing card fragment and injects it.
// createContextualFragment is used so the inline <script> and external
// policy_form.js in the fragment actually execute after insertion.
async function loadBillingCard() {
  const pane = document.getElementById('paneBilling');
  try {
    const r = await fetch(`/customers/${CD_ID}/billing-card/`, {credentials: 'same-origin'});
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const html = await r.text();
    pane.innerHTML = '';
    pane.appendChild(document.createRange().createContextualFragment(html));
  } catch (e) {
    pane.innerHTML = '<div class="cd-empty">Could not load billing policy.</div>';
  }
}

// ===== KPI strip =====
async function loadKpis() {
  const wrap = document.getElementById('cdKpis');
  try {
    const [invR, apptR, payR, sqR] = await Promise.all([
      apiFetch(`/billing/invoices/?customer=${CD_ID}&page_size=100`).then(r => r.ok ? r.json() : { results:[] }).catch(() => ({ results:[] })),
      apiFetch(`/scheduling/appointments/?customer=${CD_ID}&page_size=200`).then(r => r.ok ? r.json() : { results:[] }).catch(() => ({ results:[] })),
      apiFetch(`/billing/payments/?customer=${CD_ID}&status=completed&page_size=200`).then(r => r.ok ? r.json() : { results:[] }).catch(() => ({ results:[] })),
      apiFetch(`/customers/${CD_ID}/square-payments/`).then(r => r.ok ? r.json() : null).catch(() => null)
    ]);
    const invoices = invR.results || invR || [];
    const appts = apptR.results || apptR || [];
    const payments = payR.results || payR || [];
    // Use paginator total counts so the KPI agrees with the tab badge (F-018).
    const apptTotal = apptR.count !== undefined ? apptR.count : appts.length;
    // Lifetime paid = the customer's completed Square payments, net of refunds
    // (analytics.SquarePayment — the complete Square ledger). This matches the
    // Payments tab and the dashboard Revenue tiles. billing.Payment only
    // records CRM-initiated charges (~15% of Square activity), so it's the
    // fallback for viewers without access to the Square endpoint.
    const lifetime = (sqR && sqR.summary && sqR.summary.completed_net_total != null)
      ? sqR.summary.completed_net_total
      : payments.reduce((sum, p) => sum + (parseFloat(p.amount || 0) || 0), 0);
    const balance = invoices.reduce((sum, i) => sum + (parseFloat(i.balance_due || 0) || 0), 0);
    const lastApptDate = appts.length ? appts.map(a => a.start_datetime).filter(Boolean).sort().reverse()[0] : null;
    const nextAppt = appts.find(a => a.start_datetime && new Date(a.start_datetime) > new Date() && ['scheduled','confirmed'].includes(a.status));
    const k = (lbl, val, sub, cls='') => `<div class="cd-kpi ${cls}"><div class="cd-kpi-lbl">${escHtml(lbl)}</div><div class="cd-kpi-val">${val}</div><div class="cd-kpi-sub">${escHtml(sub||'')}</div></div>`;
    wrap.innerHTML = [
      k('Lifetime paid', fmtMoney(lifetime), `${invoices.length} invoice${invoices.length===1?'':'s'}`),
      k('Outstanding', fmtMoney(balance), balance > 0 ? 'unpaid balance' : 'all clear', balance > 0 ? 'alert' : ''),
      k('Appointments', apptTotal, lastApptDate ? `last: ${fmtDate(lastApptDate)}` : 'none'),
      k('Next appointment', nextAppt ? fmtDate(nextAppt.start_datetime) : '--', nextAppt ? (nextAppt.job_type_name || '') : 'none scheduled')
    ].join('');
  } catch (e) {
    wrap.innerHTML = '<div class="cd-kpi"><div class="cd-kpi-lbl">Stats</div><div class="cd-kpi-sub">unavailable</div></div>';
  }
}

// ===== Quick actions =====
function openBookAppt() { window.location.href = `/calendar/?customer=${CD_ID}`; }

async function openTakePay(invoiceId, balance) {
  document.getElementById('payErr').textContent = '';
  document.getElementById('payAmt').value = balance ? parseFloat(balance).toFixed(2) : '';
  document.getElementById('payNote').value = '';
  const pmSel = document.getElementById('payPm');
  const invSel = document.getElementById('payInv');
  pmSel.innerHTML = '<option value="">Loading...</option>';
  invSel.innerHTML = '<option value="">-- Not linked to an invoice --</option>';
  try {
    const pmR = await apiFetch(`/billing/payment-methods/?customer=${CD_ID}`);
    const pms = pmR.ok ? (await pmR.json()).results || [] : [];
    const _manualOpt = '<option value="__manual__">+ Key in a new card...</option>';
    if (!pms.length) {
      pmSel.innerHTML = _manualOpt;
    } else {
      pmSel.innerHTML = pms.map(p => `<option value="${p.id}"${p.is_default?' selected':''}>${escHtml(p.card_brand||p.brand||'card')} ....${escHtml(p.last_four||p.last4||'****')}${p.is_default?' (default)':''}</option>`).join('') + _manualOpt;
    }
  } catch (e) {
    pmSel.innerHTML = '<option value="">Could not load payment methods</option>';
  }
  if (!invoiceId) {
    try {
      const invR = await apiFetch(`/billing/invoices/?customer=${CD_ID}&page_size=50`);
      const items = invR.ok ? (await invR.json()).results || [] : [];
      const open_invs = items.filter(i => parseFloat(i.balance_due || 0) > 0);
      invSel.innerHTML = '<option value="">-- Not linked to an invoice --</option>' +
        open_invs.map(i => `<option value="${i.id}">#${escHtml(i.invoice_number||'')} -- ${fmtMoney(i.balance_due)} due</option>`).join('');
    } catch(e){}
  } else {
    invSel.innerHTML = `<option value="${escHtml(invoiceId)}" selected>Invoice (pre-selected)</option><option value="">-- Not linked to an invoice --</option>`;
  }
  document.getElementById('payModal').classList.add('open');
  document.getElementById('payCardRow').style.display = 'none';
  document.getElementById('paySaveCard').checked = false;
  document.getElementById('paySqErr').textContent = '';
  onPayPmChange();
}
function closePayModal() { document.getElementById('payModal').classList.remove('open'); }

// ===== Manual 'key in a new card' payment via Square Web Payments SDK =====
let _paySq = null, _payCard = null, _payCardReady = false;
async function initPaySquareCard() {
  const errEl = document.getElementById('paySqErr');
  if (_payCardReady && _payCard) return;
  if (!window.SQUARE_APP_ID || !window.SQUARE_LOCATION_ID) { if (errEl) errEl.textContent = 'Card entry is not configured for this account.'; return; }
  if (!window.Square) { if (errEl) errEl.textContent = 'Card library still loading - try again in a moment.'; return; }
  try {
    _paySq = window.Square.payments(window.SQUARE_APP_ID, window.SQUARE_LOCATION_ID);
    _payCard = await _paySq.card();
    await _payCard.attach('#paySqCard');
    _payCardReady = true;
  } catch (e) { if (errEl) errEl.textContent = 'Could not load the card form: ' + (e.message || e); }
}
function onPayPmChange() {
  const manual = document.getElementById('payPm').value === '__manual__';
  document.getElementById('payCardRow').style.display = manual ? '' : 'none';
  const invRow = document.getElementById('payInvRow');
  if (invRow) invRow.style.display = manual ? 'none' : '';
  if (manual) initPaySquareCard();
  updatePayPreview();
}
function updatePayPreview() {
  const prev = document.getElementById('payPreview');
  if (!prev) return;
  const amt = parseFloat(document.getElementById('payAmt').value) || 0;
  const manual = document.getElementById('payPm').value === '__manual__';
  const invLinked = !manual && !!document.getElementById('payInv').value;
  if (amt <= 0) { prev.style.display = 'none'; return; }
  prev.style.display = '';
  if (invLinked) { prev.innerHTML = 'Charging <b>' + fmtMoney(amt) + '</b> to the selected invoice (its tax is already included).'; return; }
  const tax = Math.round(amt * CD_TAX_RATE) / 100;
  const total = Math.round((amt + tax) * 100) / 100;
  if (CD_TAX_RATE > 0) {
    prev.innerHTML = 'Subtotal <b>' + fmtMoney(amt) + '</b> + ' + CD_TAX_RATE + '% tax <b>' + fmtMoney(tax) + '</b>' + (CD_TAX_JURIS ? ' (' + CD_TAX_JURIS + ')' : '') + ' = Total <b>' + fmtMoney(total) + '</b>';
  } else {
    prev.innerHTML = 'Total <b>' + fmtMoney(amt) + '</b> (no sales-tax rate configured for this location)';
  }
}
async function submitManualCard() {
  const amt = parseFloat(document.getElementById('payAmt').value);
  const note = document.getElementById('payNote').value;
  const err = document.getElementById('payErr');
  err.textContent = '';
  if (!amt || amt <= 0) { err.textContent = 'Enter a valid amount.'; return; }
  if (amt < 0.01) { err.textContent = 'Amount must be at least $0.01.'; return; }
  if (amt > 99999.99) { err.textContent = 'Amount exceeds the $99,999.99 per-transaction limit.'; return; }
  if (!_payCardReady || !_payCard) { err.textContent = 'Card form is still loading - try again in a moment.'; return; }
  const btn = document.getElementById('payBtn'); btn.disabled = true; btn.textContent = 'Reading card...';
  try {
    let tok = null;
    try {
      const res = await _payCard.tokenize();
      if (res.status !== 'OK') { err.textContent = (res.errors && res.errors[0] && res.errors[0].message) || 'Card entry was invalid.'; btn.disabled = false; btn.textContent = 'Charge'; return; }
      tok = res.token;
    } catch (e) { err.textContent = (e.message || 'Card entry failed.'); btn.disabled = false; btn.textContent = 'Charge'; return; }
    btn.textContent = 'Charging...';
    const r = await apiFetch('/billing/charge-manual/', 'POST', { customer_id: CD_ID, card_token: tok, pretax_amount: amt, save_card: !!document.getElementById('paySaveCard').checked, note: note || 'Office manual card entry' });
    const d = await r.json().catch(() => ({}));
    if (r.ok && d.status === 'completed') {
      if (d.tax_amount && parseFloat(d.tax_amount) > 0) { toast('Card charged ' + fmtMoney(d.total) + ' (incl. ' + fmtMoney(d.tax_amount) + ' tax)' + (d.saved_card ? ', card saved' : '')); }
      else { toast('Card charged ' + fmtMoney(d.total || amt) + (d.saved_card ? ', card saved' : '')); }
      closePayModal(); loadKpis();
      if (cdLoadedPanes.has('invoices')) loadInvoices();
      if (cdLoadedPanes.has('timeline')) loadTimeline();
    } else { err.textContent = (d.error || 'Charge failed.'); }
  } catch (e) { err.textContent = 'Network error.'; }
  btn.disabled = false; btn.textContent = 'Charge';
}

async function submitPayment() {
  const amt = parseFloat(document.getElementById('payAmt').value);
  const pmId = document.getElementById('payPm').value;
  const invId = document.getElementById('payInv').value;
  const note = document.getElementById('payNote').value;
  const err = document.getElementById('payErr');
  err.textContent = '';
  if (document.getElementById('payPm').value === '__manual__') { return submitManualCard(); }
  if (!amt || amt <= 0) { err.textContent = 'Enter a valid amount.'; return; }
  if (amt < 0.01) { err.textContent = 'Amount must be at least $0.01.'; return; }
  if (amt > 99999.99) { err.textContent = 'Amount exceeds the $99,999.99 per-transaction limit.'; return; }
  if (!pmId) { err.textContent = 'No payment method selected. Add a card on file first.'; return; }
  const btn = document.getElementById('payBtn'); btn.disabled = true; btn.textContent = 'Charging...';
  try {
    const r = await apiFetch('/billing/charge/', 'POST', {
      customer_id: CD_ID, amount: amt, payment_method_id: pmId,
      invoice_id: invId || null, note: note || ''
    });
    if (r.ok) {
      const d = await r.json().catch(() => ({}));
      if (d.tax_amount && parseFloat(d.tax_amount) > 0) {
        toast(`Charged ${fmtMoney(d.total)} (incl. ${fmtMoney(d.tax_amount)} tax${d.tax_jurisdiction ? ', ' + d.tax_jurisdiction : ''})`);
      } else {
        toast('Payment charged' + (d.total ? ' \u2014 ' + fmtMoney(d.total) : ''));
      }
      closePayModal();
      loadKpis();
      if (cdLoadedPanes.has('invoices')) loadInvoices();
      if (cdLoadedPanes.has('timeline')) loadTimeline();
    } else {
      const d = await r.json().catch(() => ({}));
      err.textContent = (d.error || Object.values(d).flat().join(', ')) || 'Charge failed.';
    }
  } catch (e) { err.textContent = 'Network error.'; }
  btn.disabled = false; btn.textContent = 'Charge';
}

function openLogCall() {
  document.getElementById('callErr').textContent = '';
  ['callDur','callReason','callNotes'].forEach(i => document.getElementById(i).value = i==='callDur'?'0':'');
  document.getElementById('callDir').value = 'inbound';
  document.getElementById('callOut').value = 'completed';
  document.getElementById('callModal').classList.add('open');
}
function closeCallModal() { document.getElementById('callModal').classList.remove('open'); }

async function submitCall() {
  const reason = document.getElementById('callReason').value.trim();
  const notes = document.getElementById('callNotes').value.trim();
  const dur = parseInt(document.getElementById('callDur').value || '0');
  const body = {
    customer: CD_ID,
    direction: document.getElementById('callDir').value,
    outcome: document.getElementById('callOut').value,
    duration_seconds: dur * 60,
    phone_number: CUSTOMER ? (CUSTOMER.phone || '') : '',
    notes: (reason ? 'Reason: ' + reason + '\n\n' : '') + notes
  };
  const err = document.getElementById('callErr');
  const btn = document.getElementById('callBtn'); btn.disabled = true; btn.textContent = 'Saving...';
  try {
    const r = await apiFetch('/communications/call-logs/', 'POST', body);
    if (r.ok) {
      toast('Call logged');
      closeCallModal();
      if (cdLoadedPanes.has('comms')) loadComms();
      if (cdLoadedPanes.has('timeline')) loadTimeline();
    } else {
      const d = await r.json().catch(() => ({}));
      err.textContent = Object.values(d).flat().join(', ') || 'Save failed.';
    }
  } catch (e) { err.textContent = 'Network error.'; }
  btn.disabled = false; btn.textContent = 'Save Call';
}

function openNewTicket() {
  document.getElementById('tkErr').textContent = '';
  ['tkSubj','tkDesc'].forEach(i => document.getElementById(i).value = '');
  document.getElementById('tkCat').value = 'general_inquiry';
  document.getElementById('tkPri').value = 'medium';
  document.getElementById('ticketModal').classList.add('open');
}
function closeTicketModal() { document.getElementById('ticketModal').classList.remove('open'); }

async function submitTicket() {
  const subj = document.getElementById('tkSubj').value.trim();
  const desc = document.getElementById('tkDesc').value.trim();
  const err = document.getElementById('tkErr');
  if (!subj) { err.textContent = 'Subject required.'; return; }
  const body = {
    customer: CD_ID, subject: subj, description: desc,
    category: document.getElementById('tkCat').value,
    priority: document.getElementById('tkPri').value,
    channel: 'phone'
  };
  const btn = document.getElementById('tkBtn'); btn.disabled = true; btn.textContent = 'Creating...';
  try {
    const r = await apiFetch('/tickets/tickets/', 'POST', body);
    if (r.ok) {
      toast('Ticket created');
      closeTicketModal();
      if (cdLoadedPanes.has('tickets')) loadTickets();
      if (cdLoadedPanes.has('timeline')) loadTimeline();
    } else {
      const d = await r.json().catch(() => ({}));
      err.textContent = Object.values(d).flat().join(', ') || 'Create failed.';
    }
  } catch (e) { err.textContent = 'Network error.'; }
  btn.disabled = false; btn.textContent = 'Create Ticket';
}

// ===== Documents =====
async function loadDocuments() {
  const pane = document.getElementById('paneDocuments');
  try {
    const data = await apiJson(`/customers/${CD_ID}/documents/`);
    document.getElementById('cntDocs').textContent = data.count || 0;
    const reports = data.treatment_reports || [];
    const agreements = data.maintenance_agreements || [];
    const inspections = data.inspection_forms || [];

    if (!reports.length && !agreements.length && !inspections.length) {
      pane.innerHTML = '<div class="cd-empty">No documents on file for this customer.</div>';
      return;
    }

    const STATUS_BADGE = {scheduled:'b-blue', confirmed:'b-green', in_progress:'b-orange', completed:'b-gray', cancelled:'b-red', no_show:'b-red'};
    let html = '';

    if (reports.length) {
      html += '<div class="cd-section-title" style="margin-bottom:10px">Treatment Reports</div>';
      html += '<table class="cd-table"><thead><tr><th>Date</th><th>Service</th><th>Technician</th><th>Status</th><th>Notes</th><th></th></tr></thead><tbody>';
      for (const d of reports) {
        const stCls = STATUS_BADGE[d.status] || 'b-gray';
        const preview = d.notes_preview ? `<span style="color:var(--text-light);font-size:12px">${escHtml(d.notes_preview.slice(0,80))}${d.notes_preview.length>80?'...':''}</span>` : '<span class="ov-val empty">--</span>';
        html += `<tr>
          <td style="white-space:nowrap">${escHtml(d.date)}</td>
          <td>${escHtml(d.service)}</td>
          <td>${escHtml(d.technician || '--')}</td>
          <td><span class="badge ${stCls}">${escHtml((d.status||'').replace(/_/g,' '))}</span></td>
          <td>${preview}</td>
          <td><a href="${escHtml(d.pdf_url)}" target="_blank" rel="noopener" class="cd-act" style="padding:4px 10px;font-size:11.5px;text-decoration:none"><i class="fas fa-file-pdf" style="color:#c62828"></i> PDF</a></td>
        </tr>`;
      }
      html += '</tbody></table>';
    }

    if (inspections.length) {
      html += '<div class="cd-section-title" style="margin-top:22px;margin-bottom:10px">Inspection Forms (NPMA-33 / WDO)</div>';
      html += '<table class="cd-table"><thead><tr><th>Date</th><th>Form</th><th>Signed</th><th></th></tr></thead><tbody>';
      for (const d of inspections) {
        html += `<tr><td style="white-space:nowrap">${escHtml(d.date||'')}</td><td>${escHtml(d.title||'Inspection Report')}</td><td>${d.tech_signed?'<span class="badge b-green">signed</span>':'<span class="ov-val empty">--</span>'}</td><td><a href="${escHtml(d.pdf_url)}" target="_blank" rel="noopener" class="cd-act" style="padding:4px 10px;font-size:11.5px;text-decoration:none"><i class="fas fa-file-pdf" style="color:#c62828"></i> PDF</a></td></tr>`;
      }
      html += '</tbody></table>';
    }

    if (agreements.length) {
      html += '<div class="cd-section-title" style="margin-top:22px;margin-bottom:10px">Maintenance Agreements</div>';
      html += '<table class="cd-table"><thead><tr><th>Date</th><th>Description</th><th></th></tr></thead><tbody>';
      for (const d of agreements) {
        html += `<tr><td>${escHtml(d.date||'')}</td><td>${escHtml(d.description||'')}</td><td><a href="${escHtml(d.pdf_url)}" target="_blank" rel="noopener" class="cd-act" style="padding:4px 10px;font-size:11.5px;text-decoration:none"><i class="fas fa-file-pdf" style="color:#c62828"></i> PDF</a></td></tr>`;
      }
      html += '</tbody></table>';
    } else {
      html += '<div class="cd-section-title" style="margin-top:22px;margin-bottom:6px">Maintenance Agreements</div>';
      html += '<div style="font-size:13px;color:var(--text-light);padding:8px 0">No maintenance agreement forms on file.</div>';
    }

    pane.innerHTML = html;
  } catch (e) {
    pane.innerHTML = '<div class="cd-empty">Could not load documents.</div>';
  }
}

// ===== Init =====
async function loadTabCounts() {
  // F-007: paint tab badges immediately so they reflect reality on page
  // load instead of staying at 0 until the operator clicks each tab.
  try {
    const r = await apiFetch(`/customers/${CD_ID}/counts/`);
    if (!r.ok) return;
    const d = await r.json();
    const set = (id, n) => { const el = document.getElementById(id); if (el) el.textContent = n; };
    set('cntTimeline', d.timeline);
    set('cntAppt',     d.appointments);
    set('cntComm',     d.communications);
    set('cntInv',      d.invoices);
    set('cntTkt',      d.tickets);
    if (d.documents !== undefined) set('cntDocs', d.documents);
  } catch (e) { /* badge stays at 0 — non-fatal */ }
}

document.addEventListener('DOMContentLoaded', () => {
  loadCustomer();
  loadKpis();
  loadTabCounts();
});

document.querySelectorAll('.cd-modal-bg').forEach(bg => {
  bg.addEventListener('click', e => { if (e.target === bg) bg.classList.remove('open'); });
});