let enabledState = true;

function toggleSettings() {
  const panel = document.getElementById('settings-panel');
  const toggle = document.querySelector('.settings-panel-toggle');
  panel.classList.toggle('open');
  toggle.classList.toggle('open');
}

function toggleEnabled() {
  enabledState = !enabledState;
  const toggle = document.getElementById('toggle-enabled');
  const label = document.getElementById('toggle-label');
  toggle.classList.toggle('active');
  label.textContent = enabledState ? 'Enabled' : 'Disabled';
}

async function saveSettings(e) {
  e.preventDefault();

  const payload = {
    enabled: enabledState,
    google_business_url: document.getElementById('google_business_url').value,
    google_place_id: document.getElementById('google_place_id').value,
    delay_hours_after_completion: parseInt(document.getElementById('delay_hours').value),
    promoter_threshold: parseInt(document.getElementById('promoter_threshold').value),
    detractor_threshold: parseInt(document.getElementById('detractor_threshold').value),
    sms_template_initial: document.getElementById('sms_initial').value,
    sms_template_promoter: document.getElementById('sms_promoter').value,
    sms_template_passive: document.getElementById('sms_passive').value,
    sms_template_detractor: document.getElementById('sms_detractor').value,
  };

  try {
    const settingsId = 5;
    const method = settingsId ? 'PUT' : 'POST';
    const url = settingsId
      ? `/api/v1/reputation/settings/${settingsId}/`
      : '/api/v1/reputation/settings/';

    const response = await fetch(url, {
      method: method,
      headers: {
        'Content-Type': 'application/json',
        'X-CSRFToken': getCookie('csrftoken')
      },
      body: JSON.stringify(payload)
    });

    if (response.ok) {
      alert('Settings saved successfully!');
      window.location.reload();
    } else {
      const error = await response.json();
      alert('Error saving settings: ' + JSON.stringify(error));
    }
  } catch (err) {
    alert('Error: ' + err.message);
  }
}

function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== '') {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      if (cookie.substring(0, name.length + 1) === (name + '=')) {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}