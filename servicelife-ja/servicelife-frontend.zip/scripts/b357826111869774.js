const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const API='/api/v1';
const hdr=(m)=>{const h={'X-CSRFToken':csrf()};if(m!=='GET')h['Content-Type']='application/json';return h};
async function api(u){const r=await fetch(API+u,{credentials:'same-origin',headers:hdr('GET')});return r.json()}
async function apiFetch(u,m='GET',b=null){const o={method:m,credentials:'same-origin',headers:hdr(m)};if(b)o.body=JSON.stringify(b);return fetch(API+u,o)}
// NOTE: showPanel is defined below as `window.showPanel = function(...)`. It
// must NOT also be declared here as `function showPanel(...)` — the
// base.html SPA shim wraps each re-injected inline script in an IIFE and
// appends `window.NAME = NAME` for every `function NAME(...)` declaration
// it finds. After SPA-nav, the auto-promoted local would overwrite the
// explicit `window.showPanel = ...` assignment below, which is what
// caused the SLA / Dispatch Lockout panels to stick on
// "Loading..." until a hard refresh.
document.getElementById('sPrimary').addEventListener('input',e=>document.getElementById('sPrimaryVal').textContent=e.target.value);
document.getElementById('sAccent').addEventListener('input',e=>document.getElementById('sAccentVal').textContent=e.target.value);

// ============================================================
// Tenant settings — load + save against /api/v1/tenant-settings/current/
// (handoff 16.7 / prepay-admin-ui)
// ============================================================
//
// Loads on page-ready. Populates Company Info fields AND Pre-Charge panel.
// Two save functions: saveTenant() for the Company Info form,
// savePrepay() for the Pre-Charge panel. Both PATCH the same endpoint
// — backend ignores fields the user didn't send.

async function loadTenant(){
  try {
    const t = await api('/tenant-settings/current/');
    // Company Info fields (only if elements present)
    const fName = document.getElementById('sName');     if (fName) fName.value = t.name || '';
    const fPh   = document.getElementById('sPhone');    if (fPh)   fPh.value = t.phone || '';
    const fEm   = document.getElementById('sEmail');    if (fEm)   fEm.value = t.email || '';
    const fAd   = document.getElementById('sAddress');  if (fAd)   fAd.value = t.address || '';
    const fTz   = document.getElementById('sTimezone'); if (fTz && t.timezone) fTz.value = t.timezone;
    // Pre-Charge panel
    document.getElementById('ppEnabled').checked = !!t.prepay_enabled;
    document.getElementById('ppDaysBefore').value = t.prepay_days_before ?? 3;
    document.getElementById('ppGraceHours').value = t.prepay_grace_hours ?? 24;
  } catch(e) {
    console.warn('Tenant load error', e);
  }
}

async function saveTenant(){
  const msgEl = document.getElementById('saveMsg');
  const body = {
    phone:    document.getElementById('sPhone')?.value || '',
    email:    document.getElementById('sEmail')?.value || '',
    address:  document.getElementById('sAddress')?.value || '',
    timezone: document.getElementById('sTimezone')?.value || 'America/New_York',
  };
  try {
    const r = await apiFetch('/tenant-settings/current/', 'PATCH', body);
    if (!r.ok) { const err = await r.json().catch(()=>({})); throw new Error(err.detail || err.error || ('Save failed (' + r.status + ')')); }
    if (msgEl) { msgEl.textContent = 'Saved'; msgEl.style.color = '#2e7d32'; setTimeout(()=>{msgEl.textContent=''},3000); }
  } catch(e) {
    if (msgEl) { msgEl.textContent = (e.message || 'Save failed'); msgEl.style.color = '#c62828'; }
  }
}

async function savePayments(){
  // Payment-gateway settings live in tenant.settings_json — wiring still TODO.
  // For now, behave like a confirmation toast so the existing button doesn't appear broken.
  document.getElementById('payMsg').textContent = 'Payment settings saved!';
  setTimeout(()=>document.getElementById('payMsg').textContent='',3000);
}

async function savePrepay(){
  const msgEl = document.getElementById('ppMsg');
  const enabled = document.getElementById('ppEnabled').checked;
  const days    = parseInt(document.getElementById('ppDaysBefore').value, 10);
  const grace   = parseInt(document.getElementById('ppGraceHours').value, 10);

  // Client-side validation mirrors backend bounds; server is authoritative.
  if (!Number.isFinite(days) || days < 0 || days > 30) {
    msgEl.textContent = 'Days before must be between 0 and 30.'; msgEl.style.color = '#c62828'; return;
  }
  if (!Number.isFinite(grace) || grace < 1 || grace > 168) {
    msgEl.textContent = 'Grace hours must be between 1 and 168.'; msgEl.style.color = '#c62828'; return;
  }

  // Confirm before flipping the tenant-wide switch on — this starts charging cards.
  if (enabled && !window.__prepayWasEnabled) {
    if (!confirm('Enabling pre-charge will start charging eligible residential customers automatically.\n\nFor a safer rollout, leave this OFF and set ONE customer\'s Prepay Override to "Always" first to verify your setup.\n\nProceed with tenant-wide enable?')) {
      return;
    }
  }

  try {
    const r = await apiFetch('/tenant-settings/current/', 'PATCH', {
      prepay_enabled: enabled,
      prepay_days_before: days,
      prepay_grace_hours: grace,
    });
    if (!r.ok) { const err = await r.json().catch(()=>({})); throw new Error(err.detail || err.error || ('Save failed (' + r.status + ')')); }
    window.__prepayWasEnabled = enabled;  // remember for next save
    msgEl.textContent = 'Saved'; msgEl.style.color = '#2e7d32';
    setTimeout(()=>{msgEl.textContent=''},3000);
  } catch(e) {
    msgEl.textContent = (e.message || 'Save failed'); msgEl.style.color = '#c62828';
  }
}

// Auto-load tenant settings on page ready.
document.addEventListener('DOMContentLoaded', loadTenant);

// --- Office Management ---
let editingOfficeId=null;
const _TZ_LABELS={
  'America/New_York':'Eastern Time (ET)',
  'America/Chicago':'Central Time (CT)',
  'America/Denver':'Mountain Time (MT)',
  'America/Phoenix':'Mountain Time – AZ',
  'America/Los_Angeles':'Pacific Time (PT)',
  'America/Anchorage':'Alaska (AKT)',
  'Pacific/Honolulu':'Hawaii (HT)',
  'America/Toronto':'Toronto (ET)',
  'America/Vancouver':'Vancouver (PT)',
  'America/Winnipeg':'Winnipeg (CT)',
  'America/Halifax':'Halifax (AT)',
  'America/St_Johns':'Newfoundland (NT)',
  'Europe/London':'London (GMT/BST)',
  'Europe/Paris':'Central Europe (CET)',
  'Europe/Helsinki':'Eastern Europe (EET)',
  'Europe/Moscow':'Moscow (MSK)',
  'Asia/Dubai':'Dubai (GST)',
  'Asia/Kolkata':'India (IST)',
  'Asia/Bangkok':'Bangkok (ICT)',
  'Asia/Singapore':'Singapore (SGT)',
  'Asia/Tokyo':'Tokyo (JST)',
  'Asia/Seoul':'Seoul (KST)',
  'Australia/Sydney':'Sydney (AEST)',
  'Pacific/Auckland':'Auckland (NZST)',
  'America/Sao_Paulo':'São Paulo (BRT)',
  'America/Argentina/Buenos_Aires':'Buenos Aires (ART)',
  'America/Mexico_City':'Mexico City (CST)',
};
function tzLabel(tz){return _TZ_LABELS[tz]||tz;}
async function loadOffices(){
  try{
    const d=await api('/offices/');
    const offices=d.results||d;
    const grid=document.getElementById('officeGrid');
    if(!offices.length){grid.innerHTML='<div style="padding:20px;text-align:center;color:var(--text-light)">No offices yet. Click "Add Office" to create one.</div>';return}
    grid.innerHTML=offices.map(o=>`
      <div style="border:1.5px solid ${o.is_default?'var(--accent)':'var(--border)'};border-radius:10px;padding:14px;background:${o.is_active?'var(--white)':'#fafafa'}">
        <div style="display:flex;justify-content:space-between;align-items:flex-start">
          <div>
            <div style="font-weight:700;font-size:14px">${o.name} ${o.is_default?'<span style="font-size:9px;background:var(--accent);color:var(--primary);padding:2px 6px;border-radius:8px;font-weight:600">DEFAULT</span>':''}</div>
            <div style="font-size:12px;color:var(--text-light);margin-top:4px"><i class="fas fa-map-marker-alt" style="color:#E53935;margin-right:4px"></i>${o.address}</div>
            ${o.phone?'<div style="font-size:12px;color:var(--text-light);margin-top:2px"><i class="fas fa-phone" style="color:#1565C0;margin-right:4px"></i>'+o.phone+'</div>':''}
            ${o.square_location_id?'<div style="font-size:11px;color:var(--text-light);margin-top:2px"><i class="fas fa-credit-card" style="color:#4CAF50;margin-right:4px"></i>Square: '+o.square_location_id+'</div>':''}
            <div style="font-size:11px;color:var(--text-light);margin-top:2px"><i class="fas fa-globe" style="color:#1565C0;margin-right:4px"></i>${o.timezone?tzLabel(o.timezone):'<span style="opacity:.6">Timezone: using tenant default</span>'}</div>
            <div style="font-size:11px;color:var(--text-light);margin-top:4px"><i class="fas fa-users" style="margin-right:4px"></i>${o.user_count} users assigned</div>
          </div>
          <div style="display:flex;gap:6px">
            <button type="button" onclick="editOffice('${o.id}')" style="border:none;background:none;cursor:pointer;color:var(--primary);font-size:13px" title="Edit"><i class="fas fa-edit"></i></button>
            <button type="button" onclick="deleteOffice('${o.id}','${o.name}')" style="border:none;background:none;cursor:pointer;color:#E53935;font-size:13px" title="Delete"><i class="fas fa-trash"></i></button>
          </div>
        </div>
      </div>
    `).join('');
  }catch(e){console.warn('Office load error',e)}
}
function showOfficeModal(){editingOfficeId=null;document.getElementById('officeModalTitle').textContent='Add Office';document.getElementById('oName').value='';document.getElementById('oAddr').value='';document.getElementById('oPhone').value='';document.getElementById('oActive').checked=true;document.getElementById('oDefault').checked=false;document.getElementById('oSquareLocId').value='';document.getElementById('oTz').value='';document.getElementById('officeModal').style.display='flex'}
function closeOfficeModal(){document.getElementById('officeModal').style.display='none'}
async function editOffice(id){editingOfficeId=id;const o=await api('/offices/'+id+'/');document.getElementById('officeModalTitle').textContent='Edit Office';document.getElementById('oName').value=o.name;document.getElementById('oAddr').value=o.address;document.getElementById('oPhone').value=o.phone||'';document.getElementById('oActive').checked=o.is_active;document.getElementById('oDefault').checked=o.is_default;document.getElementById('oSquareLocId').value=o.square_location_id||'';document.getElementById('oTz').value=o.timezone||'';document.getElementById('officeModal').style.display='flex'}
async function saveOffice(){const body={name:document.getElementById('oName').value.trim(),address:document.getElementById('oAddr').value.trim(),phone:document.getElementById('oPhone').value.trim(),is_active:document.getElementById('oActive').checked,is_default:document.getElementById('oDefault').checked,square_location_id:document.getElementById('oSquareLocId').value.trim(),timezone:document.getElementById('oTz').value};if(!body.name||!body.address){alert('Name and address required');return}if(editingOfficeId){await apiFetch('/offices/'+editingOfficeId+'/','PATCH',body)}else{await apiFetch('/offices/','POST',body)}closeOfficeModal();loadOffices()}
async function deleteOffice(id,name){if(!confirm('Delete office "'+name+'"?'))return;await apiFetch('/offices/'+id+'/','DELETE');loadOffices()}
loadOffices();

// ============================================================
// Inbox Filters — per-tenant ignored-sender list
// Backs the Settings → Inbox Filters panel. CRUD against
// /api/v1/communications/ignored-senders/ — see app/communications/
// ignored_senders_api.py for the canonical service layer.
// ============================================================
let _ignoredSenders = [];
const _IGNORE_TYPES = {email: 'Email', email_domain: 'Domain', phone: 'Phone'};
const _IGNORE_TYPE_COLORS = {email: '#1565C0', email_domain: '#6A1B9A', phone: '#2E7D32'};

async function loadIgnoredSenders() {
  const wrap = document.getElementById('ignoreList');
  if (!wrap) return;
  wrap.innerHTML = '<div style="padding:24px;text-align:center;color:var(--text-light)">Loading...</div>';
  try {
    const d = await api('/communications/ignored-senders/');
    _ignoredSenders = d.items || [];
    renderIgnoredSenders();
  } catch (e) {
    console.warn('ignored senders load error', e);
    wrap.innerHTML = '<div style="padding:20px;text-align:center;color:#c62828">Failed to load filters.</div>';
  }
}

function renderIgnoredSenders() {
  const search = (document.getElementById('ignoreSearchInp').value || '').toLowerCase().trim();
  const items = _ignoredSenders.filter(r =>
    !search || (r.value || '').toLowerCase().includes(search) || (r.reason || '').toLowerCase().includes(search)
  );
  const wrap = document.getElementById('ignoreList');
  if (!_ignoredSenders.length) {
    wrap.innerHTML = '<div style="padding:24px;text-align:center;color:var(--text-light);font-size:13px">No senders ignored. Use the &quot;Ignore&quot; button on a conversation in the inbox, or click &quot;Add Filter&quot; above.</div>';
    return;
  }
  if (!items.length) {
    wrap.innerHTML = '<div style="padding:24px;text-align:center;color:var(--text-light);font-size:13px">No matches for &quot;' + escHTML(search) + '&quot;.</div>';
    return;
  }
  const cols = '90px 1.4fr 1.2fr 110px 100px 90px';
  const header = '<div style="display:grid;grid-template-columns:' + cols + ';gap:10px;padding:10px 14px;background:#fafafa;border-bottom:2px solid var(--border);font-size:11px;font-weight:600;color:var(--text-light);text-transform:uppercase;letter-spacing:.5px"><span>Type</span><span>Value</span><span>Reason</span><span>Added By</span><span>Date</span><span style="text-align:right">Action</span></div>';
  const rows = items.map(r => {
    const dt = r.created_at ? new Date(r.created_at).toLocaleDateString() : '';
    const by = escHTML(r.created_by_name || 'system');
    const reason = r.reason ? escHTML(r.reason) : '<span style="color:var(--text-light)">&mdash;</span>';
    const color = _IGNORE_TYPE_COLORS[r.match_type] || '#666';
    const typeLabel = _IGNORE_TYPES[r.match_type] || r.match_type;
    return '<div style="display:grid;grid-template-columns:' + cols + ';gap:10px;align-items:center;padding:10px 14px;border-bottom:1px solid var(--border)">' +
      '<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:' + color + '22;color:' + color + ';font-weight:600;font-size:10px;text-transform:uppercase;letter-spacing:.5px;text-align:center">' + escHTML(typeLabel) + '</span>' +
      '<span style="font-family:monospace;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + escHTML(r.value) + '">' + escHTML(r.value) + '</span>' +
      '<span style="color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + escHTML(r.reason || '') + '">' + reason + '</span>' +
      '<span style="color:var(--text-light);font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + by + '</span>' +
      '<span style="color:var(--text-light);font-size:11px">' + escHTML(dt) + '</span>' +
      '<button type="button" class="ig-unignore-btn" data-id="' + escHTML(r.id) + '" data-label="' + escHTML(r.value) + '" style="border:1px solid var(--border);background:#fff;cursor:pointer;color:#c62828;padding:4px 10px;border-radius:4px;font-size:11px;font-weight:600;justify-self:end">Unignore</button>' +
    '</div>';
  });
  wrap.innerHTML = header + rows.join('');
}

// Delegated click handler for unignore buttons (re-rendered innerHTML
// would otherwise blow away per-button listeners).
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('.ig-unignore-btn');
  if (b) unignoreSender(b.dataset.id, b.dataset.label);
});

function showIgnoreSenderModal() {
  document.getElementById('igType').value = 'email';
  document.getElementById('igValue').value = '';
  document.getElementById('igReason').value = '';
  updateIgnoreValueHint();
  document.getElementById('ignoreSenderModal').style.display = 'flex';
  setTimeout(() => { try { document.getElementById('igValue').focus(); } catch(_) {} }, 50);
}
function closeIgnoreSenderModal() {
  document.getElementById('ignoreSenderModal').style.display = 'none';
}
function updateIgnoreValueHint() {
  const t = document.getElementById('igType').value;
  const labels = {email: 'Email address', email_domain: 'Email domain', phone: 'Phone number'};
  const placeholders = {email: 'e.g. notifications@example.invalid', email_domain: 'e.g. mailgun.org', phone: 'e.g. 555-123-4567'};
  const hints = {
    email: 'Hides every conversation from this exact address.',
    email_domain: 'Hides every conversation from any address ending in @<domain>. Use granular email if a real customer also uses this domain.',
    phone: '10-digit US numbers. Hides phone calls and SMS from this number.',
  };
  document.getElementById('igValueLabel').textContent = labels[t];
  document.getElementById('igValue').placeholder = placeholders[t];
  document.getElementById('igValueHint').textContent = hints[t];
}

async function saveIgnoreSender(force) {
  const match_type = document.getElementById('igType').value;
  const value = document.getElementById('igValue').value.trim();
  const reason = document.getElementById('igReason').value.trim();
  if (!value) { alert('Value is required.'); return; }
  const btn = document.getElementById('igSaveBtn');
  btn.disabled = true;
  try {
    const r = await apiFetch('/communications/ignored-senders/', 'POST', {match_type: match_type, value: value, reason: reason, force: !!force});
    let body = null;
    try { body = await r.json(); } catch (_) {}
    if (r.status === 409 && body && body.detail === 'value_matches_customer') {
      const name = body.customer_name || 'a customer';
      btn.disabled = false;
      if (confirm('WARNING: This ' + match_type.replace('_', ' ') + ' belongs to customer ' + name + '.\n\nIgnore anyway?')) {
        return saveIgnoreSender(true);
      }
      return;
    }
    if (!r.ok) {
      const msg = (body && (body.detail || body.message || (body.value && (Array.isArray(body.value) ? body.value[0] : body.value)) || JSON.stringify(body))) || ('HTTP ' + r.status);
      alert('Failed to add filter: ' + msg);
      return;
    }
    closeIgnoreSenderModal();
    loadIgnoredSenders();
  } catch (e) {
    alert('Network error: ' + (e.message || 'failed'));
  } finally {
    btn.disabled = false;
  }
}

async function unignoreSender(id, label) {
  if (!confirm('Stop ignoring ' + label + '?\n\nFuture messages from this sender will appear in the inbox again.')) return;
  try {
    const r = await apiFetch('/communications/ignored-senders/' + id + '/', 'DELETE');
    if (!r.ok) {
      let body = null;
      try { body = await r.json(); } catch(_) {}
      alert('Failed to unignore: ' + ((body && (body.detail || body.message)) || ('HTTP ' + r.status)));
      return;
    }
    loadIgnoredSenders();
  } catch (e) {
    alert('Network error: ' + (e.message || 'failed'));
  }
}

// --- Feedback Settings ---
async function loadFeedbackSettings(){
  try{
    const d=await api('/satisfaction/settings/');
    document.getElementById('fbAutoSend').checked=d.auto_send;
    document.getElementById('fbSMS').checked=d.send_via_sms;
    document.getElementById('fbEmail').checked=d.send_via_email;
    document.getElementById('fbDelay').value=d.send_delay_hours;
    document.getElementById('fbSMSMsg').value=d.sms_template||'';
    document.getElementById('fbEmailSubj').value=d.email_subject||'';
    document.getElementById('fbEmailMsg').value=d.email_template||'';
    // Rating-triggered actions
    document.getElementById('fbLowThreshold').value=String(d.low_rating_threshold ?? 1);
    document.getElementById('fbLowCreatesTicket').checked=!!d.low_rating_creates_ticket;
    document.getElementById('fbLowTicketPriority').value=d.low_rating_ticket_priority||'high';
    document.getElementById('fbLowTicketCategory').value=d.low_rating_ticket_category||'complaint';
    document.getElementById('fbLowRemovesTech').checked=!!d.low_rating_removes_preferred_tech;
    document.getElementById('fbHighThreshold').value=String(d.high_rating_threshold ?? 5);
    document.getElementById('fbHighSetsPreferred').checked=!!d.high_rating_sets_preferred_tech;
    document.getElementById('fbHighReplacesOthers').checked=!!d.high_rating_replaces_other_preferred;
  }catch(e){console.warn('No feedback settings yet',e)}
  document.getElementById('fbLoading').style.display='none';
  document.getElementById('fbForm').style.display='block';
}
async function saveFeedbackSettings(){
  const body={
    auto_send:document.getElementById('fbAutoSend').checked,
    send_via_sms:document.getElementById('fbSMS').checked,
    send_via_email:document.getElementById('fbEmail').checked,
    send_delay_hours:parseInt(document.getElementById('fbDelay').value),
    sms_template:document.getElementById('fbSMSMsg').value,
    email_subject:document.getElementById('fbEmailSubj').value,
    email_template:document.getElementById('fbEmailMsg').value,
    low_rating_threshold:parseInt(document.getElementById('fbLowThreshold').value),
    low_rating_creates_ticket:document.getElementById('fbLowCreatesTicket').checked,
    low_rating_ticket_priority:document.getElementById('fbLowTicketPriority').value,
    low_rating_ticket_category:document.getElementById('fbLowTicketCategory').value,
    low_rating_removes_preferred_tech:document.getElementById('fbLowRemovesTech').checked,
    high_rating_threshold:parseInt(document.getElementById('fbHighThreshold').value),
    high_rating_sets_preferred_tech:document.getElementById('fbHighSetsPreferred').checked,
    high_rating_replaces_other_preferred:document.getElementById('fbHighReplacesOthers').checked,
  };
  const r=await apiFetch('/satisfaction/settings/','PUT',body);
  const st=document.getElementById('fbStatus');
  if(r.ok){st.textContent='Saved!';st.style.color='#2e7d32';}
  else{const err=await r.json().catch(()=>({})); st.textContent='Save failed: '+(JSON.stringify(err)||r.status); st.style.color='#c62828';}
  st.style.display='inline';setTimeout(()=>st.style.display='none',3000);
}
loadFeedbackSettings();



// --- Sales Tax Matrix ---
let editingTaxId=null;
async function loadTaxRates(){
  try{
    const d=await api('/billing/tax-rates/');
    const rates=d.results||d;
    const tbody=document.getElementById('taxBody');
    if(!rates.length){tbody.innerHTML='<tr><td colspan="10" style="padding:20px;text-align:center;color:var(--text-light)">No tax rates configured. Click "Add Rate" to create one.</td></tr>';return}
    tbody.innerHTML=rates.map(r=>{
      const combined=(parseFloat(r.state_rate)+parseFloat(r.county_rate)+parseFloat(r.city_rate)+parseFloat(r.special_rate)).toFixed(3);
      return `<tr style="border-bottom:1px solid var(--border)">
        <td style="padding:8px;font-weight:600">${r.state}</td>
        <td style="padding:8px">${r.county||'<span style="color:#ccc">—</span>'}</td>
        <td style="padding:8px">${r.city||'<span style="color:#aaa;font-style:italic">All cities</span>'}</td>
        <td style="padding:8px;text-align:right">${parseFloat(r.state_rate).toFixed(3)}%</td>
        <td style="padding:8px;text-align:right">${parseFloat(r.county_rate).toFixed(3)}%</td>
        <td style="padding:8px;text-align:right">${parseFloat(r.city_rate).toFixed(3)}%</td>
        <td style="padding:8px;text-align:right">${parseFloat(r.special_rate).toFixed(3)}%</td>
        <td style="padding:8px;text-align:right;font-weight:700;color:var(--primary)">${combined}%</td>
        <td style="padding:8px;font-size:11px;color:var(--text-light)">${r.notes||''}</td>
        <td style="padding:8px;text-align:right">
          <button type="button" onclick="editTaxRate('${r.id}')" style="border:none;background:none;cursor:pointer;color:var(--primary)" title="Edit"><i class="fas fa-edit"></i></button>
          <button type="button" onclick="deleteTaxRate('${r.id}')" style="border:none;background:none;cursor:pointer;color:#E53935" title="Delete"><i class="fas fa-trash"></i></button>
        </td>
      </tr>`}).join('');
  }catch(e){console.warn('Tax load error',e)}
}
function updateTaxPreview(){
  const s=parseFloat(document.getElementById('txStateRate').value)||0;
  const co=parseFloat(document.getElementById('txCountyRate').value)||0;
  const ci=parseFloat(document.getElementById('txCityRate').value)||0;
  const sp=parseFloat(document.getElementById('txSpecialRate').value)||0;
  document.getElementById('txCombinedPreview').textContent='Combined Rate: '+(s+co+ci+sp).toFixed(3)+'%';
}
function showTaxModal(){
  editingTaxId=null;
  document.getElementById('taxModalTitle').textContent='Add Tax Rate';
  document.getElementById('txState').value='';
  document.getElementById('txCounty').value='';
  document.getElementById('txCity').value='';
  document.getElementById('txStateRate').value='6.000';
  document.getElementById('txCountyRate').value='0.000';
  document.getElementById('txCityRate').value='0.000';
  document.getElementById('txSpecialRate').value='0.000';
  document.getElementById('txNotes').value='';
  updateTaxPreview();
  document.getElementById('taxModal').style.display='flex';
}
function closeTaxModal(){document.getElementById('taxModal').style.display='none'}
async function editTaxRate(id){
  editingTaxId=id;
  const r=await api('/billing/tax-rates/'+id+'/');
  document.getElementById('taxModalTitle').textContent='Edit Tax Rate';
  document.getElementById('txState').value=r.state;
  document.getElementById('txCounty').value=r.county||'';
  document.getElementById('txCity').value=r.city||'';
  document.getElementById('txStateRate').value=parseFloat(r.state_rate).toFixed(3);
  document.getElementById('txCountyRate').value=parseFloat(r.county_rate).toFixed(3);
  document.getElementById('txCityRate').value=parseFloat(r.city_rate).toFixed(3);
  document.getElementById('txSpecialRate').value=parseFloat(r.special_rate).toFixed(3);
  document.getElementById('txNotes').value=r.notes||'';
  updateTaxPreview();
  document.getElementById('taxModal').style.display='flex';
}
async function saveTaxRate(){
  const body={
    state:document.getElementById('txState').value.trim().toUpperCase(),
    county:document.getElementById('txCounty').value.trim(),
    city:document.getElementById('txCity').value.trim(),
    state_rate:document.getElementById('txStateRate').value,
    county_rate:document.getElementById('txCountyRate').value,
    city_rate:document.getElementById('txCityRate').value,
    special_rate:document.getElementById('txSpecialRate').value,
    notes:document.getElementById('txNotes').value.trim()
  };
  if(!body.state){alert('State is required');return}
  if(editingTaxId){await apiFetch('/billing/tax-rates/'+editingTaxId+'/','PATCH',body)}
  else{await apiFetch('/billing/tax-rates/','POST',body)}
  closeTaxModal();loadTaxRates();
}
async function deleteTaxRate(id){if(!confirm('Delete this tax rate?'))return;await apiFetch('/billing/tax-rates/'+id+'/','DELETE');loadTaxRates()}
// Wire up live preview
['txStateRate','txCountyRate','txCityRate','txSpecialRate'].forEach(id=>{
  const el=document.getElementById(id);
  if(el)el.addEventListener('input',updateTaxPreview);
});
loadTaxRates();


function toggleSmtp(){var p=document.getElementById('nsEmailProvider').value;document.getElementById('smtpFields').style.display=p==='smtp'?'':'none';document.getElementById('sgKeyGroup').style.display=p==='sendgrid'?'':'none'}
function toggleSms(){var p=document.getElementById('nsSmsProvider').value;document.getElementById('stFields').style.display=p==='simpletexting'?'':'none';document.getElementById('twilioFields').style.display=p==='twilio'?'':'none'}
async function loadComms(){
  try{var d=await api('/communications/notification-settings/');
  document.getElementById('nsEmailProvider').value=d.email_provider||'smtp';
  document.getElementById('nsFromName').value=d.email_from_name||'';
  document.getElementById('nsFromEmail').value=d.email_from_address||'';
  document.getElementById('nsSmtpHost').value=d.smtp_host||'smtp.gmail.com';
  document.getElementById('nsSmtpPort').value=d.smtp_port||587;
  document.getElementById('nsSmtpUser').value=d.smtp_username||'';
  if(d.smtp_password_set)document.getElementById('nsSmtpPass').placeholder='Password saved (leave blank to keep)';
  document.getElementById('nsSmtpTls').checked=d.smtp_use_tls!==false;
  document.getElementById('nsSmsProvider').value=d.sms_provider||'simpletexting';
  if(d.simpletexting_api_key)document.getElementById('nsStKey').value=d.simpletexting_api_key;
  document.getElementById('nsTwSid').value=d.twilio_account_sid||'';
  document.getElementById('nsTwPhone').value=d.twilio_phone_number||'';
  toggleSmtp();toggleSms();
  }catch(e){console.warn('Failed to load comms settings',e)}
}
async function saveComms(){
  var body={email_provider:document.getElementById('nsEmailProvider').value,email_from_name:document.getElementById('nsFromName').value,email_from_address:document.getElementById('nsFromEmail').value,smtp_host:document.getElementById('nsSmtpHost').value,smtp_port:document.getElementById('nsSmtpPort').value,smtp_username:document.getElementById('nsSmtpUser').value,smtp_use_tls:document.getElementById('nsSmtpTls').checked,sms_provider:document.getElementById('nsSmsProvider').value};
  var pw=document.getElementById('nsSmtpPass').value;if(pw)body.smtp_password=pw;
  var stk=document.getElementById('nsStKey').value;if(stk&&!stk.startsWith('***'))body.simpletexting_api_key=stk;
  var twsid=document.getElementById('nsTwSid').value;if(twsid)body.twilio_account_sid=twsid;
  var twt=document.getElementById('nsTwToken').value;if(twt)body.twilio_auth_token=twt;
  var twp=document.getElementById('nsTwPhone').value;if(twp)body.twilio_phone_number=twp;
  var sgk=document.getElementById('nsSgKey').value;if(sgk)body.sendgrid_api_key=sgk;
  try{var resp=await apiFetch('/communications/notification-settings/save/','POST',body);var r=await resp.json();
  document.getElementById('commsMsg').textContent='Settings saved!';setTimeout(()=>document.getElementById('commsMsg').textContent='',3000);
  }catch(e){alert('Save failed: '+e.message)}
}
async function testEmail(){
  var to=prompt('Send test email to:',document.getElementById('nsFromEmail').value||'');
  if(!to)return;
  try{var resp=await apiFetch('/communications/test-email/','POST',{to:to});var r=await resp.json();
  if(r.success){alert('Test email sent to '+to+'!')}else{alert('Failed: '+(r.error||r.detail||JSON.stringify(r)))}
  }catch(e){alert('Failed: '+e.message)}
}

async function testMsgTemplate(ttype,ch){
  var wrapper=document.querySelector('.tpl-edit[data-tpl-type="'+ttype+'"]');
  if(!wrapper)return;
  var el=wrapper.querySelector('.rich-edit');
  var body=tagsToVars(el);
  if(!body.trim()){alert('Template body is empty — nothing to send.');return;}
  if(ch==='sms'){
    var phone=(document.getElementById('sPhone')||{}).value||'';
    if(!phone){alert('No company phone set. Add it under Company Information.');return;}
    try{
      var resp=await apiFetch('/communications/test-sms/','POST',{phone:phone,message:body});
      var d=await resp.json();
      if(d.status==='sent'||d.status==='queued'){alert('Test SMS sent to '+phone+'!');}
      else{alert('Failed: '+(d.error||JSON.stringify(d)));}
    }catch(e){alert('Failed: '+e.message);}
  }else{
    var email=(document.getElementById('sEmail')||{}).value||'';
    if(!email){alert('No company email set. Add it under Company Information.');return;}
    var subjEl=wrapper.querySelector('input[data-subj]');
    var subj=subjEl?subjEl.value:'';
    try{
      var resp=await apiFetch('/communications/test-email/','POST',{to:email,subject:subj,body:body});
      var d=await resp.json();
      if(d.success){alert('Test email sent to '+email+'!');}
      else{alert('Failed: '+(d.error||JSON.stringify(d)));}
    }catch(e){alert('Failed: '+e.message);}
  }
}


// ========== NOTIFICATIONS PANEL ==========
async function loadNotifications(){
  // Load toggles
  try{
    var d=await api('/communications/notification-settings/');
    document.getElementById('ntBooking').checked=d.send_booking_confirmation!==false;
    document.getElementById('ntReschedule').checked=d.send_reschedule_notice!==false;
    document.getElementById('ntCancel').checked=d.send_cancellation_notice!==false;
    document.getElementById('ntCompletion').checked=!!d.send_completion_followup;
    document.getElementById('ntTechAssign').checked=!!d.send_tech_assignment_notice;
    document.getElementById('ntTechJob').checked=d.notify_tech_on_new_job!==false;
    document.getElementById('vcEnabled').checked=!!d.voice_confirm_enabled;
    document.getElementById('vcRequireConsent').checked=d.voice_confirm_require_consent!==false;
    document.getElementById('vcWindowHours').value=(d.voice_confirm_window_hours!=null)?d.voice_confirm_window_hours:24;
    document.getElementById('vcMaxAttempts').value=(d.voice_confirm_max_attempts!=null)?d.voice_confirm_max_attempts:1;
    document.getElementById('vcCallStart').value=d.voice_confirm_call_start||'09:00';
    document.getElementById('vcCallEnd').value=d.voice_confirm_call_end||'19:00';
  }catch(e){}
  // Load templates
  try{
    var resp=await fetch(API+'/communications/templates/',{credentials:'same-origin',headers:hdr('GET')});
    var d=await resp.json();var items=d.results||d;
    var types=[
      {type:'confirmation_sms',label:'Booking Confirmation (SMS)',ch:'sms'},
      {type:'confirmation_email',label:'Booking Confirmation (Email)',ch:'email'},
      {type:'reminder_sms',label:'Appointment Reminder (SMS)',ch:'sms'},
      {type:'reminder_email',label:'Appointment Reminder (Email)',ch:'email'},
      {type:'reschedule_sms',label:'Reschedule Notice (SMS)',ch:'sms'},
      {type:'reschedule_email',label:'Reschedule Notice (Email)',ch:'email'},
      {type:'cancellation_sms',label:'Cancellation Notice (SMS)',ch:'sms'},
      {type:'cancellation_email',label:'Cancellation Notice (Email)',ch:'email'},
      {type:'completion_sms',label:'Job Completed (SMS)',ch:'sms'},
      {type:'completion_email',label:'Job Completed (Email)',ch:'email'},
      {type:'tech_new_job_sms',label:'Tech New Job (SMS)',ch:'sms'},
    ];
    var grid=document.getElementById('msgTemplatesGrid');
    grid.innerHTML=types.map(function(t){
      var existing=items.find(function(i){return i.template_type===t.type&&i.is_default});
      var rawBody=existing?existing.body:'';
      var subj=existing?existing.subject||'':'';
      var id=existing?existing.id:'';
      var chColor=t.ch==='sms'?'background:#E8F5E9;color:#2E7D32':'background:#E3F2FD;color:#1565C0';
      var icon=t.ch==='sms'?'fa-comment-dots':'fa-envelope';
      // Convert {var} to visual pills for display
      var displayBody=stripHtmlForEdit(rawBody);
      var subjRow=t.ch==='email'?'<div class="subj-row"><input data-subj="'+t.type+'" value="'+(subj||'').replace(/"/g,'&quot;')+'" placeholder="Email subject line..."></div>':'';
      var testDest=t.ch==='sms'?'company phone':'company email';
      return '<div class="tpl-edit" data-tpl-type="'+t.type+'" data-tpl-id="'+id+'">'+
        '<div class="tpl-header"><h4><i class="fas '+icon+'" style="margin-right:6px;color:'+(t.ch==='sms'?'#2E7D32':'#1565C0')+'"></i>'+t.label+'</h4><div style="display:flex;align-items:center;gap:8px"><span class="channel-badge" style="'+chColor+'">'+t.ch.toUpperCase()+'</span><button type="button" class="btn-tpl-test" onclick="testMsgTemplate(\''+t.type+'\',\''+t.ch+'\')" title="Send a test to the '+testDest+' from Company Information"><i class="fas fa-paper-plane"></i> Send Test</button></div></div>'+
        subjRow+
        '<div class="tpl-body"><div class="rich-edit" contenteditable="true" data-type="'+t.type+'" data-placeholder="Type your message here...">'+ varToTags(displayBody)+'</div></div></div>';
    }).join('');
    initDragDrop();
  }catch(e){console.warn('Failed to load templates',e)}
  // Load reminder rules
  try{
    var resp=await fetch(API+'/communications/reminder-rules/',{credentials:'same-origin',headers:hdr('GET')});
    var d=await resp.json();var rules=d.results||d;
    renderReminderRules(rules);
  }catch(e){}
}

async function saveNotifToggles(){
  var body={
    send_booking_confirmation:document.getElementById('ntBooking').checked,
    send_reschedule_notice:document.getElementById('ntReschedule').checked,
    send_cancellation_notice:document.getElementById('ntCancel').checked,
    send_completion_followup:document.getElementById('ntCompletion').checked,
    send_tech_assignment_notice:document.getElementById('ntTechAssign').checked,
    notify_tech_on_new_job:document.getElementById('ntTechJob').checked
  };
  var resp=await apiFetch('/communications/notification-settings/save/','POST',body);
  document.getElementById('toggleMsg').textContent='Saved!';
  setTimeout(function(){document.getElementById('toggleMsg').textContent=''},2000);
}

async function saveVoiceConfirm(){
  var body={
    voice_confirm_enabled:document.getElementById('vcEnabled').checked,
    voice_confirm_require_consent:document.getElementById('vcRequireConsent').checked,
    voice_confirm_window_hours:parseInt(document.getElementById('vcWindowHours').value,10)||24,
    voice_confirm_max_attempts:parseInt(document.getElementById('vcMaxAttempts').value,10)||1,
    voice_confirm_call_start:document.getElementById('vcCallStart').value||'09:00',
    voice_confirm_call_end:document.getElementById('vcCallEnd').value||'19:00'
  };
  var m=document.getElementById('vcMsg');
  try{
    var resp=await apiFetch('/communications/notification-settings/save/','POST',body);
    if(!resp.ok){var er=await resp.json().catch(function(){return {};});throw new Error(er.error||'save failed');}
    if(m){m.style.color='#2e7d32';m.textContent='Saved!';setTimeout(function(){m.textContent=''},2000);}
  }catch(e){if(m){m.style.color='#c62828';m.textContent='Save failed: '+e.message;}}
}

function stripHtmlForEdit(html){
  // Convert HTML email to plain readable text for the editor
  var t=html||'';
  t=t.replace(/<br\s*\/?>/gi,'\n');
  t=t.replace(/<\/p>\s*<p[^>]*>/gi,'\n\n');
  t=t.replace(/<[^>]+>/g,'');
  t=t.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&').replace(/&quot;/g,'"');
  return t.trim();
}
function varToTags(text){
  // Convert {variable} to styled pill spans
  return (text||'').replace(/\{(\w+)\}/g, function(m,v){
    var cls=v==='booking_url'?'var-tag link-var':'var-tag';
    return '<span class="'+cls+'" contenteditable="false" data-var="{'+v+'}">'+varLabel(v)+'</span>';
  });
}
function varLabel(v){
  var labels={customer_first:'Customer First Name',customer_name:'Full Name',service_date:'Date',service_time:'Time',service_type:'Service Type',technician_name:'Technician',company_name:'Company',company_phone:'Phone',location:'Location',duration:'Duration',booking_url:'Booking Link'};
  return labels[v]||v;
}
function tagsToVars(el){
  // Convert editor content back to {variable} text
  var clone=el.cloneNode(true);
  clone.querySelectorAll('.var-tag').forEach(function(tag){
    tag.replaceWith(tag.getAttribute('data-var')||tag.textContent);
  });
  return clone.textContent||clone.innerText||'';
}
function textToEmailHtml(text){
  // Convert plain text with {vars} to styled HTML for emails
  var lines=text.split('\n');
  var html=lines.map(function(l){return '<p>'+l.replace(/\{(\w+)\}/g,function(m){return '<strong>'+m+'</strong>'})+'</p>';}).join('');
  return html;
}
function initDragDrop(){
  // Variable pills drag
  document.querySelectorAll('.var-pill').forEach(function(pill){
    pill.addEventListener('dragstart',function(e){
      e.dataTransfer.setData('text/plain',pill.getAttribute('data-var'));
      e.dataTransfer.effectAllowed='copy';
    });
    pill.addEventListener('click',function(){
      // Insert at cursor in focused editor
      var active=document.querySelector('.rich-edit:focus');
      if(!active){
        // Find first visible editor
        active=document.querySelector('.rich-edit');
      }
      if(active){
        active.focus();
        var varCode=pill.getAttribute('data-var');
        var vName=varCode.replace(/[{}]/g,'');
        var cls=vName==='booking_url'?'var-tag link-var':'var-tag';
        var tag=document.createElement('span');
        tag.className=cls;
        tag.contentEditable='false';
        tag.setAttribute('data-var',varCode);
        tag.textContent=varLabel(vName);
        var sel=window.getSelection();
        if(sel.rangeCount){
          var range=sel.getRangeAt(0);
          range.deleteContents();
          range.insertNode(tag);
          range.setStartAfter(tag);
          range.collapse(true);
          sel.removeAllRanges();
          sel.addRange(range);
          // Add space after
          var space=document.createTextNode(' ');
          tag.parentNode.insertBefore(space,tag.nextSibling);
        }
      }
    });
  });
  // Drop on editors
  document.querySelectorAll('.rich-edit').forEach(function(ed){
    ed.addEventListener('dragover',function(e){e.preventDefault();e.dataTransfer.dropEffect='copy';ed.style.background='#f0fff0';});
    ed.addEventListener('dragleave',function(){ed.style.background='';});
    ed.addEventListener('drop',function(e){
      e.preventDefault();ed.style.background='';
      var varCode=e.dataTransfer.getData('text/plain');
      if(!varCode.startsWith('{'))return;
      var vName=varCode.replace(/[{}]/g,'');
      var cls=vName==='booking_url'?'var-tag link-var':'var-tag';
      var tag=document.createElement('span');
      tag.className=cls;tag.contentEditable='false';
      tag.setAttribute('data-var',varCode);tag.textContent=varLabel(vName);
      // Insert at drop position
      var range;
      if(document.caretRangeFromPoint){range=document.caretRangeFromPoint(e.clientX,e.clientY)}
      else if(e.rangeParent){range=document.createRange();range.setStart(e.rangeParent,e.rangeOffset)}
      if(range){range.insertNode(tag);var sp=document.createTextNode(' ');tag.parentNode.insertBefore(sp,tag.nextSibling)}
      else{ed.appendChild(tag);ed.appendChild(document.createTextNode(' '))}
    });
  });
}
async function saveMsgTemplates(){
  var editors=document.querySelectorAll('.rich-edit[data-type]');
  for(var i=0;i<editors.length;i++){
    var el=editors[i];
    var ttype=el.getAttribute('data-type');
    var wrapper=el.closest('.tpl-edit');
    var tid=wrapper.getAttribute('data-tpl-id');
    var plainBody=tagsToVars(el);
    // For email types, wrap in basic HTML
    var isEmail=ttype.indexOf('email')>=0;
    var body=isEmail?textToEmailHtml(plainBody):plainBody;
    var subjEl=wrapper.querySelector('input[data-subj]');
    var subj=subjEl?subjEl.value:'';
    var payload={template_type:ttype,body:body,subject:subj,is_default:true,is_active:true,name:ttype.replace(/_/g,' ')};
    if(tid){
      await apiFetch('/communications/templates/'+tid+'/','PATCH',payload);
    }else{
      var r=await apiFetch('/communications/templates/','POST',payload);
      var d=await r.json();
      if(d.id)wrapper.setAttribute('data-tpl-id',d.id);
    }
  }
  document.getElementById('tplMsg').textContent='Templates saved!';
  setTimeout(function(){document.getElementById('tplMsg').textContent=''},3000);
}

function renderReminderRules(rules){
  var grid=document.getElementById('reminderRulesGrid');
  if(!rules.length){grid.innerHTML='<div style="color:var(--text-light);font-size:13px;padding:12px">No rules yet. Click Add Reminder.</div>';return}
  grid.innerHTML=rules.map(function(r){
    var mode=r.timing_mode||'before';var sat=r.send_at_time||'09:00';
    var chIcon=r.channel==='sms'?'fa-comment-dots':(r.channel==='email'?'fa-envelope':'fa-bell');
    var chLabel={sms:'SMS',email:'Email',both:'SMS + Email'}[r.channel]||'SMS';
    return '<div class="rule-card" data-rule-id="'+r.id+'"><div class="rule-card-header"><div style="display:flex;align-items:center;gap:8px"><i class="fas '+chIcon+'" style="color:var(--accent)"></i><strong style="font-size:13px">'+chLabel+' Reminder</strong></div><div style="display:flex;gap:6px;align-items:center"><label style="font-size:11px;display:flex;align-items:center;gap:4px;cursor:pointer" title="Stop reminders once confirmed"><input type="checkbox" class="rr-skipconfirm"'+(r.skip_if_confirmed?' checked':'')+' style="accent-color:#FF9800"> Stop if confirmed</label><label style="font-size:11px;display:flex;align-items:center;gap:4px;cursor:pointer"><input type="checkbox" class="rr-active"'+(r.is_active?' checked':'')+' style="accent-color:var(--accent)"> Active</label><button type="button" onclick="saveRule(this)" class="rule-btn"><i class="fas fa-save"></i></button><button type="button" onclick="deleteRule(this)" class="rule-btn rule-btn-del"><i class="fas fa-trash"></i></button></div></div>'+
    '<div class="rule-card-body"><div class="rule-field"><label>When to Send</label><select class="rr-mode" onchange="toggleRuleMode(this)"><option value="before"'+(mode==='before'?' selected':'')+'>Time before appointment</option><option value="day_before_at"'+(mode==='day_before_at'?' selected':'')+'>Day(s) before at exact time</option><option value="exact_time"'+(mode==='exact_time'?' selected':'')+'>Exact time on appointment day</option></select></div>'+
    '<div class="rule-field"><label>Channel</label><select class="rr-ch"><option value="sms"'+(r.channel==='sms'?' selected':'')+'>SMS</option><option value="email"'+(r.channel==='email'?' selected':'')+'>Email</option><option value="both"'+(r.channel==='both'?' selected':'')+'>SMS + Email</option></select></div>'+
    '<div class="rule-before-fields" style="'+(mode==='before'?'':'display:none')+'"><div class="rule-field"><label>Send</label><div style="display:flex;gap:6px"><input type="number" value="'+r.timing_value+'" min="1" class="rr-val" style="width:60px"><select class="rr-unit"><option value="minutes"'+(r.timing_unit==='minutes'?' selected':'')+'>Min</option><option value="hours"'+(r.timing_unit==='hours'?' selected':'')+'>Hours</option><option value="days"'+(r.timing_unit==='days'?' selected':'')+'>Days</option></select><span style="font-size:12px;color:var(--text-light);align-self:center">before</span></div></div></div>'+
    '<div class="rule-dayat-fields" style="'+(mode==='day_before_at'?'':'display:none')+'"><div class="rule-field"><label>Days Before</label><input type="number" value="'+(r.days_before||1)+'" min="1" max="30" class="rr-daysbefore" style="width:60px"></div><div class="rule-field"><label>Send At</label><input type="time" value="'+sat+'" class="rr-sendat"></div></div>'+
    '<div class="rule-exact-fields" style="'+(mode==='exact_time'?'':'display:none')+'"><div class="rule-field"><label>Send At (appt day)</label><input type="time" value="'+sat+'" class="rr-sendat-exact"></div></div></div></div>';
  }).join('');
}
function toggleRuleMode(sel){var c=sel.closest('.rule-card'),m=sel.value;c.querySelector('.rule-before-fields').style.display=m==='before'?'':'none';c.querySelector('.rule-dayat-fields').style.display=m==='day_before_at'?'':'none';c.querySelector('.rule-exact-fields').style.display=m==='exact_time'?'':'none';}

async function saveRule(btn){
  var card=btn.closest('.rule-card');var id=card.getAttribute('data-rule-id');
  var mode=card.querySelector('.rr-mode').value;
  var body={timing_mode:mode,channel:card.querySelector('.rr-ch').value,is_active:card.querySelector('.rr-active').checked,skip_if_confirmed:card.querySelector('.rr-skipconfirm').checked,timing_value:parseInt(card.querySelector('.rr-val').value)||24,timing_unit:card.querySelector('.rr-unit').value||'hours'};
  if(mode==='day_before_at'){body.days_before=parseInt(card.querySelector('.rr-daysbefore').value)||1;body.send_at_time=card.querySelector('.rr-sendat').value||'09:00'}
  else if(mode==='exact_time'){body.send_at_time=card.querySelector('.rr-sendat-exact').value||'08:00'}
  body.name=mode==='before'?body.timing_value+' '+body.timing_unit+' before':(mode==='day_before_at'?body.days_before+' day(s) before at '+(body.send_at_time||''):'Same day at '+(body.send_at_time||''));
  await apiFetch('/communications/reminder-rules/'+id+'/','PATCH',body);
  document.getElementById('ruleMsg').textContent='Rule saved!';setTimeout(function(){document.getElementById('ruleMsg').textContent=''},2000);
}

async function deleteRule(btn){
  if(!confirm('Delete this reminder rule?'))return;
  var card=btn.closest('.rule-card');
  var id=card.getAttribute('data-rule-id');
  await apiFetch('/communications/reminder-rules/'+id+'/','DELETE');
  card.remove();
}

async function addReminderRule(){
  var body={name:'New reminder',timing_mode:'before',timing_value:24,timing_unit:'hours',channel:'sms',is_active:true,order:0,days_before:1};
  try{
    var resp=await apiFetch('/communications/reminder-rules/','POST',body);
    if(!resp.ok){var err=await resp.json();console.error('Add rule error:',err);alert('Error: '+JSON.stringify(err));return}
    var resp2=await fetch(API+'/communications/reminder-rules/',{credentials:'same-origin',headers:hdr('GET')});
    var d2=await resp2.json();
    renderReminderRules(d2.results||d2);
  }catch(e){alert('Failed to add reminder: '+e.message)}
}


// ======== Phone System Config ========
let phoneConfigId = null;
async function loadPhoneConfig(){
  try{
    const d = await api('/communications/phone-server-config/');
    const items = d.results || d;
    const state = document.getElementById('phoneConfigState');
    if(items && items.length){
      const c = items[0];
      phoneConfigId = c.id;
      document.getElementById('phProvider').value = c.provider || 'freepbx';
      document.getElementById('phHost').value = c.host || '';
      document.getElementById('phAmiPort').value = c.ami_port || 5038;
      document.getElementById('phAmiUser').value = c.ami_username || '';
      document.getElementById('phAmiPass').value = '';
      document.getElementById('phAmiPassHelp').textContent = c.ami_password_set ?
        'A password is saved. Leave blank to preserve it; enter a new one to replace.' :
        'No password saved yet. Enter one below.';
      document.getElementById('phWebhookUrl').value = c.webhook_url || '';
      document.getElementById('phWebhookSecret').value = c.webhook_secret || '';
      document.getElementById('phClickToCall').checked = !!c.click_to_call_enabled;
      document.getElementById('phScreenPop').checked = !!c.screen_pop_enabled;
      document.getElementById('phActive').checked = !!c.is_active;

      let stateHtml = '<strong>Status:</strong> ' + (c.is_active ? '<span style="color:#2e7d32">Active</span>' : '<span style="color:#c62828">Inactive</span>');
      if(c.last_tested_at){
        const when = new Date(c.last_tested_at).toLocaleString();
        stateHtml += ' &nbsp;·&nbsp; <strong>Last test:</strong> ' +
          (c.last_test_result === 'ok' ? '<span style="color:#2e7d32">✓ OK</span>' : '<span style="color:#c62828">✗ '+(c.last_test_error||'failed')+'</span>') +
          ' at ' + when;
      } else {
        stateHtml += ' &nbsp;·&nbsp; <em>Never tested</em>';
      }
      state.innerHTML = stateHtml;
    } else {
      phoneConfigId = null;
      state.innerHTML = '<em>No phone server configured. Fill out the form and click Save.</em>';
    }
  }catch(e){
    document.getElementById('phoneConfigState').innerHTML = '<span style="color:#c62828">Failed to load: ' + e + '</span>';
  }
}

async function savePhoneConfig(){
  const msg = document.getElementById('phoneMsg');
  msg.textContent = 'Saving…'; msg.style.color = '#555';
  const body = {
    provider: document.getElementById('phProvider').value,
    host: document.getElementById('phHost').value.trim(),
    ami_port: parseInt(document.getElementById('phAmiPort').value) || 5038,
    ami_username: document.getElementById('phAmiUser').value.trim(),
    ami_password: document.getElementById('phAmiPass').value,
    click_to_call_enabled: document.getElementById('phClickToCall').checked,
    screen_pop_enabled: document.getElementById('phScreenPop').checked,
    is_active: document.getElementById('phActive').checked,
  };
  if(!body.host){ msg.style.color='#c62828'; msg.textContent='Host is required.'; return; }
  try{
    if(phoneConfigId){
      await apiFetch('/communications/phone-server-config/' + phoneConfigId + '/', 'PATCH', body);
    } else {
      await apiFetch('/communications/phone-server-config/', 'POST', body);
    }
    msg.style.color='#2e7d32'; msg.textContent='Saved.';
    await loadPhoneConfig();
  }catch(e){
    msg.style.color='#c62828'; msg.textContent='Save failed: ' + e;
  }
}

async function testPhoneConnection(){
  const msg = document.getElementById('phoneMsg');
  if(!phoneConfigId){ msg.style.color='#c62828'; msg.textContent='Save configuration first.'; return; }
  msg.textContent = 'Testing…'; msg.style.color='#555';
  try{
    const r = await apiFetch('/communications/phone-server-config/' + phoneConfigId + '/test-connection/', 'POST', {});
    if(r.ok){
      msg.style.color='#2e7d32'; msg.textContent = '✓ ' + (r.banner || 'Reachable');
    } else {
      msg.style.color='#c62828'; msg.textContent = '✗ ' + (r.banner || 'Unreachable');
    }
    setTimeout(loadPhoneConfig, 500);
  }catch(e){
    msg.style.color='#c62828'; msg.textContent='Test failed: ' + e;
  }
}

async function regenWebhookSecret(){
  if(!phoneConfigId){ return; }
  if(!confirm('Regenerate webhook secret? The old one will stop working immediately and you must update your PBX dialplan.')) return;
  try{
    const r = await apiFetch('/communications/phone-server-config/' + phoneConfigId + '/regenerate-webhook-secret/', 'POST', {});
    document.getElementById('phWebhookSecret').value = r.webhook_secret;
    toast && toast('New webhook secret generated', 'success');
  }catch(e){ alert('Failed: ' + e); }
}

function copyWebhookUrl(){
  const el = document.getElementById('phWebhookUrl');
  el.select(); document.execCommand('copy');
  const msg = document.getElementById('phoneMsg');
  msg.style.color='#2e7d32'; msg.textContent='URL copied.';
  setTimeout(()=>{ if(msg.textContent==='URL copied.') msg.textContent=''; }, 2000);
}
function copyWebhookSecret(){
  const el = document.getElementById('phWebhookSecret');
  el.select(); document.execCommand('copy');
  const msg = document.getElementById('phoneMsg');
  msg.style.color='#2e7d32'; msg.textContent='Secret copied.';
  setTimeout(()=>{ if(msg.textContent==='Secret copied.') msg.textContent=''; }, 2000);
}

// Load on page ready
(typeof loadPhoneConfig === 'function') && setTimeout(loadPhoneConfig, 500);

  async function loadListenerHealth(){
    const el = document.getElementById('phListenerHealth');
    if(!el) return;
    el.textContent = 'checking…';
    el.style.color = '#888';
    try{
      const d = await api('/communications/phone/listener-health/');
      if(d.alive){
        el.innerHTML = '<span style="color:#2e7d32;font-weight:600">✓ Connected</span>' +
          ' <span style="color:#666;font-size:11px">· ' +
          (d.events_processed||0) + ' events · last event ' + (d.last_event_age_sec||0) + 's ago · ' + (d.tracked_calls||0) + ' calls tracked</span>';
      } else {
        el.innerHTML = '<span style="color:#c62828;font-weight:600">✗ Not connected</span>' +
          ' <span style="color:#666;font-size:11px">· ' + (d.message||'(check ami-listener container)') + '</span>';
      }
    }catch(e){
      el.innerHTML = '<span style="color:#c62828;font-weight:600">✗ Error</span> <span style="color:#666">' + e + '</span>';
    }
  }
  setTimeout(loadListenerHealth, 1500);
  setInterval(loadListenerHealth, 30000);


// ---- Deep-link panels via URL hash fragment ----
// Every sidebar link has href="#<panel-name>" so Cmd+click and direct
// URL access both work. Read location.hash on initial page load and
// switch to that panel if it matches a known panel id.
//
// Browser default behavior keeps the hash in sync with subsequent plain
// clicks for free (the SPA loader correctly bails on hash hrefs).
(function _restorePanelFromHash() {
  var raw = (window.location.hash || '').replace(/^#/, '').trim();
  if (!raw) return;
  // Resolve to the matching nav link element. We re-use the existing
  // showPanel(name, el) signature so the active-class swap and any
  // panel-specific loaders run the same way as a plain click.
  var link = document.querySelector('.settings-nav a[onclick*="showPanel(\'' + raw + '\',"]');
  if (!link) return;
  // showPanel might not be defined yet at parse-time depending on order;
  // queue it on the next tick. The settings.html script defines showPanel
  // synchronously before this block, but defer is cheap insurance.
  setTimeout(function() {
    try { showPanel(raw, link); } catch (e) { console.warn('hash deep-link failed:', e); }
  }, 0);
})();


// ===========================================================================
// SLA Admin: SLA Policy, Departments, Category Routing, Escalation Routes
// ===========================================================================

// All endpoints live under /api/v1/tickets/sla/*. The IsCompanyAdmin
// permission is enforced server-side; non-admins reach 403 even if they
// somehow load this template (which itself is gated by PAGE_PERMISSIONS).

const SLA_CATEGORY_LABELS = {
  service_issue:    'Service Issue',
  warranty:         'Warranty',
  damage_claim:     'Damage Claim',
  billing:          'Billing',
  scheduling:       'Scheduling',
  complaint:        'Complaint',
  callback_request: 'Callback Request',
  general_inquiry:  'General Inquiry',
  cancellation:     'Cancellation',
  other:            'Other',
};

// Cache loaded data so dependent panels (routes uses depts+offices+users) can
// reuse without re-fetching. Cleared on mutations.
const _slaCache = {departments: null, offices: null, managers: null};

function _slaUnpaginate(resp) {
  // Handle DRF pagination wrapping
  return Array.isArray(resp) ? resp : (resp.results || []);
}

// ---------- SLA Policy panel ----------
async function loadSLAPolicy() {
  const loadingEl = document.getElementById('slaPolicyLoading');
  const formEl    = document.getElementById('slaPolicyForm');
  if (!loadingEl || !formEl) return;  // panel not in DOM yet — bail safely
  loadingEl.style.display = 'block';
  formEl.style.display = 'none';
  let ok = false;
  try {
    const resp = await api('/tickets/sla/policy/');
    const items = _slaUnpaginate(resp);
    if (!items.length) {
      console.warn('SLA policy: empty response');
      return;
    }
    const p = items[0];
    document.getElementById('slaUrgentResp').value  = p.urgent_response_min;
    document.getElementById('slaUrgentResol').value = p.urgent_resolution_min;
    document.getElementById('slaHighResp').value    = p.high_response_min;
    document.getElementById('slaHighResol').value   = p.high_resolution_min;
    document.getElementById('slaMediumResp').value  = p.medium_response_min;
    document.getElementById('slaMediumResol').value = p.medium_resolution_min;
    document.getElementById('slaLowResp').value     = p.low_response_min;
    document.getElementById('slaLowResol').value    = p.low_resolution_min;
    document.getElementById('_slaPolicyId').value   = p.id;
    ok = true;
  } catch (e) {
    if (e && e.name === 'AbortError') return;  // navigation interrupt; another load will follow
    console.error('Failed to load SLA policy:', e);
  } finally {
    loadingEl.style.display = 'none';
    formEl.style.display = ok ? 'block' : 'block';  // show form anyway so user can save manually
  }
}
async function saveSLAPolicy() {
  const id = document.getElementById('_slaPolicyId').value;
  const body = {
    urgent_response_min:  +document.getElementById('slaUrgentResp').value,
    urgent_resolution_min:+document.getElementById('slaUrgentResol').value,
    high_response_min:    +document.getElementById('slaHighResp').value,
    high_resolution_min:  +document.getElementById('slaHighResol').value,
    medium_response_min:  +document.getElementById('slaMediumResp').value,
    medium_resolution_min:+document.getElementById('slaMediumResol').value,
    low_response_min:     +document.getElementById('slaLowResp').value,
    low_resolution_min:   +document.getElementById('slaLowResol').value,
  };
  const r = await apiFetch('/tickets/sla/policy/' + id + '/', 'PATCH', body);
  const status = document.getElementById('slaPolicyStatus');
  if (r.ok) { status.textContent = 'Saved.'; setTimeout(() => status.textContent = '', 3000); }
  else { status.style.color = '#c62828'; status.textContent = 'Save failed (' + r.status + ').'; }
}

// ---------- Departments panel ----------
let _editingDeptId = null;
async function loadDepartments() {
  const loadingEl = document.getElementById('deptLoading');
  const listEl    = document.getElementById('deptList');
  if (!loadingEl || !listEl) return;
  loadingEl.style.display = 'block';
  listEl.innerHTML = '';
  try {
    const resp = await api('/tickets/sla/departments/');
    const items = _slaUnpaginate(resp);
    _slaCache.departments = items;
    document.getElementById('deptList').innerHTML = items.length ? items.map(d => `
      <div style="background:var(--white);padding:14px;border-radius:8px;border:1px solid var(--border)">
        <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:6px">
          <div>
            <div style="font-weight:600;font-size:14px">${_esc(d.name)}</div>
            <div style="font-family:monospace;font-size:11px;color:var(--text-light);margin-top:2px">${_esc(d.slug)}</div>
          </div>
          <span class="badge ${d.is_active ? 'badge-green' : 'badge-orange'}">${d.is_active ? 'Active' : 'Inactive'}</span>
        </div>
        <div style="display:flex;gap:8px;margin-top:10px">
          <button type="button" onclick="editDepartment('${d.id}')" style="flex:1;padding:6px;background:#f5f5f5;border:1px solid var(--border);border-radius:6px;cursor:pointer;font-size:12px"><i class="fas fa-edit"></i> Edit</button>
          <button type="button" onclick="deleteDepartment('${d.id}','${_esc(d.name)}')" style="padding:6px 10px;background:#fff;border:1px solid var(--border);border-radius:6px;cursor:pointer;color:#c62828;font-size:12px"><i class="fas fa-trash"></i></button>
        </div>
      </div>
    `).join('') : '<div style="grid-column:1/-1;color:var(--text-light);text-align:center;padding:20px">No departments. Click "Add Department" to create one.</div>';
  } catch (e) {
    if (e && e.name === 'AbortError') return;
    console.error('Failed to load departments:', e);
    listEl.innerHTML = '<div style="color:#c62828;padding:12px;font-size:12px">Failed to load. Try a different panel and come back.</div>';
  } finally {
    loadingEl.style.display = 'none';
  }
}
function showDeptModal() {
  _editingDeptId = null;
  document.getElementById('deptModalTitle').textContent = 'Add Department';
  document.getElementById('dName').value = '';
  document.getElementById('dSlug').value = '';
  document.getElementById('dActive').checked = true;
  document.getElementById('deptModal').style.display = 'flex';
}
function closeDeptModal() { document.getElementById('deptModal').style.display = 'none'; }
async function editDepartment(id) {
  _editingDeptId = id;
  const d = await api('/tickets/sla/departments/' + id + '/');
  document.getElementById('deptModalTitle').textContent = 'Edit Department';
  document.getElementById('dName').value = d.name;
  document.getElementById('dSlug').value = d.slug;
  document.getElementById('dActive').checked = d.is_active;
  document.getElementById('deptModal').style.display = 'flex';
}
async function saveDepartment() {
  const body = {
    name: document.getElementById('dName').value.trim(),
    slug: document.getElementById('dSlug').value.trim().toLowerCase().replace(/[^a-z0-9_]/g, '_'),
    is_active: document.getElementById('dActive').checked,
  };
  if (!body.name || !body.slug) { alert('Name and slug are required.'); return; }
  const r = _editingDeptId
    ? await apiFetch('/tickets/sla/departments/' + _editingDeptId + '/', 'PATCH', body)
    : await apiFetch('/tickets/sla/departments/', 'POST', body);
  if (!r.ok) { const t = await r.text(); alert('Save failed: ' + t.substring(0, 200)); return; }
  closeDeptModal();
  _slaCache.departments = null;
  loadDepartments();
}
async function deleteDepartment(id, name) {
  if (!confirm('Delete department "' + name + '"? Tickets pointing here will lose their routing until you re-map their categories.')) return;
  const r = await apiFetch('/tickets/sla/departments/' + id + '/', 'DELETE');
  if (!r.ok && r.status !== 204) { alert('Delete failed (' + r.status + ').'); return; }
  _slaCache.departments = null;
  loadDepartments();
}

// ---------- Category -> Department mapping ----------
async function loadCatMap() {
  const loadingEl = document.getElementById('catMapLoading');
  const tableEl   = document.getElementById('catMapTable');
  if (!loadingEl || !tableEl) return;
  loadingEl.style.display = 'block';
  tableEl.style.display = 'none';
  try {
    if (!_slaCache.departments) {
      const dResp = await api('/tickets/sla/departments/');
      _slaCache.departments = _slaUnpaginate(dResp);
    }
    const mResp = await api('/tickets/sla/category-map/');
    const mappings = _slaUnpaginate(mResp);
    const byCategory = {};
    mappings.forEach(m => byCategory[m.category] = m);
    const deptOpts = _slaCache.departments.filter(d => d.is_active).map(d =>
      `<option value="${d.id}">${_esc(d.name)} (${_esc(d.slug)})</option>`
    ).join('');
    const tbody = document.getElementById('catMapTbody');
    tbody.innerHTML = Object.keys(SLA_CATEGORY_LABELS).map(cat => {
      const m = byCategory[cat];
      const sel = m && m.department ? m.department : '';
      return `
        <tr style="border-top:1px solid var(--border)">
          <td style="padding:10px"><strong>${_esc(SLA_CATEGORY_LABELS[cat])}</strong><div style="font-family:monospace;font-size:11px;color:var(--text-light)">${cat}</div></td>
          <td style="padding:8px"><select onchange="updateCatMap('${cat}','${m ? m.id : ''}',this.value)" style="width:100%;padding:6px;border:1.5px solid var(--border);border-radius:6px;font-size:13px;background:var(--white)"><option value="">— None —</option>${deptOpts.replace(`value="${sel}"`, `value="${sel}" selected`)}</select></td>
          <td style="padding:10px;text-align:right"><span id="catMapStatus_${cat}" style="font-size:11px;color:#2e7d32"></span></td>
        </tr>`;
    }).join('');
    document.getElementById('catMapTable').style.display = 'table';
  } catch (e) {
    if (e && e.name === 'AbortError') return;
    console.error('Failed to load category map:', e);
    const tbody = document.getElementById('catMapTbody');
    if (tbody) tbody.innerHTML = '<tr><td colspan="3" style="color:#c62828;padding:20px">Failed to load. Try a different panel and come back.</td></tr>';
    tableEl.style.display = 'table';
  } finally {
    loadingEl.style.display = 'none';
  }
}
async function updateCatMap(category, existingId, deptId) {
  const status = document.getElementById('catMapStatus_' + category);
  status.style.color = 'var(--text-light)'; status.textContent = 'Saving...';
  let r;
  if (!deptId) {
    if (!existingId) { status.textContent = ''; return; }
    r = await apiFetch('/tickets/sla/category-map/' + existingId + '/', 'DELETE');
  } else if (existingId) {
    r = await apiFetch('/tickets/sla/category-map/' + existingId + '/', 'PATCH', {department: deptId});
  } else {
    r = await apiFetch('/tickets/sla/category-map/', 'POST', {category: category, department: deptId});
  }
  if (r.ok || r.status === 204) {
    status.style.color = '#2e7d32'; status.textContent = '✓ Saved';
    setTimeout(() => status.textContent = '', 2500);
  } else {
    status.style.color = '#c62828'; status.textContent = 'Save failed';
  }
}

// ---------- Escalation Routes ----------
let _editingRouteId = null;
async function loadRoutes() {
  const loadingEl = document.getElementById('routesLoading');
  const tableEl   = document.getElementById('routesTable');
  const emptyEl   = document.getElementById('routesEmpty');
  if (!loadingEl || !tableEl || !emptyEl) return;
  loadingEl.style.display = 'block';
  tableEl.style.display = 'none';
  emptyEl.style.display = 'none';
  try {
    if (!_slaCache.departments) {
      _slaCache.departments = _slaUnpaginate(await api('/tickets/sla/departments/'));
    }
    if (!_slaCache.offices) {
      _slaCache.offices = _slaUnpaginate(await api('/offices/'));
    }
    if (!_slaCache.managers) {
      // Reuse the existing /users/ endpoint if available, fall back to staff list.
      try {
        const u = await api('/tickets/sla/staff/');
        _slaCache.managers = _slaUnpaginate(u);
      } catch (_) {
        _slaCache.managers = [];
      }
    }
    const routes = _slaUnpaginate(await api('/tickets/sla/escalation-routes/'));
    if (!routes.length) {
      document.getElementById('routesEmpty').style.display = 'block';
    } else {
      document.getElementById('routesTbody').innerHTML = routes.map(r => `
        <tr style="border-top:1px solid var(--border)">
          <td style="padding:10px"><strong>${_esc(r.department_name || r.department_slug || '?')}</strong></td>
          <td style="padding:10px">${r.office_name ? _esc(r.office_name) : '<em style="color:var(--text-light)">Any (org-wide)</em>'}</td>
          <td style="padding:10px">${r.manager_name ? _esc(r.manager_name) : '<em style="color:#c62828">No manager set</em>'}</td>
          <td style="padding:10px"><button type="button" onclick="editRoute('${r.id}')" style="padding:4px 10px;background:#f5f5f5;border:1px solid var(--border);border-radius:6px;cursor:pointer;font-size:11px;margin-right:4px"><i class="fas fa-edit"></i></button><button type="button" onclick="deleteRoute('${r.id}')" style="padding:4px 10px;background:#fff;border:1px solid var(--border);border-radius:6px;cursor:pointer;color:#c62828;font-size:11px"><i class="fas fa-trash"></i></button></td>
        </tr>
      `).join('');
      document.getElementById('routesTable').style.display = 'table';
    }
  } catch (e) {
    if (e && e.name === 'AbortError') return;
    console.error('Failed to load escalation routes:', e);
    const tbody = document.getElementById('routesTbody');
    if (tbody) tbody.innerHTML = '<tr><td colspan="4" style="color:#c62828;padding:20px">Failed to load. Try a different panel and come back.</td></tr>';
    tableEl.style.display = 'table';
  } finally {
    loadingEl.style.display = 'none';
  }
}
function _populateRouteSelects() {
  const dSel = document.getElementById('rDept');
  const oSel = document.getElementById('rOffice');
  const mSel = document.getElementById('rManager');
  dSel.innerHTML = '<option value="">— Select department —</option>' + (_slaCache.departments || []).filter(d => d.is_active).map(d => `<option value="${d.id}">${_esc(d.name)}</option>`).join('');
  oSel.innerHTML = '<option value="">Any office (org-wide fallback)</option>' + (_slaCache.offices || []).map(o => `<option value="${o.id}">${_esc(o.name)}</option>`).join('');
  // Filter managers: include staff with role tech_manager, company_admin, or anyone manager-able. We pass through everything the API returns.
  const mgrCandidates = (_slaCache.managers || []).filter(u => u.is_active !== false);
  mSel.innerHTML = '<option value="">— Select manager —</option>' + mgrCandidates.map(u => `<option value="${u.id}">${_esc((u.first_name||'') + ' ' + (u.last_name||'') + ' (' + (u.username||'') + (u.role ? ', ' + u.role : '') + ')')}</option>`).join('');
}
function showRouteModal() {
  _editingRouteId = null;
  _populateRouteSelects();
  document.getElementById('routeModalTitle').textContent = 'Add Escalation Route';
  document.getElementById('rDept').value = '';
  document.getElementById('rOffice').value = '';
  document.getElementById('rManager').value = '';
  document.getElementById('routeModal').style.display = 'flex';
}
function closeRouteModal() { document.getElementById('routeModal').style.display = 'none'; }
async function editRoute(id) {
  _editingRouteId = id;
  _populateRouteSelects();
  const r = await api('/tickets/sla/escalation-routes/' + id + '/');
  document.getElementById('routeModalTitle').textContent = 'Edit Escalation Route';
  document.getElementById('rDept').value = r.department || '';
  document.getElementById('rOffice').value = r.office || '';
  document.getElementById('rManager').value = r.manager || '';
  document.getElementById('routeModal').style.display = 'flex';
}
async function saveRoute() {
  const body = {
    department: document.getElementById('rDept').value,
    office: document.getElementById('rOffice').value || null,
    manager: document.getElementById('rManager').value,
  };
  if (!body.department || !body.manager) { alert('Department and Manager are required.'); return; }
  const r = _editingRouteId
    ? await apiFetch('/tickets/sla/escalation-routes/' + _editingRouteId + '/', 'PATCH', body)
    : await apiFetch('/tickets/sla/escalation-routes/', 'POST', body);
  if (!r.ok) { const t = await r.text(); alert('Save failed: ' + t.substring(0, 200)); return; }
  closeRouteModal();
  loadRoutes();
}
async function deleteRoute(id) {
  if (!confirm('Delete this escalation route?')) return;
  const r = await apiFetch('/tickets/sla/escalation-routes/' + id + '/', 'DELETE');
  if (!r.ok && r.status !== 204) { alert('Delete failed (' + r.status + ').'); return; }
  loadRoutes();
}

// Small HTML-escaper for user-controlled fields rendered into innerHTML
function _esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// Hook the existing showPanel() so SLA panels lazy-load their data
// SLA-aware showPanel.
//
// Why we redefine instead of wrapping window.showPanel:
//   The base.html SPA navigator re-executes inline <script> blocks
//   wrapped in IIFEs. The original `function showPanel(name, el)` is
//   a top-level function declaration in this script — at page load it
//   becomes window.showPanel; after SPA re-injection it becomes a
//   local of the IIFE and window.showPanel is undefined. A wrapper
//   that captures `const _origShowPanel = window.showPanel` then
//   throws on every call. So we make this version self-sufficient.
window.showPanel = function(name, el) {
  // 1. Swap visible panel + active nav link (mirror of the original).
  document.querySelectorAll('.settings-nav a').forEach(function(a){ a.classList.remove('active'); });
  document.querySelectorAll('.settings-panel').forEach(function(p){ p.classList.remove('active'); });
  if (el) el.classList.add('active');
  var target = document.getElementById('panel-' + name);
  if (target) target.classList.add('active');

  // 2. Per-panel lazy data loaders. Each one is guarded with typeof so
  // a missing function (e.g. across SPA navs that lose closures) is a
  // no-op, not a TypeError that breaks subsequent clicks.
  if (name === 'comms'           && typeof loadComms === 'function')           loadComms();
  if (name === 'notifications'   && typeof loadNotifications === 'function')   loadNotifications();
  if (name === 'pricing'         && typeof loadPricing === 'function')         loadPricing();
  if (name === 'inbox-filters'   && typeof loadIgnoredSenders === 'function')  loadIgnoredSenders();
  if (name === 'sla-policy'      && typeof loadSLAPolicy === 'function')       loadSLAPolicy();
  if (name === 'sla-departments' && typeof loadDepartments === 'function')     loadDepartments();
  if (name === 'sla-category-map'&& typeof loadCatMap === 'function')          loadCatMap();
  if (name === 'sla-routes'      && typeof loadRoutes === 'function')          loadRoutes();
  if (name === 'dispatch-lockout'&& typeof loadLockoutPolicy === 'function')   loadLockoutPolicy();
  if (name === 'routing-density' && typeof loadDensitySettings === 'function') loadDensitySettings();

  return false;  // matches original return value (used for href="#" cancellation)
};

// ============================================================
// Routing Density — per-tenant settings panel (bug 9c10791a)
// ============================================================
//
// /current/ creates an empty row on first access so we always have an id.
// Save PUTs the merged payload back.

let _densitySettingsId = null;

async function loadDensitySettings() {
  const loading = document.getElementById('densitySettingsLoading');
  const form    = document.getElementById('densitySettingsForm');
  if (!loading || !form) return;
  loading.style.display = 'block';
  form.style.display = 'none';
  try {
    const cur = await api('/routing/density-settings/current/');
    _densitySettingsId = cur.id || null;
    document.getElementById('densityHullWeight').value = (cur.hull_weight != null) ? cur.hull_weight : '0.6';
    document.getElementById('densityDriveWeight').value = (cur.drive_weight != null) ? cur.drive_weight : '0.4';
    document.getElementById('densityDailyBudget').value = (cur.daily_budget_usd != null) ? cur.daily_budget_usd : '20.00';
    loading.style.display = 'none';
    form.style.display = 'block';
  } catch (e) {
    loading.textContent = 'Failed to load routing density settings.';
    console.warn('Routing density load error', e);
  }
}

async function saveDensitySettings() {
  const status = document.getElementById('densitySettingsStatus');
  const hull   = document.getElementById('densityHullWeight').value;
  const drive  = document.getElementById('densityDriveWeight').value;
  const budget = document.getElementById('densityDailyBudget').value;
  const body = {
    hull_weight: hull,
    drive_weight: drive,
    daily_budget_usd: budget,
  };
  try {
    if (!_densitySettingsId) {
      const r = await apiFetch('/routing/density-settings/', 'POST', body);
      if (!r.ok) {
        const txt = await r.text();
        throw new Error('Save failed (' + r.status + '): ' + txt);
      }
      const j = await r.json();
      _densitySettingsId = j.id;
    } else {
      const r = await apiFetch('/routing/density-settings/' + _densitySettingsId + '/', 'PUT', body);
      if (!r.ok) {
        const txt = await r.text();
        throw new Error('Save failed (' + r.status + '): ' + txt);
      }
    }
    if (status) { status.textContent = 'Saved'; status.style.color = '#2e7d32'; setTimeout(function(){status.textContent='';}, 3000); }
  } catch (e) {
    if (status) { status.textContent = (e.message || 'Save failed'); status.style.color = '#c62828'; }
  }
}

// ============================================================
// Dispatch Lockout Policy — per-tenant settings panel (R15 DL6)
// ============================================================
//
// Loads the current row, populates the form, and PATCHes back on save.
// /current/ creates an empty row on first access so we always have an id.

let _lockoutPolicyId = null;

async function loadLockoutPolicy() {
  const loading = document.getElementById('lockoutPolicyLoading');
  const form    = document.getElementById('lockoutPolicyForm');
  if (!loading || !form) return;
  loading.style.display = 'block';
  form.style.display = 'none';
  try {
    const cur = await api('/compliance/lockout-policy/current/');
    _lockoutPolicyId = cur.id || null;
    document.getElementById('lockoutEnabled').checked = !!cur.enabled;
    const mode = cur.mode === 'block' ? 'block' : 'warn';
    document.querySelectorAll('input[name="lockoutMode"]').forEach(function(r){
      r.checked = (r.value === mode);
    });
    document.getElementById('lockoutGrace').value = (cur.expiry_grace_days != null) ? cur.expiry_grace_days : 0;
    document.getElementById('lockoutCatMatch').checked = (cur.category_match_required !== false);
    loading.style.display = 'none';
    form.style.display = 'block';
  } catch (e) {
    loading.textContent = 'Failed to load Dispatch Lockout policy.';
    console.warn('Lockout policy load error', e);
  }
}

async function saveLockoutPolicy() {
  const status = document.getElementById('lockoutSaveStatus');
  const enabled = document.getElementById('lockoutEnabled').checked;
  const modeEl = document.querySelector('input[name="lockoutMode"]:checked');
  const mode = modeEl ? modeEl.value : 'warn';
  const grace = parseInt(document.getElementById('lockoutGrace').value, 10);
  const catMatch = document.getElementById('lockoutCatMatch').checked;
  const body = {
    enabled: enabled,
    mode: mode,
    expiry_grace_days: isNaN(grace) ? 0 : grace,
    category_match_required: catMatch,
  };
  try {
    if (!_lockoutPolicyId) {
      const r = await apiFetch('/compliance/lockout-policy/', 'POST', body);
      if (!r.ok) {
        const t = await r.text();
        throw new Error('Save failed (' + r.status + '): ' + t.substring(0, 200));
      }
      const j = await r.json();
      _lockoutPolicyId = j.id;
    } else {
      const r = await apiFetch('/compliance/lockout-policy/' + _lockoutPolicyId + '/', 'PATCH', body);
      if (!r.ok) {
        const t = await r.text();
        throw new Error('Save failed (' + r.status + '): ' + t.substring(0, 200));
      }
    }
    if (status) { status.textContent = 'Saved'; status.style.color = '#2e7d32'; setTimeout(function(){status.textContent='';}, 3000); }
  } catch (e) {
    if (status) { status.textContent = (e.message || 'Save failed'); status.style.color = '#c62828'; }
  }
}

// ============================================================
// Property-Type Pricing Rules
// ============================================================
//
// Backs the #pricing settings panel. The panel + modal HTML have
// existed since the initial commit but the JS loaders/handlers were
// never written, so the table stayed on "Loading..." forever and
// "+ New Pricing Rule" was a no-op (loadPricing/openPricingRule
// referenced but undefined).

const _PROPERTY_TYPE_LABELS = {
  house: 'House',
  apartment: 'Apartment',
  multifamily: 'Multifamily',
  retail: 'Retail',
  office: 'Office',
  industrial: 'Industrial',
  restaurant: 'Restaurant',
  hospitality: 'Hospitality',
  land: 'Land',
};
let _editingPricingId = null;
let _pricingJobTypes = [];

async function loadPricing() {
  const tbody = document.getElementById('pricingBody');
  if (!tbody) return;
  try {
    const d = await api('/property-type-pricing/');
    const rows = d.results || d || [];
    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="6" style="padding:30px;text-align:center;color:var(--text-light)">No pricing rules yet. Click "+ New Pricing Rule" to add one.</td></tr>';
      return;
    }
    tbody.innerHTML = rows.map(function(r) {
      const jobLabel = r.job_type_name ? _esc(r.job_type_name) : '<span style="color:#aaa;font-style:italic">All jobs</span>';
      const propLabel = _esc(r.property_type_display || _PROPERTY_TYPE_LABELS[r.property_type] || r.property_type);
      const mult = parseFloat(r.multiplier).toFixed(3);
      const preview = r.preview_price != null ? '$' + parseFloat(r.preview_price).toFixed(2) : '<span style="color:#aaa">—</span>';
      const active = r.is_active
        ? '<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#e8f5e9;color:#2e7d32;font-size:11px;font-weight:600">Active</span>'
        : '<span style="display:inline-block;padding:2px 8px;border-radius:10px;background:#fafafa;color:#999;font-size:11px;font-weight:600">Inactive</span>';
      return '<tr style="border-bottom:1px solid var(--border)">' +
        '<td style="padding:8px 10px;font-weight:600">' + jobLabel + '</td>' +
        '<td style="padding:8px 10px">' + propLabel + '</td>' +
        '<td style="padding:8px 10px;text-align:center;font-weight:600">x' + mult + '</td>' +
        '<td style="padding:8px 10px;text-align:right">' + preview + '</td>' +
        '<td style="padding:8px 10px;text-align:center">' + active + '</td>' +
        '<td style="padding:8px 10px;text-align:center">' +
          '<button type="button" onclick="editPricingRule(\'' + _esc(r.id) + '\')" style="border:none;background:none;cursor:pointer;color:var(--primary);margin-right:4px" title="Edit"><i class="fas fa-edit"></i></button>' +
          '<button type="button" onclick="deletePricingRule(\'' + _esc(r.id) + '\')" style="border:none;background:none;cursor:pointer;color:#E53935" title="Delete"><i class="fas fa-trash"></i></button>' +
        '</td>' +
      '</tr>';
    }).join('');
  } catch (e) {
    console.warn('Pricing load error', e);
    tbody.innerHTML = '<tr><td colspan="6" style="padding:20px;text-align:center;color:#c62828">Failed to load pricing rules.</td></tr>';
  }
}

async function _ensurePricingJobTypes() {
  if (_pricingJobTypes.length) return;
  try {
    const d = await api('/job-types/');
    _pricingJobTypes = d.results || d || [];
  } catch (e) {
    console.warn('Job-types load error', e);
    _pricingJobTypes = [];
  }
}

function _populatePricingSelects(selectedJobType, selectedPropType) {
  const jt = document.getElementById('prJobType');
  if (jt) {
    jt.innerHTML = '<option value="">All jobs (tenant-wide default)</option>' +
      _pricingJobTypes.map(function(j) {
        const sel = j.id === selectedJobType ? ' selected' : '';
        return '<option value="' + _esc(j.id) + '"' + sel + '>' + _esc(j.name) + '</option>';
      }).join('');
  }
  const pt = document.getElementById('prPropertyType');
  if (pt) {
    const keys = Object.keys(_PROPERTY_TYPE_LABELS);
    pt.innerHTML = keys.map(function(k) {
      const sel = k === selectedPropType ? ' selected' : '';
      return '<option value="' + k + '"' + sel + '>' + _esc(_PROPERTY_TYPE_LABELS[k]) + '</option>';
    }).join('');
  }
}

async function openPricingRule() {
  _editingPricingId = null;
  document.getElementById('pricingModalTitle').textContent = 'New Pricing Rule';
  await _ensurePricingJobTypes();
  _populatePricingSelects(null, 'house');
  document.getElementById('prMultiplier').value = '1.000';
  document.getElementById('prNotes').value = '';
  document.getElementById('prActive').checked = true;
  document.getElementById('pricingModal').style.display = 'flex';
}

function closePricingRule() {
  document.getElementById('pricingModal').style.display = 'none';
}

async function editPricingRule(id) {
  await _ensurePricingJobTypes();
  let r;
  try {
    r = await api('/property-type-pricing/' + id + '/');
  } catch (e) {
    alert('Failed to load rule.');
    return;
  }
  _editingPricingId = id;
  document.getElementById('pricingModalTitle').textContent = 'Edit Pricing Rule';
  _populatePricingSelects(r.job_type || null, r.property_type);
  document.getElementById('prMultiplier').value = parseFloat(r.multiplier).toFixed(3);
  document.getElementById('prNotes').value = r.notes || '';
  document.getElementById('prActive').checked = !!r.is_active;
  document.getElementById('pricingModal').style.display = 'flex';
}

async function savePricingRule() {
  const jobTypeVal = document.getElementById('prJobType').value;
  const body = {
    job_type: jobTypeVal || null,
    property_type: document.getElementById('prPropertyType').value,
    multiplier: document.getElementById('prMultiplier').value,
    notes: document.getElementById('prNotes').value.trim(),
    is_active: document.getElementById('prActive').checked,
  };
  if (!body.property_type) { alert('Property type is required.'); return; }
  if (!(parseFloat(body.multiplier) >= 0)) { alert('Multiplier must be a non-negative number.'); return; }
  const btn = document.getElementById('prSaveBtn');
  btn.disabled = true;
  try {
    let r;
    if (_editingPricingId) {
      r = await apiFetch('/property-type-pricing/' + _editingPricingId + '/', 'PATCH', body);
    } else {
      r = await apiFetch('/property-type-pricing/', 'POST', body);
    }
    if (!r.ok) {
      let msg = 'HTTP ' + r.status;
      try {
        const j = await r.json();
        if (j) {
          if (j.detail) msg = j.detail;
          else if (j.non_field_errors) msg = j.non_field_errors.join(', ');
          else msg = Object.keys(j).map(function(k){ return k + ': ' + (Array.isArray(j[k]) ? j[k].join(', ') : j[k]); }).join('; ');
        }
      } catch(_) {}
      alert('Failed to save: ' + msg);
      return;
    }
    closePricingRule();
    loadPricing();
  } catch (e) {
    alert('Network error: ' + (e.message || 'failed'));
  } finally {
    btn.disabled = false;
  }
}

async function deletePricingRule(id) {
  if (!confirm('Delete this pricing rule?')) return;
  const r = await apiFetch('/property-type-pricing/' + id + '/', 'DELETE');
  if (!r.ok && r.status !== 204) { alert('Delete failed (' + r.status + ').'); return; }
  loadPricing();
}