(function(){
    if (window.__cbpNotifBell) return;
    window.__cbpNotifBell = true;

    var POLL_MS = 60000;
    var DROPDOWN_LIMIT = 10;

    function csrf() {
      var m = document.cookie.match(/csrftoken=([^;]+)/);
      return m ? m[1] : '';
    }
    function safeText(s){
      return (s == null ? '' : String(s)).replace(/[&<>"']/g, function(c){
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
      });
    }
    function timeAgo(iso){
      if(!iso) return '';
      var d = new Date(iso);
      var sec = Math.max(1, Math.floor((Date.now() - d.getTime())/1000));
      if(sec < 60) return sec + 's ago';
      var min = Math.floor(sec/60); if(min < 60) return min + 'm ago';
      var hr  = Math.floor(min/60); if(hr  < 24) return hr  + 'h ago';
      var day = Math.floor(hr/24);  if(day < 7)  return day + 'd ago';
      return d.toLocaleDateString();
    }
    function fetchJSON(url, opts){
      return fetch(url, Object.assign({credentials:'same-origin', headers:{'X-CSRFToken': csrf()}}, opts || {}))
        .then(function(r){
          if(!r.ok) throw new Error('HTTP ' + r.status);
          if(r.status === 204) return null;
          return r.json();
        });
    }

    function renderBadge(count){
      var b = document.getElementById('cbpNotifBellBadge');
      if(!b) return;
      if(count > 0){
        b.textContent = count > 99 ? '99+' : String(count);
        b.classList.add('show');
      } else {
        b.classList.remove('show');
      }
    }

    function refreshUnreadCount(){
      return fetchJSON('/api/v1/notifications/unread-count/')
        .then(function(d){ renderBadge((d && typeof d.count === 'number') ? d.count : 0); })
        .catch(function(){ /* swallow — keep last known badge state */ });
    }

    function renderDropdown(items){
      var list = document.getElementById('cbpNotifList');
      if(!list) return;
      if(!items || !items.length){
        list.innerHTML = '<div class="empty"><i class="fas fa-bell-slash"></i>You\'re all caught up.</div>';
        return;
      }
      var typeIcon = {info:'fa-info-circle', success:'fa-check-circle', warning:'fa-triangle-exclamation', error:'fa-circle-xmark', action:'fa-bolt'};
      list.innerHTML = items.map(function(n){
        var t = n.notification_type || 'info';
        var icn = typeIcon[t] || 'fa-bell';
        var ttl = safeText(n.title || '');
        var msg = safeText((n.message || '').slice(0, 80));
        var ts  = safeText(timeAgo(n.created_at));
        return '<div class="item" data-id="' + safeText(n.id) + '" data-link="' + safeText(n.link || '') + '">'
          + '<span class="icn ' + safeText(t) + '"><i class="fas ' + icn + '"></i></span>'
          + '<div class="body-col"><div class="ttl">' + ttl + '</div>'
          + '<div class="msg">' + msg + '</div>'
          + '<div class="ts">' + ts + '</div></div>'
          + '</div>';
      }).join('');
      // Wire click-to-mark-read + navigate (if link present)
      list.querySelectorAll('.item').forEach(function(el){
        el.addEventListener('click', function(){
          var id = el.getAttribute('data-id');
          var link = el.getAttribute('data-link');
          if(!id) return;
          fetchJSON('/api/v1/notifications/' + id + '/mark-read/', {method:'POST'})
            .then(function(){ refreshUnreadCount(); })
            .catch(function(){});
          if(link){
            // Close dropdown then navigate. SPA shim picks it up if internal.
            closeDropdown();
            window.location.href = link;
          } else {
            // Visually fade the item to read state
            el.style.opacity = '.55';
          }
        });
      });
    }

    function loadDropdownContent(){
      var list = document.getElementById('cbpNotifList');
      if(list) list.innerHTML = '<div class="empty"><i class="fas fa-bell"></i>Loading...</div>';
      return fetchJSON('/api/v1/notifications/?unread_only=true&page_size=' + DROPDOWN_LIMIT)
        .then(function(d){
          var rows = (d && d.results) ? d.results : (Array.isArray(d) ? d : []);
          renderDropdown(rows.slice(0, DROPDOWN_LIMIT));
        })
        .catch(function(){
          if(list) list.innerHTML = '<div class="errstate">Could not load notifications.</div>';
        });
    }

    function openDropdown(){
      var dd = document.getElementById('cbpNotifDropdown');
      var btn = document.getElementById('cbpNotifBellBtn');
      if(!dd || !btn) return;
      dd.classList.add('show');
      btn.setAttribute('aria-expanded', 'true');
      loadDropdownContent();
    }
    function closeDropdown(){
      var dd = document.getElementById('cbpNotifDropdown');
      var btn = document.getElementById('cbpNotifBellBtn');
      if(!dd || !btn) return;
      dd.classList.remove('show');
      btn.setAttribute('aria-expanded', 'false');
    }

    window.cbpToggleNotifBell = function(){
      var dd = document.getElementById('cbpNotifDropdown');
      if(!dd) return;
      if(dd.classList.contains('show')) closeDropdown(); else openDropdown();
    };

    window.cbpMarkAllNotifRead = function(ev){
      if(ev) ev.preventDefault();
      fetchJSON('/api/v1/notifications/mark-all-read/', {method:'POST'})
        .then(function(){
          refreshUnreadCount();
          loadDropdownContent();
        })
        .catch(function(){});
    };

    // Public hook for full-page consumers to nudge the badge after a write.
    window.cbpRefreshNotifBell = refreshUnreadCount;

    // Click outside the bell wrap closes the dropdown
    document.addEventListener('click', function(ev){
      var wrap = document.getElementById('cbpNotifBellWrap');
      if(!wrap) return;
      if(wrap.contains(ev.target)) return;
      var dd = document.getElementById('cbpNotifDropdown');
      if(dd && dd.classList.contains('show')) closeDropdown();
    });
    document.addEventListener('keydown', function(ev){
      if(ev.key === 'Escape') closeDropdown();
    });

    // Initial badge fetch + 60s poll. Use the original setInterval (not the
    // SPA-tracked shim) so the bell keeps ticking across page navigations.
    var origSetInterval = window.__origSetIntervalForBell || window.setInterval;
    if(window.__cbpNotifPoll){ try { clearInterval(window.__cbpNotifPoll); } catch(e){} }
    refreshUnreadCount();
    window.__cbpNotifPoll = origSetInterval(refreshUnreadCount, POLL_MS);
  })();