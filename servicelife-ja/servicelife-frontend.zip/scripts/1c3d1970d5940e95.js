const API='/api/v1';const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';const hdr=(m)=>{const h={'X-CSRFToken':csrf()};if(m!=='GET')h['Content-Type']='application/json';return h;};async function api(u,m='GET',b=null){const o={method:m,credentials:'same-origin',headers:hdr(m)};if(b)o.body=JSON.stringify(b);const r=await fetch(API+u,o);if(r.status===204)return null;return r.json();}function fmtDate(s){if(!s)return'—';return new Date(s).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
const SB={pending:'orange',approved:'green',rejected:'red',reimbursed:'blue'};
const CAN_APPROVE=['company_admin','accountant'].includes('company_admin');
function actionCell(e){if(!CAN_APPROVE)return '';if(e.status==='pending')return `<td><button onclick="approveExpense('${e.id}')" style="padding:4px 10px;background:#2e7d32;color:#fff;border:none;border-radius:5px;font-size:12px;font-weight:600;cursor:pointer;margin-right:4px">Approve</button><button onclick="rejectExpense('${e.id}')" style="padding:4px 10px;background:#c62828;color:#fff;border:none;border-radius:5px;font-size:12px;font-weight:600;cursor:pointer">Reject</button></td>`;return '<td>—</td>';}
async function loadKPIs(){try{const s=await api('/expenses/stats/');document.getElementById('kpiStrip').innerHTML=`<div class="kpi"><div class="lbl">This Month</div><div class="val">$${(s.month_total||0).toLocaleString()}</div></div><div class="kpi"><div class="lbl">Month Count</div><div class="val">${s.month_count}</div></div><div class="kpi"><div class="lbl">Pending Approval</div><div class="val" style="color:#e65100">${s.pending_approval}</div></div><div class="kpi"><div class="lbl">All-Time</div><div class="val">$${(s.all_time_total||0).toLocaleString()}</div></div>`;}catch(e){}}
async function loadData(){const tb=document.getElementById('tableBody');try{let url='/expenses/expenses/?ordering=-date';const st=document.getElementById('filterStatus').value;if(st)url+='&status='+st;const d=await api(url);const items=d.results||d;
tb.innerHTML=items.length?items.map(e=>`<tr><td>${fmtDate(e.date)}</td><td><strong>${e.description}</strong></td><td>${e.category_name||'—'}</td><td>${e.tech_name||'—'}</td><td>${e.vendor||'—'}</td><td style="font-weight:700">$${parseFloat(e.amount||0).toFixed(2)}</td><td><span class="badge badge-${SB[e.status]||'gray'}">${e.status}</span></td>${actionCell(e)}</tr>`).join(''):`<tr><td colspan="${CAN_APPROVE?8:7}"><div class="empty-state"><i class="fas fa-receipt"></i><p>No expenses yet</p></div></td></tr>`;loadKPIs();}catch(e){if(e&&e.name==='AbortError')return;tb.innerHTML=`<tr><td colspan="${CAN_APPROVE?8:7}"><div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Could not load expenses.</p></div></td></tr>`;}}
document.addEventListener('DOMContentLoaded',loadData);

function showModal(id){document.getElementById(id).classList.add('show');}
function hideModal(id){document.getElementById(id).classList.remove('show');}

async function openLogExpenseModal(){
  document.getElementById('e-desc').value='';
  document.getElementById('e-amount').value='';
  document.getElementById('e-date').value=new Date().toISOString().slice(0,10);
  document.getElementById('e-vendor').value='';
  document.getElementById('e-notes').value='';
  document.getElementById('e-error').style.display='none';
  document.getElementById('e-submit-btn').disabled=false;
  document.getElementById('e-submit-btn').textContent='Log Expense';
  const sel=document.getElementById('e-category');
  if(sel.options.length<=1){
    try{
      const cats=await api('/expenses/categories/');
      const items=cats.results||cats;
      items.forEach(c=>{const o=document.createElement('option');o.value=c.id;o.textContent=c.name;sel.appendChild(o);});
    }catch(e){}
  }
  showModal('logExpenseModal');
}

async function submitExpense(){
  const desc=document.getElementById('e-desc').value.trim();
  const amount=document.getElementById('e-amount').value;
  const date=document.getElementById('e-date').value;
  const category=document.getElementById('e-category').value;
  const vendor=document.getElementById('e-vendor').value.trim();
  const notes=document.getElementById('e-notes').value.trim();
  const errDiv=document.getElementById('e-error');
  errDiv.style.display='none';
  if(!desc){errDiv.textContent='Description is required.';errDiv.style.display='block';return;}
  if(!amount||parseFloat(amount)<=0){errDiv.textContent='Please enter a valid amount greater than 0.';errDiv.style.display='block';return;}
  if(!date){errDiv.textContent='Date is required.';errDiv.style.display='block';return;}
  const btn=document.getElementById('e-submit-btn');
  btn.disabled=true;btn.textContent='Saving…';
  const body={description:desc,amount:amount,date:date,vendor:vendor,notes:notes};
  if(category)body.category=category;
  try{
    const r=await fetch(API+'/expenses/expenses/',{method:'POST',credentials:'same-origin',headers:hdr('POST'),body:JSON.stringify(body)});
    if(!r.ok){const e=await r.json();throw new Error(JSON.stringify(e));}
    hideModal('logExpenseModal');
    loadData();
  }catch(err){
    errDiv.textContent='Failed to log expense: '+err.message;
    errDiv.style.display='block';
    btn.disabled=false;btn.textContent='Log Expense';
  }
}

async function approveExpense(id){if(!confirm('Approve this expense?'))return;try{await api('/expenses/expenses/'+id+'/','PATCH',{status:'approved'});loadData();}catch(err){alert('Could not approve expense: '+err.message);}}
async function rejectExpense(id){if(!confirm('Reject this expense?'))return;try{await api('/expenses/expenses/'+id+'/','PATCH',{status:'rejected'});loadData();}catch(err){alert('Could not reject expense: '+err.message);}}