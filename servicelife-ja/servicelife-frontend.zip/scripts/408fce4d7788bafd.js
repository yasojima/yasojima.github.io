const API='/api/v1',csrf=document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
// BUG-002: tenant tz fallback for datetime offset stamping. Used by
// saveAppt and eaSave when no per-tech IANA tz is available, so we
// never send naive datetimes to the API (server rejects them).
window._tenantTz = 'America/New_York';
// BUG-003: init _techTzMap at script-eval so saveAppt never hits undefined
window._techTzMap = {};
let cal,techs=[],jobTypes=[],selTech=null,searchCust=null,bookCust=null,availEvents=[],curView='calendar',dispDate=localDateStr();
// Multi-job: render the job-type picker as a checkbox list (not a multi-select).
function jtRenderChecks(containerId, selectedIds){
  const c=document.getElementById(containerId); if(!c) return;
  const sel=(selectedIds||[]).map(String); c.innerHTML='';
  jobTypes.forEach(function(j){
    const lab=document.createElement('label'); lab.className='jt-check';
    const cb=document.createElement('input'); cb.type='checkbox'; cb.value=j.id; cb.dataset.dur=j.default_duration; cb.dataset.window=j.offer_arrival_window?'1':'';
    if(sel.indexOf(String(j.id))!==-1) cb.checked=true;
    lab.appendChild(cb);
    lab.appendChild(document.createTextNode(' '+j.name+' ('+j.default_duration+'m)'));
    c.appendChild(lab);
  });
}
function jtGetChecked(containerId){
  const c=document.getElementById(containerId); if(!c) return [];
  return Array.prototype.map.call(c.querySelectorAll('input[type=checkbox]:checked'),function(i){return i.value;});
}
const hdr=()=>({'Content-Type':'application/json','X-CSRFToken':csrf});
const api=async(u,o={})=>(await fetch(API+u,{credentials:'same-origin',headers:hdr(),...o})).json();

// F-PREFS-2 Slice C.3.2 — preferred-tech mismatch detection (console.warn only).
// When a user selects a tech via a dropdown for a customer that has preferences,
// emit a structured console.warn so the C.3.3 modal slice has telemetry to
// verify against. Silent for: no customer, no prefs, preferred-tech selected,
// programmatic .selected=true (browsers don't dispatch 'change' for those).
// See PRD: design-queue/F-PREFS-2-slice-c3-prd.md (Pattern B, phasing).
let _currentBookContext='booking'; // 'booking' (modal) | 'dispatch' (opened from dispatch view)
let _eaCustPref=null; // {preferred_technician_ids:[], preferred_technicians:[{id,name}]} for the appt being edited
function _prefsLookupTechName(techId){
  for(const t of (techs||[])) if(String(t.id)===String(techId)) return t.name||null;
  return null;
}
function _prefsCheckMismatch(opts){
  const cust=opts&&opts.customer;
  const techId=opts&&opts.techId;
  const context=opts&&opts.context;
  if(!cust||!techId) return; // empty selection or missing customer → silent
  const prefIds=Array.isArray(cust.preferred_technician_ids)?cust.preferred_technician_ids:[];
  if(!prefIds.length) return; // customer has no prefs → no mismatch to detect
  if(prefIds.map(String).includes(String(techId))) return; // selected tech IS preferred → silence is golden
  const prefList=Array.isArray(cust.preferred_technicians)?cust.preferred_technicians:[];
  console.warn('[prefs-mismatch]',{
    customerId:String(cust.id||''),
    customerName:cust.full_name||null,
    selectedTechId:String(techId),
    selectedTechName:_prefsLookupTechName(techId),
    preferredTechIds:prefIds.map(String),
    preferredTechNames:prefList.map(p=>p&&p.name).filter(Boolean),
    context:context||'booking',
  });
}

// R16 DL5 — license-status badge helpers. The tech list payload from
// /technicians/ now carries `license_status` (DL3 schema: status,
// earliest_expiry, categories). We render the badge client-side for the
// chips row (full HTML) and as a trailing emoji glyph for native <option>
// elements (which can't render markup).
window._dispatchLockoutPolicy=null;
function _escAttr(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function badgeHtml(s){
  if(!s||!s.status)return '';
  const map={
    active:['badge-success','&#10003;','License current'],
    warning:['badge-warning','&#9888;','License expires soon'],
    expired:['badge-danger','&#10007;','License expired'],
    missing:['badge-danger','&#10007;','No license on file'],
  };
  const m=map[s.status];if(!m)return '';
  let tip=m[2];
  if(s.earliest_expiry&&(s.status==='warning'||s.status==='expired')){tip=m[2]+' ('+s.earliest_expiry+')';}
  return ' <span class="tech-license-badge '+m[0]+'" data-license-status="'+_escAttr(s.status)+'" title="'+_escAttr(tip)+'">'+m[1]+'</span>';
}
function optionGlyph(s){
  if(!s||!s.status)return '';
  if(s.status==='expired'||s.status==='missing')return ' ✗';
  if(s.status==='warning')return ' ⚠';
  return '';
}
function isLockedOut(s){
  const p=window._dispatchLockoutPolicy;
  if(!p||!p.enabled||p.mode!=='block')return false;
  if(!s||!s.status)return false;
  return s.status==='expired'||s.status==='missing';
}
async function loadDispatchLockoutPolicy(){
  try{
    const p=await api('/compliance/lockout-policy/current/');
    if(p&&typeof p==='object'&&!p.detail)window._dispatchLockoutPolicy=p;
  }catch(e){/* non-fatal — badge renders without lock-out behavior */}
}

function switchView(v){
  curView=v;
  document.querySelectorAll('.view-sel .vo').forEach(el=>{
    const txt=el.textContent.trim().toLowerCase();
    el.classList.toggle('on',(v==='calendar'&&txt.includes('week'))||(v==='dispatch'&&txt.includes('dispatch'))||(v==='availability'&&txt.includes('avail')));
  });
  document.getElementById('cal-wrap').style.display=v==='calendar'?'block':'none';
  document.getElementById('dispatch-wrap').style.display=v==='dispatch'?'block':'none';
  document.getElementById('avail-wrap').style.display=v==='availability'?'block':'none';
  if(v==='dispatch')loadDispatch();
  if(v==='availability')loadAvailability();
}

// ===== CUSTOMER AC =====
function initAC(iid,did,tid,onPick){
  const inp=document.getElementById(iid),dd=document.getElementById(did);let t;
  inp.addEventListener('input',()=>{clearTimeout(t);const q=inp.value.trim();if(q.length<2){dd.classList.remove('show');return}
    t=setTimeout(async()=>{const d=await api(`/customer-search/?q=${encodeURIComponent(q)}`);
      if(!d.length){dd.innerHTML='<div class="it" style="color:#999">No results</div>';dd.classList.add('show');return}
      dd.innerHTML=d.map(c=>`<div class="it" data-j='${JSON.stringify(c).replace(/'/g,"&#39;")}'><div class="n">${escHTML(c.full_name)} <span style="color:#aaa;font-weight:400">${escHTML(c.phone)}</span>${c.customer_type==='commercial'?' <span style="font-size:10px;background:#e3f2fd;color:#1565c0;padding:0 5px;border-radius:3px">Commercial</span>':''}</div><div class="m">${escHTML(c.service_address||'')}${c.service_address_2?' #'+escHTML(c.service_address_2):''}${c.service_city?', '+escHTML(c.service_city):''}${c.preferred_technician?' &bull; <span style="color:var(--accent)">Pref: '+escHTML(c.preferred_technician.name)+'</span>':''}</div></div>`).join('');
      dd.classList.add('show');
      dd.querySelectorAll('.it[data-j]').forEach(el=>{el.onclick=()=>{onPick(JSON.parse(el.dataset.j));dd.classList.remove('show');inp.value=''}});
    },200)});
  inp.addEventListener('blur',()=>setTimeout(()=>dd.classList.remove('show'),200));
}
function showTag(tid,wid,c,clr){
  document.getElementById(tid).innerHTML=`<span class="ct">${escHTML(c.full_name)} — ${escHTML(c.phone)}${c.preferred_technician?' <span style="font-size:10px;color:var(--accent);font-weight:700">★ '+escHTML(c.preferred_technician.name)+'</span>':''} <span class="x" onclick="${clr}">&times;</span></span>`;
  document.getElementById(tid).style.display='block';document.getElementById(wid).style.display='none';
}

function gmAC(id){const el=document.getElementById(id);if(!el)return;if(typeof google==='undefined'||!google.maps||!google.maps.importLibrary)return;
  google.maps.importLibrary('places').then(({Autocomplete})=>{
    const ac=new Autocomplete(el,{componentRestrictions:{country:'us'},fields:['formatted_address'],types:['address']});
    ac.addListener('place_changed',()=>{const p=ac.getPlace();if(p.formatted_address)el.value=p.formatted_address});
  });}
function bumpDur(){
  const s=document.getElementById('sDur');
  if(s.value==='custom')return;
  const v=parseInt(s.value)+15;
  // Check if option already exists
  for(let o of s.options)if(parseInt(o.value)===v){o.selected=true;return}
  // Add new option before 'Custom...'
  const o=document.createElement('option');
  o.value=v;
  if(v>=1440)o.textContent=Math.round(v/480*10)/10+' days';
  else if(v>=60)o.textContent=(v/60%1===0?(v/60)+'hr':(v/60).toFixed(1)+'hr');
  else o.textContent=v+'m';
  const customOpt=s.querySelector('option[value="custom"]');
  if(customOpt)s.insertBefore(o,customOpt);else s.appendChild(o);
  o.selected=true;
}
// Handle custom duration selection
document.addEventListener('DOMContentLoaded',function(){
  const sd=document.getElementById('sDur');
  if(sd)sd.addEventListener('change',function(){
    if(this.value==='custom'){
      const mins=prompt('Enter duration in minutes (e.g. 480 for a full day, 960 for 2 days):');
      if(mins&&!isNaN(parseInt(mins))){
        const v=parseInt(mins);
        const o=document.createElement('option');
        o.value=v;
        if(v>=1440)o.textContent=Math.round(v/480*10)/10+' days';
        else if(v>=60)o.textContent=(v/60%1===0?(v/60)+'hr':(v/60).toFixed(1)+'hr');
        else o.textContent=v+'m';
        const customOpt=this.querySelector('option[value="custom"]');
        if(customOpt)this.insertBefore(o,customOpt);
        o.selected=true;
      }else{this.value='30';}
    }
  });
});

function toggleMultiDay(){
  document.getElementById('bMultiDayFields').style.display=document.getElementById('bMultiDay').checked?'block':'none';
}
// BUG-003: parity helper for the Edit Appointment modal
function toggleEAMultiDay(){
  const cb=document.getElementById('ea-multiday');
  const w=document.getElementById('ea-multiday-fields');
  if(cb&&w)w.style.display=cb.checked?'block':'none';
}
function toggleNewCust(){document.getElementById('sCustWrap').style.display=document.getElementById('sNewCust').checked?'none':'block';document.getElementById('sCustTag').style.display='none';searchCust=null}

// ===== SEARCH =====
async function doSearch(){
  const btn=document.getElementById('searchBtn');btn.disabled=true;btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> Searching...';
  const from=document.getElementById('sFrom').value,to=document.getElementById('sTo').value,addr=document.getElementById('sAddr').value,dur=document.getElementById('sDur').value;
  const days=from&&to?Math.ceil((new Date(to)-new Date(from))/864e5)+1:7;
  // Sync search date range to availability view days dropdown
  const availDaysEl=document.getElementById('availDays');
  if(availDaysEl){
    // Set to matching option or add a custom one
    let matched=false;
    for(let o of availDaysEl.options){if(parseInt(o.value)===days){o.selected=true;matched=true;break}}
    if(!matched){
      const o=document.createElement('option');o.value=days;o.textContent=days+' days';
      availDaysEl.appendChild(o);o.selected=true;
    }
  }
  const jt=document.getElementById('sJobType')?document.getElementById('sJobType').value:'';
  const p=new URLSearchParams({date:from||localDateStr(),duration:dur,days,address:addr});
  if(jt)p.set('job_type',jt);
  if(searchCust)p.set('customer',searchCust.id);
  try{const d=await api(`/scheduling/smart-slots/?${p}`);lastSearchData=d;lastSearchDur=parseInt(dur);
    // Build techId -> timezone map from search results
    window._techTzMap={};
    if(d.technicians){d.technicians.forEach(t=>{if(t.timezone)window._techTzMap[t.technician_id]=t.timezone;});}renderAvail(d,parseInt(dur));const _effFrom=from||localDateStr();let _effTo=to;if(!_effTo){const _e=new Date(_effFrom+'T12:00:00');_e.setDate(_e.getDate()+(days-1));_effTo=fmt(_e);}if(from){cal.gotoDate(from);dispDate=from;const dF=document.getElementById('dispFrom'),dT=document.getElementById('dispTo');if(dF)dF.value=from;if(dT)dT.value=to||from;if(curView==='dispatch')loadDispatch();if(curView==='availability')loadAvailability();}syncSearchToRV(_effFrom,_effTo);document.getElementById('clearBtn').style.display=''}catch(e){alert('Search failed')}
  btn.disabled=false;btn.innerHTML='<i class="fas fa-search"></i> Search';
}
function renderAvail(data,dur){
  availEvents.forEach(e=>e.remove());availEvents=[];if(!data.technicians){renderAvailMobileList([]);return;}
  const mobileSegs=[];
  // Build busy ranges from existing calendar events (appointments + breaks)
  const calEvents=cal.getEvents().filter(e=>{const tp=e.extendedProps?.type;return !tp||tp==='appt'||tp==='break'});
  const busyByDate={};
  for(const e of calEvents){
    if(!e.start||!e.end)continue;
    const dk=localDateStr(e.start);
    if(!busyByDate[dk])busyByDate[dk]=[];
    busyByDate[dk].push({s:e.start.getHours()*60+e.start.getMinutes(),e:e.end.getHours()*60+e.end.getMinutes()});
  }
  // Also add break ranges from work schedules
  const breakEvents=cal.getEvents().filter(e=>e.display==='background'||e.extendedProps?.type==='break');
  for(const e of breakEvents){
    if(!e.start||!e.end)continue;
    const dk=localDateStr(e.start);
    if(!busyByDate[dk])busyByDate[dk]=[];
    busyByDate[dk].push({s:e.start.getHours()*60+e.start.getMinutes(),e:e.end.getHours()*60+e.end.getMinutes()});
  }
  for(const t of data.technicians){for(const s of t.slots){
    const slotS=tmn(s.start_time),slotE=tmn(s.end_time);
    const busy=(busyByDate[s.date]||[]).slice().sort((a,b)=>a.s-b.s);
    // Split slot into sub-segments that don't overlap with busy ranges
    let segments=[{s:slotS,e:slotE}];
    for(const b of busy){
      const next=[];
      for(const seg of segments){
        if(b.e<=seg.s||b.s>=seg.e){next.push(seg);continue}
        if(b.s>seg.s)next.push({s:seg.s,e:b.s});
        if(b.e<seg.e)next.push({s:b.e,e:seg.e});
      }
      segments=next;
    }
    segments=segments.filter(seg=>(seg.e-seg.s)>=(dur||15));
    // Tile each free segment into discrete, back-to-back bookable slots (one per
    // duration step) so an OPEN day shows ALL start times — not just the start of
    // the morning and after-lunch gaps.
    const _step=(dur||30);
    const tiles=[];
    for(const _seg of segments){
      for(let _s=_seg.s; _s+_step<=_seg.e+0.5; _s+=_step){ tiles.push({s:_s,e:_s+_step}); }
    }
    for(const seg of tiles){
      const segStart=String(Math.floor(seg.s/60)).padStart(2,'0')+':'+String(seg.s%60).padStart(2,'0');
      const segEnd=String(Math.floor(seg.e/60)).padStart(2,'0')+':'+String(seg.e%60).padStart(2,'0');
      const parts=[t.technician_name];if(t.is_preferred)parts.unshift('★');
      if(s.travel_from_previous!==null)parts.push(s.travel_from_previous+'min from '+(s.previous_job||'prev'));
      if(s.travel_to_next!==null)parts.push(s.travel_to_next+'min to '+(s.next_job||'next'));
      parts.push(Math.round(seg.e-seg.s)+'min window');
      const ev=cal.addEvent({title:parts.join('\n'),start:s.date+'T'+segStart+':00',end:s.date+'T'+segEnd+':00',
        backgroundColor:t.technician_color+'40',borderColor:t.technician_color,textColor:t.technician_color,
        classNames:['avail-event',t.is_preferred?'pref':''],
        extendedProps:{type:'avail',tech_id:t.technician_id,tech_name:t.technician_name,is_preferred:t.is_preferred,slot:s,duration:dur,address:data.job_address}});
      availEvents.push(ev);
      mobileSegs.push({date:s.date,segStart,segEnd,techName:t.technician_name,isPreferred:t.is_preferred,travelFrom:(s.travel_from_previous!=null?s.travel_from_previous:null),travelTo:(s.travel_to_next!=null?s.travel_to_next:null),p:{type:'avail',tech_id:t.technician_id,tech_name:t.technician_name,is_preferred:t.is_preferred,slot:s,duration:dur,address:data.job_address,event:{start:new Date(s.date+'T'+segStart+':00'),end:new Date(s.date+'T'+segEnd+':00')}}});
    }
  }}
  renderAvailMobileList(mobileSegs);
}
// Mobile-friendly slot RESULTS LIST: on phones, show search results as a tappable
// list grouped by day (instead of the full FullCalendar grid). Tapping a slot
// runs the same booking flow as clicking a calendar availability event.
function renderAvailMobileList(segs){
  const box=document.getElementById('availMobileList'),wrap=document.getElementById('cal-wrap');
  if(!box||!wrap)return;
  const isMobile=window.matchMedia('(max-width:768px)').matches;
  const f12=function(hhmm){const pp=(hhmm||'').split(':');let h=parseInt(pp[0]||'0'),m=pp[1]||'00';const ap=h>=12?'PM':'AM';h=h%12||12;return h+':'+m+' '+ap;};
  if(!segs||!segs.length){box.innerHTML='';wrap.classList.remove('mobile-slots');return;}
  const byDate={};segs.forEach(x=>{(byDate[x.date]=byDate[x.date]||[]).push(x);});
  const dates=Object.keys(byDate).sort();
  let html='<div class="aml-note"><i class="fas fa-hand-pointer"></i> Tap a time to book it.</div>';
  for(const d of dates){
    const items=byDate[d].sort((a,b)=>a.segStart.localeCompare(b.segStart));byDate[d]=items;
    const dLabel=new Date(d+'T12:00:00').toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric'});
    html+='<div class="aml-day"><h4>'+dLabel+' &middot; '+items.length+' slot'+(items.length!==1?'s':'')+'</h4>';
    for(let i=0;i<items.length;i++){const x=items[i];
      const meta=[];if(x.travelFrom!=null)meta.push(x.travelFrom+'m from prev');if(x.travelTo!=null)meta.push(x.travelTo+'m to next');
      html+='<div class="aml-slot'+(x.isPreferred?' pref':'')+'" data-d="'+d+'" data-i="'+i+'">'
        +'<div class="aml-time">'+f12(x.segStart)+'</div>'
        +'<div class="aml-mid"><div class="aml-tech">'+(x.isPreferred?'★ ':'')+escHTML(x.techName)+'</div>'
        +'<div class="aml-meta">'+f12(x.segStart)+'–'+f12(x.segEnd)+(meta.length?' &middot; '+meta.join(' &middot; '):'')+'</div></div>'
        +'<div class="aml-go">›</div></div>';
    }
    html+='</div>';
  }
  box.innerHTML=html;
  box.querySelectorAll('.aml-slot').forEach(function(el){el.addEventListener('click',function(){const x=byDate[el.dataset.d][parseInt(el.dataset.i)];if(x&&x.p)bookFromAvail(x.p);});});
  if(isMobile)wrap.classList.add('mobile-slots');else wrap.classList.remove('mobile-slots');
}
function clearSearch(){availEvents.forEach(e=>e.remove());availEvents=[];document.getElementById('clearBtn').style.display='none';lastSearchData=null;loadRV();
  {const _b=document.getElementById('availMobileList');if(_b)_b.innerHTML='';document.getElementById('cal-wrap').classList.remove('mobile-slots');}
  document.getElementById('sAddr').value='';document.getElementById('sCust').value='';document.getElementById('sCustTag').style.display='none';document.getElementById('sCustWrap').style.display='block';searchCust=null}

// ===== DISPATCH =====
async function loadDispatch(){
  // Slice E1: invalidate the density cache so freshly saved/edited appointments
  // are reflected in the next hover/preview. Cheap — it's just a Map.clear().
  if(window.dispatchDensity&&window.dispatchDensity.invalidate)window.dispatchDensity.invalidate();
  const g=document.getElementById('dispGrid'),f=document.getElementById('dispFoot');
  g.innerHTML='<div style="padding:40px;text-align:center;color:var(--text-light);grid-column:1/-1"><i class="fas fa-spinner fa-spin"></i> Loading dispatch...</div>';
  // Sync dates from search bar or dispatch date pickers
  const sFrom=document.getElementById('sFrom');
  const sTo=document.getElementById('sTo');
  const dFrom=document.getElementById('dispFrom');
  const dTo=document.getElementById('dispTo');
  // Set dispatch dates from search if available
  if(sFrom&&sFrom.value&&dFrom&&!dFrom.value){dFrom.value=sFrom.value}
  if(sTo&&sTo.value&&dTo&&!dTo.value){dTo.value=sTo.value}
  // Default to a rolling 7-day window (today .. today+6) so the dispatch view
  // opens with the next 7 days as quick-select day tabs, not just today.
  const today=localDateStr();
  if(dFrom&&!dFrom.value)dFrom.value=today;
  if(dTo&&!dTo.value){const _e=new Date(today+'T12:00:00');_e.setDate(_e.getDate()+6);dTo.value=localDateStr(_e);}
  const fromDate=dFrom?dFrom.value:today;
  const toDate=dTo?dTo.value:today;
  // Build array of dates
  const dates=[];
  const cur=new Date(fromDate+'T12:00:00');
  const end=new Date(toDate+'T12:00:00');
  while(cur<=end){dates.push(localDateStr(cur));cur.setDate(cur.getDate()+1)}
  if(!dates.length)dates.push(today);
  // Update title
  const titleEl=document.getElementById('dispTitle');
  if(titleEl){
    if(dates.length===1){
      const dt=new Date(dates[0]+'T12:00:00');
      titleEl.textContent='Dispatch — '+dt.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});
    }else{
      const s=new Date(fromDate+'T12:00:00'),e=new Date(toDate+'T12:00:00');
      titleEl.textContent='Dispatch — '+s.toLocaleDateString('en-US',{month:'short',day:'numeric'})+' – '+e.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
    }
  }
  // Build day tabs
  const tabsEl=document.getElementById('dispDayTabs');
  if(tabsEl&&dates.length>1){
    let tabHtml='';
    for(let i=0;i<dates.length;i++){
      const d=new Date(dates[i]+'T12:00:00');
      const label=d.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
      const isToday=dates[i]===today;
      const isActive=dates[i]===(dispDate||today);
      tabHtml+='<button type="button" class="nbtn" onclick="showDispDay(\''+dates[i]+'\')" id="dispDayBtn'+i+'" style="padding:5px 12px;border:1.5px solid '+(isActive?'var(--accent)':isToday?'var(--accent)':'var(--border)')+';border-radius:5px;font-size:11px;font-weight:600;cursor:pointer;background:'+(isActive?'var(--accent)':'var(--white)')+';color:'+(isActive?'var(--primary)':'var(--text)')+'">'+label+'</button>';
    }
    tabsEl.innerHTML=tabHtml;
    tabsEl.style.display='flex';
  }else if(tabsEl){tabsEl.style.display='none'}
  // Load dispatch for the current selected day
  const useDate=dispDate||dates[0];
  if(!dates.includes(useDate))dispDate=dates[0];
  let d;
  try{d=await api('/scheduling/dispatch/?date='+(dispDate||dates[0]));}catch(e){g.innerHTML='<div style="padding:40px;text-align:center;color:var(--text-light);grid-column:1/-1">Error loading dispatch</div>';return;}
  if(!d.technicians||!d.technicians.length){g.innerHTML='<div style="padding:40px;text-align:center;color:var(--text-light);grid-column:1/-1">No technicians scheduled for this day</div>';f.innerHTML='';return}
  let html='';
  for(const t of d.technicians){
    const sc={'active':'#4CAF50','on_route':'#4CAF50','not_started':'#ccc'}[t.status]||'#ccc';
    const _ddDate=dispDate||dates[0];
    // R20 RTE4: tech-day-cell + data-technician/data-date are the hooks
    // window.densityBadges.load() uses to attach the density badge.
    html+=`<div class="disp-col tech-day-cell" data-tech-id="${t.technician_id}" data-disp-date="${_ddDate}" data-technician="${t.technician_id}" data-date="${_ddDate}"><div class="tech-hdr"><div class="tech-av" style="background:${t.technician_color}">${t.technician_initials}</div><div class="tech-info"><div class="tn">${t.technician_name}</div><div class="ts">${t.job_count} jobs &bull; ${Math.round(t.total_travel_minutes/60*10)/10}hr drive</div></div><div class="tech-dot" style="background:${sc}" title="${t.status}"></div></div>`;
    // Slice E1: per-tech-day density band (populated lazily on hover/drag).
    html+=`<div class="density-band" data-density-band data-band="" data-loaded="0" tabindex="0"><span class="db-dot"></span><span class="db-label">Density</span><span class="db-meta">…</span><div class="db-tip">Hover to compute route density for this technician\x27s ${_ddDate} schedule.</div></div>`;
    html+=`<div class="route-line" style="border-color:${t.technician_color}">`;
    for(let ji=0;ji<t.jobs.length;ji++){
      const j=t.jobs[ji];
      const done=j.status==='completed';const prog=j.status==='in_progress';
      const bcls=done?'jb-done':prog?'jb-prog':'jb-sched';
      const btext=done?'&#10003; Completed':prog?'In progress':'Scheduled';
      html+=`<div class="rj ${done||prog?'done':'pending'}" data-appointment-id="${j.id}" style="color:${t.technician_color};cursor:pointer"><div class="jt">${j.time} — ${j.customer_name}</div><div class="jm">${j.job_type} &bull; ${j.duration}min</div>`;
      if(done||prog)html+=`<div class="jb ${bcls}">${btext}</div>`;
      html+=`</div>`;
      if(j.travel_from_previous)html+=`<div class="rt">&#128663; ${j.travel_from_previous}min drive</div>`;
      // Calculate suggested time: end of this job
      const endTime24=j.end_time_24||'';
      const nextJob=t.jobs[ji+1];
      const travelToNext=nextJob?nextJob.travel_from_previous||0:0;
      html+=`<div class="disp-add" onclick="dispAddAppt('${t.technician_id}','${endTime24}',${j.duration||30},${travelToNext},'${(j.customer_id||'').replace(/'/g,"\\'")}','${(j.customer_name||'').replace(/'/g,"\\'")}','${(j.location||'').replace(/'/g,"\\'")}')"><i class="fas fa-plus-circle"></i> Appointment</div>`;
    }
    if(!t.jobs.length)html+=`<div class="disp-add" onclick="dispAddAppt('${t.technician_id}','09:00')" style="opacity:.7;padding:8px 0"><i class="fas fa-plus-circle"></i> Add first appointment</div>`;
    // Show breaks for this tech
    if(t.breaks&&t.breaks.length){
      for(const brk of t.breaks){
        html+=`<div style="padding:6px 8px;margin:4px 0;background:rgba(255,152,0,0.12);border-left:3px solid #FF9800;border-radius:0 4px 4px 0;font-size:11px;color:#E65100;font-weight:600">☕ ${brk.name} ${brk.start}–${brk.end}</div>`;
      }
      // Add "+ Appointment" after the last break so users can schedule in the afternoon
      const lastBreak=t.breaks[t.breaks.length-1];
      const afterBreakTime=lastBreak.end||'13:00';
      // Only show if after-break time is before end of day (18:00)
      if(afterBreakTime<'18:00'){
        html+=`<div class="disp-add" onclick="dispAddAppt('${t.technician_id}','${afterBreakTime}',30,0)"><i class="fas fa-plus-circle"></i> Appointment</div>`;
      }
    }
    html+=`</div></div>`;
  }
  g.innerHTML=html;
  f.innerHTML=`<div class="leg"><div class="ld" style="background:#4CAF50"></div>Active</div><div class="leg"><div class="ld" style="background:#FF9800"></div>Late</div><div class="leg"><div class="ld" style="background:#ccc"></div>Not started</div><span style="margin-left:auto">${d.total_jobs} jobs across ${d.technician_count} technicians</span>`;
  // Slice E1: wire density-band hover handlers on the freshly rendered cols.
  if(window.dispatchDensity&&window.dispatchDensity.attach){window.dispatchDensity.attach(g);}
  // R20 RTE4: populate per-tech-day density badges via /density-by-day/.
  // Re-fired on every dispatch render because disp-col cells are recreated.
  if(window.densityBadges&&window.densityBadges.load){
    const ws=window.densityBadges.weekStartFor(dispDate||localDateStr());
    if(ws){g.dataset.weekStart=ws;window.densityBadges.load(ws,g);}
  }
}

// F-017: dispatch-view appointment blocks are rendered as plain <div class="rj">
// inside #dispGrid (not FullCalendar events), so the calendar-wide eventClick
// handler never fires for them. Wire a one-time delegated click on #dispGrid
// that opens the same edit modal the week/day views use.
document.addEventListener('DOMContentLoaded',function(){
  var grid=document.getElementById('dispGrid');
  if(!grid)return;
  grid.addEventListener('click',function(ev){
    var block=ev.target.closest('[data-appointment-id]');
    if(!block||!grid.contains(block))return;
    var id=block.dataset.appointmentId;
    if(!id)return;
    if(typeof openEditAppt==='function')openEditAppt(id);
  });
});

// ===== SLICE E1: DISPATCH DENSITY WIDGET =====
//
// Populates the per-tech-day density band (.density-band inside each
// .disp-col) lazily on hover, and exposes window.dispatchDensity.previewAddition
// for callers (e.g. an unassigned-jobs drawer) to show a real-time fit score
// while dragging a candidate appointment over a tech column.
//
// API surface used:
//   GET  /api/v1/scheduling/density/?tech_id=&date=
//   POST /api/v1/scheduling/density/score-addition/  body: {tech_id,date,candidate_appointment_id}
(function(){
  const cache = new Map();   // key: techId|date  -> {density,color_band,appointment_count}
  const inflight = new Map();
  function key(techId,date){return techId+'|'+date}
  function bandLabel(b){return b==='green'?'Tight route':b==='amber'?'Moderate spread':b==='red'?'Spread out':''}
  function fmt(d){return (typeof d==='number'?d.toFixed(2):'?')}

  async function fetchDensity(techId,date){
    const k=key(techId,date);
    if(cache.has(k))return cache.get(k);
    if(inflight.has(k))return inflight.get(k);
    const p=fetch(API+'/scheduling/density/?tech_id='+encodeURIComponent(techId)+'&date='+encodeURIComponent(date),{credentials:'same-origin',headers:hdr()})
      .then(r=>r.ok?r.json():Promise.reject(r.status))
      .then(j=>{cache.set(k,j);inflight.delete(k);return j})
      .catch(err=>{inflight.delete(k);throw err});
    inflight.set(k,p);
    return p;
  }

  function render(el,data){
    if(!el)return;
    el.dataset.band=data.color_band||'';
    el.dataset.loaded='1';
    el.dataset.preview='0';
    el.querySelector('.db-meta').textContent='Route density: '+fmt(data.density)+' · '+(data.appointment_count||0)+' stop'+((data.appointment_count===1)?'':'s');
    const tip=el.querySelector('.db-tip');
    if(tip){
      const lbl=bandLabel(data.color_band);
      tip.textContent='Route density '+fmt(data.density)+'. '+(lbl?lbl+' (':'')+'green ≥0.6, amber ≥0.3, red <0.3'+(lbl?')':'')+'. Lower mean miles between stops = higher density.';
    }
  }

  function renderPreview(el,data){
    if(!el)return;
    el.dataset.band=data.color_band||'';
    el.dataset.preview='1';
    el.querySelector('.db-label').textContent='Adding fit';
    el.querySelector('.db-meta').textContent='Fit '+fmt(data.fit_score)+' · +'+(typeof data.miles_added==='number'?data.miles_added.toFixed(1):'?')+'mi';
    const tip=el.querySelector('.db-tip');
    if(tip)tip.textContent='Fit score '+fmt(data.fit_score)+' if added here (1.0 = on-route, 0.0 = far). +'+(data.miles_added||0).toFixed(1)+' mi mean detour.';
  }

  function clearPreview(col){
    if(!col)return;
    col.removeAttribute('data-density-drop-active');
    const el=col.querySelector('[data-density-band]');
    if(!el)return;
    el.dataset.preview='0';
    el.querySelector('.db-label').textContent='Density';
    const k=key(col.dataset.techId,col.dataset.dispDate);
    if(cache.has(k))render(el,cache.get(k));
  }

  async function loadIntoCol(col){
    const el=col.querySelector('[data-density-band]');
    if(!el||el.dataset.loaded==='1'||el.dataset.loading==='1')return;
    el.dataset.loading='1';
    try{
      const data=await fetchDensity(col.dataset.techId,col.dataset.dispDate);
      render(el,data);
    }catch(err){
      el.dataset.band='';
      el.querySelector('.db-meta').textContent='unavailable';
    }finally{
      el.dataset.loading='0';
    }
  }

  function attach(root){
    const cols=(root||document).querySelectorAll('.disp-col[data-tech-id][data-disp-date]');
    cols.forEach(col=>{
      if(col.dataset.densityBound==='1')return;
      col.dataset.densityBound='1';
      const el=col.querySelector('[data-density-band]');
      if(el){
        const trigger=()=>loadIntoCol(col);
        el.addEventListener('mouseenter',trigger);
        el.addEventListener('focus',trigger);
        // Also load on first hover anywhere in the column (the band may be
        // off-screen for tall columns until you scroll, but the user is
        // clearly interested in this tech's day).
        col.addEventListener('mouseenter',trigger,{once:true});
      }
      col.addEventListener('dragover',function(ev){
        // Only react if the drag carries our candidate-appointment MIME.
        const types=ev.dataTransfer?ev.dataTransfer.types:null;
        if(!types||!Array.from(types).some(t=>t==='application/x-candidate-appointment-id'||t==='text/x-candidate-appointment-id'))return;
        ev.preventDefault();
        col.dataset.densityDropActive='1';
        if(col.dataset.densityPreviewing==='1')return;
        col.dataset.densityPreviewing='1';
        let candidateId='';
        try{candidateId=ev.dataTransfer.getData('application/x-candidate-appointment-id')||ev.dataTransfer.getData('text/x-candidate-appointment-id')||'';}catch(_){candidateId=''}
        if(!candidateId){col.dataset.densityPreviewing='0';return}
        previewAddition(col.dataset.techId,col.dataset.dispDate,candidateId,el).finally(()=>{col.dataset.densityPreviewing='0'});
      });
      col.addEventListener('dragleave',function(ev){
        // Only clear when we leave the column itself, not a child.
        if(ev.relatedTarget&&col.contains(ev.relatedTarget))return;
        clearPreview(col);
      });
      col.addEventListener('drop',function(){clearPreview(col)});
    });
  }

  async function previewAddition(techId,date,candidateApptId,bandEl){
    const target=bandEl||document.querySelector('.disp-col[data-tech-id="'+techId+'"][data-disp-date="'+date+'"] [data-density-band]');
    if(!target)return null;
    try{
      const r=await fetch(API+'/scheduling/density/score-addition/',{method:'POST',credentials:'same-origin',headers:hdr(),body:JSON.stringify({tech_id:techId,date:date,candidate_appointment_id:candidateApptId})});
      if(!r.ok)throw r.status;
      const j=await r.json();
      renderPreview(target,j);
      return j;
    }catch(err){
      return null;
    }
  }

  function invalidate(techId,date){
    if(techId&&date){cache.delete(key(techId,date));return}
    cache.clear();
  }

  window.dispatchDensity={attach:attach,previewAddition:previewAddition,invalidate:invalidate,_cache:cache};
})();


function onAvailDateChange(){
  // Update sFrom/sTo from the avail panel pickers, then reload
  const af=document.getElementById('availFrom'),at=document.getElementById('availTo');
  const sf=document.getElementById('sFrom'),st=document.getElementById('sTo');
  if(af&&af.value){if(sf)sf.value=af.value;}
  if(at&&at.value){if(st)st.value=at.value;}
  else if(af&&af.value){if(st)st.value=af.value;}
  loadAvailability();
}
function availToday(){
  const today=localDateStr();
  const end=localDateStr(new Date(Date.now()+6*864e5));
  const af=document.getElementById('availFrom'),at=document.getElementById('availTo');
  if(af)af.value=today;if(at)at.value=end;
  const sf=document.getElementById('sFrom'),st=document.getElementById('sTo');
  if(sf)sf.value=today;if(st)st.value=end;
  loadAvailability();
}
async function loadAvailability(){
  const grid=document.getElementById('availGrid');
  const days=document.getElementById('availDays').value;
  const dur=document.getElementById('availDur').value;
  const searchDur=document.getElementById('sDur').value;
  if(searchDur && searchDur!=='30'){document.getElementById('availDur').value=searchDur}
  const start=document.getElementById('sFrom').value||localDateStr();
  grid.innerHTML='<div style="padding:30px;text-align:center;color:var(--text-light)"><i class="fas fa-spinner fa-spin"></i> Loading availability...</div>';
  
  // Use smart-slots API (same as Week/Resource view)
  const p=new URLSearchParams({date:start,duration:dur,days:days,address:document.getElementById('sAddr').value||''});
  if(searchCust)p.set('customer',searchCust.id);
  const jt=document.getElementById('sJobType')?document.getElementById('sJobType').value:'';
  if(jt)p.set('job_type',jt);
  
  let d;
  try{
    d=await api('/scheduling/smart-slots/?'+p.toString());
    // Also update lastSearchData so resource view stays in sync
    lastSearchData=d;lastSearchDur=parseInt(dur);
    // Build techId -> timezone map from search results
    window._techTzMap={};
    if(d.technicians){d.technicians.forEach(t=>{if(t.timezone)window._techTzMap[t.technician_id]=t.timezone;});}
  }catch(e){
    grid.innerHTML='<div style="padding:30px;text-align:center;color:var(--text-light)">Error loading availability</div>';
    return;
  }
  
  if(!d.technicians||!d.technicians.length){
    grid.innerHTML='<div style="padding:30px;text-align:center;color:var(--text-light)">No qualified technicians available for this search</div>';
    return;
  }
  
  // Group slots by date per tech
  let html='';
  for(const t of d.technicians){
    // Build slot groups by date
    const byDate={};
    for(const s of t.slots){
      if(!byDate[s.date])byDate[s.date]=[];
      byDate[s.date].push(s);
    }
    
    // Build badges
    let badges='';
    if(t.is_preferred) badges+='<span style="background:#FFF3E0;color:#E65100;padding:2px 8px;border-radius:10px;font-size:9px;font-weight:700">★ PREFERRED</span> ';
    if(t.ability){
      const ac=t.ability.proficiency>=4?'#E8F5E9;color:#2E7D32':t.ability.proficiency>=3?'#FFF8E1;color:#F57F17':'#FBE9E7;color:#BF360C';
      badges+='<span style="background:'+ac+';padding:2px 8px;border-radius:10px;font-size:9px;font-weight:700">'+t.ability.proficiency_label+' · '+t.ability.score+' pts</span> ';
    }
    if(t.max_travel_minutes) badges+='<span style="background:#E3F2FD;color:#1565C0;padding:2px 8px;border-radius:10px;font-size:9px;font-weight:700">Max travel: '+t.max_travel_minutes+'min</span> ';
    
    const avgSc=t.avg_score||0;
    const scoreColor=avgSc>=70?'#4CAF50':avgSc>=40?'#FF9800':'#f44336';
    
    html+='<div class="avail-tech">';
    html+='<div class="avail-tech-hdr">';
    html+='<div class="av" style="background:'+t.technician_color+'">'+(t.technician_name||'').split(' ').map(n=>n[0]).join('')+'</div>';
    html+='<div class="info"><div class="tn">'+t.technician_name+' '+badges+'</div>';
    const techBreaks=t.slots.filter(s=>s.break_minutes>0);
    const brkLabel=techBreaks.length?' · ☕ Breaks: '+techBreaks.map(s=>s.breaks&&s.breaks.length?s.breaks[0].name+' '+s.breaks[0].start_time.slice(0,5)+'-'+s.breaks[0].end_time.slice(0,5):'').filter(x=>x).join(', '):'';
    html+='<div class="ts">'+t.slot_count+' open slots · Avg Score: '+avgSc+brkLabel+'</div></div>';
    html+='<div style="text-align:right"><div style="font-size:11px;font-weight:700;color:'+scoreColor+'">'+avgSc+' pts</div></div>';
    html+='</div>';
    
    html+='<div class="avail-days">';
    const dates=Object.keys(byDate).sort();
    for(const day of dates){
      const dt=new Date(day+'T12:00:00');
      const label=dt.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
      const slots=byDate[day];
      html+='<div class="avail-day"><div class="dl">'+label+'</div><div class="slots">';
      for(const s of slots){
        const sc=s.score||0;
        const slotBg=sc>=70?'background:#E8F5E9;border-color:#4CAF50;color:#2E7D32':sc>=40?'background:#FFF8E1;border-color:#FF9800;color:#E65100':'background:#FFEBEE;border-color:#EF5350;color:#C62828';
        const mins=s.available_minutes||0;
        // Build per-slot travel info
        let travelInfo='';
        if(s.break_minutes) travelInfo+=' · ☕ '+s.break_minutes+'min break';
        if(s.travel_from_previous!==null&&s.travel_from_previous!==undefined) travelInfo+=' · 🚗 '+s.travel_from_previous+'min from '+(s.previous_job||'prev');
        if(s.travel_to_next!==null&&s.travel_to_next!==undefined) travelInfo+=' · '+s.travel_to_next+'min to '+(s.next_job||'next');
        
        html+='<div class="avail-slot" style="'+slotBg+'" onclick="availBook(\x27'+t.technician_id+'\x27,\x27'+s.date+'\x27,\x27'+s.start_time+'\x27,\x27'+s.end_time+'\x27,'+(s.travel_from_previous||0)+','+(s.travel_to_next||0)+','+(!!(s.is_first_slot))+')" title="Score: '+sc+travelInfo+'">';
        html+='<span class="st">'+fmtSlotTime(s.start_time)+'–'+fmtSlotTime(s.end_time)+'</span>';
        html+='<span class="dur">'+mins+'min</span>';
        // CAL-TRAVEL: show both legs of travel time visibly on the slot card.
        // Skip the prev-leg chip on first-of-day slots (tech starts from home, no prior job).
        if(s.travel_from_previous>0&&!s.is_first_slot) html+='<span class="dur" style="margin-left:4px;opacity:.7" title="'+(s.travel_from_previous+'min from '+(s.previous_job||'prev'))+'">🚗'+s.travel_from_previous+'m←</span>';
        if(s.travel_to_next>0) html+='<span class="dur" style="margin-left:4px;opacity:.7" title="'+(s.travel_to_next+'min to '+(s.next_job||'next'))+'">→'+s.travel_to_next+'m🚗</span>';
        if(s.break_minutes) html+='<span class="dur" style="margin-left:4px;opacity:.7">☕'+s.break_minutes+'m</span>';
        if(s.extended_travel) html+='<span class="dur" style="margin-left:4px;background:#FFF3E0;color:#E65100;border:1px solid #FFB74D;border-radius:6px;padding:0 4px;font-weight:600">long drive</span>';
        html+='<span class="dur" style="margin-left:auto;font-weight:700">'+sc+'</span>';
        html+='</div>';
      }
      html+='</div></div>';
    }
    html+='</div></div>';
  }
  grid.innerHTML=html;
}

function fmtSlotTime(t){
  if(!t)return '';
  const [h,m]=t.split(':').map(Number);
  const ampm=h>=12?'PM':'AM';
  const h12=h%12||12;
  return h12+':'+String(m).padStart(2,'0')+ampm;
}

function availBook(techId,date,startTime,endTime,travelMin,travelToNext,isFirst){
  openBookModal();
  document.getElementById('bDate').value=date;
  // Offset start time by travel minutes — but NOT for first job of day (tech starts from home/office)
  let adjStart=startTime;
  if(travelMin && travelMin>0 && !isFirst){
    let [h,m]=startTime.split(':').map(Number);
    m+=travelMin;
    while(m>=60){m-=60;h++}
    m=Math.ceil(m/5)*5;
    if(m>=60){m=0;h++}
    adjStart=String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
  }
  document.getElementById('bTime').value=adjStart;
  // Cap duration: must leave room for travel to next job
  if(endTime && travelToNext>0){
    const [sh,sm]=adjStart.split(':').map(Number);
    const [eh,em]=endTime.split(':').map(Number);
    const maxMin=(eh*60+em)-(sh*60+sm)-travelToNext;
    if(maxMin>0){
      const curDur=parseInt(document.getElementById('bDur').value)||30;
      if(curDur>maxMin) document.getElementById('bDur').value=Math.floor(maxMin/5)*5;
    }
  }
  for(let o of document.getElementById('bTech').options){
    if(o.value===techId){o.selected=true;break}
  }
  // Look up breaks for this slot
  if(window._slotBreaksMap){
    const key=techId+'_'+date+'_'+startTime;
    setBookingBreaks(window._slotBreaksMap[key]||[]);
  }
  if(lastSearchData&&lastSearchData.job_address)document.getElementById('bLoc').value=lastSearchData.job_address;
  // Job type is already pre-checked by openBookModal() (called above) from #sJobType.
  if(searchCust){bookCust=searchCust;document.getElementById('bCustId').value=searchCust.id;showTag('bCustTag','bCustWrap',searchCust,"clearBookCust()");loadServiceLocations(searchCust.id);bApplyBookingMode()}
}

// Store breaks for the selected slot (used by saveAppt to wrap around breaks)
window._bookingBreaks=[];
function setBookingBreaks(breaks){window._bookingBreaks=breaks||[];}

function dispAddAppt(techId, endTime24, jobDuration, travelToNext, custId, custName, location){
  openBookModal();
  // F-PREFS-2 Slice C.3.2 — mark this booking-modal session as a dispatch flow
  // so the bTech change listener tags its console.warn with context:'dispatch'.
  // openBookModal() resets to 'booking' by default; this override must come after.
  _currentBookContext='dispatch';
  document.getElementById('bDate').value=dispDate;
  
  // Calculate start time: previous job end + drive time to next
  if(endTime24){
    let [h,m]=endTime24.split(':').map(Number);
    // Add travel time (drive from previous job location to next)
    const driveMin=travelToNext||15; // default 15min buffer if no travel data
    m+=driveMin;
    while(m>=60){m-=60;h++}
    // Round to nearest 15 min
    m=Math.ceil(m/15)*15;
    if(m>=60){m=0;h++}
    document.getElementById('bTime').value=String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
  }
  
  // Pre-select technician
  for(let o of document.getElementById('bTech').options){
    if(o.value===techId){o.selected=true;break}
  }
  
  // Pre-populate customer if we have one
  if(custId && custName){
    document.getElementById('bCustId').value=custId;
    document.getElementById('bCust').value='';
    document.getElementById('bCustWrap').style.display='none';
    document.getElementById('bCustTag').style.display='block';
    document.getElementById('bCustTag').innerHTML=`<span class="ct">${custName} <span class="x" onclick="clearBookCust()">&times;</span></span>`;
    bookCust={id:custId,full_name:custName};loadServiceLocations(custId);
  }
  
  // Pre-fill location
  if(location){
    document.getElementById('bLoc').value=location;
  }
}
function dispToday(){
  const today=localDateStr();
  document.getElementById('dispFrom').value=today;
  document.getElementById('dispTo').value=today;
  dispDate=today;
  loadDispatch();
}
function showDispDay(dateStr){
  dispDate=dateStr;
  loadDispatch();
}
function dispNav(dir){
  if(dir===0){dispDate=localDateStr()}
  else{const dt=new Date(dispDate+'T12:00:00');dt.setDate(dt.getDate()+dir);dispDate=localDateStr(dt)}
  document.getElementById('dispFrom').value=dispDate;
  document.getElementById('dispTo').value=dispDate;
  loadDispatch();
}

// ===== CALENDAR INIT =====
async function init(){
  // Stale-validation cleanup on both calendar modals (idempotent, attaches once).
  if(window.cbpAttachClearOnInput){
    cbpAttachClearOnInput(document.getElementById('bookModal'));
    cbpAttachClearOnInput(document.getElementById('editApptModal'));
  }
  // R16 DL5: fetch tenant's dispatch lockout policy alongside techs/job-types
  // so badge rendering + locked-out gray-out can decide synchronously below.
  const[ts,jts,_lp]=await Promise.all([api('/technicians/'),api('/job-types/'),loadDispatchLockoutPolicy()]);
  techs=ts.results||[];jobTypes=jts.results||[];
  const sj=document.getElementById('sJobType');jobTypes.forEach(j=>{const o=document.createElement('option');o.value=j.id;o.textContent=j.name;o.dataset.dur=j.default_duration;sj.appendChild(o)});
  sj.addEventListener('change',function(){const o=this.options[this.selectedIndex];if(o.dataset.dur)document.getElementById('sDur').value=o.dataset.dur});
  const bt=document.getElementById('bTech'),bj=document.getElementById('bJobType');
  // R16 DL5: stamp data-license-status on each option so dispatch JS / future
  // modals can read posture without re-querying. Native <option> can't render
  // HTML so we append a glyph to t.name for visual feedback.
  techs.forEach(t=>{const o=document.createElement('option');o.value=t.id;o.textContent=(t.name||t.id)+optionGlyph(t.license_status);o.dataset.serviceable=JSON.stringify(t.serviceable_property_types||[]);o.dataset.licenseStatus=(t.license_status&&t.license_status.status)||'unknown';if(isLockedOut(t.license_status)){o.disabled=true;o.classList.add('tech-locked-out');}bt.appendChild(o)});
  // F-PREFS-2 Slice C.3.2 — booking-modal tech-dropdown mismatch detection.
  // 'change' only fires on user input; programmatic .selected=true (auto-select,
  // dispAddAppt pre-fill, slot bookFromAvail) stays silent — that's intentional.
  bt.addEventListener('change',function(){
    _prefsCheckMismatch({customer:bookCust,techId:this.value,context:_currentBookContext});
  });
  // F-PREFS-2 Slice C.3.2 — edit-modal tech-dropdown mismatch detection.
  // ea-tech options are populated each time eaLoadAppt runs, but the <select>
  // element itself is static — attach the listener once here.
  const eaT=document.getElementById('ea-tech');
  if(eaT){
    eaT.addEventListener('change',function(){
      _prefsCheckMismatch({customer:_eaCustPref,techId:this.value,context:'edit'});
    });
  }
  jtRenderChecks('bJobType', []);
  // Multi-job: auto-fill duration only when exactly ONE service is checked
  // (manual otherwise, per the multi-job decision).
  bj.addEventListener('change',function(){const ck=bj.querySelectorAll('input[type=checkbox]:checked');if(ck.length===1&&ck[0].dataset.dur)document.getElementById('bDur').value=ck[0].dataset.dur;bApplyBookingMode();});
  const tc=document.getElementById('techChips');
  tc.innerHTML='<div class="tc on" onclick="filt(null,this)"><div class="d" style="background:#999"></div>All</div>';
  // R16 DL5: chips row supports HTML so we render the full <span class="tech-license-badge"> here.
  techs.forEach(t=>{const lockedCls=isLockedOut(t.license_status)?' tech-locked-out':'';tc.innerHTML+=`<div class="tc${lockedCls}" data-license-status="${(t.license_status&&t.license_status.status)||'unknown'}" onclick="filt('${t.id}',this)"><div class="d" style="background:${t.color||'#2196F3'}"></div>${t.name}${badgeHtml(t.license_status)}</div>`});
  const today=localDateStr();
  document.getElementById('sFrom').value=today;document.getElementById('sTo').value=localDateStr(new Date(Date.now()+6*864e5));const _af=document.getElementById('availFrom'),_at=document.getElementById('availTo');if(_af)_af.value=today;if(_at)_at.value=localDateStr(new Date(Date.now()+6*864e5));
  document.getElementById('bDate').value=today;document.getElementById('bDate').min=today;
  initAC('sCust','sCustDD','sCustTag',c=>{searchCust=c;showTag('sCustTag','sCustWrap',c,'clearSearch()');if(c.full_address)document.getElementById('sAddr').value=c.full_address});
  initAC('bCust','bCustDD','bCustTag',c=>{bookCust=c;if(c.property_type)filterTechsByProperty(c.property_type);loadServiceLocations(c.id);document.getElementById('bCustId').value=c.id;showTag('bCustTag','bCustWrap',c,"clearBookCust()");if(c.full_address)document.getElementById('bLoc').value=c.service_address||c.full_address;if(document.getElementById('bLoc2')&&c.service_address_2)document.getElementById('bLoc2').value=c.service_address_2;if(c.preferred_technician){for(let o of document.getElementById('bTech').options)if(o.value===c.preferred_technician.id){o.selected=true;break}}bFillCustSiteNotes(c);if(document.getElementById('bSiteContactName'))document.getElementById('bSiteContactName').value=c.site_contact_name||'';if(document.getElementById('bSiteContactPhone'))document.getElementById('bSiteContactPhone').value=c.site_contact_phone||'';if(document.getElementById('bSiteContactEmail'))document.getElementById('bSiteContactEmail').value=c.site_contact_email||'';if(document.getElementById('bSiteContactRole'))document.getElementById('bSiteContactRole').value=c.site_contact_role||'';bApplyBookingMode();});
  setTimeout(()=>{gmAC('sAddr');gmAC('bLoc');gmAC('ea-cust-addr');gmAC('ea-loc')},1000);
  cal=new FullCalendar.Calendar(document.getElementById('calendar'),{
    initialView:'rolling7',views:{rolling7:{type:'timeGrid',duration:{days:7},buttonText:'7 Days'}},initialDate:localDateStr(),headerToolbar:{left:'prev,next today',center:'title',right:'dayGridMonth,rolling7,timeGridDay'},
    timeZone: window._tenantTz || 'America/New_York',
    slotMinTime:'06:00:00',slotMaxTime:'21:00:00',slotDuration:'00:15:00',allDaySlot:false,slotLabelFormat:{hour:'numeric',minute:'2-digit',omitZeroMinute:true,meridiem:'short'},nowIndicator:true,selectable:true,selectOverlap:false,slotEventOverlap:false,unselectAuto:true,editable:false,droppable:true,
    drop(info){ try{ flexHandleDrop(info); }catch(e){ console.error('flex drop',e); } },
    height:'auto',expandRows:true,stickyHeaderDates:true,eventTimeFormat:{hour:'numeric',minute:'2-digit',meridiem:'short'},
    events:(info,ok,fail)=>{let u=`/scheduling/calendar/?start=${info.startStr.slice(0,10)}&end=${info.endStr.slice(0,10)}`;if(selTech)u+=`&technician=${selTech}`;
      api(u).then(d=>ok(d.map(e=>{
        const isBreak=e.display==='background';
        return{id:e.id,title:e.title,start:e.start,end:e.end,
          backgroundColor:isBreak?'rgba(255,152,0,0.15)':e.color,
          borderColor:isBreak?'#FF9800':e.color,
          display:isBreak?'background':undefined,
          extendedProps:{type:isBreak?'break':'appt',...e}}
      }))).catch(fail)},
    eventClick(info){info.jsEvent.preventDefault();info.jsEvent.stopPropagation();const p=info.event.extendedProps;if(p.type==='break')return;if(p.type==='avail'){bookFromAvail({...p, event:info.event});return}showDet(info.event)},
    select(info){if(document.getElementById('detPanel').classList.contains('open')){closeDet();cal.unselect();return}document.getElementById('bDate').value=info.startStr.slice(0,10);document.getElementById('bTime').value=info.startStr.slice(11,16)||'09:00';openBookModal()},
    eventDidMount(info){const p=info.event.extendedProps;if(p.type==='avail'){info.el.style.cursor='pointer';info.el.title='Click to book: '+p.tech_name+(p.is_preferred?' (★ Preferred)':'')}else if(p.type==='appt'&&p.arrival_window_label){info.el.title=(info.el.title?info.el.title+'\n':'')+'Customer arrival window: '+p.arrival_window_label;}}
  });
  cal.render();
  // FullCalendar's timeGrid can mis-size its day columns when first rendered
  // before the container has its final layout (notably under the cbp-spa
  // content swap + DOMContentLoaded shim), collapsing the 7-day view to just
  // the current day until the user clicks Today. Force a re-measure once the
  // layout has settled so the full week shows immediately.
  requestAnimationFrame(function(){ try{ cal.updateSize(); }catch(e){} });
  setTimeout(function(){ try{ cal.updateSize(); }catch(e){} }, 150);
  // Load break events for visible date range
  loadBreakEvents();

  // ===== Pre-fill from ?customer=<uuid> (deep-link from customer detail page) =====
  try {
    const params = new URLSearchParams(window.location.search);
    const preCustId = params.get('customer');
    if (preCustId) {
      const c = await api('/customers/' + preCustId + '/');
      if (c && c.id) {
        // Hydrate searchCust so subsequent flows pick it up
        searchCust = c;
        // Build display object the autocomplete tag expects (full_name + tag UI)
        const displayName = c.full_name || ((c.first_name||'') + ' ' + (c.last_name||'')).trim() || c.company_name || 'Customer';
        const tagPayload = Object.assign({}, c, { full_name: displayName });
        showTag('sCustTag','sCustWrap', tagPayload, 'clearSearch()');
        if (c.full_address) document.getElementById('sAddr').value = c.full_address;
        // Auto-open booking modal — existing logic at openBookModal() picks up searchCust
        setTimeout(() => openBookModal(), 600);
      }
    }
  } catch (e) {
    console.warn('Customer prefill failed:', e);
  }
}

async function loadBreakEvents(){
  try{
    const d=await api('/work-schedules/');
    if(!d.results)return;
    // Remove existing break events
    cal.getEvents().forEach(e=>{if(e.extendedProps&&e.extendedProps.type==='break')e.remove()});
    for(const sched of d.results){
      const days=sched.days||[];
      for(const day of days){
        if(!day.is_working_day||!day.breaks||!day.breaks.length)continue;
        // Find dates in the visible range that match this day_of_week
        const view=cal.view;
        const start=new Date(view.activeStart);
        const end=new Date(view.activeEnd);
        for(let dt=new Date(start);dt<end;dt.setDate(dt.getDate()+1)){
          if(dt.getDay()===((day.day_of_week+1)%7)){// JS Sun=0, Django Mon=0
            const dateStr=localDateStr(dt);
            for(const brk of day.breaks){
              cal.addEvent({
                title:'☕ '+brk.name,
                start:dateStr+'T'+(brk.start_time||'').slice(0,5)+':00',
                end:dateStr+'T'+(brk.end_time||'').slice(0,5)+':00',
                display:'background',
                backgroundColor:'rgba(255,152,0,0.15)',
                borderColor:'#FF9800',
                extendedProps:{type:'break',name:brk.name}
              });
            }
          }
        }
      }
    }
  }catch(e){console.warn('Break events load failed:',e)}
}
// Reload breaks when calendar navigates
document.addEventListener('DOMContentLoaded',()=>{
  setTimeout(()=>{if(cal)cal.on('datesSet',loadBreakEvents)},2000);
});

// ═══ RESOURCE DAY VIEW ═══
let lastSearchData=null;
let lastSearchDur=30;
let rvDate=new Date();
const HOURS_START=7,HOURS_END=21;

function initRV(){
  const today=new Date();
  rvDate=new Date(today);
  syncRVFromSearch();
  // Default the pickers directly above the calendar to today → 7 days from now
  const rvF=document.getElementById('rvFrom'),rvT=document.getElementById('rvTo');
  const end=new Date();end.setDate(end.getDate()+7);
  if(rvF)rvF.value=localDateStr(new Date());
  if(rvT)rvT.value=localDateStr(end);
}
function fmt(d){const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),dd=String(d.getDate()).padStart(2,'0');return y+'-'+m+'-'+dd}
function rvPrev(){rvDate.setDate(rvDate.getDate()-7);syncRVDates();loadRV()}
function rvNext(){rvDate.setDate(rvDate.getDate()+7);syncRVDates();loadRV()}
function rvToday(){rvDate=new Date();syncRVDates();loadRV()}
function syncRVDates(){
  // Called by prev/next/today — update the visible RV date inputs
  const d0=new Date(rvDate);
  d0.setDate(d0.getDate()-d0.getDay()+1); // Monday of week
  const d6=new Date(d0);d6.setDate(d0.getDate()+6);
  const fmt=d=>localDateStr(d);
  const rvF=document.getElementById('rvFrom'),rvT=document.getElementById('rvTo');
  if(rvF)rvF.value=fmt(d0);
  if(rvT)rvT.value=fmt(d6);
  // Also keep sFrom/sTo in sync for search panel
  const sFrom=document.getElementById('sFrom'),sTo=document.getElementById('sTo');
  if(sFrom)sFrom.value=fmt(d0);
  if(sTo)sTo.value=fmt(d6);
}
function onRVDateChange(){
  // User changed the visible RV date picker — drive rvDate from it
  const rvF=document.getElementById('rvFrom');
  if(rvF&&rvF.value){
    rvDate=new Date(rvF.value+'T00:00:00');
    const rvT=document.getElementById('rvTo');
    // If to < from, snap to from
    if(rvT&&rvT.value&&rvT.value<rvF.value)rvT.value=rvF.value;
    // Sync sFrom/sTo
    const sFrom=document.getElementById('sFrom'),sTo=document.getElementById('sTo');
    if(sFrom)sFrom.value=rvF.value;
    if(sTo&&rvT)sTo.value=rvT.value||rvF.value;
    loadRV();
  }
}
function syncRVFromSearch(){
  const sFrom=document.getElementById('sFrom'),sTo=document.getElementById('sTo');
  const rvF=document.getElementById('rvFrom'),rvT=document.getElementById('rvTo');
  if(!rvF||!rvT)return;
  if(sFrom&&sFrom.value){rvF.value=sFrom.value;const af=document.getElementById('availFrom');if(af)af.value=sFrom.value;}
  else rvF.value=fmt(new Date());
  if(sTo&&sTo.value)rvT.value=sTo.value;
  else{const e=new Date();e.setDate(e.getDate()+6);rvT.value=fmt(e)}
}


function bookFromRVSlot(techId,date,startTime,dur,travelMin,travelToNext,slotEnd,isFirst){
  // Look up breaks for this slot from the global map
  if(window._slotBreaksMap){
    // Find the slot that contains this segment's start time
    for(const [k,v] of Object.entries(window._slotBreaksMap)){
      if(k.startsWith(techId+'_'+date+'_')){setBookingBreaks(v);break;}
    }
  }
  openBookModal();
  document.getElementById('bDate').value=date;
  // Offset start time by travel minutes — but NOT for first job of day
  let adjStart=startTime;
  if(travelMin && travelMin>0 && !isFirst){
    let [h,m]=startTime.split(':').map(Number);
    m+=travelMin;
    while(m>=60){m-=60;h++}
    m=Math.ceil(m/5)*5;
    if(m>=60){m=0;h++}
    adjStart=String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
  }
  document.getElementById('bTime').value=adjStart;
  // Cap duration: must leave room for travel to next job
  let adjDur=dur;
  if(slotEnd && travelToNext>0){
    const [sh,sm]=adjStart.split(':').map(Number);
    const [eh,em]=slotEnd.split(':').map(Number);
    const maxMin=(eh*60+em)-(sh*60+sm)-travelToNext;
    if(maxMin>0 && dur>maxMin) adjDur=Math.floor(maxMin/5)*5;
  }
  document.getElementById('bDur').value=adjDur;
  for(let o of document.getElementById('bTech').options)if(o.value===techId){o.selected=true;break}
  if(lastSearchData&&lastSearchData.job_address)document.getElementById('bLoc').value=lastSearchData.job_address;
  // Job type is already pre-checked by openBookModal() (called above) from #sJobType.
  if(searchCust){bookCust=searchCust;document.getElementById('bCustId').value=searchCust.id;showTag('bCustTag','bCustWrap',searchCust,"clearBookCust()");if(searchCust.full_address)document.getElementById('bLoc').value=searchCust.full_address;bApplyBookingMode()}
}

function syncSearchToRV(from,to){
  const rvF=document.getElementById('rvFrom'),rvT=document.getElementById('rvTo');
  if(rvF&&from)rvF.value=from;
  if(rvT)rvT.value=to||from||rvT.value;
  const af=document.getElementById('availFrom');if(af&&from)af.value=from;
  // If resource view is active, reload it to show the searched range
  const rvEl=document.getElementById('resourceView');
  if(rvEl&&rvEl.classList.contains('active'))loadRV();
}

async function loadRV(){
  const fromEl=document.getElementById('rvFrom');
  const toEl=document.getElementById('rvTo');
  if(!fromEl||!toEl)return;
  const fromDate=fromEl.value;
  const toDate=toEl.value;
  if(!fromDate||!toDate)return;
  
  const title=document.getElementById('rvDayTitle');
  const container=document.getElementById('rvContainer');
  if(title)title.textContent='Loading...';
  
  try{
    // Load each day in range
    const start=new Date(fromDate+'T12:00:00');
    const end=new Date(toDate+'T12:00:00');
    const days=[];
    const cur=new Date(start);
    while(cur<=end){days.push(fmt(cur));cur.setDate(cur.getDate()+1)}
    
    // Fetch all days in parallel
    const results=await Promise.all(days.map(d=>api('/scheduling/resource-day/?date='+d)));
    
    if(title){
      const s=new Date(fromDate+'T12:00:00');
      const e=new Date(toDate+'T12:00:00');
      title.textContent=s.toLocaleDateString('en-US',{month:'short',day:'numeric'})+' – '+e.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
    }
    
    renderRVWeek(results, days);
  }catch(e){
    console.error('RV load error',e);
    if(container)container.innerHTML='<div style="padding:40px;text-align:center;color:var(--text-light)">Error loading: '+e.message+'</div>';
  }
}

function renderRVWeek(dayResults, dates){
  const container=document.getElementById('rvContainer');
  if(!container)return;
  if(!dayResults.length||!dayResults[0].technicians){container.innerHTML='<div style="padding:40px;text-align:center;color:var(--text-light)">No data</div>';return}
  
  // Build day tabs
  let html='<div style="display:flex;gap:4px;margin-bottom:8px;flex-wrap:wrap">';
  for(let i=0;i<dates.length;i++){
    const d=new Date(dates[i]+'T12:00:00');
    const label=d.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
    const isToday=dates[i]===fmt(new Date());
    html+='<button type="button" class="nbtn" onclick="showRVDay('+i+')" id="rvDayBtn'+i+'" style="padding:5px 12px;border:1.5px solid '+(isToday?'var(--accent)':'var(--border)')+';border-radius:5px;font-size:11px;font-weight:600;cursor:pointer;background:'+(isToday?'var(--accent)':'var(--white)')+';color:'+(isToday?'var(--primary)':'var(--text)')+'">'+label+'</button>';
  }
  html+='</div>';
  
  // Render each day as a hidden panel
  for(let di=0;di<dayResults.length;di++){
    const data=dayResults[di];
    const techs=data.technicians||[];
    const isToday=dates[di]===fmt(new Date());
    html+='<div class="rv-day-panel" id="rvDayPanel'+di+'" style="display:'+(isToday?'block':'none')+'">';
    html+=renderRVDay(techs, dates[di]);
    html+='</div>';
  }
  
  container.innerHTML=html;
  
  // If today isn't in range, show first day
  const todayIdx=dates.indexOf(fmt(new Date()));
  if(todayIdx===-1)showRVDay(0);
}

window._rvDayCount=0;
function showRVDay(idx){
  document.querySelectorAll('.rv-day-panel').forEach((p,i)=>p.style.display=i===idx?'block':'none');
  document.querySelectorAll('[id^=rvDayBtn]').forEach((b,i)=>{
    b.style.background=i===idx?'var(--accent)':'var(--white)';
    b.style.color=i===idx?'var(--primary)':'var(--text)';
    b.style.borderColor=i===idx?'var(--accent)':'var(--border)';
  });
}

function renderRVDay(techs, dayDate){
  if(!techs.length)return '<div style="padding:20px;text-align:center;color:var(--text-light)">No technicians</div>';
  const ROW_H=40;
  const rows=(HOURS_END-HOURS_START)*2;
  
  // Build availability lookup: tech_id -> slots for this day
  const availByTech={};
  if(lastSearchData&&lastSearchData.technicians){
    for(const st of lastSearchData.technicians){
      const daySlots=(st.slots||[]).filter(s=>s.date===dayDate);
      if(daySlots.length)availByTech[st.technician_id]={slots:daySlots,is_preferred:st.is_preferred,name:st.technician_name};
    }
  }
  
  let html='<div class="rv-grid" style="grid-template-columns:60px repeat('+techs.length+',minmax(140px,1fr))">';
  
  // Header
  html+='<div class="rv-hdr"><div class="cell" style="background:#f8f9fa"></div>';
  for(const t of techs){
    const av=availByTech[t.tech_id];
    const prefBadge=av&&av.is_preferred?' <span style="color:#FFD600">★</span>':'';
    const mtBadge=t.max_travel_minutes?' <span style="font-size:9px;background:#E3F2FD;color:#1565C0;padding:1px 5px;border-radius:8px;font-weight:400" title="Max travel: '+t.max_travel_minutes+'min"><i class="fas fa-car" style="font-size:8px"></i> '+t.max_travel_minutes+'m</span>':'';
    const slotBadge=av?' <span style="font-size:9px;background:#E8F5E9;color:#2E7D32;padding:1px 5px;border-radius:8px;font-weight:400">'+av.slots.length+' slots</span>':'';
    html+='<div class="cell" style="border-bottom:3px solid '+t.color+'">'+t.name+mtBadge+prefBadge+slotBadge+'</div>';
  }
  html+='</div>';
  
  // Time rows
  for(let r=0;r<rows;r++){
    const h=HOURS_START+Math.floor(r/2);
    const m=r%2===0?'00':'30';
    const label=r%2===0?(h>12?h-12:h)+(h>=12?'pm':'am'):'';
    html+='<div class="rv-time">'+label+'</div>';
    
    for(let ti=0;ti<techs.length;ti++){
      const t=techs[ti];
      const slotMins=h*60+parseInt(m);
      let cls='rv-cell';
      let inner='';
      
      if(!t.is_working){
        cls+=' rv-off';
        if(r===Math.floor(rows/2))inner='<div class="rv-off-label">Off</div>';
      }else{
        const ws=tmn(t.work_start||'08:00');
        const we=tmn(t.work_end||'18:00');
        if(slotMins<ws||slotMins>=we){
          cls+=' rv-off';
        }
      }
      
      // Render appointments AND availability in first row only
      if(r===0){
        // Availability slots - clip around existing appointments
        const av=availByTech[t.tech_id];
        if(av){
          // Store breaks map for booking lookup
          if(!window._slotBreaksMap)window._slotBreaksMap={};
          window._techTzMap=window._techTzMap||{};
          if(t.timezone)window._techTzMap[t.tech_id]=t.timezone;
          for(const sl of av.slots){
            const key=t.tech_id+'_'+sl.date+'_'+sl.start_time;
            window._slotBreaksMap[key]=sl.breaks||[];
          }
          // Build list of busy ranges from appointments AND breaks — exact times for segment math (no buffer)
          const busy=(t.appointments||[]).map(a=>{const s=tmn(a.start),e=a.end?tmn(a.end):s+(a.duration||60);return{s,e}});
          // Include breaks as busy ranges so availability doesn't overlap them
          for(const brk of (t.breaks||[])){
            busy.push({s:tmn(brk.start),e:tmn(brk.end)});
          }
          busy.sort((a,b)=>a.s-b.s);
          
          for(const s of av.slots){
            const slotS=tmn(s.start_time), slotE=tmn(s.end_time);
            const sc=s.score||0;
            const cls2=sc>=70?'great':sc>=40?'good':'fair';
            const esc2=(x)=>(x||'').replace(/'/g,'&#39;').replace(/"/g,'&#34;');
            
            // Split this slot into sub-segments that don't overlap with busy ranges
            let segments=[{s:slotS,e:slotE}];
            for(const b of busy){
              const next=[];
              for(const seg of segments){
                if(b.e<=seg.s||b.s>=seg.e){next.push(seg);continue}// no overlap
                if(b.s>seg.s)next.push({s:seg.s,e:b.s});// before busy
                if(b.e<seg.e)next.push({s:b.e,e:seg.e});// after busy
              }
              segments=next;
            }
            // Filter out tiny segments (< 15min)
            segments=segments.filter(seg=>(seg.e-seg.s)>=(lastSearchDur||15));
            
            for(const seg of segments){
              const topPx=(seg.s-HOURS_START*60)/30*ROW_H;
              const hPx=Math.max((seg.e-seg.s)/30*ROW_H,15);
              const segStart=String(Math.floor(seg.s/60)).padStart(2,'0')+':'+String(seg.s%60).padStart(2,'0');
              const segEnd=String(Math.floor(seg.e/60)).padStart(2,'0')+':'+String(seg.e%60).padStart(2,'0');
              
              const brkMin=s.break_minutes||0;
              let tip=segStart+'-'+segEnd+' ('+Math.round(seg.e-seg.s)+'min'+(brkMin?', '+brkMin+'min break':'')+')';
              if(s.travel_from_previous!==null)tip+='\n'+s.travel_from_previous+'min from '+(s.previous_job||'prev');
              if(s.travel_to_next!==null)tip+='\n'+s.travel_to_next+'min to '+(s.next_job||'next');
              tip+='\nScore: '+sc+(av.is_preferred?' ★ PREFERRED':'');
              
              inner+='<div class="rv-avail '+cls2+'" style="top:'+topPx+'px;height:'+hPx+'px" title="'+esc2(tip)+'" onclick="bookFromRVSlot(\''+t.tech_id+'\',\''+s.date+'\',\''+segStart+'\','+lastSearchDur+','+(s.travel_from_previous||0)+','+(s.travel_to_next||0)+',\''+s.end_time+'\','+(!!s.is_first_slot)+')">';
              if(av.is_preferred&&seg===segments[0])inner+='<span class="av-star">★</span> ';
              inner+='<span class="av-score">'+sc+'</span>';
              inner+='<div class="av-time">'+segStart+'-'+segEnd+'</div>';
              if(hPx>22)inner+='<div class="av-info">'+Math.round(seg.e-seg.s)+'min';
              if(seg===segments[0]){var _tp=[];if(s.travel_from_previous!=null)_tp.push('🚗'+s.travel_from_previous+'m←');if(s.travel_to_next!=null)_tp.push('→'+s.travel_to_next+'m');if(_tp.length)inner+=' · '+_tp.join(' ');}
              if(hPx>22)inner+='</div>';
              inner+='</div>';
            }
          }
        }
        
        // Appointments (render on top) — BUG-016: split into in-bounds vs off-hours
        const _gridStartM=HOURS_START*60, _gridEndM=HOURS_END*60;
        const _offBefore=[], _offAfter=[];
        for(const a of (t.appointments||[])){
          const aStart=tmn(a.start);
          const aEnd=a.end?tmn(a.end):aStart+(a.duration||60);
          const esc=(x)=>(x||'').replace(/'/g,'&#39;').replace(/"/g,'&#34;');
          // Off-hours: starts before grid OR at-or-after grid end. These get a boundary badge.
          if(aStart<_gridStartM){_offBefore.push(a);continue}
          if(aStart>=_gridEndM){_offAfter.push(a);continue}
          const topPx=(aStart-HOURS_START*60)/30*ROW_H;
          const hPx=Math.max((aEnd-aStart)/30*ROW_H,20);
          inner+='<div class="rv-appt" style="top:'+topPx+'px;height:'+hPx+'px;background:'+a.color+'" title="'+esc(a.customer_name)+' — '+esc(a.job_type)+'\\n'+a.start+'-'+a.end+'\\n'+esc(a.location)+(a.arrival_window_label?'\\nArrival window: '+esc(a.arrival_window_label):'')+'" onclick="showRVDet('+esc(JSON.stringify(a))+',\''+dayDate+'\')">';
          inner+='<div class="at">'+a.start+'-'+a.end+(a.arrival_window_label?' <span title="Customer arrival window" style="opacity:.85">🕑'+esc(a.arrival_window_label)+'</span>':'')+'</div>';
          if(hPx>25)inner+='<div class="ad">'+esc(a.job_type||a.title)+'</div>';
          if(hPx>40)inner+='<div class="ad">'+esc(a.customer_name)+'</div>';
          if(hPx>55&&a.location)inner+='<div class="ad">'+esc(a.location)+'</div>';
          inner+=rvCommsIcons(a, hPx);
          inner+='</div>';
        }
        // BUG-016: Off-hours boundary badges. Tooltip lists all; click opens the first.
        if(_offBefore.length){
          const titles=_offBefore.map(a=>a.start+' '+(a.customer_name||'(no cust)')+(a.location?' · '+a.location:'')).join('\n').replace(/"/g,'&#34;');
          const firstId=_offBefore[0].id;
          const lbl=_offBefore.length===1?'1 appt before '+HOURS_START+'am':_offBefore.length+' appts before '+HOURS_START+'am';
          inner+='<div class="rv-offhours rv-offhours-top" title="'+titles+'\nClick to open first." onclick="openEditAppt(\''+firstId+'\')">↑ '+lbl+'</div>';
        }
        if(_offAfter.length){
          const titles=_offAfter.map(a=>a.start+' '+(a.customer_name||'(no cust)')+(a.location?' · '+a.location:'')).join('\n').replace(/"/g,'&#34;');
          const firstId=_offAfter[0].id;
          const endHr=HOURS_END>12?(HOURS_END-12)+'pm':HOURS_END+'am';
          const lbl=_offAfter.length===1?'1 appt after '+endHr:_offAfter.length+' appts after '+endHr;
          inner+='<div class="rv-offhours rv-offhours-bot" title="'+titles+'\nClick to open first." onclick="openEditAppt(\''+firstId+'\')">↓ '+lbl+'</div>';
        }
        // Time-off bands (partial day off / half day) — gray shaded like a
        // non-working day, so PTO windows read the same as Sundays.
        for(const ob of (t.off_bands||[])){
          const oStart=tmn(ob.start);
          const oEnd=tmn(ob.end);
          const topPx=(oStart-HOURS_START*60)/30*ROW_H;
          const hPx=Math.max((oEnd-oStart)/30*ROW_H,12);
          const rsn=(ob.reason||'Time off').replace(/"/g,'&#34;');
          inner+='<div style="position:absolute;left:0;right:0;top:'+topPx+'px;height:'+hPx+'px;background:repeating-linear-gradient(45deg,rgba(120,120,120,0.13),rgba(120,120,120,0.13) 6px,rgba(120,120,120,0.20) 6px,rgba(120,120,120,0.20) 12px);border-left:3px solid #9e9e9e;z-index:1;display:flex;align-items:center;padding-left:6px;font-size:9px;color:#555;font-weight:600;pointer-events:none" title="Off '+ob.start+'-'+ob.end+' — '+rsn+'">⛔ Off</div>';
        }
        // Breaks (orange background bands)
        for(const brk of (t.breaks||[])){
          const bStart=tmn(brk.start);
          const bEnd=tmn(brk.end);
          const topPx=(bStart-HOURS_START*60)/30*ROW_H;
          const hPx=Math.max((bEnd-bStart)/30*ROW_H,10);
          inner+='<div style="position:absolute;left:0;right:0;top:'+topPx+'px;height:'+hPx+'px;background:rgba(255,152,0,0.18);border-left:3px solid #FF9800;z-index:0;display:flex;align-items:center;padding-left:6px;font-size:9px;color:#E65100;font-weight:600;pointer-events:none" title="'+brk.name+' '+brk.start+'-'+brk.end+'">☕ '+brk.name+'</div>';
        }
      }
      
      html+='<div class="'+cls+'" style="position:relative">'+inner+'</div>';
    }
  }
  html+='</div>';
  return html;
}

function tmn(t){if(!t)return 0;const p=t.split(':');return parseInt(p[0])*60+parseInt(p[1])}

function switchCalView(v){
  const calEl=document.getElementById('calendar');
  const rvEl=document.getElementById('resourceView');
  const btnCal=document.getElementById('btnCalView');
  const btnRes=document.getElementById('btnResView');
  if(!calEl||!rvEl)return;
  if(v==='resource'){
    calEl.style.display='none';
    rvEl.classList.add('active');
    if(btnRes){btnRes.style.background='var(--accent)';btnRes.style.color='var(--primary)';btnRes.style.borderColor='var(--accent)'}
    if(btnCal){btnCal.style.background='var(--white)';btnCal.style.color='var(--text)';btnCal.style.borderColor='var(--border)'}
    loadRV();
  }else{
    rvEl.classList.remove('active');
    calEl.style.display='';
    if(btnCal){btnCal.style.background='var(--accent)';btnCal.style.color='var(--primary)';btnCal.style.borderColor='var(--accent)'}
    if(btnRes){btnRes.style.background='var(--white)';btnRes.style.color='var(--text)';btnRes.style.borderColor='var(--border)'}
    if(typeof cal!=='undefined'&&cal)cal.updateSize();
  }
}

document.addEventListener('DOMContentLoaded',()=>{
  init();initRV();
  // Honour ?view=dispatch or ?view=availability deep-links (e.g. /dispatch/ redirect)
  (()=>{const _vp=new URLSearchParams(window.location.search).get('view');if(_vp&&['dispatch','availability'].includes(_vp))switchView(_vp);})();
  setTimeout(()=>{
    switchCalView('resource');
    // Auto-run a default availability search on first load so slot grid is populated
    // and click-to-book works without the user having to click Search first.
    setTimeout(()=>{
      const sFrom=document.getElementById('sFrom'),sTo=document.getElementById('sTo'),sDur=document.getElementById('sDur');
      if(sFrom && !sFrom.value){
        const today=localDateStr();
        const end=new Date();end.setDate(end.getDate()+6);
        sFrom.value=today;
        if(sTo)sTo.value=localDateStr(end);
        if(sDur && !sDur.value)sDur.value='30';
        if(typeof doSearch==='function')doSearch();
      }
    },300);
  },500);
});
function filt(id,el){selTech=id;document.querySelectorAll('.tc').forEach(c=>c.classList.remove('on'));el.classList.add('on');cal.refetchEvents()}

// ===== DETAIL =====
function showDet(ev){openEditAppt(ev.id);}
function showRVDet(a,dayDate){openEditAppt(a.id);}

// ===== Item 2c: click-to-call + click-to-SMS from resource-week appt cards =====
function rvToast(msg, isErr){
  var t=document.getElementById("_rvToast");
  if(!t){ t=document.createElement("div"); t.id="_rvToast";
    t.style.cssText="position:fixed;top:20px;right:20px;padding:12px 18px;border-radius:6px;color:#fff;font-size:14px;z-index:99999;box-shadow:0 4px 12px rgba(0,0,0,.2);max-width:400px;display:none";
    document.body.appendChild(t); }
  t.style.background=isErr?"#c0392b":"#27ae60"; t.textContent=msg; t.style.display="block";
  clearTimeout(t._timer); t._timer=setTimeout(function(){t.style.display="none";},5000);
}
function rvCommsIcons(a, hPx){
  const esc=(x)=>(x||'').replace(/'/g,'&#39;').replace(/"/g,'&#34;');
  if(hPx<=44) return "";
  var ph=(a.customer_phone||"").trim();
  if(!ph) return "";
  var cid=a.customer_id||"";
  var out='<div class="rv-acts">';
  if(!a.do_not_call){ out+='<a href="#" class="rv-act" title="Call customer" data-phone="'+esc(ph)+'" data-cid="'+esc(cid)+'" onclick="event.stopPropagation();rvCall(this);return false"><i class="fas fa-phone-alt"></i></a>'; }
  if(!a.sms_opted_out){ out+='<a href="#" class="rv-act" title="Text customer" data-phone="'+esc(ph)+'" data-cid="'+esc(cid)+'" onclick="event.stopPropagation();rvSms(this);return false"><i class="fas fa-comment"></i></a>'; }
  out+="</div>";
  return out;
}
async function rvCall(el){
  var phone=el.dataset.phone||""; var cid=el.dataset.cid||"";
  if(!phone) return;
  el.style.opacity=".5"; el.style.pointerEvents="none";
  try{
    var r=await fetch(API+"/communications/phone/click-to-call/",{method:"POST",credentials:"same-origin",headers:hdr(),body:JSON.stringify({to_number:phone,customer_id:cid||null})});
    var d={}; try{d=await r.json();}catch(_){}
    if(r.ok) rvToast("Calling... your desk phone should ring shortly.");
    else rvToast(d.message||d.detail||d.error||"Call could not be placed",true);
  }catch(e){ rvToast("Call could not be placed: "+e.message,true); }
  finally{ setTimeout(function(){el.style.opacity="";el.style.pointerEvents="";},1500); }
}
function rvSms(el){
  var modal=document.getElementById("rvSmsModal");
  modal.dataset.phone=el.dataset.phone||""; modal.dataset.cid=el.dataset.cid||"";
  document.getElementById("rvSmsTo").textContent="To "+(el.dataset.phone||"");
  document.getElementById("rvSmsBody").value="";
  modal.classList.add("show");
  setTimeout(function(){var b=document.getElementById("rvSmsBody");if(b)b.focus();},40);
}
async function rvSmsSend(){
  var modal=document.getElementById("rvSmsModal");
  var phone=modal.dataset.phone||""; var cid=modal.dataset.cid||"";
  var body=(document.getElementById("rvSmsBody").value||"").trim();
  if(!body){ rvToast("Enter a message",true); return; }
  var btn=document.getElementById("rvSmsSend"); var orig=btn.innerHTML;
  btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> Sending...';
  try{
    var r=await fetch(API+"/communications/inbox/start/",{method:"POST",credentials:"same-origin",headers:hdr(),body:JSON.stringify({customer_id:cid||null,phone:phone,body:body})});
    var d={}; try{d=await r.json();}catch(_){}
    if(r.ok){ modal.classList.remove("show"); rvToast("Message sent"); }
    else rvToast(d.message||d.detail||d.error||"Could not send",true);
  }catch(e){ rvToast("Could not send: "+e.message,true); }
  finally{ btn.disabled=false; btn.innerHTML=orig; }
}
(function _rvSmsInit(){
  var css=".rv-acts{display:flex;gap:4px;margin-top:3px}"
    +".rv-act{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;border-radius:4px;background:rgba(255,255,255,.9);color:#0d47a1;text-decoration:none;font-size:9px;line-height:1}"
    +".rv-act:hover{background:#fff}"
    +".rvsms-overlay{display:none;position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:1000;align-items:flex-start;justify-content:center}"
    +".rvsms-overlay.show{display:flex}"
    +".rvsms-modal{background:#fff;border-radius:12px;box-shadow:0 18px 50px rgba(0,0,0,.28);width:min(440px,92vw);margin-top:12vh;overflow:hidden}"
    +".rvsms-head{display:flex;align-items:center;justify-content:space-between;padding:16px 18px;border-bottom:1px solid #e5e7eb}"
    +".rvsms-head h3{margin:0;font-size:15px;font-weight:700}"
    +".rvsms-x{border:none;background:none;font-size:24px;line-height:1;color:#888;cursor:pointer}"
    +".rvsms-body{padding:16px 18px}"
    +".rvsms-foot{display:flex;justify-content:flex-end;gap:8px;padding:14px 18px;border-top:1px solid #e5e7eb;background:#fafafa}"
    +".rvsms-btn{padding:9px 16px;border:1.5px solid #d1d5db;border-radius:7px;background:#fff;font-weight:600;font-size:13px;cursor:pointer}"
    +".rvsms-btn-primary{background:#0d47a1;border-color:#0d47a1;color:#fff}"
    +".rvsms-btn:disabled{opacity:.6;cursor:default}";
  var st=document.createElement("style"); st.textContent=css; document.head.appendChild(st);
  var html='<div class="rvsms-overlay" id="rvSmsModal" role="dialog" aria-modal="true">'
    +'<div class="rvsms-modal">'
    +'<div class="rvsms-head"><h3><i class="fas fa-comment"></i> Text customer</h3><button type="button" class="rvsms-x" id="rvSmsClose">&times;</button></div>'
    +'<div class="rvsms-body">'
    +'<div id="rvSmsTo" style="font-size:13px;color:#6b7280;margin-bottom:10px"></div>'
    +'<label style="display:block;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.3px;color:#6b7280;margin-bottom:5px">Message</label>'
    +'<textarea id="rvSmsBody" rows="4" style="width:100%;box-sizing:border-box;padding:9px 11px;border:1.5px solid #d1d5db;border-radius:7px;font-size:14px;font-family:inherit" placeholder="Type your message..."></textarea>'
    +'</div>'
    +'<div class="rvsms-foot"><button type="button" class="rvsms-btn" id="rvSmsCancel">Cancel</button>'
    +'<button type="button" class="rvsms-btn rvsms-btn-primary" id="rvSmsSend"><i class="fas fa-paper-plane"></i> Send</button></div>'
    +'</div></div>';
  document.body.insertAdjacentHTML("beforeend", html);
  document.getElementById("rvSmsClose").addEventListener("click", function(){ document.getElementById("rvSmsModal").classList.remove("show"); });
  document.getElementById("rvSmsCancel").addEventListener("click", function(){ document.getElementById("rvSmsModal").classList.remove("show"); });
  document.getElementById("rvSmsSend").addEventListener("click", rvSmsSend);
  document.getElementById("rvSmsModal").addEventListener("click", function(e){ if(e.target.id==="rvSmsModal") this.classList.remove("show"); });
})();
function closeDet(){document.getElementById('detPanel').classList.remove('open')}
async function chSt(id,a){await fetch(`${API}/scheduling/appointments/${id}/${a}/`,{method:'POST',credentials:'same-origin',headers:hdr(),body:'{}'});closeDet();cal.refetchEvents();if(curView==='dispatch')loadDispatch()}

// Surface the customer's SITE-level notes (access + special instructions) in the
// booking Notes field — the same instructions the CSR inbox shows. Post-notes-
// reconciliation these live on the ServiceLocation, not the customer, so we read
// the resolved fields customer_search now returns (works for single-site too).
// Save the new-booking reconciled notes (site access + this-visit access +
// internal note) to the freshly-created appointment via the shared notes-bundle
// endpoint — same source/shape as the edit modal and CSR inbox. Appointment
// notes ride in job_notes on the create payload, so they're not repeated here.
async function bSaveNotes(id){
  const g=i=>{var el=document.getElementById(i); return el?el.value:undefined;};
  const map={ site_access_instructions:'bSiteAccess', visit_access_instructions:'bVisitAccess', internal_notes:'bRepNotes' };
  const body={}; let any=false;
  for(const k in map){ const v=g(map[k]); if(v!==undefined && v!==''){ body[k]=v; any=true; } }
  if(!any) return;
  try{ await fetch(`${API}/scheduling/appointments/${id}/notes-bundle/`,{method:'POST',credentials:'same-origin',headers:hdr(),body:JSON.stringify(body)}); }catch(_){}
}
function bFillCustSiteNotes(c){
  if(!c) return;
  var set=function(id,val){ var el=document.getElementById(id); if(el && !el.value.trim() && val) el.value=val; };
  // Prefill the site's standing access into the site-access field (its home).
  set('bSiteAccess', c.site_access_instructions);
  // Surface any standing special instructions as context on the appointment
  // notes so the CSR sees them while booking (legacy fallback included).
  set('bNotes', c.site_special_instructions || c.special_instructions);
}
function bookFromAvail(p){openBookModal();document.getElementById('bDate').value=p.slot.date;
  // Use the calendar event's actual start (segment start after break split), not the full slot start
  var evStart=p.event?p.event.start:null;
  var st=evStart?String(evStart.getHours()).padStart(2,'0')+':'+String(evStart.getMinutes()).padStart(2,'0'):p.slot.start_time;
  // Only add travel if there's a real previous appointment (not first slot of day)
  if(p.slot.travel_from_previous && p.slot.travel_from_previous>0 && !p.slot.is_first_slot){
    let [h,m]=st.split(':').map(Number);m+=p.slot.travel_from_previous;while(m>=60){m-=60;h++}m=Math.ceil(m/5)*5;if(m>=60){m=0;h++}
    st=String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
  }
  document.getElementById('bTime').value=st;
  // Store break info for this slot
  setBookingBreaks(p.slot.breaks||[]);
  // Cap duration for travel to next
  if(p.slot.travel_to_next && p.slot.travel_to_next>0 && p.slot.end_time){
    const [sh,sm]=st.split(':').map(Number);
    const [eh,em]=p.slot.end_time.split(':').map(Number);
    const maxMin=(eh*60+em)-(sh*60+sm)-p.slot.travel_to_next;
    if(maxMin>0 && p.duration>maxMin) p.duration=Math.floor(maxMin/5)*5;
  }document.getElementById('bDur').value=p.duration;
  for(let o of document.getElementById('bTech').options)if(o.value===p.tech_id){o.selected=true;break}
  if(p.address)document.getElementById('bLoc').value=p.address;
  if(searchCust&&!bookCust){bookCust=searchCust;document.getElementById('bCustId').value=searchCust.id;showTag('bCustTag','bCustWrap',searchCust,"clearBookCust()");if(searchCust.full_address)document.getElementById('bLoc').value=searchCust.full_address;bFillCustSiteNotes(searchCust);}}



function toggleMultiDay(){
  document.getElementById('bMultiDayFields').style.display=document.getElementById('bMultiDay').checked?'block':'none';
}
function toggleNewCust(){
  const on=document.getElementById('bNewCustToggle').checked;
  if(on&&document.getElementById('bNewPropType')&&!document.getElementById('bNewPropType').options.length)onBNewTypeChange();
  document.getElementById('bNewCustFields').style.display=on?'block':'none';
  document.getElementById('bCustWrap').style.display=on?'none':'block';
  document.getElementById('bCustTag').style.display='none';
  if(on){document.getElementById('bCustId').value='';bookCust=null;
    // Pre-fill address from location field
    const loc=document.getElementById('bLoc').value;
    if(loc)document.getElementById('bNewAddr').value=loc;
  }
}
function openBookModal(){cbpRecReset('bRec');bookCust=null;document.getElementById('bCustId').value='';document.getElementById('bCustTag').style.display='none';document.getElementById('bCustWrap').style.display='block';
  // F-PREFS-2 Slice C.3.2 — default context. dispAddAppt() overrides to 'dispatch' after this returns.
  _currentBookContext='booking';
  document.getElementById('bNewCustToggle').checked=false;document.getElementById('bNewCustFields').style.display='none';
  document.getElementById('bCrew').value='1';document.getElementById('bMultiDay').checked=false;document.getElementById('bMultiDayFields').style.display='none';document.getElementById('bTotalHrs').value='8';document.getElementById('bNewFirst').value='';document.getElementById('bNewLast').value='';document.getElementById('bNewPhone').value='';document.getElementById('bNewEmail').value='';document.getElementById('bNewAddr').value='';if(document.getElementById('bNewAddr2'))document.getElementById('bNewAddr2').value='';if(document.getElementById('bLoc2'))document.getElementById('bLoc2').value='';if(document.getElementById('bLocRow')){document.getElementById('bLocRow').style.display='none';document.getElementById('bServiceLoc').value='';}document.getElementById('bNewType').value='residential';document.getElementById('bNewCompany').value='';document.getElementById('bNewCompanyWrap').style.display='none';if(document.getElementById('bNewPropType'))onBNewTypeChange();['bNotes','bSiteAccess','bVisitAccess','bRepNotes'].forEach(function(_id){var _el=document.getElementById(_id);if(_el)_el.value='';});var _bp=document.getElementById('bPrice');if(_bp)_bp.value='';var _nsrR=document.getElementById('bNewSiteRow');if(_nsrR)_nsrR.style.display='none';['bNewSiteName','bNewSiteAddr','bNewSiteAddr2','bNewSiteCity','bNewSiteZip'].forEach(function(_id){var _el=document.getElementById(_id);if(_el)_el.value='';});var _nss=document.getElementById('bNewSiteState');if(_nss)_nss.value='PA';
  window._bookingBreaks=[];window._contractCardId=0;var ccEl=document.getElementById('contractCards');if(ccEl){ccEl.querySelectorAll('.contract-card').forEach(function(c){c.remove()})};var gcb=document.getElementById('bGenContract');if(gcb){gcb.checked=false};var cs=document.getElementById('contractCards');if(cs)cs.style.display='none';var bac=document.getElementById('btnAddContract');if(bac)bac.style.display='none';
  // Transfer search bar duration and job type to booking modal
  var sDurEl=document.getElementById('sDur');
  if(sDurEl&&sDurEl.value&&sDurEl.value!=='custom') document.getElementById('bDur').value=sDurEl.value;
  // #bJobType is a checkbox group (not a <select>): pre-check the search-bar's
  // job type so the CSR doesn't have to reselect it. Always re-render (clears any
  // stale checks from a prior booking); pre-check the search job type when set.
  var sJtEl=document.getElementById('sJobType');
  var _sJtVal=(sJtEl&&sJtEl.value)?sJtEl.value:'';
  jtRenderChecks('bJobType', _sJtVal?[_sJtVal]:[]);
  if(_sJtVal){
    // If search didn't pin a duration, default to the selected job type's duration.
    var _sJtOpt=sJtEl.options[sJtEl.selectedIndex];
    if((!sDurEl||!sDurEl.value||sDurEl.value==='custom')&&_sJtOpt&&_sJtOpt.dataset.dur)document.getElementById('bDur').value=_sJtOpt.dataset.dur;
  }
  // Transfer search address to location
  var sAddrEl=document.getElementById('sAddr');
  if(sAddrEl&&sAddrEl.value) document.getElementById('bLoc').value=sAddrEl.value;
  // Transfer search customer
  if(searchCust&&!bookCust){bookCust=searchCust;document.getElementById('bCustId').value=searchCust.id;showTag('bCustTag','bCustWrap',searchCust,"clearBookCust()")}
  document.getElementById('bDate').min=localDateStr();
  window._bWin=null;bApplyBookingMode();
  document.getElementById('bookModal').classList.add('open')}
function closeBook(){document.getElementById('bookModal').classList.remove('open')}

// ---- Arrival-window mode (create modal) ------------------------------------
// City Best rule: an EXISTING residential customer booked for a window-eligible
// job type (JobType.offer_arrival_window — recurring/warranty) is given a 2-hour
// arrival window, not an exact time. Commercial customers, new customers, initial
// / one-time types, and mixed selections stay exact-time. Mirrors the proven
// Reschedule-tab flow (eaSearchSlots/eaApplySlot) but presents whole 2-hour bands.
function bComputeWindowMode(){
  if(document.getElementById('bNewCustToggle').checked) return false;   // new cust = exact
  if(!bookCust || bookCust.customer_type!=='residential') return false; // commercial/unknown = exact
  const boxes=document.querySelectorAll('#bJobType input[type=checkbox]:checked');
  if(!boxes.length) return false;
  return Array.prototype.every.call(boxes,function(b){return b.dataset.window==='1';});
}
function bApplyBookingMode(){
  const win=bComputeWindowMode();
  const tcell=document.getElementById('bTimeCell'), wblk=document.getElementById('bWinBlock');
  if(win){ if(tcell)tcell.style.display='none'; if(wblk)wblk.style.display=''; }
  else {
    if(tcell)tcell.style.display=''; if(wblk)wblk.style.display='none';
    window._bWin=null;
    const p=document.getElementById('bWinPicked'); if(p)p.textContent='';
    const r=document.getElementById('bWinResults'); if(r)r.innerHTML='';
  }
  return win;
}
async function bLoadWindows(){
  const date=document.getElementById('bDate').value;
  if(!date){eaToast('Pick a date first','error');return;}
  const dur=parseInt(document.getElementById('bDur').value)||30;
  const cust=document.getElementById('bCustId').value;
  const addr=document.getElementById('bLoc').value.trim();
  const jt=jtGetChecked('bJobType')[0]||'';
  const el=document.getElementById('bWinResults');
  el.innerHTML='<span style="font-size:12px;color:var(--text-light)">Searching…</span>';
  const p=new URLSearchParams({date:date,days:'1',duration:dur});
  if(cust)p.set('customer',cust); if(addr)p.set('address',addr); if(jt)p.set('job_type',jt);
  try{
    const r=await fetch(`${API}/scheduling/smart-slots/?${p}`,{credentials:'same-origin'});
    const d=await r.json();
    // Roll the per-tech exact slots up into 2-hour bands; keep the best-scoring
    // placement per band (that placement's tech + start become the internal time).
    const bands={};
    (d.technicians||[]).forEach(function(t){(t.slots||[]).forEach(function(s){
      if(!s.win_key||!s.win_start_iso||!s.win_end_iso) return;
      const cand={score:s.score||0,time:s.start_time||s.start||'',techId:t.technician_id,techName:t.technician_name,date:s.date,start:s.win_start_iso,end:s.win_end_iso,label:s.win_label};
      const cur=bands[s.win_key];
      if(!cur||cand.score>cur.score) bands[s.win_key]=cand;
    });});
    const keys=Object.keys(bands).sort(function(a,b){return bands[a].time.localeCompare(bands[b].time);});
    if(!keys.length){el.innerHTML='<span style="font-size:12px;color:var(--text-light)">No availability that day — try another date.</span>';return;}
    el.innerHTML='';
    keys.forEach(function(k){
      const b=bands[k];
      const chip=document.createElement('button');
      chip.type='button'; chip.className='btn-outline';
      chip.style.cssText='font-size:12px;padding:8px 10px;text-align:left;min-width:120px';
      chip.innerHTML='<div style="font-weight:700">'+b.label+'</div><div style="font-size:10px;color:var(--text-light)">'+(b.techName||'')+'</div>';
      chip.onclick=function(){bPickWindow(b,chip);};
      el.appendChild(chip);
    });
  }catch(e){el.innerHTML='<span style="color:#F44336;font-size:12px">Search failed</span>';}
}
function bPickWindow(b,chip){
  window._bWin={start:b.start,end:b.end,label:b.label,time:b.time,techId:b.techId,date:b.date};
  document.getElementById('bTime').value=b.time;
  if(b.date)document.getElementById('bDate').value=b.date;
  if(b.techId){for(let o of document.getElementById('bTech').options)if(o.value===b.techId){o.selected=true;break;}}
  document.getElementById('bWinPicked').textContent='✓ '+b.label+(b.techName?(' — '+b.techName):'');
  document.querySelectorAll('#bWinResults .btn-outline').forEach(function(c){c.style.background='';});
  if(chip)chip.style.background='#E8F5E9';
}
function clearBookCust(){bookCust=null;document.getElementById('bCustId').value='';document.getElementById('bCustTag').style.display='none';document.getElementById('bCustWrap').style.display='block';if(document.getElementById('bLocRow')){document.getElementById('bLocRow').style.display='none';document.getElementById('bServiceLoc').value='';var _nsrC=document.getElementById('bNewSiteRow');if(_nsrC)_nsrC.style.display='none';}if(typeof bApplyBookingMode==='function')bApplyBookingMode();}

// Convert a naive local time string (YYYY-MM-DDTHH:MM:SS) in a given IANA tz to an ISO string
// that Django will interpret as the correct UTC moment.
// Falls back to treating it as local if Intl.DateTimeFormat offset resolution fails.
function localToUTC(naiveDt, ianaTimezone){
  try{
    // Parse the naive datetime as if it were in the office timezone
    const [datePart, timePart] = naiveDt.split('T');
    const [y,mo,d] = datePart.split('-').map(Number);
    const [h,mi,s] = (timePart||'00:00:00').split(':').map(Number);
    // Get the UTC offset for this moment in the given timezone
    const fmt = new Intl.DateTimeFormat('en-US',{timeZone:ianaTimezone,timeZoneName:'shortOffset',hour:'numeric',minute:'numeric',year:'numeric',month:'2-digit',day:'2-digit'});
    // Use a temp Date in UTC and iterate to find the actual UTC moment
    // Simpler: use the offset from a reference Date constructed in UTC
    const utcGuess = new Date(Date.UTC(y,mo-1,d,h,mi,s||0));
    const offsetMin = getUTCOffsetMin(utcGuess, ianaTimezone);
    const utcMs = utcGuess.getTime() - offsetMin*60000;
    return new Date(utcMs).toISOString(); // keep Z — Django needs UTC marker
  }catch(e){
    return naiveDt.slice(0,19);
  }
}
function getUTCOffsetMin(date, ianaTimezone){
  // Returns offset in minutes (e.g. EDT = -240)
  try{
    const utcStr = date.toLocaleString('en-US',{timeZone:'UTC',hour12:false,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'});
    const tzStr  = date.toLocaleString('en-US',{timeZone:ianaTimezone,hour12:false,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'});
    const parse = s=>{const[dt,tm]=s.split(', ');const[mo,d,y]=dt.split('/');const[h,mi,se]=tm.split(':');return new Date(Date.UTC(y,mo-1,d,h==='24'?0:h,mi,se)).getTime()};
    return (parse(tzStr)-parse(utcStr))/60000;
  }catch(e){return 0}
}

function cbpFreqResolve(p){
var selId=(p==='bRec')?'bRec':'ea-rec';var sel=document.getElementById(selId);
var modeEl=document.getElementById(p+'Mode');var mode=modeEl?modeEl.value:'same_date';
if(!sel||sel.value==='none'){return {recurrence:'none',interval:1,mode:mode};}
var v=sel.value;
if(v==='custom'){var cuEl=document.getElementById(p+'CustomUnit');var unit=cuEl?cuEl.value:'weekly';
var n=parseInt((document.getElementById(p+'Int')||{}).value)||1;
return {recurrence:(unit==='monthly'?'monthly':'weekly'),interval:Math.max(n,1),mode:mode};}
var MAP={weekly:['weekly',1],biweekly:['weekly',2],triweekly:['weekly',3],
monthly:['monthly',1],bimonthly:['monthly',2],quarterly:['monthly',3],
biannual:['monthly',6],annual:['monthly',12]};
var m=MAP[v]||['weekly',1];return {recurrence:m[0],interval:m[1],mode:mode};}
function cbpRecToggle(sel,p){var v=sel.value;var o=document.getElementById(p+'Opts');if(!o)return;
if(v==='none'){o.style.display='none';return;}o.style.display='block';
var r=cbpFreqResolve(p);
var cr=document.getElementById(p+'CustomRow');if(cr)cr.style.display=(v==='custom')?'flex':'none';
var mo=document.getElementById(p+'Monthly');if(mo)mo.style.display=(r.recurrence==='monthly')?'block':'none';}
function cbpOrd(n){var sfx=['th','st','nd','rd'],vv=n%100;return n+(sfx[(vv-20)%10]||sfx[vv]||sfx[0]);}
function cbpRecHint(p){var sel=document.getElementById(p==='bRec'?'bRec':'ea-rec');
var h=document.getElementById(p+'Hint');if(!sel||!h)return;
if(sel.value==='none'){h.textContent='';return;}
var r=cbpFreqResolve(p);var iv=r.interval;
var de=document.getElementById(p==='bRec'?'bDate':'ea-date');var dstr=de?de.value:'';
var d=dstr?new Date(dstr+'T00:00:00'):null;
var dows=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
if(r.recurrence==='weekly'){h.textContent='Every '+(iv===1?'week':iv+' weeks')+(d?' on '+dows[d.getDay()]+'s':'')+'.';return;}
var mode=r.mode;var ev='every '+(iv===1?'month':iv+' months');
if(!d){h.textContent='Repeats '+ev+'.';return;}
if(mode==='same_date'){h.textContent='The '+cbpOrd(d.getDate())+', '+ev+'.';}
else if(mode==='last_weekday'){h.textContent='The last '+dows[d.getDay()]+', '+ev+'.';}
else{var nth=Math.min(Math.floor((d.getDate()-1)/7)+1,4);h.textContent='The '+cbpOrd(nth)+' '+dows[d.getDay()]+', '+ev+'.';}}
function cbpRecLoad(p,a){var sel=document.getElementById(p==='bRec'?'bRec':'ea-rec');if(!sel)return;
var rec=a.recurrence||'none',iv=parseInt(a.recurrence_interval)||1,mode=a.recurrence_monthly_mode||'same_date';
var legacy={biweekly:['weekly',2],bimonthly:['monthly',2],quarterly:['monthly',3],biannual:['monthly',6]};
if(legacy[rec]){iv=legacy[rec][1];rec=legacy[rec][0];}
var token='none',cu='weekly';
if(rec==='weekly'){token=(iv===2?'biweekly':(iv===3?'triweekly':(iv===1?'weekly':'custom')));cu='weekly';}
else if(rec==='monthly'){token=(iv===2?'bimonthly':(iv===3?'quarterly':(iv===6?'biannual':(iv===12?'annual':(iv===1?'monthly':'custom')))));cu='monthly';}
sel.value=token;
var i=document.getElementById(p+'Int');if(i)i.value=iv;
var cuEl=document.getElementById(p+'CustomUnit');if(cuEl)cuEl.value=cu;
var mm=document.getElementById(p+'Mode');if(mm)mm.value=mode;
var au=document.getElementById(p+'Auto');if(au)au.checked=(a.auto_renew!==false);
cbpRecToggle(sel,p);cbpRecHint(p);}
function cbpRecReset(p){var sel=document.getElementById(p==='bRec'?'bRec':'ea-rec');if(!sel)return;sel.value='none';
var i=document.getElementById(p+'Int');if(i)i.value=1;
var cuEl=document.getElementById(p+'CustomUnit');if(cuEl)cuEl.value='weekly';
var m=document.getElementById(p+'Mode');if(m)m.value='same_date';
var a=document.getElementById(p+'Auto');if(a)a.checked=true;
cbpRecToggle(sel,p);cbpRecHint(p);}
async function saveAppt(){
  // BUG-004: client-side guard for required fields BEFORE we touch the
  // network. Empty bDate / bTime / bDur previously sent gibberish ('T:00')
  // to the API and surfaced as a confusing JSON-dump toast.
  const _vDt = document.getElementById('bDate').value;
  const _vTm = document.getElementById('bTime').value;
  const _vDur = parseInt(document.getElementById('bDur').value);
  // Window mode (residential + recurring/warranty): a 2-hour arrival window must
  // be picked instead of an exact start time.
  const _winMode = bComputeWindowMode();
  if (!_vDt) { eaToast('Please pick a date before saving','error'); return; }
  if (_winMode) {
    if (!window._bWin) { eaToast('Please pick an arrival window before saving','error'); return; }
  } else if (!_vTm) { eaToast('Please pick a date and time before saving','error'); return; }
  if (!_vDur || _vDur <= 0) { eaToast('Please pick a valid duration','error'); return; }
  if (!document.getElementById('bNewCustToggle').checked) {
    const _vCust = document.getElementById('bCustId').value;
    if (!_vCust) { eaToast('Please select a customer (or toggle New Customer)','error'); return; }
  }
  // BUG-003: guard the ENTIRE function with the busy flag, not just the
  // final cbpSubmit POST. saveAppt does an awaited /customers/ POST in
  // the new-customer flow before reaching cbpSubmit; without this guard,
  // a second click during that window would re-run validation + customer
  // create + appointment POST in parallel with the first invocation.
  // The dataset-flag check is synchronous so a millisecond-later second
  // click bails immediately.
  const _saveBtn = document.getElementById('apptCreateBtn');
  if (_saveBtn && _saveBtn.dataset.cbpBusy === '1') return;
  if (_saveBtn) {
    _saveBtn.dataset.cbpBusy = '1';
    _saveBtn.disabled = true;
    _saveBtn.dataset.cbpOrigHtml = _saveBtn.innerHTML;
    _saveBtn.innerHTML = '<span class="cbp-spinner" aria-hidden="true"></span>Saving...';
  }
  try {
  const dt=document.getElementById('bDate').value,tm=document.getElementById('bTime').value,dur=parseInt(document.getElementById('bDur').value);
  // End time = start + duration (breaks are handled by the calendar display, not stored in appointment)
  const _bookTechId=document.getElementById('bTech').value;
  // BUG-002: ALWAYS produce a tz-aware (UTC) datetime. Fall back to tenant
  // tz when no per-tech tz is available. The naive branch was sending
  // 'YYYY-MM-DDTHH:MM:SS' with no offset, which the server rejects.
  const _bookTz=(window._techTzMap&&_bookTechId&&window._techTzMap[_bookTechId])||window._tenantTz||'America/New_York';
  const _naiveStart=`${dt}T${tm}:00`;
  const startDt=localToUTC(_naiveStart,_bookTz);
  const endDt=new Date(new Date(startDt).getTime()+dur*60000).toISOString();
  
  // If new customer mode, create customer first
  let custId=document.getElementById('bCustId').value||null;
  if(document.getElementById('bNewCustToggle').checked){
    const fn=document.getElementById('bNewFirst').value.trim(),ln=document.getElementById('bNewLast').value.trim(),ph=document.getElementById('bNewPhone').value.trim();
    if(!fn||!ln||!ph){eaToast('New customer requires first name, last name, and phone','error');return}
    const addr=document.getElementById('bNewAddr').value.trim()||document.getElementById('bLoc').value.trim();
    const nct=document.getElementById('bNewType').value;const ncn=document.getElementById('bNewCompany').value.trim();if(nct==='commercial'&&!ncn){eaToast('Company name required for commercial customers','error');return}const npt=document.getElementById('bNewPropType')?document.getElementById('bNewPropType').value:(nct==='commercial'?'office':'house');const custBody={first_name:fn,last_name:ln,phone:ph,email:document.getElementById('bNewEmail').value.trim(),service_address:addr,service_address_2:document.getElementById('bNewAddr2')?document.getElementById('bNewAddr2').value.trim():'',service_state:'PA',customer_type:nct,company_name:ncn,property_type:npt};
    const cr=await fetch(API+'/customers/',{method:'POST',credentials:'same-origin',headers:hdr(),body:JSON.stringify(custBody)});
    if(!cr.ok){let ce=null;try{ce=await cr.json();}catch(_){}eaToast('Customer creation failed: '+formatApiError(ce, 'HTTP '+cr.status),'error');return}
    const newCust=await cr.json();
    custId=newCust.id;
  }
  
  // Add-new-site: when Service Location picker is '__new__', create a
  // ServiceLocation for this customer first, then link the appointment to it.
  let _newSiteId=null;
  const _slSel=document.getElementById('bServiceLoc');
  if(_slSel&&_slSel.value==='__new__'){
    if(!custId){eaToast('Pick or create a customer before adding a new site','error');return}
    const _sAddr=((document.getElementById('bNewSiteAddr')||{}).value||'').trim();
    if(!_sAddr){eaToast('New site requires a street address','error');return}
    const _sName=((document.getElementById('bNewSiteName')||{}).value||'').trim();
    const _slBody={customer:custId,location_name:_sName||_sAddr,address:_sAddr,is_active:true};
    _slBody.address_2=((document.getElementById('bNewSiteAddr2')||{}).value||'').trim();
    _slBody.city=((document.getElementById('bNewSiteCity')||{}).value||'').trim();
    _slBody.state=(((document.getElementById('bNewSiteState')||{}).value||'').trim()||'PA');
    _slBody.zip_code=((document.getElementById('bNewSiteZip')||{}).value||'').trim();
    const _slr=await fetch(API+'/service-locations/',{method:'POST',credentials:'same-origin',headers:hdr(),body:JSON.stringify(_slBody)});
    if(!_slr.ok){let _se=null;try{_se=await _slr.json();}catch(_){}eaToast('Could not add new site: '+formatApiError(_se,'HTTP '+_slr.status),'error');return}
    const _newSite=await _slr.json();_newSiteId=_newSite.id;
    document.getElementById('bLoc').value=_sAddr;
    if(document.getElementById('bLoc2'))document.getElementById('bLoc2').value=_slBody.address_2||'';
  }
  const _svcLocVal=_newSiteId||((_slSel&&_slSel.value&&_slSel.value!=='__new__')?_slSel.value:null);
  const _rb=cbpFreqResolve('bRec');
  const _bJtSel=jtGetChecked('bJobType');
  const body={customer:custId,service_location:_svcLocVal,technician:document.getElementById('bTech').value||null,
    job_type:_bJtSel[0]||null,job_types:_bJtSel,start_datetime:startDt,end_datetime:endDt,duration_minutes:dur,
    location:document.getElementById('bLoc').value.trim(),unit_suite:(document.getElementById('bLoc2')?document.getElementById('bLoc2').value.trim():''),job_notes:document.getElementById('bNotes').value,recurrence:_rb.recurrence,recurrence_interval:_rb.interval,recurrence_monthly_mode:_rb.mode,auto_renew:document.getElementById('bRecAuto').checked,status:'scheduled',auto_assign:!document.getElementById('bTech').value,site_contact_name:(document.getElementById('bSiteContactName')||{}).value||'',site_contact_phone:(document.getElementById('bSiteContactPhone')||{}).value||'',site_contact_email:(document.getElementById('bSiteContactEmail')||{}).value||'',site_contact_role:(document.getElementById('bSiteContactRole')||{}).value||'',
    crew_size:parseInt(document.getElementById('bCrew').value)||1,
    is_multiday:document.getElementById('bMultiDay').checked,
    price:(document.getElementById('bPrice')||{}).value||'',
    total_work_minutes:document.getElementById('bMultiDay').checked?parseInt(document.getElementById('bTotalHrs').value||8)*60:null};
  // Window mode: attach the customer-facing 2-hour arrival window (the picked
  // band's bounds). start_datetime above stays the internal placement time.
  if(_winMode && window._bWin){ body.arrival_window_start=window._bWin.start; body.arrival_window_end=window._bWin.end; }
  // BUG-003 part 2: was stripping is_multiday=false, breaking the toggle.
  // Only strip undefined / '' (i.e. 'field absent'). Keep explicit
  // null (PATCH-clear), false (boolean off), and 0 (numeric).
  Object.keys(body).forEach(k=>{ if (body[k] === undefined || body[k] === '') delete body[k]; });
  // cbpSubmit: disables Create + spinner, dedupes double-clicks, swallows
  // AbortError on SPA-nav. Keeps modal open on error so user can fix + retry.
  // Clear the outer guard flag so cbpSubmit's own busy-check doesn't bail
  // (saveAppt sets cbpBusy='1' early to guard the new-customer creation phase,
  // but cbpSubmit also checks cbpBusy==='1' and returns immediately if set).
  if (_saveBtn) _saveBtn.dataset.cbpBusy = '';
  await cbpSubmit(document.getElementById('apptCreateBtn'), async () => {
    async function _postAppt(){
      try{
        return await fetch(`${API}/scheduling/appointments/`,{method:'POST',credentials:'same-origin',headers:hdr(),body:JSON.stringify(body)});
      }catch(e){
        if(e&&e.name==='AbortError') throw e;
        eaToast('Network error — please try again','error');
        return null;
      }
    }
    let r = await _postAppt();
    if(!r) return;
    // Multi-site address confirmation: the server refuses to book a
    // multi-location customer until the operator confirms the exact address the
    // technician will be dispatched to. Show it, and on "OK" re-submit; on
    // "Cancel" leave the modal open so they can pick a different site.
    // Resolve operator-confirmable 409s by confirming + re-submitting:
    //   (1) multi-site address confirmation, and
    //   (2) force-create past a scheduling conflict the operator may override
    //       (double-booking, or tech off/after-hours → override_available=true).
    // Looped (bounded) so a create needing both is handled in sequence.
    for(let _g409=0; r && r.status===409 && _g409<3; _g409++){
      let g=null;try{g=await r.clone().json();}catch(_){}
      if(g && g.code==='address_confirmation_required'){
        const _addr=g.resolved_address||document.getElementById('bLoc').value.trim();
        const ok=await cbpConfirm('This customer has multiple service locations.\n\nThe technician will be dispatched to:\n'+_addr+'\n\nProceed with this address? (Cancel to go back and pick a different site.)');
        if(!ok) return;
        body.address_confirmed=true;
        r = await _postAppt();
        if(!r) return;
      }else if(g && g.override_available){
        const why = g.conflict_type==='hard'
          ? 'This technician already has an overlapping appointment during this window.'
          : 'This technician is off or outside their working hours during this window.';
        const ok=await cbpConfirm(why+'\n\nForce-create the appointment anyway?');
        if(!ok) return;
        body.override_conflicts=true;
        r = await _postAppt();
        if(!r) return;
      }else{
        break;  // unknown 409 — fall through to the error toast below
      }
    }
    if(r.ok){
      var apptData=await r.json();
      // Save the reconciled notes (site access, visit access, internal) via the
      // shared notes-bundle endpoint. Appointment notes go via job_notes in the
      // create payload above; these three aren't create fields.
      try{ if(apptData && apptData.id) await bSaveNotes(apptData.id); }catch(_){}
      // Generate contract if checkbox is checked
      if(document.getElementById('bGenContract') && document.getElementById('bGenContract').checked && document.querySelectorAll('.contract-card .cc-tpl').length){
        try{await generateAllContracts(apptData.id)}catch(ce){console.warn('Contract generation error:',ce)}
      }
      closeBook();cal.refetchEvents();if(curView==='dispatch')loadDispatch();if(curView==='availability')loadAvailability();loadRV();clearSearch();
      eaToast('Appointment created');
    }else{
      let e=null;try{e=await r.json();}catch(_){}
      eaToast('Could not create appointment: '+formatApiError(e, 'HTTP '+r.status),'error');
    }
  });
  } finally {
    if (_saveBtn) {
      _saveBtn.dataset.cbpBusy = '';
      _saveBtn.disabled = false;
      if (_saveBtn.dataset.cbpOrigHtml) _saveBtn.innerHTML = _saveBtn.dataset.cbpOrigHtml;
    }
  }
}

// === Contract Generation ===
// === Multi-Contract System ===
window._contractTemplates=[];
window._contractCardId=0;

function toggleContractSection(){
  var show=document.getElementById('bGenContract').checked;
  document.getElementById('contractCards').style.display=show?'':'none';
  document.getElementById('btnAddContract').style.display=show?'':'none';
  if(show){
    if(!window._contractTemplates.length) loadContractTemplates();
    autoLookupTax();
    // Auto-add first card if none exist
    if(!document.querySelectorAll('.contract-card').length) addContractCard();
  }
}
async function loadContractTemplates(){
  try{
    var r=await fetch(API+'/contracts/templates/',{credentials:'same-origin',headers:hdr()});
    var d=await r.json(); var items=d.results||d;
    window._contractTemplates=items;
    // Refresh all existing card dropdowns
    document.querySelectorAll('.cc-tpl').forEach(function(sel){
      var cur=sel.value;
      sel.innerHTML='<option value="">Select template...</option>'+items.map(function(t){
        return '<option value="'+t.id+'" data-init="'+(t.default_initial_fee||0)+'" data-rec="'+(t.default_recurring_fee||0)+'" data-amt="'+(t.default_amount||0)+'" data-freq="'+(t.default_billing_frequency||'one_time')+'">'+t.name+'</option>';
      }).join('');
      if(cur) sel.value=cur;
    });
  }catch(e){console.warn('Failed to load contract templates',e)}
}
function addContractCard(){
  var id=++window._contractCardId;
  var opts='<option value="">Select template...</option>';
  window._contractTemplates.forEach(function(t){
    opts+='<option value="'+t.id+'" data-init="'+(t.default_initial_fee||0)+'" data-rec="'+(t.default_recurring_fee||0)+'" data-amt="'+(t.default_amount||0)+'">'+t.name+'</option>';
  });
  var html='<div class="contract-card" id="cc-'+id+'" style="padding:10px;border:1px solid #ddd;border-radius:6px;background:#fff;margin-bottom:8px">';
  html+='<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">';
  html+='<select class="f-inp cc-tpl" data-cc="'+id+'" onchange="ccTplChange('+id+')" style="flex:1;margin-right:8px">'+opts+'</select>';
  html+='<button type="button" onclick="removeContractCard('+id+')" style="background:none;border:none;color:#e53935;cursor:pointer;font-size:14px;padding:2px 6px" title="Remove"><i class="fas fa-times"></i></button>';
  html+='</div>';
  html+='<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">';
  html+='<div><label class="f-lbl">Initial Fee</label><div style="position:relative"><span style="position:absolute;left:6px;top:7px;color:#999;font-size:12px">$</span><input type="number" step="0.01" value="0" class="f-inp cc-init" data-cc="'+id+'" style="padding-left:18px;font-size:12px"></div></div>';
  html+='<div><label class="f-lbl">Recurring Fee</label><div style="position:relative"><span style="position:absolute;left:6px;top:7px;color:#999;font-size:12px">$</span><input type="number" step="0.01" value="0" class="f-inp cc-rec" data-cc="'+id+'" style="padding-left:18px;font-size:12px"></div></div>';
  html+='<div><label class="f-lbl">One-Time Fee</label><div style="position:relative"><span style="position:absolute;left:6px;top:7px;color:#999;font-size:12px">$</span><input type="number" step="0.01" value="0" class="f-inp cc-ot" data-cc="'+id+'" style="padding-left:18px;font-size:12px"></div></div>';
  html+='</div></div>';
  document.getElementById('contractCards').insertAdjacentHTML('beforeend',html);
}
function removeContractCard(id){
  var el=document.getElementById('cc-'+id);
  if(el) el.remove();
}
function ccTplChange(id){
  var sel=document.querySelector('#cc-'+id+' .cc-tpl');
  var opt=sel.options[sel.selectedIndex];
  if(!opt||!opt.value)return;
  document.querySelector('#cc-'+id+' .cc-init').value=opt.dataset.init||0;
  document.querySelector('#cc-'+id+' .cc-rec').value=opt.dataset.rec||0;
  document.querySelector('#cc-'+id+' .cc-ot').value=opt.dataset.amt||0;
}
async function autoLookupTax(){
  var loc=document.getElementById('bLoc').value||'';
  if(!loc)return;
  // Parse city and state from service address
  // Handles: "123 St, Philadelphia, PA 19145", "123 St, Philadelphia, PA 19145, USA", "123 St, Philadelphia, PA"
  var city='',state='';
  // Strip trailing country (USA, US, United States)
  var clean=loc.replace(/,\s*(USA|US|United States)\s*$/i,'').trim();
  // Try "City, ST ZIP" or "City, ST" pattern anywhere in the string
  var m=clean.match(/,\s*([^,]+),\s*([A-Z]{2})\s*\d{0,5}\s*$/);
  if(m){city=m[1].trim();state=m[2]}
  if(!state){
    // Try "City, ST" at end
    var m2=clean.match(/,\s*([^,]+?)\s+([A-Z]{2})\s*\d{0,5}\s*$/);
    if(m2){city=m2[1].trim();state=m2[2]}
  }
  if(!state){
    // Fallback: find any 2-letter state code preceded by comma
    var m3=clean.match(/([A-Z]{2})\s*\d{5}/);
    if(m3) state=m3[1];
    var m4=clean.match(/,\s*([^,]+),\s*[A-Z]{2}/);
    if(m4) city=m4[1].trim();
  }
  if(!state) return;
  try{
    var url=API+'/billing/tax-lookup/?state='+encodeURIComponent(state);
    if(city) url+='&city='+encodeURIComponent(city);
    var r=await fetch(url,{credentials:'same-origin',headers:hdr()});
    if(r.ok){
      var d=await r.json();
      if(d.combined_rate){
        document.getElementById('bContractTax').value=d.combined_rate;
        document.getElementById('taxAutoLabel').textContent='('+d.match_type+': '+(d.city||d.county||d.state)+')';
        updateFeePreview();
      }
    }
  }catch(e){console.warn('Tax lookup failed',e)}
}
async function generateAllContracts(appointmentId){
  var cards=document.querySelectorAll('.contract-card');
  var tax=parseFloat(document.getElementById('bContractTax').value)||0;
  var created=0;
  for(var i=0;i<cards.length;i++){
    var card=cards[i];
    var tplId=card.querySelector('.cc-tpl').value;
    if(!tplId) continue;
    try{
      var body={template_id:tplId,appointment_id:appointmentId,
        initial_treatment_fee:parseFloat(card.querySelector('.cc-init').value)||0,
        recurring_fee:parseFloat(card.querySelector('.cc-rec').value)||0,
        one_time_fee:parseFloat(card.querySelector('.cc-ot').value)||0,
        tax_rate:tax};
      var r=await fetch(API+'/contracts/contracts/generate-for-appointment/',{method:'POST',credentials:'same-origin',headers:hdr(),body:JSON.stringify(body)});
      if(r.ok){created++;var d=await r.json();console.log('Contract created:',d.contract_number)}
      else{var e=await r.json();console.warn('Contract gen failed:',e)}
    }catch(e){console.warn('Contract gen error:',e)}
  }
  if(created) console.log(created+' contract(s) generated');
}


let _eaId=null,_eaCustId=null;
function openEditAppt(id){
  _eaId=id;window._eaCustSnap=null;
  document.getElementById('editApptModal').style.display='flex';
  document.getElementById('editApptTitle').textContent='Loading...';
  document.getElementById('ea-rs-results').innerHTML='Hit Search to find available slots.';
  eaTab('details');
  eaLoadAppt(id);
}
function closeEditAppt(){document.getElementById('editApptModal').style.display='none';_eaId=null;_eaCustId=null;_eaCustPref=null;}
// F-035: ESC key closes the edit modal (and the book modal).
// Guarded — uses _cbpBackdropClose (defined below) so dirty modals prompt.
document.addEventListener('keydown',function(e){
  if(e.key!=='Escape')return;
  var ea=document.getElementById('editApptModal');
  if(ea&&ea.style.display!=='none'){_cbpBackdropClose(ea, closeEditAppt);return;}
  var bk=document.getElementById('bookModal');
  if(bk&&(bk.classList.contains('open')||bk.style.display==='flex')){_cbpBackdropClose(bk, closeBook);return;}
});
// F-035: clicking the backdrop (outside the modal card) also closes it.
// Guarded — if the modal carries _cbpIsDirty() and reports dirty, prompt.
function _cbpBackdropClose(el, closeFn){
  if (el.dataset.discardConfirm === '1' &&
      typeof el._cbpIsDirty === 'function' && el._cbpIsDirty()) {
    if (!window.confirm('You have unsaved changes. Discard them?')) return;
    el._cbpResetDirty();
  }
  closeFn();
}
document.addEventListener('DOMContentLoaded',function(){
  var ea=document.getElementById('editApptModal');
  if(ea)ea.addEventListener('click',function(ev){if(ev.target===ea)_cbpBackdropClose(ea, closeEditAppt);});
  var bk=document.getElementById('bookModal');
  if(bk)bk.addEventListener('click',function(ev){if(ev.target===bk)_cbpBackdropClose(bk, closeBook);});
});
function eaTab(t){
  ['details','reschedule','contracts'].forEach(x=>{
    document.getElementById('ea-panel-'+x).style.display=x===t?'':'none';
    document.getElementById('ea-tab-'+x).classList.toggle('on',x===t);
  });
  if(t==='contracts'&&_eaId)eaLoadContracts();
}
async function eaLoadAppt(id){
  const r=await fetch(`${API}/scheduling/appointments/${id}/`,{credentials:'same-origin'});
  if(!r.ok){alert('Could not load appointment');return;}
  const a=await r.json();
  _eaCustId=a.customer;
  window._eaJobTypeId=a.job_type||null;
  window._eaCustomerId=a.customer||null;
  document.getElementById('editApptTitle').textContent=a.customer_name||'Appointment';
  const bc={'scheduled':'bg-s','confirmed':'bg-c','completed':'bg-d','cancelled':'bg-x','in_progress':'bg-p','reminded':'bg-s','en_route':'bg-c','arrived':'bg-c'}[a.status]||'bg-s';
  const badge=document.getElementById('editApptStatusBadge');badge.className='badge '+bc;badge.textContent=a.status;
  if(a.customer){
    try{
      const cr=await fetch(`${API}/customers/${a.customer}/`,{credentials:'same-origin'});
      if(cr.ok){const cu=await cr.json();
        document.getElementById('ea-cust-first').value=cu.first_name||'';
        document.getElementById('ea-cust-last').value=cu.last_name||'';
        document.getElementById('ea-cust-phone').value=cu.phone||'';
        document.getElementById('ea-cust-email').value=cu.email||'';
        document.getElementById('ea-cust-addr').value=cu.service_address||'';
        window._eaCustSnap={first_name:cu.first_name||'',last_name:cu.last_name||'',phone:cu.phone||'',email:cu.email||'',service_address:cu.service_address||''};
        // F-PREFS-2 Slice C.3.2 — fetch the customer's preferred-tech set so the
        // ea-tech change listener can detect mismatch. Union the legacy FK (on
        // the customer record) with the M2M list (from /preference/). Same
        // semantics as customer_search's union; we do it client-side here
        // because /customers/<id>/ doesn't (yet) emit the union.
        _eaCustPref=null;
        try{
          const pr=await fetch(`${API}/customers/${a.customer}/preference/`,{credentials:'same-origin'});
          const pj=pr.ok?await pr.json():null;
          const m2m=(pj&&pj.preference&&Array.isArray(pj.preference.preferred_technicians))?pj.preference.preferred_technicians:[];
          const union={};
          // legacy FK first; UUID + name resolved from techs[] (loaded by init())
          if(cu.preferred_technician){
            const fkId=String(cu.preferred_technician);
            union[fkId]={id:fkId,name:_prefsLookupTechName(fkId)};
          }
          for(const t of m2m){
            if(!t||!t.id) continue;
            const tid=String(t.id);
            if(!union[tid]) union[tid]={id:tid,name:t.name||_prefsLookupTechName(tid)};
          }
          const arr=Object.values(union);
          _eaCustPref={
            id:String(a.customer),
            full_name:a.customer_name||null,
            preferred_technician_ids:arr.map(x=>x.id),
            preferred_technicians:arr.map(x=>({id:x.id,name:x.name})),
          };
        }catch(e){_eaCustPref=null;}
      }
    }catch(e){}
  }
  const st=a.start_datetime?new Date(a.start_datetime):null;
  const techId=String(a.technician||'');
  const techTz=(window._techTzMap&&techId&&window._techTzMap[techId])||null;
  let localDate='',localTime='';
  if(st){
    if(techTz){try{
      const fd=new Intl.DateTimeFormat('en-CA',{timeZone:techTz,year:'numeric',month:'2-digit',day:'2-digit'});
      const ft=new Intl.DateTimeFormat('en-US',{timeZone:techTz,hour:'2-digit',minute:'2-digit',hour12:false});
      localDate=fd.format(st);localTime=ft.format(st).padStart(5,'0');
    }catch(e){localDate=localDateStr(st);localTime=localTimeStr(st);}}
    else{localDate=localDateStr(st);localTime=localTimeStr(st);}
  }
  document.getElementById('ea-date').value=localDate;
  document.getElementById('ea-time').value=localTime;
  // Phase 2 — show the customer-facing arrival window for a windowed booking.
  // Clear any prior slot-pick so editing an existing appt doesn't re-attach a
  // stale window on save (eaSave only attaches when a slot was picked THIS open).
  window._eaWin=null;
  var _eaWinRow=document.getElementById('ea-window-row');
  if(_eaWinRow){
    if(a.arrival_window_label){document.getElementById('ea-window-val').textContent=a.arrival_window_label;_eaWinRow.style.display='block';}
    else{_eaWinRow.style.display='none';}
  }
  document.getElementById('ea-dur').value=a.duration_minutes||60;
  var _eaPr=document.getElementById('ea-price');if(_eaPr)_eaPr.value=(a.price!=null&&a.price!=='')?a.price:'';
  document.getElementById('ea-rs-dur').value=a.duration_minutes||60;
  document.getElementById('ea-rs-from').value=localDate;
  // Location and unit/suite are SEPARATE appointment fields
  // (Appointment.location + Appointment.unit_suite). Show each in its own box.
  // Do NOT split the address: location holds the full street/city/state/zip.
  document.getElementById('ea-loc').value = a.location || '';
  document.getElementById('ea-loc2').value = a.unit_suite || '';
  // BUG-003 part 2: populate service-location dropdown (commercial multi-site)
  loadEaServiceLocations(a.customer, a.service_location);
  eaLoadNotesBundle(_eaId, a);
  // BUG-003: populate parity fields (Recurrence / Crew Size / Multi-day)
  cbpRecLoad('eaRec',a);
  document.getElementById('ea-crew').value=parseInt(a.crew_size)||1;
  const _eaMd=!!a.is_multiday;
  document.getElementById('ea-multiday').checked=_eaMd;
  document.getElementById('ea-multiday-fields').style.display=_eaMd?'block':'none';
  document.getElementById('ea-total-hrs').value=a.total_work_minutes?Math.round(a.total_work_minutes/60):8;
  const sel=document.getElementById('ea-status');for(let o of sel.options)if(o.value===a.status){o.selected=true;break}
  // Technician dropdown
  const bt=document.getElementById('ea-tech');bt.innerHTML='<option value="">Auto-assign</option>';
  const srcT=document.getElementById('bTech');
  // R16 DL5: propagate license-status data + locked-out state when cloning
  // bTech options into ea-tech so the edit-appointment picker honors the
  // same posture badges + block-mode disabled state.
  if(srcT){for(let o of srcT.options){if(!o.value)continue;const op=document.createElement('option');op.value=o.value;op.textContent=o.textContent;if(o.dataset.licenseStatus)op.dataset.licenseStatus=o.dataset.licenseStatus;if(o.disabled)op.disabled=true;if(o.classList.contains('tech-locked-out'))op.classList.add('tech-locked-out');if(o.value===techId)op.selected=true;bt.appendChild(op);}}
  if(a.technician_name&&a.technician_name!=='Unassigned'){let f=false;for(let o of bt.options)if(o.value===techId){f=true;break}if(!f&&techId){const op=document.createElement('option');op.value=techId;op.textContent=a.technician_name;op.selected=true;bt.appendChild(op);}}
  // Job type checkboxes (multi-job: preselect every service on the visit)
  const _selIds=(a.job_types&&a.job_types.length)?a.job_types.map(function(j){return String(j.id);}):(a.job_type?[String(a.job_type)]:[]);
  jtRenderChecks('ea-jobtype', _selIds);
}
async function eaSave(){
  if(!_eaId)return;
  // BUG-004: client-side guard, mirrors saveAppt. Customer is fixed for
  // edits, so we just need date/time/duration sanity.
  const _vDt = document.getElementById('ea-date').value;
  const _vTm = document.getElementById('ea-time').value;
  const _vDur = parseInt(document.getElementById('ea-dur').value);
  if (!_vDt || !_vTm) { eaToast('Please pick a date and time before saving','error'); return; }
  if (!_vDur || _vDur <= 0) { eaToast('Please pick a valid duration','error'); return; }
  // BUG-003: guard the ENTIRE function with the busy flag (see saveAppt).
  // eaSave does an awaited /customers/<id>/ PATCH before its cbpSubmit,
  // which is the same race window saveAppt has.
  // FIX: cbpSubmit (base.html) already owns the busy-flag mutex, the button
  // disable/spinner, and AbortError handling. eaSave must NOT pre-set
  // dataset.cbpBusy here — if it does, cbpSubmit sees cbpBusy==='1' and
  // returns WITHOUT running its callback, silently dropping EVERY appointment
  // save (zero network requests). Let cbpSubmit own the button, like eaMarkComplete.
  const dt=document.getElementById('ea-date').value,tm=document.getElementById('ea-time').value,dur=parseInt(document.getElementById('ea-dur').value)||60;
  const techId=document.getElementById('ea-tech').value;
  // BUG-002: ALWAYS produce a tz-aware (UTC) datetime. Tenant tz fallback
  // when no tech selected. Naive serialization is rejected by the server.
  const techTz=(window._techTzMap&&techId&&window._techTzMap[techId])||window._tenantTz||'America/New_York';
  const startDt=localToUTC(`${dt}T${tm}:00`,techTz);
  const endDt=new Date(new Date(startDt).getTime()+dur*60000).toISOString();
  const _eaIsMd=document.getElementById('ea-multiday').checked;
  // Location + unit/suite are separate fields; send each independently.
  // Add-new-site (edit): when picker is '__new__', create a ServiceLocation
  // for this appointment's customer first, then link it.
  const _eaSvcLocEl = document.getElementById('ea-service-loc');
  let _eaNewSiteId=null;
  if(_eaSvcLocEl&&_eaSvcLocEl.value==='__new__'){
    if(!_eaCustId){eaToast('This appointment has no customer to attach a new site to','error');return}
    const _sAddr=((document.getElementById('eaNewSiteAddr')||{}).value||'').trim();
    if(!_sAddr){eaToast('New site requires a street address','error');return}
    const _sName=((document.getElementById('eaNewSiteName')||{}).value||'').trim();
    const _slBody={customer:_eaCustId,location_name:_sName||_sAddr,address:_sAddr,is_active:true};
    _slBody.address_2=((document.getElementById('eaNewSiteAddr2')||{}).value||'').trim();
    _slBody.city=((document.getElementById('eaNewSiteCity')||{}).value||'').trim();
    _slBody.state=(((document.getElementById('eaNewSiteState')||{}).value||'').trim()||'PA');
    _slBody.zip_code=((document.getElementById('eaNewSiteZip')||{}).value||'').trim();
    const _slr=await fetch(API+'/service-locations/',{method:'POST',credentials:'same-origin',headers:hdr(),body:JSON.stringify(_slBody)});
    if(!_slr.ok){let _se=null;try{_se=await _slr.json();}catch(_){}eaToast('Could not add new site: '+formatApiError(_se,'HTTP '+_slr.status),'error');return}
    const _newSite=await _slr.json();_eaNewSiteId=_newSite.id;
    document.getElementById('ea-loc').value=_sAddr;
    if(document.getElementById('ea-loc2'))document.getElementById('ea-loc2').value=_slBody.address_2||'';
  }
  const _eaLoc = document.getElementById('ea-loc').value.trim();
  const _eaLoc2 = (document.getElementById('ea-loc2')?document.getElementById('ea-loc2').value.trim():'');
  const _eaSvcLoc = _eaNewSiteId || ((_eaSvcLocEl && _eaSvcLocEl.value && _eaSvcLocEl.value!=='__new__') ? _eaSvcLocEl.value : null);
  const _re=cbpFreqResolve('eaRec');
  const _eaJtSel=jtGetChecked('ea-jobtype');
  const body={technician:techId||null,job_type:_eaJtSel[0]||null,job_types:_eaJtSel,start_datetime:startDt,end_datetime:endDt,duration_minutes:dur,location:_eaLoc,unit_suite:_eaLoc2,service_location:_eaSvcLoc,status:document.getElementById('ea-status').value,// BUG-003 parity fields; notes saved via notes-bundle
    recurrence:_re.recurrence,recurrence_interval:_re.interval,recurrence_monthly_mode:_re.mode,auto_renew:document.getElementById('eaRecAuto').checked,crew_size:parseInt(document.getElementById('ea-crew').value)||1,is_multiday:_eaIsMd,total_work_minutes:_eaIsMd?(parseInt(document.getElementById('ea-total-hrs').value||8)*60):null,price:(document.getElementById('ea-price')||{}).value||''};
  // Phase 2 — attach the arrival window only when this save used a picked
  // windowed slot AND the time wasn't hand-edited (exact-time override). Omitted
  // otherwise, so unrelated edits never wipe an existing window (PATCH semantics).
  if(window._eaWin&&window._eaWin.start&&document.getElementById('ea-time').value===window._eaWin.time){
    body.arrival_window_start=window._eaWin.start;body.arrival_window_end=window._eaWin.end;
  }
  // BUG-003 part 2: was stripping is_multiday=false, breaking the toggle.
  // Only strip undefined / '' (i.e. 'field absent'). Keep explicit
  // null (PATCH-clear), false (boolean off), and 0 (numeric).
  Object.keys(body).forEach(k=>{ if (body[k] === undefined || body[k] === '') delete body[k]; });
  // cbpSubmit handles button disable + spinner + dedup + AbortError swallow.
  // Customer PATCH and appointment PATCH are both wrapped together; on failure
  // of either, modal stays open and user gets a real error message.
  await cbpSubmit(document.getElementById('eaSaveBtn'), async () => {
    try{
      if(_eaCustId){
        const cp={first_name:document.getElementById('ea-cust-first').value.trim(),last_name:document.getElementById('ea-cust-last').value.trim(),phone:document.getElementById('ea-cust-phone').value.trim(),email:document.getElementById('ea-cust-email').value.trim(),service_address:document.getElementById('ea-cust-addr').value.trim()};
        const _sn=window._eaCustSnap;
        const _custChanged=!!_sn&&(cp.first_name!==(_sn.first_name||'')||cp.last_name!==(_sn.last_name||'')||cp.phone!==(_sn.phone||'')||cp.email!==(_sn.email||'')||cp.service_address!==(_sn.service_address||''));
        if(_custChanged){
          const cr=await fetch(`${API}/customers/${_eaCustId}/`,{method:'PATCH',credentials:'same-origin',headers:hdr(),body:JSON.stringify(cp)});
          if(!cr.ok){
            let ce=null;try{ce=await cr.json();}catch(_){}
            eaToast('Customer details not saved: '+formatApiError(ce, 'HTTP '+cr.status)+' (appointment changes still saved)','error');
          }
        }
      }
      const r=await fetch(`${API}/scheduling/appointments/${_eaId}/`,{method:'PATCH',credentials:'same-origin',headers:hdr(),body:JSON.stringify(body)});
      if(r.ok){
        await eaSaveNotes();
        closeEditAppt();cal.refetchEvents();if(curView==='dispatch')loadDispatch();loadRV();
        eaToast('Appointment updated');
      }else{
        let e=null;try{e=await r.json();}catch(_){}
        eaToast('Save failed: '+formatApiError(e, 'HTTP '+r.status),'error');
      }
    }catch(e){
      if(e&&e.name==='AbortError') throw e;
      eaToast('Network error — please try again','error');
    }
  });
}
function eaRepNoteMeta(by,at){
  if(!by && !at) return '';
  var t=at?new Date(at).toLocaleString([], {month:'short',day:'numeric',year:'numeric',hour:'2-digit',minute:'2-digit'}):'';
  return 'Edited by '+(by||'customer')+(t?' \u00b7 '+t:'');
}
// Load the reconciled notes bundle (same source/shape as the CSR Inbox) into
// the edit modal. `a` supplies the rep_notes edit stamp for the meta line.
async function eaLoadNotesBundle(id, a){
  const set=(k,v)=>{var el=document.getElementById(k); if(el)el.value=v||'';};
  ['ea-jobnotes','ea-visitaccess','ea-repnotes','ea-site-access','ea-site-special'].forEach(k=>set(k,''));
  var m=document.getElementById('ea-repnotes-meta');
  if(m && a){ m.textContent=eaRepNoteMeta(a.rep_notes_updated_by_name,a.rep_notes_updated_at); }
  try{
    const r=await fetch(`${API}/scheduling/appointments/${id}/notes-bundle/`,{credentials:'same-origin',headers:hdr()});
    if(!r.ok) return;
    const d=await r.json(); const n=(d&&d.notes)||{}; const site=n.site||{};
    set('ea-jobnotes', n.appointment_notes);
    set('ea-visitaccess', n.visit_access_instructions);
    set('ea-repnotes', n.internal_notes);
    set('ea-site-access', site.access && site.access.text);
    set('ea-site-special', site.special && site.special.text);
    // Optimistic-concurrency token — echoed back on save to block a stale
    // overwrite of a newer edit (see eaSaveNotes).
    window._eaNotesVersion = n.notes_version || '';
  }catch(_){}
}
// Save all note fields through the shared notes-bundle endpoint so the calendar
// and CSR inbox always write the same columns. Non-fatal to the main save.
async function eaSaveNotes(force){
  const g=id=>{var el=document.getElementById(id); return el?el.value:undefined;};
  const map={ appointment_notes:'ea-jobnotes',
    visit_access_instructions:'ea-visitaccess', internal_notes:'ea-repnotes',
    site_access_instructions:'ea-site-access', site_special_instructions:'ea-site-special' };
  const body={}; let any=false;
  for(const k in map){ const v=g(map[k]); if(v!==undefined){ body[k]=v; any=true; } }
  if(!any) return;
  body.base_version = window._eaNotesVersion || '';
  if(force) body.force_notes_overwrite = true;
  try{
    var r=await fetch(`${API}/scheduling/appointments/${_eaId}/notes-bundle/`,{method:'POST',credentials:'same-origin',headers:hdr(),body:JSON.stringify(body)});
    if(r.status===409){
      var c=null;try{c=await r.json();}catch(_){}
      var info=(c&&c.conflict)||{}; var who=info.by||'Someone else'; var when='';
      try{ if(info.at) when=' at '+new Date(info.at).toLocaleString(); }catch(_){}
      var ok=await cbpConfirm(who+' changed these notes'+when+' since you opened this appointment. Overwrite their version with yours? (Cancel keeps theirs — reopen to see it.)');
      if(ok){ window._eaNotesVersion=(info.current_version||window._eaNotesVersion); return eaSaveNotes(true); }
      eaToast('Kept their version — reopen the appointment to see the latest notes.','error');
      return;
    }
    if(!r.ok && r.status!==403){ var e=null;try{e=await r.json();}catch(_){}
      eaToast('Notes not saved: '+formatApiError(e,'HTTP '+r.status),'error'); }
  }catch(_){ eaToast('Notes not saved (network)','error'); }
}

async function eaMarkComplete(){
  if(!_eaId) return;
  // cbpSubmit handles button disable + dedup; r.ok check ensures we don't
  // toast success when the action endpoint actually rejected (e.g. 409 if
  // already completed, 400 if missing required fields).
  await cbpSubmit(document.getElementById('eaCompleteBtn'), async () => {
    try{
      // F-004 — legacy /complete/ retired (410 Gone). Use the gated
      // /end/ endpoint. Treatment-report gate applies; admins can
      // bypass via the field job card with force=true.
      const r=await fetch(`${API}/scheduling/appointments/${_eaId}/end/`,{method:'POST',credentials:'same-origin',headers:hdr(),body:'{}'});
      if(!r.ok){
        let e=null;try{e=await r.json();}catch(_){}
        if(r.status===422 && e && e.error==='treatment_report_required'){
          eaToast('Treatment report required — open the field job card.','error');
          return;
        }
        eaToast('Could not mark complete: '+(e&&e.detail?e.detail:('HTTP '+r.status)),'error');
        return;
      }
      closeEditAppt();cal.refetchEvents();if(curView==='dispatch')loadDispatch();loadRV();
      eaToast('Marked complete');
    }catch(e){
      if(e&&e.name==='AbortError') throw e;
      eaToast('Network error — please try again','error');
    }
  });
}
async function eaConfirmCancel(){
  if(!_eaId) return;
  // Required cancellation reason (structured picklist) — no more silent
  // "customer_canceled" default. cbpCancelReason returns null if the user
  // backs out.
  const _reason = await cbpCancelReason({title:'Cancel this appointment?'});
  if(!_reason) return;
  // BUG-002 fix: previously this was fire-and-forget — modal closed and
  // success toast fired regardless of whether the POST actually succeeded.
  // Now: button is disabled while the request is in flight, modal stays
  // open on any failure, and success toast only fires on a real 2xx.
  await cbpSubmit(document.getElementById('eaCancelApptBtn'), async () => {
    try{
      const r=await fetch(`${API}/scheduling/appointments/${_eaId}/cancel/`,{method:'POST',credentials:'same-origin',headers:hdr(),body:JSON.stringify({reason:_reason,notify_customer:{channel:'none'}})});
      if(!r.ok){
        let e=null;try{e=await r.json();}catch(_){}
        eaToast('Could not cancel: '+(e&&e.detail?e.detail:('HTTP '+r.status)),'error');
        return;
      }
      closeEditAppt();cal.refetchEvents();if(curView==='dispatch')loadDispatch();loadRV();
      eaToast('Appointment cancelled');
    }catch(e){
      if(e&&e.name==='AbortError') throw e;
      eaToast('Network error — please try again','error');
    }
  });
}
async function eaDelete(){
  // BUG-012 (FE half): soft-delete the appointment.
  // B's destroy() (ca9b9aa) sets deleted_at=now() and returns 204; the
  // default Appointment manager filters deleted_at IS NULL so the row
  // disappears from the calendar/dispatch/RV after refetch.
  if(!_eaId) return;
  if(!await cbpConfirm('Delete this appointment? It will be hidden from the calendar. Recoverable by an admin.')) return;
  await cbpSubmit(document.getElementById('eaDeleteApptBtn'), async () => {
    try{
      const r=await fetch(`${API}/scheduling/appointments/${_eaId}/`,{method:'DELETE',credentials:'same-origin',headers:hdr()});
      if(!r.ok){
        let e=null;try{e=await r.json();}catch(_){}
        eaToast('Could not delete: '+(e&&e.detail?e.detail:('HTTP '+r.status)),'error');
        return;
      }
      closeEditAppt();cal.refetchEvents();if(curView==='dispatch')loadDispatch();loadRV();
      eaToast('Appointment deleted');
    }catch(e){
      if(e&&e.name==='AbortError') throw e;
      eaToast('Network error — please try again','error');
    }
  });
}
async function eaSearchSlots(){
  const from=document.getElementById('ea-rs-from').value||localDateStr();
  const days=document.getElementById('ea-rs-days').value,dur=document.getElementById('ea-rs-dur').value;
  const loc=document.getElementById('ea-loc').value,techId=document.getElementById('ea-tech').value;
  const el=document.getElementById('ea-rs-results');el.innerHTML='<div style="color:var(--text-light)">Searching...</div>';
  const p=new URLSearchParams({date:from,days,duration:dur});if(loc)p.set('address',loc);if(window._eaCustomerId)p.set('customer',window._eaCustomerId);if(window._eaJobTypeId)p.set('job_type',window._eaJobTypeId);
  try{
    const r=await fetch(`${API}/scheduling/smart-slots/?${p}`,{credentials:'same-origin'});
    const d=await r.json();
    if(!d.technicians||!d.technicians.length){el.innerHTML='<div style="color:var(--text-light)">No slots found.</div>';return;}
    let html='<div style="display:flex;flex-direction:column;gap:10px">';
    d.technicians.forEach(t=>{
      if(!t.slot_count)return;
      html+=`<div style="margin-bottom:10px"><div style="font-size:11px;font-weight:700;color:${t.technician_color||'var(--accent)'};margin-bottom:6px"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${t.technician_color||'#999'};margin-right:4px;vertical-align:middle"></span>${t.technician_name}`;
      if(t.is_preferred)html+=' <span style="color:#FF9800;font-size:10px">&#9733; Preferred</span>';
      html+='</div><div style="display:flex;flex-wrap:wrap;gap:5px">';
      // smart-slots returns t.slots[] with start_time/end_time/date/score/travel fields
      const slotList=t.slots||[];
      slotList.forEach(s=>{
        const slotDate=s.date||'';
        const slotStart=s.start_time||s.start||'';
        const lbl=slotDate?new Date(slotDate+'T12:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'}):'';
        const sc=s.score||0;
        // Same tier colours as main availability view
        const slotBg=sc>=70?'background:#E8F5E9;border-color:#4CAF50;color:#2E7D32':sc>=40?'background:#FFF8E1;border-color:#FF9800;color:#E65100':'background:#FFEBEE;border-color:#EF5350;color:#C62828';
        const avMin=s.available_minutes||0;
        // Format start time 12h
        function fmtT(tt){if(!tt)return '';const[h,m]=tt.split(':').map(Number);const ap=h>=12?'PM':'AM';return (h%12||12)+':'+(m<10?'0':'')+m+ap;}
        let meta='';
        // CAL-TRAVEL: show both legs; suppress prev-leg for first-of-day slots.
        if(s.travel_from_previous!=null&&s.travel_from_previous>0&&!s.is_first_slot)meta+='🚗'+s.travel_from_previous+'m← ';
        if(s.travel_to_next!=null&&s.travel_to_next>0)meta+='→'+s.travel_to_next+'m🚗 ';
        if(s.break_minutes)meta+='☕'+s.break_minutes+'m ';
        const titleTip='Score: '+sc+(s.travel_from_previous!=null?' · '+s.travel_from_previous+'min from '+(s.previous_job||'prev'):'')+(s.travel_to_next?' · '+s.travel_to_next+'min to '+(s.next_job||'next'):'');
        html+=`<div class="ea-slot" style="${slotBg};padding:6px 8px;min-width:90px" onclick="eaApplySlot('${t.technician_id}','${slotDate}','${slotStart}',${parseInt(dur)},'${s.win_start_iso||''}','${s.win_end_iso||''}','${(s.win_label||'').replace(/'/g,'')}')" title="${titleTip}">`;
        html+=`<div style="font-weight:700;font-size:12px">${fmtT(slotStart)}</div>`;
        html+=`<div style="font-size:10px;opacity:.8">${lbl}</div>`;
        html+=`<div style="display:flex;justify-content:space-between;align-items:center;margin-top:3px;font-size:10px">`;
        html+=`<span>${avMin}min${meta?'<br>'+meta.trim():''}</span>`;
        html+=`<span style="font-weight:700;font-size:11px">${sc}</span>`;
        html+=`</div></div>`;
      });
      html+='</div></div></div>';
    });
    el.innerHTML=html+'</div>';
  }catch(e){el.innerHTML='<div style="color:#F44336">Search failed</div>';}
}
function eaApplySlot(techId,date,time,dur,winStart,winEnd,winLabel){
  document.getElementById('ea-date').value=date;
  document.getElementById('ea-time').value=time;
  document.getElementById('ea-dur').value=dur;
  for(let o of document.getElementById('ea-tech').options)if(o.value===techId){o.selected=true;break}
  // Phase 2 \u2014 remember the 2-hour arrival window this slot falls in (if any).
  // eaSave attaches it only when the time is left unchanged; editing ea-time
  // by hand is the exact-time override, so we key on the placement time.
  window._eaWin=(winStart&&winEnd)?{start:winStart,end:winEnd,time:time,label:winLabel||''}:null;
  eaTab('details');eaToast(window._eaWin?('Arrival window '+(winLabel||'')+' \u2014 review and save'):'Slot selected \u2014 review and save to confirm');
}
async function eaLoadContracts(){
  const el=document.getElementById('ea-contracts-list');
  el.innerHTML='<div style="font-size:12px;color:var(--text-light)">Loading...</div>';
  try{
    const r=await fetch(`${API}/contracts/contracts/?appointment=${_eaId}&page_size=50`,{credentials:'same-origin'});
    const d=await r.json();const contracts=d.results||d||[];
    el.innerHTML=contracts.length?contracts.map(ct=>`<div class="ea-contract-row"><div><div class="cn">${ct.contract_number||'Draft'} \u2014 ${ct.title||'Contract'}</div><div class="cs">${ct.status} \u00b7 ${ct.customer_name||''}</div></div><div style="display:flex;gap:6px;align-items:center"><a href="/contracts/?highlight=${ct.id}" target="_blank" style="font-size:11px;color:var(--accent)">View</a><button type="button" class="ea-contract-unlink" title="Unlink" onclick="eaUnlinkContract('${ct.id}')">&times;</button></div></div>`).join(''):'<div style="font-size:12px;color:var(--text-light);margin-bottom:8px">No contracts linked.</div>';
    const pick=document.getElementById('ea-contract-pick');pick.innerHTML='<option value="">— select contract —</option>';
    if(_eaCustId){
      const cr=await fetch(`${API}/contracts/contracts/?customer=${_eaCustId}&page_size=100`,{credentials:'same-origin'});
      const cd=await cr.json();const linked=new Set(contracts.map(c=>c.id));
      (cd.results||cd||[]).forEach(ct=>{if(linked.has(ct.id))return;const o=document.createElement('option');o.value=ct.id;o.textContent=`${ct.contract_number||'Draft'} \u2014 ${ct.title||'Contract'} (${ct.status})`;pick.appendChild(o);});
    }
  }catch(e){el.innerHTML='<div style="color:#F44336;font-size:12px">Failed</div>';}
}
async function eaLinkContract(){const id=document.getElementById('ea-contract-pick').value;if(!id)return;const r=await fetch(`${API}/contracts/contracts/${id}/`,{method:'PATCH',credentials:'same-origin',headers:hdr(),body:JSON.stringify({appointment:_eaId})});if(r.ok){eaLoadContracts();eaToast('Contract linked');}else alert('Failed');}
async function eaUnlinkContract(contractId){const r=await fetch(`${API}/contracts/contracts/${contractId}/`,{method:'PATCH',credentials:'same-origin',headers:hdr(),body:JSON.stringify({appointment:null})});if(r.ok){eaLoadContracts();eaToast('Contract unlinked');}else alert('Failed');}
// BUG-004: Format DRF error shapes into user-friendly toast messages.
// DRF returns errors in two main shapes:
//   {'detail': '...'}                  (auth/perm/throttle)
//   {'field': ['msg1', 'msg2'], ...}   (validation)
// The old code did `e.detail || JSON.stringify(e)`, dumping raw JSON
// for the second shape. This walks both into readable text.
window.formatApiError = function(e, fallbackMsg){
  if (!e || typeof e !== 'object') return fallbackMsg || 'Request failed';
  if (typeof e.detail === 'string' && e.detail.trim()) return e.detail;
  var lines = [];
  for (var k in e) {
    if (!Object.prototype.hasOwnProperty.call(e, k)) continue;
    if (k === 'detail') continue;
    var v = e[k];
    var msgs = Array.isArray(v) ? v : [v];
    msgs.forEach(function(m){
      if (typeof m === 'string' && m.trim()) {
        var label = k.replace(/_/g, ' ');
        label = label.charAt(0).toUpperCase() + label.slice(1);
        lines.push(label + ': ' + m);
      }
    });
  }
  if (lines.length) return lines.join('\n');
  return fallbackMsg || 'Request failed';
};
function eaToast(msg,kind){let t=document.getElementById('_eaToast');if(!t){t=document.createElement('div');t.id='_eaToast';t.style.cssText='position:fixed;bottom:24px;left:50%;transform:translateX(-50%);color:#fff;padding:10px 20px;border-radius:6px;font-size:13px;z-index:9999;opacity:0;transition:opacity .2s;pointer-events:none';document.body.appendChild(t);}t.style.background=(kind==='error')?'#C0392B':'#323232';t.textContent=msg;t.style.opacity='1';clearTimeout(t._to);t._to=setTimeout(()=>t.style.opacity='0',(kind==='error')?4000:2400);}

// Reload the calendar events + every availability surface so newly-booked slots
// drop out and the remaining open slots for that day show. Used after any
// scheduling action and by the manual Refresh button.
function refreshAvailability(){
  try{cal.refetchEvents();}catch(_){}
  try{loadRV();}catch(_){}                               // resource/availability grid (live resource-day)
  if(typeof curView!=='undefined'){
    if(curView==='dispatch'){try{loadDispatch();}catch(_){}}
    if(curView==='availability'){try{loadAvailability();}catch(_){}}
  }
}
function manualRefresh(){
  const i=document.querySelector('#refreshBtn i'); if(i)i.classList.add('fa-spin');
  refreshAvailability();
  // If the flex sidebar is open, recompute its recommendations against the
  // current calendar (force=true busts the cached slots).
  if(document.getElementById('flexPanel').classList.contains('open')) flexLoad(true);
  eaToast('Availability refreshed');
  setTimeout(()=>{if(i)i.classList.remove('fa-spin');},600);
}

// ===== Flexible + overdue commercial-site sidebar + drag-to-schedule =====
let _flexDraggable=null;
function _fxEsc(s){const d=document.createElement('div');d.textContent=(s==null?'':String(s));return d.innerHTML;}
function flexToggle(){const p=document.getElementById('flexPanel');if(p.classList.contains('open'))flexClose();else flexOpen();}
function flexOpen(){const p=document.getElementById('flexPanel');p.classList.add('open');p.setAttribute('aria-hidden','false');flexLoad();}
function flexClose(){const p=document.getElementById('flexPanel');p.classList.remove('open');p.setAttribute('aria-hidden','true');}
function flexInitDrag(){
  if(_flexDraggable||!window.FullCalendar||!FullCalendar.Draggable)return;
  _flexDraggable=new FullCalendar.Draggable(document.getElementById('flexBody'),{
    itemSelector:'.flex-card[data-tech]:not([data-tech=""])',   // only once a slot is resolved
    eventData:()=>({create:false})   // we own the drop; don't let FC create a phantom event
  });
}
async function flexRefreshBadge(){
  try{const d=await api('/scheduling/flex-overdue/?recommend=0');const b=document.getElementById('flexCount');
    if(d&&d.sites&&d.sites.length){b.textContent=d.sites.length;b.style.display='';}else{b.style.display='none';}}catch(_){}
}
let _flexSeq=0;
async function flexLoad(force){
  const body=document.getElementById('flexBody');const seq=++_flexSeq;
  body.innerHTML='<div class="fx-empty">Loading…</div>';
  // The list is instant; per-site optimal slots are precomputed by a background
  // task into a cache, which this endpoint reads. Misses come back pending and
  // we poll until the warm task fills them in. force=true busts the cache so
  // slots recompute against the current calendar (after bookings elsewhere).
  let d;try{d=await api('/scheduling/flex-overdue/?recommend=1'+(force?'&refresh=1':''));}catch(e){body.innerHTML='<div class="fx-empty">Could not load.</div>';return;}
  if(seq!==_flexSeq)return;  // a newer load started
  const sites=(d&&d.sites)||[];const badge=document.getElementById('flexCount');
  if(sites.length){badge.textContent=sites.length;badge.style.display='';}else{badge.style.display='none';}
  if(!sites.length){body.innerHTML='<div class="fx-empty">No commercial sites are flagged <b>flexible</b> and overdue right now.<br><br>Mark a site flexible under Customer → Locations.</div>';return;}
  body.innerHTML='<div id="flexGroups"></div>'+sites.map(flexCardHtml).join('');
  flexInitDrag();
  flexLoadGroups(seq, force);
  if(d.pending) flexPollRecs(seq);
}
// Bunches of nearby overdue sites worth scheduling together on a free day.
let _flexGroups=[];
async function flexLoadGroups(seq, force){
  let d;try{d=await api('/scheduling/flex-overdue/groups/'+(force?'?refresh=1':''));}catch(_){return;}
  if(seq!==_flexSeq)return;
  _flexGroups=(d&&d.groups)||[];
  const host=document.getElementById('flexGroups'); if(!host)return;
  host.innerHTML = _flexGroups.length
    ? '<div class="fg-sectionhdr">Group together on one trip</div>'+_flexGroups.map(flexGroupHtml).join('')
    : '';
}
function flexGroupHtml(g, i){
  const dt=new Date(g.date+'T12:00:00');
  const when=dt.toLocaleDateString([], {weekday:'short',month:'short',day:'numeric'});
  const stops=(g.stops||[]).map(s=>'<li>'+_fxEsc(s.start_time)+' — '+_fxEsc(s.name)
    +' <span class="fc-drive">('+(s.first?'start':(s.leg_min+'m hop'))+')</span></li>').join('');
  return '<div class="flex-group">'
    +'<div class="fg-hd"><i class="fas fa-layer-group"></i> '+g.site_count+' nearby sites — one trip</div>'
    +'<div class="fc-rec"><b>'+_fxEsc(g.technician_name||'Tech')+'</b> · '+_fxEsc(when)
    +'<br><span class="fc-drive">tech free that day · avg '+g.avg_leg_min+' min between stops · '+g.total_drive_min+' min total drive</span></div>'
    +'<ol class="fg-stops">'+stops+'</ol>'
    +'<div class="fc-actions"><button type="button" class="fc-btn primary" onclick="flexBookGroup('+i+')">Schedule all '+g.site_count+'</button></div>'
  +'</div>';
}
async function flexBookGroup(i){
  const g=_flexGroups[i]; if(!g)return;
  const dt=new Date(g.date+'T12:00:00');
  const when=dt.toLocaleDateString([], {weekday:'short',month:'short',day:'numeric'});
  if(!await cbpConfirm('Schedule all '+g.site_count+' sites with '+(g.technician_name||'tech')+' on '+when+' as one route?\n\nNo customer notifications will be sent.'))return;
  const body={technician_id:g.technician_id, stops:(g.stops||[]).map(s=>({service_location:s.location_id, start:s.start_at, duration_min:s.duration_min, job_type_id:s.job_type_id}))};
  let r;try{r=await _flexPost('/scheduling/flex-overdue/book-group/', body);}catch(e){eaToast('Booking failed.','error');return;}
  if(r.status===201){ eaToast('Booked '+r.json.count+' appointments'); refreshAvailability(); flexLoad(); return; }
  if(r.status===409){
    if(r.json.override_available && await cbpConfirm('Some stops have conflicts. Force-book the whole group?')){
      const r2=await _flexPost('/scheduling/flex-overdue/book-group/', Object.assign({},body,{override:true}));
      if(r2.status===201){ eaToast('Booked '+r2.json.count+' (override)'); refreshAvailability(); flexLoad(); return; }
    }
    eaToast('Group has conflicts — could not book.','error'); return;
  }
  if(r.status===403){ eaToast('You don’t have permission to override conflicts.','error'); return; }
  eaToast((r.json&&r.json.error)||('Could not book (HTTP '+r.status+')'),'error');
}
// While the background task computes slots, re-read the (cache-backed) list every
// few seconds and fill in each card as its recommendation lands.
async function flexPollRecs(seq){
  for(let tries=0; tries<24; tries++){
    await new Promise(r=>setTimeout(r, 2500));
    if(seq!==_flexSeq)return;
    let d;try{d=await api('/scheduling/flex-overdue/?recommend=1');}catch(_){continue;}
    if(seq!==_flexSeq)return;
    (d.sites||[]).forEach(s=>{ if(!s.pending) flexApplyRec(s, s.recommendation, s.recommendation_note); });
    if(!d.pending) return;
  }
}
function flexRecInner(rec, note){
  if(rec){
    const dt=new Date(rec.start_at);
    const when=dt.toLocaleDateString([], {weekday:'short',month:'short',day:'numeric'})+' · '+dt.toLocaleTimeString([], {hour:'numeric',minute:'2-digit'});
    let drive=(rec.travel_min_from_prior!=null)?(rec.travel_min_from_prior+(rec.from_home?' min from home':' min from prior stop')):'first stop of day';
    drive+=(rec.travel_min_to_next!=null)?(' · '+rec.travel_min_to_next+(rec.to_home?' min to home':' min to next job')):' · last stop of day';
    const ext=rec.extended?('<span style="color:#b26a00;font-weight:600"> · beyond '+(rec.extended_after_days||10)+'d — no gap sooner</span>'):'';
    return '<div class="fc-rec"><b>'+_fxEsc(rec.technician_name||'Tech')+'</b> · '+_fxEsc(when)+ext+'<br><span class="fc-drive">'+_fxEsc(drive)+(rec.win_label?(' · '+_fxEsc(rec.win_label)):'')+(rec.fit_band?(' · '+_fxEsc(rec.fit_band)):'')+'</span></div>'
      +'<div class="fc-actions"><button type="button" class="fc-btn primary" onclick="flexScheduleCard(this)">Schedule best slot</button><span class="fc-grip" title="Drag onto any calendar gap"><i class="fas fa-up-down-left-right"></i> drag</span></div>';
  }
  if(note==='__pending__') return '<div class="fc-none"><i class="fas fa-circle-notch fa-spin" style="margin-right:6px;color:#bbb"></i>Finding best slot…</div>';
  return '<div class="fc-none">'+_fxEsc(note||'No slot found in the horizon.')+'</div>';
}
function flexCardHtml(s){
  const rec=s.recommendation;
  const over=(s.days_overdue!=null)?(s.days_overdue+'d overdue'):'overdue';
  const data='data-loc="'+_fxEsc(s.location_id)+'" data-title="'+_fxEsc((s.customer_name||'')+' — '+(s.location_name||''))
    +'" data-dur="'+_fxEsc((rec&&rec.duration_min)||'')+'" data-tech="'+_fxEsc((rec&&rec.technician_id)||'')
    +'" data-techname="'+_fxEsc((rec&&rec.technician_name)||'')+'" data-jt="'+_fxEsc(s.job_type_id||'')
    +'" data-recstart="'+_fxEsc((rec&&rec.start_at)||'')+'"';
  return '<div class="flex-card" '+data+'>'
    +'<div class="fc-site">'+_fxEsc(s.location_name||s.address||'Site')+'</div>'
    +'<div class="fc-cust">'+_fxEsc(s.customer_name||'')+'</div>'
    +'<div class="fc-meta">'+_fxEsc(s.job_type||'')+(s.frequency_label?(' · '+_fxEsc(s.frequency_label)):'')+'</div>'
    +'<div class="fc-overdue">'+_fxEsc(over)+'</div>'
    +'<div class="fc-recwrap">'+flexRecInner(rec, rec?'':(s.pending?'__pending__':(s.recommendation_note||'__pending__')))+'</div></div>';
}
function flexApplyRec(s, rec, note){
  const card=document.querySelector('.flex-card[data-loc="'+s.location_id+'"]');
  if(!card)return;
  if(rec){
    card.dataset.tech=rec.technician_id||'';
    card.dataset.techname=rec.technician_name||'';
    card.dataset.dur=(rec.duration_min||'');
    card.dataset.jt=rec.job_type_id||card.dataset.jt||'';
    card.dataset.recstart=rec.start_at||'';
  }else{ card.dataset.tech='';card.dataset.recstart=''; }
  const w=card.querySelector('.fc-recwrap');
  if(w) w.innerHTML=flexRecInner(rec, note);
}
function _flexPayloadFromCard(card,startIso){
  const d=card.dataset;
  return {location_id:d.loc, technician_id:d.tech||null, technician_name:d.techname||'', start:startIso,
          duration_min:parseInt(d.dur,10)||null, job_type_id:d.jt||null, label:d.title||''};
}
function flexScheduleCard(btn){
  const card=btn.closest('.flex-card');if(!card)return;
  if(!card.dataset.recstart){eaToast('No recommended slot for this site.','error');return;}
  flexConfirmAndBook(_flexPayloadFromCard(card,card.dataset.recstart));
}
function flexHandleDrop(info){
  const el=info.draggedEl;if(!el||!el.dataset||!el.dataset.loc)return;
  if(!el.dataset.tech){eaToast('No recommended tech for this site — use New Appointment to pick one.','error');return;}
  const startIso=(info.dateStr||(info.date&&info.date.toISOString()));
  flexConfirmAndBook(_flexPayloadFromCard(el,startIso));
}
async function _flexPost(u,b){const r=await fetch(API+u,{method:'POST',credentials:'same-origin',headers:hdr(),body:JSON.stringify(b)});let j={};try{j=await r.json();}catch(_){}return{status:r.status,json:j};}
async function flexConfirmAndBook(p){
  if(!p.start){eaToast('Could not read the drop time.','error');return;}
  let v;try{v=await _flexPost('/scheduling/flex-overdue/validate/',p);}catch(e){eaToast('Validation failed.','error');return;}
  const vj=v.json||{};
  const dt=new Date(p.start);
  const whenTxt=dt.toLocaleString([], {weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});
  let override=false;
  if(vj.violations&&vj.violations.length){
    const msg='Placing '+(p.label||'this site')+' with '+(p.technician_name||'tech')+' on '+whenTxt+' has conflicts:\n\n• '+vj.violations.map(x=>x.detail).join('\n• ')+'\n\nForce-book anyway? (needs override permission)';
    if(!await cbpConfirm(msg))return;
    override=true;
  }else{
    let warn='';if(vj.warnings&&vj.warnings.length)warn='\n\nNote: '+vj.warnings.map(x=>x.detail).join('; ');
    if(!await cbpConfirm('Book '+(p.label||'this site')+' with '+(p.technician_name||'tech')+' on '+whenTxt+'?\n\nNo customer notification will be sent.'+warn))return;
  }
  let r;try{r=await _flexPost('/scheduling/flex-overdue/book/',Object.assign({},p,{override:override}));}catch(e){eaToast('Booking failed.','error');return;}
  if(r.status===201){
    eaToast('Booked — '+(p.technician_name||'tech')+' · '+whenTxt+(r.json.overridden?' (override)':''));
    refreshAvailability();   // show the day's remaining open slots with the new booking removed
    flexLoad();
  }else if(r.status===409){
    if(r.json.override_available&&await cbpConfirm('Conflicts remain. Force-book with override?')){
      const r2=await _flexPost('/scheduling/flex-overdue/book/',Object.assign({},p,{override:true}));
      if(r2.status===201){eaToast('Booked (override).');refreshAvailability();flexLoad();return;}
    }
    eaToast((vj.violations&&vj.violations[0]&&vj.violations[0].detail)||'Could not book (conflict).','error');
  }else if(r.status===403){eaToast('You don’t have permission to override conflicts.','error');}
  else{eaToast((r.json&&r.json.error)||('Could not book (HTTP '+r.status+')'),'error');}
}
if(document.readyState!=='loading')setTimeout(flexRefreshBadge,1200);else document.addEventListener('DOMContentLoaded',()=>setTimeout(flexRefreshBadge,1200));



const B_NEW_PROP_RES=[['house','House'],['apartment','Apartment']];
const B_NEW_PROP_COM=[['multifamily','Multifamily'],['retail','Retail'],['office','Office'],['industrial','Industrial'],['restaurant','Restaurant'],['hospitality','Hospitality'],['land','Land']];
function onBNewTypeChange(){
  const t=document.getElementById('bNewType').value;
  const compWrap=document.getElementById('bNewCompanyWrap');
  if(compWrap)compWrap.style.display=(t==='commercial')?'grid':'none';
  const sel=document.getElementById('bNewPropType');
  if(!sel)return;
  const prev=sel.value;
  const list=(t==='commercial')?B_NEW_PROP_COM:B_NEW_PROP_RES;
  sel.innerHTML=list.map(([v,l])=>`<option value="${v}">${l}</option>`).join('');
  if(list.some(([v])=>v===prev))sel.value=prev;
  else sel.value=(t==='commercial')?'office':'house';
  filterTechsByProperty(sel.value);
}

async function loadServiceLocations(customerId){
  const row=document.getElementById('bLocRow');
  const sel=document.getElementById('bServiceLoc');
  if(!row||!sel)return;
  sel.innerHTML='<option value="">Use primary service address</option>';
  var _nsr0=document.getElementById('bNewSiteRow');if(_nsr0)_nsr0.style.display='none';
  if(!customerId){row.style.display='none';return;}
  try{
    const r=await fetch('/api/v1/service-locations/?customer='+customerId+'&is_active=true&page_size=200',{credentials:'same-origin'});
    const d=await r.json();
    const items=d.results||d;
    items.forEach(l=>{
      const o=document.createElement('option');
      o.value=l.id;
      o.textContent=l.location_name+(l.address?' — '+l.address+(l.address_2?' '+l.address_2:''):'');
      o.dataset.address=l.address||'';
      o.dataset.address2=l.address_2||'';
      o.dataset.city=l.city||'';
      o.dataset.state=l.state||'';
      o.dataset.zip=l.zip_code||'';
      o.dataset.contact=l.site_contact_name||'';o.dataset.contactPhone=l.site_contact_phone||'';o.dataset.contactEmail=l.site_contact_email||'';o.dataset.contactRole=l.site_contact_role||'';
      o.dataset.access=l.access_instructions||'';
      o.dataset.special=l.special_instructions||'';
      sel.appendChild(o);
    });
  }catch(e){console.warn('Loc load failed',e);}
  var _na=document.createElement('option');_na.value='__new__';_na.textContent='+ Add a new site...';sel.appendChild(_na);
  row.style.display='grid';
}

// BUG-003 part 2: edit-appt-modal twins of loadServiceLocations / onServiceLocChange.
// Same pattern as Create modal but operate on ea-* IDs and accept a
// `currentServiceLocId` so we can mark the appointment's existing
// location as selected on load.
async function loadEaServiceLocations(customerId, currentServiceLocId){
  const row = document.getElementById('ea-loc-row');
  const sel = document.getElementById('ea-service-loc');
  if (!row || !sel) return;
  sel.innerHTML = '<option value="">Use primary service address</option>';
  var _nsr0=document.getElementById('eaNewSiteRow');if(_nsr0)_nsr0.style.display='none';
  if (!customerId) { row.style.display = 'none'; return; }
  try {
    const r = await fetch('/api/v1/service-locations/?customer=' + customerId + '&is_active=true&page_size=200', {credentials:'same-origin'});
    const d = await r.json();
    const items = d.results || d;
    items.forEach(l => {
      const o = document.createElement('option');
      o.value = l.id;
      o.textContent = l.location_name + (l.address ? ' - ' + l.address + (l.address_2 ? ' ' + l.address_2 : '') : '');
      o.dataset.address = l.address || '';
      o.dataset.address2 = l.address_2 || '';
      o.dataset.contact = l.site_contact_name || '';
      o.dataset.contactPhone = l.site_contact_phone || '';
      o.dataset.contactEmail = l.site_contact_email || '';
      o.dataset.contactRole = l.site_contact_role || '';
      o.dataset.access = l.access_instructions || '';
      o.dataset.special = l.special_instructions || '';
      if (currentServiceLocId && String(l.id) === String(currentServiceLocId)) o.selected = true;
      sel.appendChild(o);
    });
  } catch (e) {
    console.warn('EA loc load failed', e);
  }
  var _na=document.createElement('option');_na.value='__new__';_na.textContent='+ Add a new site...';sel.appendChild(_na);
  row.style.display = 'grid';
}
function onEaServiceLocChange(){
  var _nsEl=document.getElementById('eaNewSiteRow');
  var _slPick=document.getElementById('ea-service-loc');
  if(_slPick&&_slPick.value==='__new__'){
    if(_nsEl)_nsEl.style.display='grid';
    var _nsa=document.getElementById('eaNewSiteAddr');
    if(_nsa&&!_nsa.value){var _bl=document.getElementById('ea-loc');if(_bl&&_bl.value)_nsa.value=_bl.value;}
    return;
  }
  if(_nsEl)_nsEl.style.display='none';
  const sel = document.getElementById('ea-service-loc');
  if (!sel || !sel.value) {
    // Cleared: leave ea-loc/ea-loc2 alone (user may have manually edited).
    return;
  }
  const o = sel.options[sel.selectedIndex];
  document.getElementById('ea-loc').value = o.dataset.address || '';
  if (document.getElementById('ea-loc2')) document.getElementById('ea-loc2').value = o.dataset.address2 || '';
}

function onServiceLocChange(){
  var _nsEl=document.getElementById('bNewSiteRow');
  var _slPick=document.getElementById('bServiceLoc');
  if(_slPick&&_slPick.value==='__new__'){
    if(_nsEl)_nsEl.style.display='grid';
    var _nsa=document.getElementById('bNewSiteAddr');
    if(_nsa&&!_nsa.value){var _bl=document.getElementById('bLoc');if(_bl&&_bl.value)_nsa.value=_bl.value;}
    return;
  }
  if(_nsEl)_nsEl.style.display='none';
  // Quick-Win #4 — auto-fill site contact fields from selected service location.
  try {
    const sel = document.getElementById('bServiceLoc');
    const opt = sel && sel.options[sel.selectedIndex];
    const dn = opt ? (opt.dataset.contact || '') : '';
    const dp = opt ? (opt.dataset.contactPhone || '') : '';
    const de = opt ? (opt.dataset.contactEmail || '') : '';
    const dr = opt ? (opt.dataset.contactRole || '') : '';
    const $n = document.getElementById('bSiteContactName');
    const $p = document.getElementById('bSiteContactPhone');
    const $e = document.getElementById('bSiteContactEmail');
    const $r = document.getElementById('bSiteContactRole');
    // Only overwrite the contact fields when an explicit service location
    // is picked (sel.value truthy). The default 'Use primary service
    // address' leaves the values populated by the customer-pick.
    if (sel && sel.value) {
      if ($n) $n.value = dn;
      if ($p) $p.value = dp;
      if ($e) $e.value = de;
      if ($r) $r.value = dr;
    }
  } catch (err) { /* non-fatal */ }

  const sel=document.getElementById('bServiceLoc');
  if(!sel||!sel.value){
    // Revert to customer primary address
    if(bookCust&&bookCust.service_address){
      document.getElementById('bLoc').value=bookCust.service_address;
      if(document.getElementById('bLoc2'))document.getElementById('bLoc2').value=bookCust.service_address_2||'';
    }
    return;
  }
  const o=sel.options[sel.selectedIndex];
  document.getElementById('bLoc').value=o.dataset.address||'';
  if(document.getElementById('bLoc2'))document.getElementById('bLoc2').value=o.dataset.address2||'';
  // Append site contact + access info to notes helper
  const parts=[];
  if(o.dataset.contact)parts.push('Site contact: '+o.dataset.contact);
  if(o.dataset.access)parts.push('Access: '+o.dataset.access);
  if(o.dataset.special)parts.push(o.dataset.special);
  if(parts.length){
    const noteEl=document.getElementById('bNotes');
    if(noteEl&&!noteEl.value.trim())noteEl.value=parts.join(' | ');
  }
}
function filterTechsByProperty(propertyType){
  const sel=document.getElementById('bTech');
  if(!sel)return;
  for(const o of sel.options){
    if(!o.value){o.disabled=false;o.textContent=o.textContent.replace(/ ⚠$/,'');continue;}
    let types=[];try{types=JSON.parse(o.dataset.serviceable||'[]');}catch(e){}
    const canService=!types.length||!propertyType||types.includes(propertyType);
    o.disabled=!canService;
    const base=o.textContent.replace(/ ⚠$/,'');
    o.textContent=canService?base:base+' ⚠';
  }
}

// ── Discard-confirm guard for create/edit modals ─────────────────────
// Tracks 'dirty' by listening for any input/change inside the modal.
// Exposes el._cbpIsDirty()/el._cbpResetDirty() so base.html's
// closeModalEl() can prompt before closing on backdrop click or ESC.
// X/Cancel buttons close immediately (call hideModal directly) — by design,
// since those are intentional clicks. Reset dirty whenever the modal
// transitions from hidden to visible (new openNew/openEdit invocation).
(function(){
  const MODAL_IDS = ['bookModal', 'editApptModal'];
  MODAL_IDS.forEach(function(id){
    const el = document.getElementById(id);
    if (!el) return;
    let dirty = false;
    const mark = function(){ dirty = true; };
    el.addEventListener('input',  mark);
    el.addEventListener('change', mark);
    new MutationObserver(function(muts){
      muts.forEach(function(m){
        if (m.attributeName !== 'class') return;
        const oldCls = (m.oldValue || '').split(/\s+/);
        const wasHidden = !oldCls.includes('show') && !oldCls.includes('open');
        const isShown  = el.classList.contains('show') || el.classList.contains('open');
        if (wasHidden && isShown) dirty = false;
      });
    }).observe(el, { attributes: true, attributeFilter: ['class'], attributeOldValue: true });
    el.dataset.discardConfirm = '1';
    el._cbpIsDirty    = function(){ return dirty; };
    el._cbpResetDirty = function(){ dirty = false; };
  });
})();