(function(){
    function bindDatePickers(root){
      if (!window.flatpickr) return;
      var inputs = (root || document).querySelectorAll('input[type="date"]:not(.flatpickr-input)');
      inputs.forEach(function(el){
        // Skip if this input is itself the alt rendered by a previous flatpickr pass
        if (el.classList.contains('flatpickr-alt-input')) return;
        flatpickr(el, {
          allowInput: true,
          altInput: true,
          altFormat: 'm/d/Y',
          dateFormat: 'Y-m-d',
        });
        // Many page-level JS handlers run AFTER flatpickr has bound and set
        // values via `el.value = '2026-05-17'` directly. flatpickr binds an
        // alt-input pattern — the original <input type="date"> becomes
        // hidden and a sibling visible input shows the m/d/Y form — so a
        // raw `.value =` updates the hidden field but leaves the visible
        // alt stale (the user sees an empty box). Patch the value setter
        // on the bound element to route through flatpickr's setDate(),
        // which updates BOTH the hidden value and the visible alt.
        // triggerChange=true so any pre-existing change/input listeners
        // (e.g. form validation, recurrence calculators) still fire.
        try {
          var proto = Object.getPrototypeOf(el);
          var desc = Object.getOwnPropertyDescriptor(proto, 'value') ||
                     Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
          if (desc && desc.set) {
            var nativeSetter = desc.set;
            Object.defineProperty(el, 'value', {
              configurable: true,
              get: function(){ return desc.get.call(this); },
              set: function(v){
                // Re-entrancy guard: flatpickr.setDate() internally writes
                // to this.input.value as part of its state sync. Without
                // this guard, that inner write hits THIS setter, calls
                // setDate again, which writes .value again — infinite
                // recursion and a stack overflow (see /calendar/ which has
                // 11 date inputs and JS that auto-fills several on load).
                // We mark the element while we're "inside" setDate; nested
                // writes during that window use the native setter instead.
                if (this._fpSetterBusy) {
                  nativeSetter.call(this, v);
                  return;
                }
                if (this._flatpickr) {
                  this._fpSetterBusy = true;
                  try {
                    this._flatpickr.setDate(v, true);
                  } finally {
                    this._fpSetterBusy = false;
                  }
                } else {
                  // flatpickr instance was destroyed (e.g. teardown) —
                  // fall back to the native setter so we don't crash.
                  nativeSetter.call(this, v);
                }
              },
            });
          }
        } catch (e) {
          // If patching fails (older browser, frozen prototype, etc.) the
          // page still works — the user just sees a stale alt input that
          // they can click to fix. Don't block the rest of the binding.
        }
      });
    }
    document.addEventListener('DOMContentLoaded', function(){
      bindDatePickers(document);
    });
    // Re-bind after SPA-style content swaps (mirrors the overlay observer above)
    window.addEventListener('cbp:spa-navigated', function(){
      bindDatePickers(document);
    });
    // Also catch <input type="date"> added later via JS (modals, dynamic forms)
    var dateObs = new MutationObserver(function(mutations){
      mutations.forEach(function(m){
        m.addedNodes.forEach(function(n){
          if (n.nodeType !== 1) return;
          if (n.matches && n.matches('input[type="date"]:not(.flatpickr-input)')) {
            bindDatePickers(n.parentNode);
          }
          if (n.querySelectorAll) bindDatePickers(n);
        });
      });
    });
    document.addEventListener('DOMContentLoaded', function(){
      dateObs.observe(document.body, { childList: true, subtree: true });
    });
  })();