/* ── Shared autocomplete helpers ── */
const _pdaxTimers = {};

const _pdaxCfg = {
  tech: {
    url: q => '/api/v1/technicians/search/?q=' + encodeURIComponent(q),
    render: r => r.map(t =>
      `<div class="pdax-dd-item" data-id="${t.id}" data-label="${_pdaxEsc(t.name)}">
        <strong>${_pdaxEsc(t.name)}</strong>${t.email ? ' &middot; ' + _pdaxEsc(t.email) : ''}
       </div>`
    ).join(''),
  },
  cust: {
    url: q => '/api/v1/customer-search/?q=' + encodeURIComponent(q),
    render: r => r.map(c =>
      `<div class="pdax-dd-item" data-id="${c.id}" data-label="${_pdaxEsc(c.first_name + ' ' + c.last_name)}">
        <strong>${_pdaxEsc(c.first_name)} ${_pdaxEsc(c.last_name)}</strong>${c.phone ? ' &middot; ' + _pdaxEsc(c.phone) : ''}
       </div>`
    ).join(''),
  },
  prod: {
    url: q => '/api/v1/fieldops/pesticide-products/search/?q=' + encodeURIComponent(q),
    render: r => (r.results || r).map(p =>
      `<div class="pdax-dd-item" data-id="${p.id}" data-label="${_pdaxEsc(p.name)}">
        <strong>${_pdaxEsc(p.name)}</strong>${p.epa_reg_number ? ' &middot; EPA ' + _pdaxEsc(p.epa_reg_number) : ''}
       </div>`
    ).join(''),
  },
};

function _pdaxEsc(s) {
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function pdaxSearch(key, q) {
  document.getElementById('pdax-' + key + '-id').value = '';
  clearTimeout(_pdaxTimers[key]);
  const dd = document.getElementById('pdax-' + key + '-dd');
  if (q.length < 2) { dd.style.display = 'none'; return; }
  _pdaxTimers[key] = setTimeout(() => {
    fetch(_pdaxCfg[key].url(q), {credentials: 'same-origin', headers: {'Accept': 'application/json'}})
      .then(r => r.ok ? r.json() : [])
      .then(res => {
        const items = res.results || res;
        if (!items.length) { dd.style.display = 'none'; return; }
        dd.innerHTML = _pdaxCfg[key].render(res);
        dd.querySelectorAll('.pdax-dd-item').forEach(el => {
          el.addEventListener('click', () => {
            document.getElementById('pdax-' + key + '-id').value = el.dataset.id;
            document.getElementById('pdax-' + key + '-q').value = el.dataset.label;
            dd.style.display = 'none';
          });
        });
        dd.style.display = 'block';
      }).catch(() => {});
  }, 250);
}

function pdaxCloseDd(key) {
  const dd = document.getElementById('pdax-' + key + '-dd');
  if (dd) dd.style.display = 'none';
}

document.addEventListener('click', e => {
  ['tech', 'cust', 'prod'].forEach(key => {
    if (!e.target.closest('#pdax-' + key + '-q') && !e.target.closest('#pdax-' + key + '-dd')) {
      pdaxCloseDd(key);
    }
  });
});

/* ── Form submit ── */
function pdaxSubmit(ev) {
  ev.preventDefault();
  const form = document.getElementById('pdax-form');
  const start = form.start.value.trim();
  const end = form.end.value.trim();
  const fmt = (form.format.value || 'xlsx').toLowerCase();
  const tech = form.technician_id.value.trim();
  const cust = form.customer_id.value.trim();
  const prod = form.product_id.value.trim();
  const status = document.getElementById('pdax-status');
  status.className = 'pdax-status';
  status.textContent = '';

  if (!start || !end) {
    status.className = 'pdax-status is-error';
    status.textContent = 'Start and end dates are required.';
    return false;
  }
  if (end < start) {
    status.className = 'pdax-status is-error';
    status.textContent = 'End must be on or after start.';
    return false;
  }

  const params = new URLSearchParams({start: start, end: end, format: fmt});
  if (tech) params.set('technician_id', tech);
  if (cust) params.set('customer_id', cust);
  if (prod) params.set('product_id', prod);

  status.className = 'pdax-status is-info';
  status.textContent = 'Generating report — large date ranges may take a few seconds…';

  const url = '/api/v1/compliance/reports/pa-dept-ag/?' + params.toString();
  window.location.href = url;
  return false;
}