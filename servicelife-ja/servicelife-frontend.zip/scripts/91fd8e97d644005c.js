(function(){
  const csrftoken = (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';

  document.querySelectorAll('tr.row-link').forEach(tr => {
    tr.addEventListener('click', () => { window.location = tr.dataset.href; });
  });

  const modal = document.getElementById('bug-modal');
  const errBox = document.getElementById('bug-errors');
  function openModal(){ modal.classList.add('show'); document.getElementById('bug-title').focus(); }
  function closeModal(){ modal.classList.remove('show'); errBox.classList.remove('show'); errBox.textContent = ''; document.getElementById('bug-form').reset(); }

  document.getElementById('new-bug-btn').addEventListener('click', (e) => { e.preventDefault(); openModal(); });
  document.getElementById('bug-cancel').addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });

  document.getElementById('bug-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      const r = await fetch('/settings/system-bugs/', {
        method: 'POST',
        headers: {'X-CSRFToken': csrftoken, 'Accept': 'application/json'},
        credentials: 'same-origin',
        body: fd,
      });
      const data = await r.json();
      if (!r.ok || !data.ok) {
        errBox.textContent = (data.errors || ['Unknown error.']).join(' ');
        errBox.classList.add('show');
        return;
      }
      window.location = data.redirect;
    } catch (err) {
      errBox.textContent = 'Network error: ' + err.message;
      errBox.classList.add('show');
    }
  });
})();