function njdxSubmit(ev) {
  ev.preventDefault();
  const form = document.getElementById('njdx-form');
  const start = form.start.value.trim();
  const end = form.end.value.trim();
  const status = document.getElementById('njdx-status');
  status.className = 'njdx-status';
  status.textContent = '';

  if (!start || !end) {
    status.className = 'njdx-status is-error';
    status.textContent = 'Start and end dates are required.';
    return false;
  }
  if (end < start) {
    status.className = 'njdx-status is-error';
    status.textContent = 'End must be on or after start.';
    return false;
  }

  const params = new URLSearchParams({start: start, end: end});

  status.className = 'njdx-status is-info';
  status.textContent = 'Generating CSV — large date ranges may take a few seconds…';

  const url = '/api/v1/compliance/reports/nj-dep/csv/?' + params.toString();
  window.location.href = url;
  return false;
}