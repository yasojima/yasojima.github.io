(function(){
  const API='/api/v1/communications/transcription-health/data/';
  const STATUSES=[
    {key:'pending',     label:'Pending',     icon:'fa-clock',                color:'#6b7280'},
    {key:'in_progress', label:'In Progress', icon:'fa-spinner',              color:'#3b82f6'},
    {key:'ok',          label:'OK',          icon:'fa-check-circle',         color:'#A5CE3A'},
    {key:'partial',     label:'Partial',     icon:'fa-exclamation-triangle', color:'#f59e0b'},
    {key:'failed',      label:'Failed',      icon:'fa-times-circle',         color:'#dc2626'},
    {key:'skipped',     label:'Skipped',     icon:'fa-forward',              color:'#9ca3af'},
  ];

  function renderStatusCards(counts){
    const grid=document.getElementById('thStatusGrid');
    grid.innerHTML=STATUSES.map(s=>{
      const n=counts[s.key]||0;
      return `<div class="th-status-card ${s.key}"><div class="lbl"><i class="fas ${s.icon}"></i> ${s.label}</div><div class="val">${n}</div></div>`;
    }).join('');
  }

  function renderTrendChart(trend){
    const ctx=document.getElementById('thTrendChart').getContext('2d');
    const labels=trend.map(d=>d.date.slice(5));  // MM-DD
    const datasets=STATUSES.filter(s=>s.key!=='pending'&&s.key!=='in_progress').map(s=>({
      label:s.label,
      data:trend.map(d=>d[s.key]||0),
      backgroundColor:s.color,
      borderRadius:2,
      stack:'a',
    }));
    new Chart(ctx,{type:'bar',data:{labels,datasets},options:{
      responsive:true,maintainAspectRatio:true,
      plugins:{legend:{position:'bottom',labels:{font:{size:10},boxWidth:10}}},
      scales:{x:{stacked:true,ticks:{font:{size:10}}},y:{stacked:true,beginAtZero:true,ticks:{font:{size:10},precision:0}}},
    }});
  }

  function renderAttemptsChart(dist,cap){
    const ctx=document.getElementById('thAttemptsChart').getContext('2d');
    // Span 0..max(cap, max(dist.attempts)) so the cap line always shows.
    const maxA=Math.max(cap, ...(dist.length?dist.map(d=>d.attempts):[0]));
    const labels=[];const data=[];
    for(let i=0;i<=maxA;i++){labels.push(String(i));const m=dist.find(d=>d.attempts===i);data.push(m?m.count:0);}
    // Color bars red if attempts >= cap (these are the "needs review" ones).
    const colors=labels.map(l=>parseInt(l,10)>=cap?'#dc2626':'#A5CE3A');
    // Plugin: draw a vertical line at the cap.
    const capLine={id:'capLine',afterDatasetsDraw(chart){
      const x=chart.scales.x.getPixelForValue(cap);
      const{top,bottom}=chart.chartArea;
      const ctx2=chart.ctx;
      ctx2.save();ctx2.strokeStyle='#dc2626';ctx2.lineWidth=2;ctx2.setLineDash([5,4]);
      ctx2.beginPath();ctx2.moveTo(x,top);ctx2.lineTo(x,bottom);ctx2.stroke();
      ctx2.fillStyle='#dc2626';ctx2.font='10px sans-serif';ctx2.fillText('cap='+cap,x+4,top+10);
      ctx2.restore();
    }};
    new Chart(ctx,{type:'bar',data:{labels,datasets:[{label:'Calls',data,backgroundColor:colors,borderRadius:2}]},options:{
      responsive:true,maintainAspectRatio:true,
      plugins:{legend:{display:false},tooltip:{callbacks:{title:items=>items[0].label+' attempt(s)'}}},
      scales:{x:{title:{display:true,text:'attempts',font:{size:10}},ticks:{font:{size:10}}},y:{beginAtZero:true,ticks:{font:{size:10},precision:0}}},
    },plugins:[capLine]});
  }

  function renderReviewPanel(count){
    const panel=document.getElementById('thReviewPanel');
    document.getElementById('thNeedsReviewCount').textContent=count;
    panel.style.display='flex';  // Always visible — '0' is itself a useful signal.
  }

  function renderFootnote(ratio,threshold){
    const note=document.getElementById('thFootnote');
    const pct=(ratio*100).toFixed(1);
    const tpct=(threshold*100).toFixed(0);
    const alerting=ratio>=threshold;
    const cls=alerting?'alert-on':'alert-off';
    const sym=alerting?'<i class="fas fa-bell"></i>':'<i class="fas fa-check"></i>';
    note.innerHTML=`<div class="lhs"><strong>${pct}%</strong> partial-rate over the last 24h <span style="color:var(--text-light)">(${alerting?'above':'below'} ${tpct}% alert threshold)</span></div><div class="${cls}">${sym} ${alerting?'Alerting':'Healthy'}</div>`;
  }

  function fmtTimeShort(d){return d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'});}

  async function load(){
    try{
      const res=await fetch(API,{credentials:'same-origin'});
      if(!res.ok){throw new Error('HTTP '+res.status);}
      const d=await res.json();
      renderStatusCards(d.status_counts||{});
      renderTrendChart(d.trend_7d||[]);
      renderAttemptsChart(d.attempt_distribution||[],d.max_attempts_cap||5);
      renderReviewPanel(d.needs_review_count||0);
      renderFootnote(d.partial_ratio_24h||0, d.alert_threshold||0.3);
      document.getElementById('thUpdated').textContent='Updated '+fmtTimeShort(new Date());
    }catch(e){
      document.getElementById('thStatusGrid').innerHTML=
        '<div class="th-loading" style="color:#dc2626">Failed to load: '+e.message+'</div>';
      console.error('transcription-health load failed:',e);
    }
  }
  load();
})();