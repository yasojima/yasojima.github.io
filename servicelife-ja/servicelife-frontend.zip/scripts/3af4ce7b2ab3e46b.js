(function(){
    if (window.__cbpSpaInitialized) return;
    window.__cbpSpaInitialized = true;

    var contentSelector = ".main .content";
    var topbarSelector = ".main";  // we'll re-render the topbar block too

    function isInternalLink(a) {
      if (!a || !a.href) return false;
      if (a.target && a.target !== "_self") return false;
      if (a.hasAttribute("download")) return false;
      if (a.dataset.noSpa !== undefined) return false;
      // Skip non-destination hrefs used as JS handler hooks (e.g.
      // <a href="#" onclick="showPanel(...)">). new URL("#", base).hash
      // is "" not "#", so the existing same-path-with-hash check below
      // wouldn't catch them.
      var rawHref = (a.getAttribute("href") || "").trim();
      if (!rawHref || rawHref === "#" || rawHref.charAt(0) === "#") return false;
      if (rawHref.toLowerCase().indexOf("javascript:") === 0) return false;
      var u;
      try { u = new URL(a.href, window.location.href); } catch(e) { return false; }
      if (u.origin !== window.location.origin) return false;
      // Skip anchors that only differ by hash on the same path
      if (u.pathname === window.location.pathname && u.hash) return false;
      // Skip non-GET-able paths we know about
      if (u.pathname.startsWith("/api/")) return false;
      if (u.pathname === "/logout/") return false;  // session change → full reload
      if (u.pathname.startsWith("/admin/")) return false;
      return true;
    }

    function setActiveSidebar(pathname) {
      document.querySelectorAll(".sidebar-nav a").forEach(function(a){
        try {
          var u = new URL(a.href, window.location.href);
          a.classList.toggle("active", u.pathname === pathname);
        } catch(e){}
      });
    }

    function runInlineScripts(container) {
      // The HTML inserted via innerHTML does NOT execute <script> tags.
      // Walk them and re-create as live <script> elements so they run.
      //
      // CRITICAL: inline scripts in our pages are NOT wrapped in IIFEs —
      // they declare `const state`, `const API` etc at the top level.
      // Re-executing them as-is on every SPA navigation throws
      //   SyntaxError: Identifier 'state' has already been declared
      // which kills the entire script's execution silently. The page
      // looks rendered but is dead: no event listeners attach, the
      // OLD setInterval keeps firing against stale references.
      //
      // Fix: wrap each re-executed inline script in its own IIFE so
      // const/let bindings become locals. Globals declared via `var`
      // or `window.X` still work (they reassign rather than redeclare),
      // and most importantly all the event handlers and DOM
      // initialization code re-runs cleanly.
      var scripts = container.querySelectorAll("script");
      scripts.forEach(function(old){
        // Skip non-JavaScript <script> data blocks (Django's json_script emits
        // type="application/json"; also text/template etc.). Re-creating them
        // wraps their payload in an IIFE, corrupting the JSON — which silently
        // breaks any page that does JSON.parse(getElementById(id).textContent)
        // after an SPA nav (Bug: /maintenance/ showed blank until full refresh).
        var _t = (old.getAttribute("type") || "").toLowerCase();
        if (_t && _t !== "module" && _t.indexOf("javascript") === -1) return;
        var s = document.createElement("script");
        for (var i=0; i<old.attributes.length; i++) {
          var a = old.attributes[i];
          s.setAttribute(a.name, a.value);
        }
        if (old.src) {
          // External script: re-add as-is; browser caches and dedupes.
        } else {
          // Inline: wrap in IIFE so top-level const/let are scoped to
          // this run. The wrap is safe even for already-IIFE'd scripts —
          // it just nests one IIFE inside another, no behavior change.
          //
          // CRITICAL: pages declare `function openNew() {}` etc. at the
          // top level and reference those from inline onclick= attrs in
          // their HTML. Inline event handler attributes can only resolve
          // names from the global scope — IIFE-locals are invisible. So
          // we extract every `function NAME(...)` declaration and emit
          // `window.NAME = NAME` lines inside the IIFE to auto-promote
          // them. Without this, every onclick= button on a SPA-navigated
          // page throws ReferenceError and silently does nothing.
          var src = old.textContent;
          var fnRegex = /(?:^|\n)\s*(?:async\s+)?function\*?\s+([A-Za-z_$][\w$]*)\s*\(/g;
          var seen = {}, names = [], m;
          while ((m = fnRegex.exec(src)) !== null) {
            if (!seen[m[1]]) { seen[m[1]] = 1; names.push(m[1]); }
          }
          var promote = names.map(function(n){
            // try/catch so a name not actually in IIFE scope (e.g. one
            // we matched inside a nested function) doesn't throw.
            return "try{window." + n + "=" + n + "}catch(e){}";
          }).join(";");
          s.textContent = "(function(){\n" + src + "\n;" + promote + "\n})();";
        }
        old.parentNode.replaceChild(s, old);
      });
    }

    // Auto-track timers from PAGE SCRIPTS so we can clean them up on
    // navigation. Pages set setInterval to poll for new messages etc;
    // without cleanup, every SPA visit stacks another timer running
    // against stale closures.
    //
    // CRITICAL: we ONLY track timers registered while page scripts are
    // running (the runInlineScripts pass after a swap). Timers
    // registered by base.html itself (e.g. the softphone widget's
    // in-call timer that updates every second during a live call) must
    // NOT be killed on nav — that would freeze the timer mid-call even
    // though the audio stream is still flowing. We use an
    // __inPageScript flag that runInlineScripts toggles.
    var __pageTimers = { intervals: [], timeouts: [] };
    var __inPageScript = false;
    var __origSetInterval = window.setInterval;
    var __origSetTimeout = window.setTimeout;
    window.setInterval = function(fn, ms) {
      var id = __origSetInterval.apply(this, arguments);
      if (__inPageScript) __pageTimers.intervals.push(id);
      return id;
    };
    window.setTimeout = function(fn, ms) {
      var id = __origSetTimeout.apply(this, arguments);
      // Only track within page-script context, and only "long" timeouts
      // that might outlive a nav (skip debounce/rAF-shim noise).
      if (__inPageScript && ms && ms > 1000) __pageTimers.timeouts.push(id);
      return id;
    };
    function clearPageTimers() {
      __pageTimers.intervals.forEach(function(id){ clearInterval(id); });
      __pageTimers.timeouts.forEach(function(id){ clearTimeout(id); });
      __pageTimers.intervals = [];
      __pageTimers.timeouts = [];
    }

    // Track in-flight fetches per page so we can abort them on nav.
    // Without this, a page kicks off fetch()s during boot (e.g. inbox
    // loadList()) and they resolve AFTER navigation has swapped the
    // DOM out from under them. Their .then() handlers then try to
    // touch elements that no longer exist (getElementById('cnt-open')
    // returns null), throwing TypeError and spamming the console.
    //
    // Solution: monkey-patch fetch() to associate every request with
    // an AbortController. clearPageFetches() aborts them all on nav,
    // which causes their pending promises to reject with AbortError.
    // The page's .then() never runs, no DOM is touched, no error.
    var __pageFetchControllers = [];
    var __origFetch = window.fetch;
    window.fetch = function(input, init) {
      // If caller already passed a signal, respect it — chain ours
      // alongside via a composite. For simplicity, only wrap when no
      // signal was supplied (the common case).
      init = init || {};
      if (!init.signal) {
        var ctrl = new AbortController();
        init.signal = ctrl.signal;
        __pageFetchControllers.push(ctrl);
      }
      return __origFetch.call(this, input, init);
    };
    function clearPageFetches() {
      __pageFetchControllers.forEach(function(ctrl){
        try { ctrl.abort(); } catch(e){}
      });
      __pageFetchControllers = [];
    }

    // Catch unhandled promise rejections from AbortError. These are
    // expected (we caused them by aborting), and pages don't always
    // .catch() them. Swallow specifically AbortError; let real errors
    // through to the console.
    window.addEventListener("unhandledrejection", function(ev){
      var r = ev.reason;
      if (r && (r.name === "AbortError" || (r.message || "").indexOf("aborted") !== -1)) {
        ev.preventDefault();
      }
    });

    // DOMContentLoaded handler shim. Pages call
    //   document.addEventListener('DOMContentLoaded', initFn)
    // but DCL fires exactly once at original page parse. After SPA-nav,
    // re-injected scripts re-register the listener but the event has
    // already fired, so handlers never run. Calendar suffers from this
    // (3 DCL listeners gate all initialization).
    //
    // Fix: when a DCL or load listener is registered AFTER DCL has
    // already fired, schedule the handler immediately on the next tick.
    // Matches HTMX/Turbo/Inertia behavior.
    var __domAlreadyLoaded = (document.readyState === "interactive" || document.readyState === "complete");
    if (!__domAlreadyLoaded) {
      document.addEventListener("DOMContentLoaded", function(){ __domAlreadyLoaded = true; }, { once: true });
    }
    var __origDocAddEventListener = document.addEventListener.bind(document);
    document.addEventListener = function(type, listener, options) {
      if (__domAlreadyLoaded && (type === "DOMContentLoaded" || type === "load") && typeof listener === "function") {
        // Fire the handler asynchronously, matching native behavior
        // for already-fired events.
        setTimeout(function(){ try { listener({ type: type }); } catch(e){ console.error(e); } }, 0);
        return;
      }
      return __origDocAddEventListener(type, listener, options);
    };

    // Copy any <script src>/<link rel=stylesheet> from an INCOMING page's <head>
    // that the live document doesn't already have, into the live <head>.
    //
    // Why this exists: swapContent only re-executes scripts inside the swapped
    // regions (.content / #cbp-page-js). It never touches <head>, so a library
    // loaded via a head <script src> (the extra_head block, e.g. Chart.js) is
    // NOT re-injected on SPA nav. Navigating to a chart page from one that hadn't
    // already loaded the lib left `Chart` undefined → every `new Chart(...)`
    // threw (silently, inside async loaders) and charts only appeared after a
    // full refresh. We add the missing assets and return a Promise that resolves
    // once newly-added SCRIPTS have loaded, so the caller runs page init only
    // after the library is defined. Returns null when nothing was missing — the
    // common case stays fully synchronous (no timing change for non-asset pages).
    function ensureHeadAssets(doc) {
      if (!doc || !doc.head) return null;
      var have = {};
      document.querySelectorAll("script[src]").forEach(function(s){ have[s.src] = 1; });
      document.querySelectorAll('link[rel~="stylesheet"][href]').forEach(function(l){ have[l.href] = 1; });

      var waits = [];
      doc.head.querySelectorAll('script[src], link[rel~="stylesheet"][href]').forEach(function(node){
        var isScript = node.tagName === "SCRIPT";
        var raw = isScript ? node.getAttribute("src") : node.getAttribute("href");
        if (!raw) return;
        var url;
        try { url = new URL(raw, window.location.href).href; } catch(e) { return; }
        // Google Maps API throws "included multiple times" (breaking maps +
        // downstream popups) if its loader runs twice. Its URL varies by
        // ?callback= per page, so the exact-URL dedupe below misses it. If Maps
        // is already loaded, DON'T re-inject — but the API only fires `callback`
        // on first load, so invoke this page's callback directly so its map
        // still initializes on SPA nav.
        if (isScript && url.indexOf("maps.googleapis.com/maps/api/js") !== -1 &&
            window.google && window.google.maps) {
          try {
            var _cb = new URL(url).searchParams.get("callback");
            if (_cb && typeof window[_cb] === "function") setTimeout(window[_cb], 0);
          } catch(e) {}
          return;
        }
        if (have[url]) return;
        have[url] = 1; // guard dupes within the same incoming <head>
        var el = document.createElement(isScript ? "script" : "link");
        for (var i = 0; i < node.attributes.length; i++) {
          el.setAttribute(node.attributes[i].name, node.attributes[i].value);
        }
        if (isScript) {
          el.async = false; // preserve order among newly-added scripts
          waits.push(new Promise(function(res){
            var done = false, fin = function(){ if (!done) { done = true; res(); } };
            el.onload = el.onerror = fin;
            setTimeout(fin, 5000); // never let a stuck asset hang navigation
          }));
        }
        document.head.appendChild(el);
      });
      return waits.length ? Promise.all(waits) : null;
    }

    function swapContent(html, pathname) {
      // Parse the response HTML in a detached document so we can pluck
      // out just the regions we care about without affecting the live page.
      var doc = new DOMParser().parseFromString(html, "text/html");

      var newContent = doc.querySelector(contentSelector);
      var liveContent = document.querySelector(contentSelector);
      if (!newContent || !liveContent) {
        // Page doesn't have our standard layout — fall back to full reload.
        window.location.href = pathname;
        return;
      }

      // Notify outgoing page so it can clean up its own EventSources,
      // WebSockets, etc that aren't covered by the auto-timer cleanup.
      window.dispatchEvent(new CustomEvent("cbp:spa-before-leave", {
        detail: { fromPath: window.location.pathname, toPath: pathname }
      }));
      // Auto-cleanup of tracked timers (setInterval/setTimeout from the
      // outgoing page). Page-level cleanup hooked via cbp:spa-before-leave
      // runs first, so pages can do their own bookkeeping before our
      // sweep clears anything they missed.
      clearPageTimers();
      // Abort in-flight fetches so their .then() handlers don't run
      // against the new (wrong) DOM and throw TypeError on missing
      // elements. AbortError rejections are caught by the
      // unhandledrejection listener above.
      clearPageFetches();

      // Update title
      if (doc.title) document.title = doc.title;

      // Pull in any <head> assets the new page needs (e.g. a chart library in
      // the extra_head block) BEFORE running its scripts — see ensureHeadAssets.
      var headPending = ensureHeadAssets(doc);

      function finishSwap() {
        // Swap page-specific CSS (lives in <style id="cbp-page-css"> in <head>).
        // Without this swap, the old page's CSS lingers and the new page's CSS
        // never loads, producing unstyled garbage.
        var newCss = doc.getElementById("cbp-page-css");
        var liveCss = document.getElementById("cbp-page-css");
        if (newCss && liveCss) liveCss.textContent = newCss.textContent;

        // Swap topbar (#cbp-topbar — sibling of .content inside .main).
        var newTopbar = doc.getElementById("cbp-topbar");
        var liveTopbar = document.getElementById("cbp-topbar");
        if (newTopbar && liveTopbar) liveTopbar.innerHTML = newTopbar.innerHTML;

        // Swap content. Flip __inPageScript so any setInterval/setTimeout
        // calls made by the page's inline scripts get tracked (and cleaned
        // up on next nav). Timers registered by base.html (softphone
        // widget's call timer, etc) bypass this tracking.
        liveContent.innerHTML = newContent.innerHTML;
        __inPageScript = true;
        try {
          runInlineScripts(liveContent);
          // Swap + re-execute page-specific scripts (#cbp-page-js — end of body).
          var newPageJs = doc.getElementById("cbp-page-js");
          var livePageJs = document.getElementById("cbp-page-js");
          if (newPageJs && livePageJs) {
            livePageJs.innerHTML = newPageJs.innerHTML;
            runInlineScripts(livePageJs);
          }
        } finally {
          __inPageScript = false;
        }

        // Update sidebar active state
        setActiveSidebar(pathname);

        // Scroll to top (matches normal nav)
        window.scrollTo(0, 0);

        // Notify any listeners (page-specific code can react to the new context)
        window.dispatchEvent(new CustomEvent("cbp:spa-navigated", { detail: { pathname: pathname } }));
      }

      // Wait for newly-added head scripts (chart libs, etc.) to load so the
      // page's init code finds them defined; otherwise run immediately.
      if (headPending) headPending.then(finishSwap); else finishSwap();
    }

    function navigate(url, push) {
      var pathname = new URL(url, window.location.href).pathname + new URL(url, window.location.href).search;
      // Show a quick top-of-page progress hint so users feel responsiveness
      document.body.style.cursor = "progress";

      fetch(url, { credentials: "same-origin", headers: { "X-Requested-With": "cbp-spa" } })
        .then(function(r){
          if (!r.ok) throw new Error("HTTP " + r.status);
          return r.text();
        })
        .then(function(html){
          if (push) window.history.pushState({ cbpSpa: true }, "", url);
          swapContent(html, new URL(url, window.location.href).pathname);
        })
        .catch(function(err){
          console.warn("[spa] navigation failed, falling back to full reload:", err);
          window.location.href = url;
        })
        .finally(function(){
          document.body.style.cursor = "";
        });
    }

    // Intercept clicks on links matching our criteria
    document.addEventListener("click", function(ev){
      // Modifier keys (cmd/ctrl/shift/middle-click) → let the browser handle normally
      if (ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.altKey || ev.button !== 0) return;
      // If an inline onclick (or earlier listener) already preventDefault'd,
      // they are handling this click themselves — don't SPA-navigate.
      if (ev.defaultPrevented) return;
      var a = ev.target.closest("a");
      if (!a) return;
      if (!isInternalLink(a)) return;
      // Same-path, same-search clicks (e.g. clicking the active sidebar
      // item that points back to the page you're already on) shouldn't
      // refetch — fetching /settings/ from /settings/#company strips
      // the hash, swaps in fresh HTML, and resets in-page state to the
      // default panel (Bug 1d93b421: the Company Info panel "eventually
      // goes back" to the Settings Home Overview after the user clicks
      // the active "Settings" sidebar link). isInternalLink already
      // filters out same-path-with-hash links (those are panel-switchers
      // handled by the page's own onclick); here we additionally drop
      // hashless self-clicks. preventDefault ensures the browser doesn't
      // do its own full-load fallback that would also strip the hash.
      var targetUrl;
      try { targetUrl = new URL(a.href, window.location.href); } catch(e) { return; }
      if (targetUrl.pathname === window.location.pathname &&
          targetUrl.search === window.location.search) {
        ev.preventDefault();
        return;
      }
      ev.preventDefault();
      navigate(a.href, true);
    });

    // Browser back/forward
    window.addEventListener("popstate", function(ev){
      // If a modal is open, close it and stay on the current page. The modal
      // history shim (below) pushes a history entry when any .modal-overlay
      // opens, so this pop lands back on the same URL with no content change.
      if (typeof window.__cbpCloseTopModal === 'function' && window.__cbpCloseTopModal()) return;
      navigate(window.location.href, false);
    });

    console.log("[spa] navigation shim active — softphone state will persist across page nav");
  })();