(function(){
  var CC_CUSTOMER_ID = "21ee8599-bf93-4e96-94a7-e7da182c0ada";
  var CC_BASE = "/api/v1/customers/" + CC_CUSTOMER_ID + "/contacts/";
  var CC_DATA = {};
  var ROLE_LABELS = {owner:"Owner",property_manager:"Property Manager",tenant:"Tenant",on_site_contact:"On-Site Contact",ap:"Accounts Payable",other:"Other"};

  function ccCsrf(){ return (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || ''; }
  function esc(s){ return (s==null?'':String(s)).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  function el(id){ return document.getElementById(id); }

  function ccRender(list){
    CC_DATA = {};
    var content = el("ccContent");
    if(!list || !list.length){
      content.innerHTML = '<div class="cc-empty">No additional contacts yet. Add owners, property managers, tenants, or billing contacts who should receive notifications.</div>';
      return;
    }
    var html = '<div class="cc-list">';
    list.forEach(function(c){
      CC_DATA[c.id] = c;
      var flags = [];
      if(c.receives_invoices) flags.push('Invoices');
      if(c.receives_service_notifications) flags.push('Service');
      if(c.receives_dunning) flags.push('Dunning');
      var flagHtml = flags.length ? ('<div class="cc-flags">' + flags.map(function(f){ return '<span class="cc-flag">'+esc(f)+'</span>'; }).join('') + '</div>') : '';
      var chans = [];
      if(c.via_email) chans.push('Email');
      if(c.via_sms) chans.push('SMS');
      var chanHtml = chans.length ? ('<div class="cc-chan">Sends via ' + chans.join(' + ') + '</div>') : '<div class="cc-chan cc-chan-off">No delivery channel selected</div>';
      var meta = [];
      if(c.email) meta.push(esc(c.email));
      if(c.phone) meta.push(esc(c.phone));
      html += '<div class="cc-card"><div class="cc-card-top"><div>'
        + '<span class="cc-name">'+esc(c.name)+'</span><span class="cc-role">'+esc(ROLE_LABELS[c.role]||c.role)+'</span>'
        + (meta.length?('<div class="cc-meta">'+meta.join(' &middot; ')+'</div>'):'')
        + flagHtml
        + chanHtml
        + '</div><div class="cc-actions">'
        + '<button type="button" onclick="ccOpenForm(\''+c.id+'\')">Edit</button>'
        + '<button type="button" class="danger" onclick="ccDelete(\''+c.id+'\')">Delete</button>'
        + '</div></div></div>';
    });
    html += '</div>';
    content.innerHTML = html;
  }

  function ccLoad(){
    fetch(CC_BASE, {credentials:'same-origin', headers:{'X-CSRFToken':ccCsrf()}})
      .then(function(r){ return r.ok ? r.json() : Promise.reject(r.status); })
      .then(ccRender)
      .catch(function(e){ el("ccContent").innerHTML = '<div class="cc-empty">Could not load contacts.</div>'; });
  }

  window.ccOpenForm = function(id){
    el("ccErr").style.display='none';
    var c = id ? CC_DATA[id] : null;
    el("ccEditId").value = c ? c.id : '';
    el("ccFormTitle").textContent = c ? 'Edit contact' : 'Add contact';
    el("ccName").value = c ? (c.name||'') : '';
    el("ccRole").value = c ? (c.role||'other') : 'other';
    el("ccEmail").value = c ? (c.email||'') : '';
    el("ccPhone").value = c ? (c.phone||'') : '';
    el("ccRecInv").checked = c ? !!c.receives_invoices : false;
    el("ccRecSvc").checked = c ? !!c.receives_service_notifications : false;
    el("ccRecDun").checked = c ? !!c.receives_dunning : false;
    el("ccViaEmail").checked = c ? !!c.via_email : true;
    el("ccViaSms").checked = c ? !!c.via_sms : false;
    el("ccForm").style.display='block';
  };
  window.ccCloseForm = function(){ el("ccForm").style.display='none'; };

  window.ccSave = function(){
    var id = el("ccEditId").value;
    var body = {
      name: el("ccName").value.trim(),
      role: el("ccRole").value,
      email: el("ccEmail").value.trim(),
      phone: el("ccPhone").value.trim(),
      receives_invoices: el("ccRecInv").checked,
      receives_service_notifications: el("ccRecSvc").checked,
      receives_dunning: el("ccRecDun").checked,
      via_email: el("ccViaEmail").checked,
      via_sms: el("ccViaSms").checked
    };
    var errBox = el("ccErr"); errBox.style.display='none';
    if(!body.name){ errBox.textContent='Name is required.'; errBox.style.display='block'; return; }
    if(!body.email && !body.phone){ errBox.textContent='Provide an email or a phone.'; errBox.style.display='block'; return; }
    var url = id ? (CC_BASE + id + '/') : CC_BASE;
    var method = id ? 'PATCH' : 'POST';
    var btn = el("ccSaveBtn"); btn.disabled=true; var orig=btn.textContent; btn.textContent='Saving...';
    fetch(url, {method:method, credentials:'same-origin', headers:{'X-CSRFToken':ccCsrf(),'Content-Type':'application/json'}, body:JSON.stringify(body)})
      .then(function(r){ return r.json().then(function(d){ return {ok:r.ok,d:d}; }).catch(function(){ return {ok:r.ok,d:{}}; }); })
      .then(function(o){
        if(o.ok){ ccCloseForm(); ccLoad(); }
        else {
          var msg = (o.d && (o.d.detail || (o.d.non_field_errors&&o.d.non_field_errors[0]) || o.d.error)) || 'Could not save contact.';
          errBox.textContent = msg; errBox.style.display='block';
        }
      })
      .catch(function(){ errBox.textContent='Network error.'; errBox.style.display='block'; })
      .then(function(){ btn.disabled=false; btn.textContent=orig; });
  };

  window.ccDelete = function(id){
    var c = CC_DATA[id];
    if(!confirm('Delete contact ' + (c?c.name:'') + '?')) return;
    fetch(CC_BASE + id + '/', {method:'DELETE', credentials:'same-origin', headers:{'X-CSRFToken':ccCsrf()}})
      .then(function(r){ if(r.ok){ ccLoad(); } else { alert('Could not delete contact.'); } })
      .catch(function(){ alert('Network error deleting contact.'); });
  };

  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', ccLoad); } else { ccLoad(); }
})();