(function(){
  // The view that renders customer_detail.html passes ``customer_id``
  // (a string UUID). We read it here so the partial does not depend on
  // CD_ID being already-defined when the script runs.
  var PM_CUSTOMER_ID = "2a3f58b6-9724-49b9-9342-91136c780631";
  var PM_DETACH_PROVIDER = null;
  var PM_DETACH_ID = null;

  function pmCsrf(){
    return (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';
  }
  function pmEsc(s){
    if (s === null || s === undefined) return '';
    return String(s).replace(/[&<>"']/g, function(c){
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];
    });
  }
  function pmFmtExp(month, year){
    if (!month || !year) return '';
    var m = String(month).padStart(2,'0');
    return m + '/' + String(year).slice(-2);
  }
  function pmIsExpired(month, year){
    if (!month || !year) return false;
    var now = new Date();
    var y = parseInt(year, 10), m = parseInt(month, 10);
    if (y < now.getFullYear()) return true;
    if (y === now.getFullYear() && m < (now.getMonth() + 1)) return true;
    return false;
  }

  async function pmFetch(path, method, body){
    return fetch(path, {
      method: method || 'GET',
      credentials: 'same-origin',
      headers: {
        'X-CSRFToken': pmCsrf(),
        'Content-Type': 'application/json',
      },
      body: body ? JSON.stringify(body) : null,
    });
  }

  function pmRowHtml(provider, pm){
    var brand, last4, expMonth, expYear;
    if (provider === 'stripe'){
      brand = pm.brand || pm.payment_type || 'card';
      last4 = pm.last4 || '****';
      expMonth = pm.exp_month;
      expYear = pm.exp_year;
    } else {
      brand = pm.card_brand || 'card';
      last4 = pm.last_four || '****';
      expMonth = pm.exp_month;
      expYear = pm.exp_year;
    }
    var exp = pmFmtExp(expMonth, expYear);
    var expCls = pmIsExpired(expMonth, expYear) ? 'cd-pm-bad' : '';
    var label = (brand || '').toUpperCase() + ' ****' + last4;

    var badges = [];
    if (pm.is_default) badges.push('<span class="badge b-green">Default</span>');
    if (!pm.is_active) badges.push('<span class="badge b-gray">Inactive</span>');

    var inUse = (pm.in_use_by_recurring || []).length;
    var actions = '';
    if (pm.is_active){
      if (!pm.is_default){
        actions += '<button type="button" onclick="cdMakePmDefault(\'' + provider + '\', \'' + pm.id + '\')">Make default</button>';
      }
      actions += '<button type="button" class="danger" onclick="cdConfirmDetachPm(\'' + provider + '\', \'' + pm.id + '\', \'' + pmEsc(label).replace(/'/g, "\\'") + '\', ' + inUse + ')">Detach</button>';
    }

    return '<tr>' +
      '<td><strong>' + pmEsc(brand.toUpperCase()) + '</strong> ****' + pmEsc(last4) + '</td>' +
      '<td' + (expCls ? ' class="' + expCls + '"' : '') + '>' + pmEsc(exp || '--') + (expCls ? ' (expired)' : '') + '</td>' +
      '<td>' + badges.join(' ') + '</td>' +
      '<td>' + (inUse > 0 ? '<span class="cd-pm-warn">' + inUse + ' recurring</span>' : '<span style="color:var(--text-light)">--</span>') + '</td>' +
      '<td class="cd-pm-actions">' + actions + '</td>' +
      '</tr>';
  }

  function pmTableHtml(provider, rows){
    if (!rows.length){
      return '';
    }
    var head = '<table class="cd-table"><thead><tr>' +
      '<th>Card</th><th>Expires</th><th>Status</th><th>Recurring use</th><th></th>' +
      '</tr></thead><tbody>';
    var body = rows.map(function(r){ return pmRowHtml(provider, r); }).join('');
    return head + body + '</tbody></table>';
  }

  window.cdLoadPaymentMethods = async function(){
    var box = document.getElementById('cdPmContent');
    box.innerHTML = '<div class="cd-loading"><i class="fas fa-spinner fa-spin"></i> Loading payment methods...</div>';
    try {
      var r = await pmFetch('/api/v1/billing/admin/customers/' + PM_CUSTOMER_ID + '/payment-methods/');
      if (!r.ok){
        box.innerHTML = '<div class="cd-empty">Could not load payment methods (HTTP ' + r.status + ').</div>';
        return;
      }
      var data = await r.json();
      var stripe = data.stripe || [];
      var square = data.square || [];

      var html = '';
      html += '<div style="margin-bottom:14px"><div style="font-size:12px;font-weight:600;color:var(--text-light);margin-bottom:6px">Stripe</div>';
      if (stripe.length){
        html += pmTableHtml('stripe', stripe);
      } else {
        html += '<div class="cd-pm-empty">No Stripe cards on file.</div>';
      }
      html += '</div>';

      html += '<div><div style="font-size:12px;font-weight:600;color:var(--text-light);margin-bottom:6px">Square</div>';
      if (square.length){
        html += pmTableHtml('square', square);
      } else {
        html += '<div class="cd-pm-empty">No Square cards on file.</div>';
      }
      html += '</div>';

      if (!stripe.length && !square.length){
        html = '<div class="cd-pm-empty">No cards on file. Customer can add one via the customer portal at <code>/portal/</code>.</div>';
      }

      box.innerHTML = html;
    } catch (e){
      box.innerHTML = '<div class="cd-empty">Network error loading payment methods.</div>';
    }
  };

  window.cdMakePmDefault = async function(provider, pmId){
    try {
      var r = await pmFetch(
        '/api/v1/billing/admin/customers/' + PM_CUSTOMER_ID +
        '/payment-methods/' + pmId + '/set-default/',
        'POST',
        { provider: provider }
      );
      if (!r.ok){
        var d = await r.json().catch(function(){ return {}; });
        if (typeof toast === 'function') toast(d.error || 'Could not set default', 'error');
        return;
      }
      if (typeof toast === 'function') toast('Default updated');
      cdLoadPaymentMethods();
    } catch (e){
      if (typeof toast === 'function') toast('Network error', 'error');
    }
  };

  window.cdConfirmDetachPm = function(provider, pmId, label, inUseCount){
    PM_DETACH_PROVIDER = provider;
    PM_DETACH_ID = pmId;
    document.getElementById('cdPmDetachLabel').textContent = label || 'this card';
    document.getElementById('cdPmDetachErr').textContent = '';
    var conflict = document.getElementById('cdPmDetachConflict');
    conflict.style.display = 'none';
    conflict.textContent = '';
    var btn = document.getElementById('cdPmDetachBtn');
    btn.disabled = false;
    btn.textContent = 'Detach';
    if (inUseCount && inUseCount > 0){
      conflict.textContent = 'This card is in use by ' + inUseCount + ' active recurring schedule(s). Detach will be refused — pause or reassign those schedules first.';
      conflict.style.display = 'block';
    }
    document.getElementById('cdPmDetachModal').classList.add('open');
  };

  window.cdSubmitDetachPm = async function(){
    if (!PM_DETACH_PROVIDER || !PM_DETACH_ID) return;
    var btn = document.getElementById('cdPmDetachBtn');
    var err = document.getElementById('cdPmDetachErr');
    var conflict = document.getElementById('cdPmDetachConflict');
    err.textContent = '';
    btn.disabled = true; btn.textContent = 'Detaching...';
    try {
      var r = await pmFetch(
        '/api/v1/billing/admin/customers/' + PM_CUSTOMER_ID +
        '/payment-methods/' + PM_DETACH_ID + '/detach/',
        'POST',
        { provider: PM_DETACH_PROVIDER }
      );
      var d = await r.json().catch(function(){ return {}; });
      if (r.status === 409){
        conflict.textContent = (d.error || 'In use by recurring schedules') +
          (d.schedule_ids ? ' — schedules: ' + d.schedule_ids.join(', ') : '');
        conflict.style.display = 'block';
        btn.disabled = false; btn.textContent = 'Detach';
        return;
      }
      if (!r.ok){
        err.textContent = d.error || ('Detach failed (HTTP ' + r.status + ')');
        btn.disabled = false; btn.textContent = 'Detach';
        return;
      }
      document.getElementById('cdPmDetachModal').classList.remove('open');
      if (d.local_only_detach && typeof toast === 'function'){
        toast('Detached locally — Stripe call failed', 'error');
      } else if (typeof toast === 'function'){
        toast('Card detached');
      }
      cdLoadPaymentMethods();
    } catch (e){
      err.textContent = 'Network error.';
      btn.disabled = false; btn.textContent = 'Detach';
    }
  };

  document.addEventListener('DOMContentLoaded', function(){
    cdLoadPaymentMethods();
  });
})();