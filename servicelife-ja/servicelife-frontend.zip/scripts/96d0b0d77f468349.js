(function(){
    if (window.cbpMakeDraggable) return; // idempotent across SPA nav
    /**
     * Make an element draggable via a handle.
     *
     * @param {string} elementId      id of the element to move (uses position:fixed)
     * @param {string} handleSelector CSS selector for the drag handle WITHIN element
     *                                (or '' to use element itself)
     * @param {string} storageKey     localStorage key for persistence
     * @param {object} opts           { onMove(x,y), onEnd(x,y), clickThreshold (px) }
     */
    window.cbpMakeDraggable = function(elementId, handleSelector, storageKey, opts){
      opts = opts || {};
      var threshold = (typeof opts.clickThreshold === 'number') ? opts.clickThreshold : 5;
      var el = document.getElementById(elementId);
      if (!el) return;
      var handle = handleSelector ? el.querySelector(handleSelector) : el;
      if (!handle) return;
      // Mark already-wired so SPA re-runs are idempotent (the element may be
      // the same DOM node across nav if it lives in a persistent base.html block).
      if (handle.dataset.cbpDraggable === '1') return;
      handle.dataset.cbpDraggable = '1';
      handle.style.touchAction = 'none'; // disable browser pan during drag

      // Restore saved position
      try {
        var saved = JSON.parse(localStorage.getItem(storageKey) || 'null');
        if (saved && typeof saved.x === 'number' && typeof saved.y === 'number') {
          applyPos(saved.x, saved.y);
        }
      } catch (_) {}

      function applyPos(x, y){
        // Clamp to viewport so the widget can't be lost off-screen after a
        // viewport resize (e.g. mobile rotation).
        var rect = el.getBoundingClientRect();
        var maxX = Math.max(0, window.innerWidth  - rect.width);
        var maxY = Math.max(0, window.innerHeight - rect.height);
        x = Math.max(0, Math.min(x, maxX));
        y = Math.max(0, Math.min(y, maxY));
        el.style.left   = x + 'px';
        el.style.top    = y + 'px';
        el.style.right  = 'auto';
        el.style.bottom = 'auto';
        if (typeof opts.onMove === 'function') opts.onMove(x, y);
      }

      var dragging = false, moved = false;
      var startX = 0, startY = 0;     // pointer position at mousedown
      var origX = 0, origY = 0;       // element top-left at mousedown

      function onDown(e){
        // Only respond to primary pointer
        if (e.type === 'mousedown' && e.button !== 0) return;
        // Skip if the user clicked an interactive control inside the handle
        // (button, input, a) — those need their own click behavior. The
        // bubble itself is the click target for the AI FAB (no nested
        // controls), so this matters only for the softphone header which
        // has a chevron button.
        var t = e.target;
        // Skip if mousedown is on an interactive child of the handle (e.g.
        // the softphone's chevron-minimize button inside #cbp-sp-header).
        // But NOT if the target IS the handle itself — that's the AI FAB
        // case where the handle is a <button id='aiFabBtn'>; we still want
        // it to drag.
        if (t.closest && t !== handle) {
          var hit = t.closest('button, a, input, select, textarea, .cbp-no-drag');
          if (hit && hit !== handle) return;
        }
        var pt = e.touches ? e.touches[0] : e;
        var rect = el.getBoundingClientRect();
        origX = rect.left;
        origY = rect.top;
        startX = pt.clientX;
        startY = pt.clientY;
        dragging = true;
        moved = false;
        document.addEventListener('mousemove', onMove,  { passive: false });
        document.addEventListener('mouseup',   onUp);
        document.addEventListener('touchmove', onMove,  { passive: false });
        document.addEventListener('touchend',  onUp);
      }
      function onMove(e){
        if (!dragging) return;
        var pt = e.touches ? e.touches[0] : e;
        var dx = pt.clientX - startX;
        var dy = pt.clientY - startY;
        if (!moved && (Math.abs(dx) + Math.abs(dy)) >= threshold) {
          moved = true;
          el.style.transition = 'none';
        }
        if (moved) {
          e.preventDefault();
          applyPos(origX + dx, origY + dy);
        }
      }
      function onUp(){
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup',   onUp);
        document.removeEventListener('touchmove', onMove);
        document.removeEventListener('touchend',  onUp);
        if (moved) {
          // Persist final position. Use rect because applyPos clamps to viewport.
          var rect = el.getBoundingClientRect();
          try {
            localStorage.setItem(storageKey, JSON.stringify({ x: rect.left, y: rect.top }));
          } catch (_) {}
          if (typeof opts.onEnd === 'function') opts.onEnd(rect.left, rect.top);
          // Swallow the synthetic click that follows a mouseup so we don't
          // toggle the widget after a drag. handle's click listeners fire
          // after mouseup unless we suppress them. Use a capture-phase
          // one-shot handler.
          var swallow = function(e){
            e.stopPropagation();
            e.preventDefault();
            handle.removeEventListener('click', swallow, true);
          };
          handle.addEventListener('click', swallow, true);
          // Failsafe: clear after a tick in case no click fires.
          setTimeout(function(){ handle.removeEventListener('click', swallow, true); }, 50);
        }
        dragging = false;
      }
      handle.addEventListener('mousedown',  onDown);
      handle.addEventListener('touchstart', onDown, { passive: true });

      // Re-clamp on window resize so a dragged-to-corner bubble isn't lost
      // when the user resizes the browser smaller.
      window.addEventListener('resize', function(){
        var rect = el.getBoundingClientRect();
        if (rect.left > 0 || rect.top > 0) applyPos(rect.left, rect.top);
      });
    };

    /**
     * cbpEnsureVisible(elementId) — after a widget has been expanded or its
     * contents have changed size, call this to shift it back into the
     * viewport if any edge now overflows. Persists the corrected position
     * to the same storageKey the element was dragged with, so a subsequent
     * reload restores the corrected (visible) location. No-op if the
     * element is already fully on-screen.
     *
     * @param {string} elementId
     * @param {string} [storageKey] — if provided, the corrected position is
     *                               saved here so reload preserves visibility.
     */
    window.cbpEnsureVisible = function(elementId, storageKey){
      var el = document.getElementById(elementId);
      if (!el) return;
      var rect = el.getBoundingClientRect();
      // If element is hidden or zero-sized, do nothing.
      if (rect.width === 0 || rect.height === 0) return;
      var margin = 8;
      var newLeft = rect.left;
      var newTop  = rect.top;
      // If element is wider/taller than viewport, just align to top-left;
      // there's nowhere to fit it. Otherwise, push back into bounds.
      if (rect.width <= window.innerWidth - margin*2) {
        if (newLeft < margin) newLeft = margin;
        else if (newLeft + rect.width > window.innerWidth - margin) {
          newLeft = window.innerWidth - rect.width - margin;
        }
      } else {
        newLeft = margin;
      }
      if (rect.height <= window.innerHeight - margin*2) {
        if (newTop < margin) newTop = margin;
        else if (newTop + rect.height > window.innerHeight - margin) {
          newTop = window.innerHeight - rect.height - margin;
        }
      } else {
        newTop = margin;
      }
      if (newLeft !== rect.left || newTop !== rect.top) {
        el.style.left   = newLeft + 'px';
        el.style.top    = newTop + 'px';
        el.style.right  = 'auto';
        el.style.bottom = 'auto';
        if (storageKey) {
          try {
            localStorage.setItem(storageKey, JSON.stringify({ x: newLeft, y: newTop }));
          } catch (_) {}
        }
      }
    };
  })();