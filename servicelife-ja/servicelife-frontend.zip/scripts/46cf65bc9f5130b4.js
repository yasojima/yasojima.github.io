const API='/api/v1';
let map,markers=[],allTechs=[];

window.initTechMap=function(){
  map=new google.maps.Map(document.getElementById('techMap'),{
    center:{lat:39.95,lng:-75.16},zoom:10,
    mapTypeControl:false,streetViewControl:false,fullscreenControl:true,
    mapId:'DEMO_MAP_ID',
    styles:[{featureType:'poi',stylers:[{visibility:'off'}]},{featureType:'transit',stylers:[{visibility:'off'}]}]
  });
  loadLive();
  setInterval(loadLive,30000);
};

function determineStatus(t){
  if(t.current_job) return {key:'on_job',label:'On Job',cls:'st-on-job',pulse:'orange'};
  // A today job whose start time passed but isn't underway -> Running Late.
  if(t.late_job) return {key:'running_late',label:'Running Late',cls:'st-running-late',pulse:'red'};
  if(t.next_job){
    // En route / on time apply ONLY to today's next job. A job on a later day
    // means the tech isn't working right now, so don't flag En Route/Late for it.
    if(t.next_job.is_today){
      const iso=t.next_job.start_iso;
      if(iso){
        const diffMin=(new Date(iso)-new Date())/60000;
        if(diffMin<45) return {key:'on_route',label:'En Route',cls:'st-on-route',pulse:'green'};
      }
      return {key:'on_time',label:'On Time',cls:'st-on-time',pulse:'green'};
    }
    return t.latitude?{key:'idle',label:'Idle',cls:'st-idle',pulse:'green'}
                     :{key:'off_duty',label:'Off Duty',cls:'st-off-duty',pulse:'gray'};
  }
  if(!t.latitude) return {key:'off_duty',label:'Off Duty',cls:'st-off-duty',pulse:'gray'};
  return {key:'idle',label:'Idle',cls:'st-idle',pulse:'green'};
}

async function loadLive(){
  try{
    const r=await fetch(API+'/scheduling/gps-live/',{credentials:'same-origin'});
    const d=await r.json();
    allTechs=(d.technicians||[]).map(t=>{
      t._status=determineStatus(t);
      return t;
    });
    // KPIs
    const onJob=allTechs.filter(t=>t._status.key==='on_job').length;
    const onRoute=allTechs.filter(t=>['on_route','on_time','running_late'].includes(t._status.key)).length;
    const idle=allTechs.filter(t=>['idle','off_duty'].includes(t._status.key)).length;
    document.getElementById('kActive').textContent=allTechs.length;
    document.getElementById('kOnJob').textContent=onJob;
    document.getElementById('kOnRoute').textContent=onRoute;
    document.getElementById('kIdle').textContent=idle;
    document.getElementById('lastUpdate').textContent=new Date().toLocaleTimeString();
    renderCards();
    renderMap();
  }catch(e){console.error(e)}
}

function renderCards(){
  const filter=document.getElementById('filterStatus').value;
  let techs=allTechs;
  if(filter){
    if(filter==='on_route') techs=techs.filter(t=>['on_route','on_time'].includes(t._status.key));else if(filter==='running_late') techs=techs.filter(t=>t._status.key==='running_late');
    else if(filter==='idle') techs=techs.filter(t=>['idle','off_duty'].includes(t._status.key));
    else techs=techs.filter(t=>t._status.key===filter);
  }
  const list=document.getElementById('techList');
  if(!techs.length){list.innerHTML='<div class="empty-state"><i class="fas fa-satellite-dish"></i><div style="font-weight:600;margin-bottom:4px">No technicians</div></div>';return}
  list.innerHTML=techs.map(t=>{
    const s=t._status;
    const currentInfo=t.current_job?`<div class="job-row"><span class="job-label">${t.current_job.customer}</span><span>${t.current_job.job_type||'Service'}</span></div>`:'';
    const lateInfo=t.late_job?`<div class="job-row"><span class="job-label" style="color:#c62828">Late for: ${t.late_job.customer}</span><span class="eta">${t.late_job.start_time||''}</span></div>`:'';
    const nextInfo=t.next_job?`<div class="job-row"><span>Next: ${t.next_job.customer}</span><span class="eta">${t.next_job.when_label||t.next_job.start_time||''}</span></div>`:'';
    const gps=t.latitude?`<div class="gps-info"><i class="fas fa-satellite"></i> ${parseFloat(t.latitude).toFixed(4)}, ${parseFloat(t.longitude).toFixed(4)} ${t.last_updated?'• '+new Date(t.last_updated).toLocaleTimeString():''}</div>`:'<div class="gps-info"><i class="fas fa-satellite-dish" style="color:#999"></i> No GPS signal</div>';
    return `<div class="tech-card" onclick="focusTech(${t.latitude||0},${t.longitude||0})">
      <div class="tech-card-header">
        <div class="tech-av" style="background:${t.color||'#2196F3'}">${t.initials||'?'}</div>
        <div class="tech-info"><h4>${t.name||'Unknown'}</h4><div class="sub">${t.current_job?t.current_job.customer+(t.current_job.location?' — '+t.current_job.location:''):t.next_job?'Next: '+t.next_job.customer:'No jobs'}</div></div>
        <span class="status-pill ${s.cls}"><span class="pulse pulse-${s.pulse}"></span>${s.label}</span>
      </div>
      <div class="tech-card-body">${currentInfo}${lateInfo}${nextInfo}${gps}</div>
    </div>`;
  }).join('');
}

function focusTech(lat,lng){
  if(map&&lat&&lng){map.panTo({lat:parseFloat(lat),lng:parseFloat(lng)});map.setZoom(15)}
}

function renderMap(){
  if(!map)return;
  markers.forEach(m=>{if(m.setMap)m.setMap(null);else m.map=null;});markers=[];
  const bounds=new google.maps.LatLngBounds();
  let hasPoints=false;
  allTechs.forEach(t=>{
    if(!t.latitude||!t.longitude)return;
    const pos={lat:parseFloat(t.latitude),lng:parseFloat(t.longitude)};
    bounds.extend(pos);hasPoints=true;
    const s=t._status;
    const fillColor=s.key==='on_job'?'#e65100':s.key==='running_late'?'#c62828':s.key==='on_route'||s.key==='on_time'?'#1565c0':s.key==='off_duty'?'#9e9e9e':t.color||'#2196F3';
    const markerTitle=t.name+' — '+s.label;
    const markerZIndex=s.key==='on_job'?10:s.key==='running_late'?9:5;
    const iwContent=`<div style="font-size:13px;line-height:1.6;min-width:220px">
      <strong>${t.name}</strong> <span class="status-pill ${s.cls}" style="font-size:9px">${s.label}</span>
      ${t.current_job?'<br><b>Current:</b> '+t.current_job.customer+(t.current_job.location?' — '+t.current_job.location:''):''}
      ${t.next_job?'<br><b>Next:</b> '+t.next_job.customer+' at '+(t.next_job.when_label||t.next_job.start_time):''}
      ${t.completed_today!==undefined?'<br><span style="color:#666">'+t.completed_today+' jobs done today</span>':''}
    </div>`;
    const iw=new google.maps.InfoWindow({content:iwContent});
    let m;
    {
      const el=document.createElement('div');
      el.style.cssText=`width:32px;height:32px;border-radius:50%;background:${fillColor};border:2px solid #fff;box-shadow:0 1px 3px rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center;color:#fff;font-size:10px;font-weight:700;cursor:pointer;`;
      el.textContent=t.initials||'?';
      m=new google.maps.marker.AdvancedMarkerElement({position:pos,map:map,title:markerTitle,content:el,zIndex:markerZIndex});
    }
    m.addListener('click',()=>iw.open(map,m));
    markers.push(m);
  });
  if(hasPoints){
    if(markers.length===1){map.setCenter(markers[0].position);map.setZoom(13)}
    else map.fitBounds(bounds,{padding:50})
  }
}