let gMap=null,gMarkers=[];
function initGPSMap(){
  if(typeof google==='undefined'||!google.maps)return;
  const el=document.getElementById('gpsMap');
  gMap=new google.maps.Map(el,{
    center:{lat:39.95,lng:-75.16},zoom:10,
    mapTypeControl:false,streetViewControl:false,fullscreenControl:false,
    gestureHandling:'greedy',
    mapId:'DEMO_MAP_ID',
    styles:[{featureType:'poi',stylers:[{visibility:'off'}]},{featureType:'transit',stylers:[{visibility:'off'}]}]
  });
  /* BUG-049: drop shimmer once Maps lib has rendered into the div */
  el.classList.remove('is-loading');
}
function updateGPSMarkers(techs){
  if(!gMap)return;
  gMarkers.forEach(m=>{if(m.setMap)m.setMap(null);else m.map=null;});gMarkers=[];
  const bounds=new google.maps.LatLngBounds();let has=false;
  techs.forEach(t=>{
    if(!t.latitude||!t.longitude)return;has=true;
    const pos={lat:t.latitude,lng:t.longitude};bounds.extend(pos);
    const iwContent='<div style="font-size:13px"><strong>'+t.name+'</strong><br>'+(t.current_job?'On job: '+t.current_job.customer:t.next_job?'Next: '+t.next_job.customer:'Idle')+'</div>';
    const iw=new google.maps.InfoWindow({content:iwContent});
    let m;
    {
      const el=document.createElement('div');
      el.style.cssText=`width:32px;height:32px;border-radius:50%;background:${t.color||'#2196F3'};border:2px solid #fff;box-shadow:0 1px 3px rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center;color:#fff;font-size:10px;font-weight:700;cursor:pointer;`;
      el.textContent=t.initials||t.name[0];
      m=new google.maps.marker.AdvancedMarkerElement({position:pos,map:gMap,title:t.name,content:el});
    }
    m.addListener('click',()=>iw.open(gMap,m));gMarkers.push(m);
  });
  if(has&&gMarkers.length>0){if(gMarkers.length===1){gMap.setCenter(gMarkers[0].position);gMap.setZoom(14);}else gMap.fitBounds(bounds,{padding:40});}
}