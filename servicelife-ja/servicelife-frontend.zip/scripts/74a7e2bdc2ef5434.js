const API='/api/v1',csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const PRI={urgent:'red',high:'orange',medium:'blue',low:'gray'};
const STA={open:'blue',in_progress:'orange',waiting_customer:'yellow',waiting_tech:'yellow',escalated:'red',resolved:'green',closed:'gray'};
let editId=null;
function toast(m,t='success'){const e=document.getElementById('toast');e.textContent=m;e.className='toast '+t;setTimeout(()=>e.className='toast',3000)}
async function apiFetch(u,m='GET',b=null){const o={method:m,credentials:'same-origin',headers:{'X-CSRFToken':csrf(),'Content-Type':'application/json'}};if(b)o.body=JSON.stringify(b);return fetch(API+u,o)}
async function api(u,m='GET',b=null){return(await apiFetch(u,m,b)).json()}
let STAFF_CACHE=null;
async function populateAssignees(selectedId){
  const sel=document.getElementById('fAssign');if(!sel)return;
  if(!STAFF_CACHE){try{STAFF_CACHE=await api('/tickets/assignable-staff/');}catch(e){STAFF_CACHE=[];}}
  sel.innerHTML='<option value="">\u2014 Unassigned \u2014</option>'+(STAFF_CACHE||[]).map(u=>`<option value="${u.id}">${escHTML(u.name)}</option>`).join('');
  sel.value=selectedId||'';
}
function fmtDate(s){return s?new Date(s).toLocaleDateString('en-US',{month:'short',day:'numeric'}):'\u2014'}
async function loadStats(){try{const d=await api('/tickets/stats/');document.getElementById('kOpen').textContent=d.open||0;document.getElementById('kProgress').textContent=d.in_progress||0;document.getElementById('kEscalated').textContent=d.escalated||0;document.getElementById('kResolved').textContent=d.resolved_today||0}catch(e){}}
async function loadData(){
  const tb=document.getElementById('tableBody');
  try{
  loadStats();
  let u='/tickets/tickets/?ordering=-created_at';
  const s=document.getElementById('search').value,st=document.getElementById('fStatus').value,p=document.getElementById('fPriority').value,c=document.getElementById('fCategory').value;
  if(s)u+='&search='+encodeURIComponent(s);if(st)u+='&status='+st;if(p)u+='&priority='+p;if(c)u+='&category='+c;
  const d=await api(u);const items=d.results||d;
  if(!items.length){tb.innerHTML='<tr><td colspan="9"><div class="empty-state"><i class="fas fa-ticket-alt"></i><p>No tickets found</p></div></td></tr>';return}
  tb.innerHTML=items.map(t=>`<tr class="clickable" tabindex="0" role="link" onkeydown="if(event.key==='Enter'||event.key===' '){this.click();event.preventDefault()}" onclick="openEdit('${t.id}')">
    <td><span class="ticket-id">${t.ticket_number||'#'}</span></td>
    <td>${escHTML(t.customer_name||'\u2014')}</td>
    <td style="max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHTML(t.subject)}</td>
    <td><span class="badge badge-gray">${(t.category_display||t.category||'').replace(/_/g,' ')}</span></td>
    <td><span class="badge badge-${PRI[t.priority]||'gray'}">${t.priority}</span></td>
    <td><span class="badge badge-${STA[t.status]||'gray'}">${(t.status_display||t.status||'').replace(/_/g,' ')}</span></td>
    <td>${escHTML(t.assigned_to_name||'\u2014')}</td>
    <td>${fmtDate(t.created_at)}</td>
    <td><button type="button" class="btn-sm" onclick="event.stopPropagation();openEdit('${t.id}')"><i class="fas fa-edit"></i></button></td>
  </tr>`).join('')
  }catch(e){if(e&&e.name==='AbortError')return;tb.innerHTML='<tr><td colspan="9"><div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Could not load tickets.</p></div></td></tr>';}
}
async function searchCust(){const q=document.getElementById('fCustSearch').value;if(q.length<2){document.getElementById('custResults').innerHTML='';return}
  const d=await api('/customers/?search='+encodeURIComponent(q)+'&page_size=5');const items=d.results||d;
  document.getElementById('custResults').innerHTML=items.map(c=>`<div style="padding:6px 8px;cursor:pointer;border-bottom:1px solid var(--border)" onclick="pickCust('${c.id}','${c.first_name} ${c.last_name}')">${escHTML(c.first_name)} ${escHTML(c.last_name)} <span style="color:var(--text-light)">${escHTML(c.phone||'')}</span></div>`).join('')}
function pickCust(id,name){document.getElementById('fCustId').value=id;document.getElementById('fCustSearch').value=name;document.getElementById('custResults').innerHTML=''}
function openNew(){editId=null;document.getElementById('commentsSection').style.display='none';document.getElementById('modalTitle').textContent='New Ticket';['fSubject','fCustSearch','fCustId'].forEach(i=>document.getElementById(i).value='');document.getElementById('fDesc').value='';document.getElementById('fStat').value='open';populateAssignees('');
  // BUG-015: hide Resolved/Closed on create (not valid initial states)
  document.querySelectorAll('#fStat option').forEach(o=>{o.hidden=(o.value==='resolved'||o.value==='closed');});
  document.getElementById('ticketModal').classList.add('open')}
async function openEdit(id){editId=id;history.replaceState(null,'','#edit='+encodeURIComponent(id));const t=await api('/tickets/tickets/'+id+'/');document.getElementById('modalTitle').textContent='Edit Ticket #'+t.ticket_number;document.getElementById('fCustId').value=t.customer;document.getElementById('fCustSearch').value=t.customer_name||'';document.getElementById('fSubject').value=t.subject;document.getElementById('fDesc').value=t.description;document.getElementById('fCat').value=t.category;document.getElementById('fPri').value=t.priority;// BUG-015: restore all status options on edit (existing ticket can be any status)
  document.querySelectorAll('#fStat option').forEach(o=>{o.hidden=false;});
  document.getElementById('fStat').value=t.status;document.getElementById('fChan').value=t.channel||'phone';populateAssignees(t.assigned_to||'');document.getElementById('fCommentBody').value='';document.getElementById('commentsSection').style.display='';renderComments(t.comments||[]);document.getElementById('ticketModal').classList.add('open')}
function closeModal(){document.getElementById('ticketModal').classList.remove('open');document.getElementById('commentsSection').style.display='none';if(window.location.hash.startsWith('#edit='))history.replaceState(null,'',window.location.pathname);}
async function saveTicket(){
  const b={customer:document.getElementById('fCustId').value,subject:document.getElementById('fSubject').value.trim(),description:document.getElementById('fDesc').value.trim(),category:document.getElementById('fCat').value,priority:document.getElementById('fPri').value,status:document.getElementById('fStat').value,channel:document.getElementById('fChan').value,assigned_to:document.getElementById('fAssign').value||null};
  if(!b.customer||!b.subject){toast('Customer and subject required','error');return;}
  const btn=document.getElementById('ticketSaveBtn');
  await cbpSubmit(btn, async () => {
    try{
      const r = editId
        ? await apiFetch('/tickets/tickets/'+editId+'/','PATCH',b)
        : await apiFetch('/tickets/tickets/','POST',b);
      if(r.ok){toast(editId?'Ticket updated':'Ticket created');closeModal();loadData();loadStats();/* BUG-017: re-fetch KPIs after PATCH/POST */}
      else{
        let d={};try{d=await r.json();}catch(_){}
        toast('Error: '+(Object.values(d).flat().join(', ')||('HTTP '+r.status)),'error');
      }
    }catch(e){if(e&&e.name==='AbortError')throw e;toast('Network error — please retry','error');}
  });
}
function renderComments(comments){const el=document.getElementById('commentsThread');if(!comments||!comments.length){el.innerHTML='<div style="color:var(--text-light);font-size:12px;padding:6px 0">No comments yet.</div>';return;}const TYPE_LABEL={reply:'Reply',internal_note:'Internal Note',status_change:'Status Change',escalation:'Escalation'};el.innerHTML=comments.map(c=>{const internal=c.is_internal||c.comment_type==='internal_note';const bg=internal?'#fff8e1':'#f1f8ff';const border=internal?'#ffe082':'#bbdefb';const lbl=TYPE_LABEL[c.comment_type]||(c.comment_type||'Reply');const dt=c.created_at?new Date(c.created_at).toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}):'';return`<div class="comment-bubble" style="background:${bg};border:1px solid ${border}"><div class="cb-meta"><span class="cb-author">${escHTML(c.author_name||'System')}</span><span class="cb-type">${escHTML(lbl)}·${escHTML(dt)}</span></div><div class="cb-body">${escHTML(c.body||'')}</div></div>`;}).join('');el.scrollTop=el.scrollHeight;}
async function submitComment(){const body=document.getElementById('fCommentBody').value.trim();if(!body){toast('Comment body cannot be empty','error');return;}const commentType=document.getElementById('fCommentType').value;const btn=document.getElementById('commentSubmitBtn');await cbpSubmit(btn,async()=>{try{const r=await apiFetch('/tickets/tickets/'+editId+'/add_comment/','POST',{body:body,comment_type:commentType,is_internal:commentType==='internal_note'});if(r.ok){document.getElementById('fCommentBody').value='';const t=await api('/tickets/tickets/'+editId+'/');renderComments(t.comments||[]);toast('Comment added');}else{let d={};try{d=await r.json();}catch(_){}toast('Error: '+(Object.values(d).flat().join(', ')||('HTTP '+r.status)),'error');}}catch(e){if(e&&e.name==='AbortError')throw e;toast('Network error — please retry','error');}});}
document.addEventListener('DOMContentLoaded',loadData);
// Mirror customers.html #edit=UUID deep-link pattern so ticket URLs are shareable/refreshable.
document.addEventListener('DOMContentLoaded',()=>{const hash=window.location.hash||'';let id=null;if(hash.startsWith('#edit='))id=decodeURIComponent(hash.slice('#edit='.length));if(!id)return;setTimeout(()=>{openEdit(id);},50);});