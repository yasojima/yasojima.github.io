const API='/api/v1';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(method)=>{
  const h={'X-CSRFToken':csrf()};
  if(method!=='GET') h['Content-Type']='application/json';
  return h;
};
async function api(url,method='GET',body=null){
  const opts={method,credentials:'same-origin',headers:hdr(method)};
  if(body) opts.body=JSON.stringify(body);
  const r=await fetch(API+url,opts);
  if(r.status===204) return null;
  return r.json();
}
function fmtDate(s){if(!s)return'—';const d=new Date(s);return d.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
function fmtDateTime(s){if(!s)return'—';const d=new Date(s);return d.toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});}
function fmtTime(s){if(!s)return'—';const d=new Date(s);return d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'});}
function statusBadge(s){const m={scheduled:'blue',confirmed:'blue',in_progress:'orange',completed:'green',cancelled:'red',no_show:'gray'};return `<span class="badge badge-${m[s]||'gray'}">${(s||'').replace(/_/g,' ')}</span>`;}
function showModal(id){document.getElementById(id).classList.add('show');}
function hideModal(id){document.getElementById(id).classList.remove('show');}

async function loadData(){
  const d=await api('/scheduling/job-logs/?ordering=-created_at');
  const items=d.results||d;
  const tb=document.getElementById('tableBody');
  if(!items.length){tb.innerHTML='<tr><td colspan="7"><div class="empty-state"><i class="fas fa-file-alt"></i><p>No job logs yet. Logs are created when jobs are completed.</p></div></td></tr>';return;}
  tb.innerHTML=items.map(j=>`<tr><td>${fmtDate(j.created_at)}</td><td>${j.technician_name||'—'}</td><td>${j.customer_name||'—'}</td><td>${j.areas_treated||'—'}</td><td>${j.chemicals_used||'—'}</td><td>${fmtTime(j.started_at)}</td><td>${fmtTime(j.completed_at)}</td></tr>`).join('');
}
document.addEventListener('DOMContentLoaded',loadData);