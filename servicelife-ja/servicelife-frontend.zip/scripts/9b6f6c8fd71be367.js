const API='/api/v1';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(method)=>{
  const h={'X-CSRFToken':csrf()};
  if(method!=='GET') h['Content-Type']='application/json';
  return h;
};
async function api(url,method='GET',body=null){
  const opts={method,credentials:'same-origin',headers:hdr(method)};
  if(body) opts.body=JSON.stringify(body);
  const r=await fetch(API+url,opts);
  if(r.status===204) return null;
  let data=null;
  try{data=await r.json();}catch(e){data={detail:'Server returned '+r.status};}
  if(!r.ok){
    const err=new Error('API '+r.status);
    err.status=r.status;
    err.data=data;
    throw err;
  }
  return data;
}
function showApiError(err, formId){
  const msg = (err && err.data) ? cbpFormatApiError(err.data, 'Please check the form and try again.') : 'Something went wrong. Please check the form and try again.';
  toast(msg, 'error');
  if(formId && err && err.data && typeof err.data==='object'){
    document.querySelectorAll('#'+formId+' .field-error').forEach(el=>el.remove());
    document.querySelectorAll('#'+formId+' .field-invalid').forEach(el=>el.classList.remove('field-invalid'));
    const fieldMap = {
      'service_address':'fAddr','service_city':'fCity','service_state':'fState','service_zip':'fZip',
      'billing_address':'fBillAddr','billing_city':'fBillCity','billing_state':'fBillState','billing_zip':'fBillZip',
      'first_name':'fFirst','last_name':'fLast','phone':'fPhone','email':'fEmail',
      'company_name':'fCompany','customer_type':'fType','property_type':'fPropType','notes':'fNotes'
    };
    Object.entries(err.data).forEach(([k,v])=>{
      const id=fieldMap[k]||k;
      const inp=document.getElementById(id);
      if(inp){
        inp.classList.add('field-invalid');
        const span=document.createElement('div');
        span.className='field-error';
        span.style.cssText='color:#c0392b;font-size:12px;margin-top:2px;';
        span.textContent=Array.isArray(v)?v[0]:String(v);
        inp.parentNode.appendChild(span);
      }
    });
  }
}
function toast(msg, kind){
  let t=document.getElementById('_apiToast');
  if(!t){
    t=document.createElement('div');
    t.id='_apiToast';
    t.style.cssText='position:fixed;top:20px;right:20px;padding:12px 18px;border-radius:6px;color:#fff;font-size:14px;z-index:99999;box-shadow:0 4px 12px rgba(0,0,0,0.2);max-width:400px;display:none;';
    document.body.appendChild(t);
  }
  t.style.background=kind==='error'?'#c0392b':'#27ae60';
  t.textContent=msg;
  t.style.display='block';
  clearTimeout(t._timer);
  t._timer=setTimeout(()=>{t.style.display='none';},5000);
}
function fmtDate(s){if(!s)return'—';const d=new Date(s);return d.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
function fmtDateTime(s){if(!s)return'—';const d=new Date(s);return d.toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});}
function fmtTime(s){if(!s)return'—';const d=new Date(s);return d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'});}
function statusBadge(s){const m={scheduled:'blue',confirmed:'blue',in_progress:'orange',completed:'green',cancelled:'red',no_show:'gray'};return `<span class="badge badge-${m[s]||'gray'}">${(s||'').replace(/_/g,' ')}</span>`;}
const _custModal = { prevFocus: null, keyHandler: null };

function _custModalTrapFocus(e) {
  const root = document.getElementById('modal');
  if (!root || !root.classList.contains('show')) return;
  const focusable = Array.from(root.querySelectorAll(
    'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
  ));
  if (!focusable.length) return;
  const first = focusable[0], last = focusable[focusable.length - 1];
  if (e.shiftKey && document.activeElement === first) {
    e.preventDefault(); last.focus();
  } else if (!e.shiftKey && document.activeElement === last) {
    e.preventDefault(); first.focus();
  }
}

function showModal(id) {
  const el = document.getElementById(id);
  el.classList.add('show');
  _custModal.prevFocus = document.activeElement;
  if (_custModal.keyHandler) document.removeEventListener('keydown', _custModal.keyHandler, true);
  _custModal.keyHandler = function(e) { if (e.key === 'Tab') _custModalTrapFocus(e); };
  document.addEventListener('keydown', _custModal.keyHandler, true);
  setTimeout(() => {
    const first = el.querySelector(
      'input:not([type="hidden"]):not([disabled]), select:not([disabled]), textarea:not([disabled])'
    );
    if (first) first.focus();
  }, 30);
}

function hideModal(id) {
  document.getElementById(id).classList.remove('show');
  if (_custModal.keyHandler) {
    document.removeEventListener('keydown', _custModal.keyHandler, true);
    _custModal.keyHandler = null;
  }
  if (_custModal.prevFocus && _custModal.prevFocus.focus) {
    try { _custModal.prevFocus.focus(); } catch (e) { /* ignore */ }
    _custModal.prevFocus = null;
  }
  // BUG-007 / F-011: clear edit deep-link so refresh doesn't reopen modal.
  // We accept both ?edit= (legacy) and #edit= (current — keeps the UUID out
  // of the URL the browser sends to the server / referer chain).
  // Preserve pagination params (?page, ?page_size) when stripping ?edit=.
  const hasQuery = window.location.search.includes('edit=');
  const hasHash  = window.location.hash.startsWith('#edit=');
  if (hasQuery || hasHash) {
    const params = new URLSearchParams(window.location.search);
    params.delete('edit');
    const qs = params.toString() ? '?' + params.toString() : '';
    history.replaceState(null, '', window.location.pathname + qs);
  }
}

let editId=null;
// BUG-019 (FE half): pagination state + handlers.
// B's pagination is page-numbered with page/page_size query params and
// {count, next, previous, results} response. Default page_size=25.
let _curPage = 1;
let _pageSize = 25;
// Defensive: hasNext/hasPrev mirror the API's d.next/d.previous so goToPage()
// can refuse to walk off either end even when the Next/Prev <button disabled>
// attribute is bypassed (force-click in devtools, automation, double-click
// race against re-render). Pattern matches licenses.html + appointments.html.
let _hasNext = false, _hasPrev = false;
let _sortField = 'created_at';
let _sortDir = 'desc';
// Sync _curPage/_pageSize into the browser URL so refresh/back preserve position.
// Uses pushState on explicit navigation, replaceState on implicit resets (search/filter).
function _syncUrlState(replace){
  const params = new URLSearchParams(window.location.search);
  if (_curPage > 1) params.set('page', _curPage); else params.delete('page');
  if (_pageSize !== 25) params.set('page_size', _pageSize); else params.delete('page_size');
  const isDefaultSort = _sortField === 'created_at' && _sortDir === 'desc';
  if (!isDefaultSort) params.set('sort', (_sortDir === 'desc' ? '-' : '') + _sortField);
  else params.delete('sort');
  const qs = params.toString() ? '?' + params.toString() : '';
  // Preserve #hash fragment (used by #edit= deep-link, unrelated to pagination).
  history[replace ? 'replaceState' : 'pushState'](null, '', window.location.pathname + qs + window.location.hash);
}
function sortBy(field){
  if(_sortField===field){_sortDir=(_sortDir==='asc')?'desc':'asc';}
  else{_sortField=field;_sortDir='asc';}
  _curPage=1;
  _syncUrlState(true);
  document.querySelectorAll('.data-table th.sortable').forEach(th=>{
    th.classList.remove('sort-asc','sort-desc');
    if(th.dataset.sort===_sortField) th.classList.add('sort-'+_sortDir);
  });
  loadData();
}
async function loadData(){
  const ordering=(_sortDir==='desc'?'-':'')+_sortField;
  let url='/customers/?ordering='+ordering+'&page='+_curPage+'&page_size='+_pageSize;
  const s=document.getElementById('search').value;
  const t=document.getElementById('filterType').value;
  if(t) url+='&customer_type='+t;
  if(s) url+='&search='+encodeURIComponent(s);
  let d;
  try { d = await api(url); }
  catch (e) {
    // If we requested a page that no longer exists (e.g. last item on a page
    // was deleted), DRF returns 404. Fall back to page 1 once.
    if (_curPage > 1) { _curPage = 1; _syncUrlState(true); return loadData(); }
    throw e;
  }
  const items=d.results||d;
  const tb=document.getElementById('tableBody');
  if(!items.length){
    tb.innerHTML='<tr><td colspan="6"><div class="empty-state"><i class="fas fa-users"></i><p>No customers found</p></div></td></tr>';
    renderPagination(d);
    return;
  }
  tb.innerHTML=items.map(c=>{
    const name=escHTML(c.customer_type==='commercial'&&c.company_name?c.company_name:`${c.first_name||''} ${c.last_name||''}`.trim());
    const typeBadge=c.customer_type==='commercial'?'<span class="badge badge-purple">Commercial</span>':'<span class="badge badge-blue">Residential</span>';
    return `<tr class="clickable" tabindex="0" role="link" onkeydown="if(event.key==='Enter'||event.key===' '){this.click();event.preventDefault()}" onclick="window.location.href='/customers/${c.id}/'" style="cursor:pointer"><td><a href="/customers/${c.id}/" onclick="event.stopPropagation()" style="color:inherit;text-decoration:none"><strong>${name}</strong>${c.customer_type==='commercial'?'<br><small style="color:var(--text-light)">'+escHTML(((c.first_name||'')+' '+(c.last_name||'')).trim())+'</small>':''}</a></td><td>${typeBadge}</td><td>${custCommsCell(c)}</td><td>${escHTML(c.email)||'—'}</td><td>${escHTML(c.service_address)||'—'}${c.service_city?', '+escHTML(c.service_city):''}</td><td style="white-space:nowrap">${fmtDate(c.created_at)}  <a href="#" onclick="event.stopPropagation();openEdit('${c.id}');return false" title="Quick edit" style="margin-left:8px;color:var(--text-light);text-decoration:none;font-size:12px"><i class="fas fa-pen"></i></a>${c.customer_type==='commercial'?`  <a href="/customers/${c.id}/locations/" onclick="event.stopPropagation()" title="Manage service locations" style="margin-left:6px;color:var(--accent);text-decoration:none;font-size:12px"><i class="fas fa-map-marked-alt"></i> Sites</a>`:''}</td></tr>`;
  }).join('');
  renderPagination(d);
}
function loadDataReset(){ _curPage = 1; _syncUrlState(true); loadData(); }
function goToPage(n){
  // BUG-pagination-spa: inline HTML onclicks can NOT see IIFE-scoped
  // `let _curPage`. The SPA shim wraps page scripts in IIFEs on every
  // nav after the first, so _curPage is invisible to inline handlers —
  // `_curPage+1` evaluates to NaN, the click silently no-ops, and the
  // user has to hard-refresh to bypass the IIFE wrap.
  //
  // Fix: accept string sentinels 'next' / 'prev' (and any numeric value
  // for jump-input). The function resolves _curPage from its own
  // module scope, where it IS visible.
  if (n === 'next') n = _curPage + 1;
  else if (n === 'prev') n = _curPage - 1;
  n = parseInt(n, 10);
  if (!Number.isFinite(n) || n < 1) return;
  // Defensive bounds check: don't advance past the last page (catches a
  // force-click on a Next that should've been disabled). Going BACKWARDS
  // toward an earlier page is always safe — only block forward over-runs.
  if (n > _curPage && !_hasNext) return;
  _curPage = n;
  _syncUrlState(false);
  loadData();
}
function setPageSize(n){
  n = parseInt(n, 10);
  if (!Number.isFinite(n) || n < 1) return;
  _pageSize = n;
  _curPage = 1;
  _syncUrlState(true);
  loadData();
}
function renderPagination(d){
  const el = document.getElementById('pagination');
  if (!el) return;
  // Non-paginated response (raw array) — hide chrome.
  if (!d || typeof d.count !== 'number') { el.style.display = 'none'; _hasNext = _hasPrev = false; return; }
  _hasNext = !!d.next;
  _hasPrev = !!d.previous;
  const total = d.count;
  if (total === 0) { el.style.display = 'none'; return; }
  const totalPages = Math.max(1, Math.ceil(total / _pageSize));
  // Clamp curPage in case page_size changed and curPage is now out of range.
  if (_curPage > totalPages) _curPage = totalPages;
  const from = (_curPage - 1) * _pageSize + 1;
  const to   = Math.min(_curPage * _pageSize, total);
  const prevDisabled = !d.previous ? 'disabled' : '';
  const nextDisabled = !d.next ? 'disabled' : '';
  el.style.display = 'flex';
  el.innerHTML =
    '<button type="button" '+prevDisabled+' onclick="goToPage(\'prev\')" title="Previous page"><i class="fas fa-chevron-left"></i> Prev</button>'
    + '<span class="pg-label">Page</span>'
    + '<input class="pg-jump" id="pgJump" type="number" min="1" max="'+totalPages+'" value="'+_curPage+'" '
    +   'onkeydown="if(event.key===\'Enter\'){event.preventDefault();goToPage(this.value);}" '
    +   'data-cur="'+_curPage+'" '
    +   'onblur="if(parseInt(this.value,10)!==parseInt(this.dataset.cur,10))goToPage(this.value);">'
    + '<span class="pg-label">of '+totalPages+'</span>'
    + '<button type="button" '+nextDisabled+' onclick="goToPage(\'next\')" title="Next page">Next <i class="fas fa-chevron-right"></i></button>'
    + '<span class="pg-label" style="margin-left:12px">Per page</span>'
    + '<select onchange="setPageSize(this.value)">'
    +   ['10','25','50','100'].map(n => '<option value="'+n+'"'+(parseInt(n,10)===_pageSize?' selected':'')+'>'+n+'</option>').join('')
    + '</select>'
    + '<span class="summary">Showing '+from+'–'+to+' of '+total+'</span>';
}
function openNew(){editId=null;document.getElementById('modalTitle').textContent='New Customer';['fFirst','fLast','fPhone','fEmail','fAddr','fAddr2','fCity','fZip','fNotes','fCompany','fBillAddr','fBillAddr2','fBillCity','fBillState','fBillZip','fLeadDetail'].forEach(id=>document.getElementById(id).value='');document.getElementById('fLeadSource').value='';document.getElementById('fDoNotCall').checked=false;document.getElementById('fDoNotEmail').checked=false;document.getElementById('fSmsOptOut').checked=false;document.getElementById('fTaxExempt').checked=false;document.getElementById('fType').value='residential';document.getElementById('fState').value='PA';document.getElementById('fBillState').value='PA';document.getElementById('fBillDiff').checked=false;document.getElementById('fBillingSection').style.display='none';document.getElementById('btnManageLocs').style.display='none';onTypeChange();showModal('modal');}
async function openEdit(id){editId=id;const c=await api('/customers/'+id+'/');document.getElementById('modalTitle').textContent='Edit Customer';document.getElementById('fType').value=c.customer_type||'residential';onTypeChange();if(c.property_type)document.getElementById('fPropType').value=c.property_type;document.getElementById('fCompany').value=c.company_name||'';document.getElementById('fFirst').value=c.first_name||'';document.getElementById('fLast').value=c.last_name||'';document.getElementById('fPhone').value=c.phone||'';document.getElementById('fEmail').value=c.email||'';document.getElementById('fAddr').value=c.service_address||'';document.getElementById('fAddr2').value=c.service_address_2||'';document.getElementById('fCity').value=c.service_city||'';document.getElementById('fState').value=c.service_state||'PA';document.getElementById('fZip').value=c.service_zip||'';document.getElementById('fNotes').value=c.notes||'';document.getElementById('fBillAddr').value=c.billing_address||'';document.getElementById('fBillAddr2').value=c.billing_address_2||'';document.getElementById('fBillCity').value=c.billing_city||'';document.getElementById('fBillState').value=c.billing_state||'PA';document.getElementById('fBillZip').value=c.billing_zip||'';const hasBilling=c.billing_same_as_service===false;document.getElementById('fBillDiff').checked=hasBilling;document.getElementById('fBillingSection').style.display=hasBilling?'block':'none';document.getElementById('btnManageLocs').style.display=c.customer_type==='commercial'?'inline-flex':'none';document.getElementById('fLeadSource').value=c.lead_source||'';document.getElementById('fLeadDetail').value=c.lead_source_detail||'';document.getElementById('fDoNotCall').checked=!!c.do_not_call;document.getElementById('fDoNotEmail').checked=!!c.do_not_email;document.getElementById('fSmsOptOut').checked=!!c.sms_opted_out;document.getElementById('fTaxExempt').checked=!!c.tax_exempt;showModal('modal');}
async function save(){
  // Client-side validation runs first so a bad form never even tries to hit
  // the API. cbpSubmit only wraps the network round-trip below.
  const ct=document.getElementById('fType').value;
  const cn=document.getElementById('fCompany').value.trim();
  if(ct==='commercial'&&!cn){toast('Company Name is required for commercial customers','error');return}
  const body={customer_type:ct,company_name:cn,property_type:document.getElementById('fPropType').value,first_name:document.getElementById('fFirst').value,last_name:document.getElementById('fLast').value,phone:document.getElementById('fPhone').value,email:document.getElementById('fEmail').value,service_address:document.getElementById('fAddr').value,service_address_2:document.getElementById('fAddr2').value,service_city:document.getElementById('fCity').value,service_state:document.getElementById('fState').value,service_zip:document.getElementById('fZip').value,notes:document.getElementById('fNotes').value,lead_source:document.getElementById('fLeadSource').value,lead_source_detail:document.getElementById('fLeadDetail').value,do_not_call:document.getElementById('fDoNotCall').checked,do_not_email:document.getElementById('fDoNotEmail').checked,sms_opted_out:document.getElementById('fSmsOptOut').checked,tax_exempt:document.getElementById('fTaxExempt').checked};
  const billDiff=document.getElementById('fBillDiff').checked;
  body.billing_same_as_service=!billDiff;
  if(billDiff){body.billing_address=document.getElementById('fBillAddr').value;body.billing_address_2=document.getElementById('fBillAddr2').value;body.billing_city=document.getElementById('fBillCity').value;body.billing_state=document.getElementById('fBillState').value;body.billing_zip=document.getElementById('fBillZip').value;}else{body.billing_address='';body.billing_address_2='';body.billing_city='';body.billing_state='';body.billing_zip='';}
  // cbpSubmit: disables button + spinner, dedupes double-clicks, swallows
  // AbortError on SPA nav, re-throws other errors so showApiError still runs.
  await cbpSubmit(document.getElementById('customerSaveBtn'), async () => {
    try{
      if(editId) await api('/customers/'+editId+'/','PATCH',body);
      else await api('/customers/','POST',body);
      hideModal('modal');
      toast(editId?'Customer updated':'Customer created','ok');
      if (!editId) _curPage = 1;
      loadData();
    }catch(err){
      showApiError(err, 'modal');
    }
  });
}

const PROP_TYPES_RESIDENTIAL=[['house','House'],['apartment','Apartment']];
const PROP_TYPES_COMMERCIAL=[['multifamily','Multifamily'],['retail','Retail'],['office','Office'],['industrial','Industrial'],['restaurant','Restaurant'],['hospitality','Hospitality'],['land','Land']];
function onTypeChange(){
  const t=document.getElementById('fType').value;
  const row=document.getElementById('fCompanyRow');
  row.style.display=(t==='commercial')?'grid':'none';
  document.getElementById('fCompany').required=(t==='commercial');
  const sel=document.getElementById('fPropType');
  const prev=sel.value;
  const list=(t==='commercial')?PROP_TYPES_COMMERCIAL:PROP_TYPES_RESIDENTIAL;
  sel.innerHTML=list.map(([v,l])=>`<option value="${v}">${l}</option>`).join('');
  if(list.some(([v])=>v===prev)) sel.value=prev;
  else sel.value=(t==='commercial')?'office':'house';
  if(!editId) fetchBillingPolicyPreview(t);
}
let _previewTimer=null;
async function fetchBillingPolicyPreview(customerType){
  clearTimeout(_previewTimer);
  _previewTimer=setTimeout(async()=>{
    const el=document.getElementById('billingPolicyPreview');
    const txt=document.getElementById('billingPolicyPreviewText');
    if(!el||!txt) return;
    try{
      const r=await fetch(`${API}/billing/policies/preview/?customer_type=${encodeURIComponent(customerType)}`,{credentials:'same-origin'});
      if(!r.ok){el.style.display='none';return;}
      const d=await r.json();
      if(d.policy_code){
        const src={'tenant_default':'tenant default','customer_type':'type default','parent_account':'parent account'}[d.source]||d.source||'';
        txt.textContent=`Billing policy: ${d.display_name||d.policy_code}${src?' ('+src+')':''}`;
        el.style.display='block';
      } else {
        el.style.display='none';
      }
    }catch(e){el.style.display='none';}
  },200);
}

function toggleBilling(){
  const on=document.getElementById('fBillDiff').checked;
  document.getElementById('fBillingSection').style.display=on?'block':'none';
}
function goToLocations(){if(editId)window.location='/customers/'+editId+'/locations/'}

// ===== Item 2b: click-to-call + click-to-SMS from the customer list =====
(function _custCommsInit(){
  var css = ".cust-acts{display:inline-flex;gap:6px;margin-left:8px;vertical-align:middle}"
    + ".cust-act{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:5px;color:#0d47a1;background:#e8f0fe;text-decoration:none;font-size:11px}"
    + ".cust-act:hover{background:#d2e3fc}"
    + ".cust-act-busy{opacity:.5;pointer-events:none}"
    + ".cust-act-off{color:#c0c0c0;background:#f3f3f3;cursor:default}"
    + ".cs-foot{display:flex;justify-content:flex-end;gap:8px;margin-top:14px}";
  var st=document.createElement("style"); st.textContent=css; document.head.appendChild(st);
  var html = '<div class="modal-overlay" id="csModal" role="dialog" aria-modal="true" aria-labelledby="csTitle">'
    + '<div class="modal" style="max-width:440px">'
    + '<div class="modal-header"><h3 id="csTitle"><i class="fas fa-comment"></i> Text customer</h3>'
    + '<button type="button" class="modal-close" id="csClose">&times;</button></div>'
    + '<div class="modal-body">'
    + '<div id="csName" style="font-size:13px;color:var(--text-light);margin-bottom:10px"></div>'
    + '<label style="display:block;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.3px;color:var(--text-light);margin-bottom:5px">Message</label>'
    + '<textarea id="csBody" rows="4" style="width:100%;box-sizing:border-box;padding:9px 11px;border:1.5px solid var(--border);border-radius:7px;font-size:14px;font-family:inherit" placeholder="Type your message..."></textarea>'
    + '<div class="cs-foot"><button type="button" class="btn btn-outline" id="csCancel">Cancel</button>'
    + '<button type="button" class="btn btn-primary" id="csSend"><i class="fas fa-paper-plane"></i> Send</button></div>'
    + '</div></div></div>';
  document.body.insertAdjacentHTML("beforeend", html);
  document.getElementById("csClose").addEventListener("click", function(){ hideModal("csModal"); });
  document.getElementById("csCancel").addEventListener("click", function(){ hideModal("csModal"); });
  document.getElementById("csSend").addEventListener("click", custSmsSend);
})();

function custCommsCell(c){
  var ph=(c.phone||"").trim();
  if(!ph) return "&mdash;";
  var safe=escHTML(ph);
  var icons="";
  if(c.do_not_call){
    icons += '<span class="cust-act cust-act-off" title="Do-not-call is set for this customer"><i class="fas fa-phone-slash"></i></span>';
  } else {
    icons += '<a href="#" class="cust-act" title="Call this customer" data-id="'+escHTML(c.id)+'" data-phone="'+safe+'" onclick="event.stopPropagation();custCall(this);return false"><i class="fas fa-phone-alt"></i></a>';
  }
  if(c.sms_opted_out){
    icons += '<span class="cust-act cust-act-off" title="Customer opted out of texts"><i class="fas fa-comment-slash"></i></span>';
  } else {
    icons += '<a href="#" class="cust-act" title="Text this customer" data-id="'+escHTML(c.id)+'" data-phone="'+safe+'" onclick="event.stopPropagation();custSms(this);return false"><i class="fas fa-comment"></i></a>';
  }
  return safe+'<span class="cust-acts">'+icons+'</span>';
}

async function custCall(el){
  var id=el.dataset.id||""; var phone=el.dataset.phone||"";
  if(!phone) return;
  el.classList.add("cust-act-busy");
  try{
    await api("/communications/phone/click-to-call/","POST",{to_number:phone, customer_id:id||null});
    toast("Calling... your desk phone should ring shortly.","success");
  }catch(e){
    var d=(e&&e.data)?(e.data.message||e.data.detail||e.data.error||""):"";
    toast("Call could not be placed"+(d?": "+d:""),"error");
  }finally{
    setTimeout(function(){ el.classList.remove("cust-act-busy"); },1500);
  }
}

function custSms(el){
  var modal=document.getElementById("csModal");
  modal.dataset.id = el.dataset.id||"";
  modal.dataset.phone = el.dataset.phone||"";
  document.getElementById("csName").textContent = "To " + (el.dataset.phone||"");
  document.getElementById("csBody").value="";
  showModal("csModal");
  setTimeout(function(){ var b=document.getElementById("csBody"); if(b) b.focus(); },40);
}

async function custSmsSend(){
  var modal=document.getElementById("csModal");
  var id=modal.dataset.id||""; var phone=modal.dataset.phone||"";
  var body=(document.getElementById("csBody").value||"").trim();
  if(!body){ toast("Enter a message","error"); return; }
  var btn=document.getElementById("csSend"); var orig=btn.innerHTML;
  btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> Sending...';
  try{
    await api("/communications/inbox/start/","POST",{customer_id:id||null, phone:phone, body:body});
    hideModal("csModal");
    toast("Message sent","success");
  }catch(e){
    var d=(e&&e.data)?(e.data.message||e.data.detail||e.data.error||""):"";
    toast("Could not send"+(d?": "+d:""),"error");
  }finally{
    btn.disabled=false; btn.innerHTML=orig;
  }
}
document.addEventListener('DOMContentLoaded',()=>{
  // Restore page/page_size/sort from URL so refresh and shared links preserve position.
  const params = new URLSearchParams(window.location.search);
  const p = parseInt(params.get('page'), 10);
  const ps = parseInt(params.get('page_size'), 10);
  if (p > 0) _curPage = p;
  if (ps > 0) _pageSize = ps;
  const sortParam = params.get('sort');
  if (sortParam) {
    _sortField = sortParam.startsWith('-') ? sortParam.slice(1) : sortParam;
    _sortDir = sortParam.startsWith('-') ? 'desc' : 'asc';
    document.querySelectorAll('.data-table th.sortable').forEach(th => {
      th.classList.remove('sort-asc', 'sort-desc');
      if (th.dataset.sort === _sortField) th.classList.add('sort-' + _sortDir);
    });
  }
  // Rewrite URL if params existed but were invalid (e.g. ?page=abc, ?page=-1).
  if ((params.has('page') && !(p > 0)) || (params.has('page_size') && !(ps > 0))) {
    _syncUrlState(true);
  }
  loadData();
});
// Handle browser back/forward — restore state from the URL the browser restores.
window.addEventListener('popstate', ()=>{
  const params = new URLSearchParams(window.location.search);
  const p = parseInt(params.get('page'), 10);
  const ps = parseInt(params.get('page_size'), 10);
  _curPage = p > 0 ? p : 1;
  _pageSize = ps > 0 ? ps : 25;
  const sortParam = params.get('sort');
  if (sortParam) {
    _sortField = sortParam.startsWith('-') ? sortParam.slice(1) : sortParam;
    _sortDir = sortParam.startsWith('-') ? 'desc' : 'asc';
  } else {
    _sortField = 'created_at';
    _sortDir = 'desc';
  }
  document.querySelectorAll('.data-table th.sortable').forEach(th => {
    th.classList.remove('sort-asc', 'sort-desc');
    if (th.dataset.sort === _sortField) th.classList.add('sort-' + _sortDir);
  });
  loadData();
});
// BUG-012 / F-011: support deep-link from customer-detail Edit pencil.
// Preferred form is /customers/#edit=<id>; the fragment is never sent in the
// HTTP request URL or the Referer header, so the customer UUID stays
// client-side. We still accept ?edit=<id> for backward compatibility with
// any cached/bookmarked links.
document.addEventListener('DOMContentLoaded', () => {
  let editId = null;
  const hash = window.location.hash || '';
  if (hash.startsWith('#edit=')) {
    editId = decodeURIComponent(hash.slice('#edit='.length));
  } else {
    editId = new URLSearchParams(window.location.search).get('edit');
  }
  if (!editId) return;
  // Wait for loadData() to settle so the table is populated; the modal
  // doesn't depend on the table but openEdit re-fetches anyway, so we just
  // need a small delay to keep visual order sensible.
  setTimeout(() => { openEdit(editId); }, 50);
});
// Wire stale-validation cleanup on the customer modal once at load.
document.addEventListener('DOMContentLoaded',()=>{ if(window.cbpAttachClearOnInput) cbpAttachClearOnInput(document.getElementById('modal')); });
// Address autocomplete fills street / unit / city / state / ZIP separately
// (City + ZIP are required server-side — core/address_rules.py).
function gmAC(id,f){const el=document.getElementById(id);if(!el)return;if(typeof google==='undefined'||!google.maps||!google.maps.importLibrary)return;
  google.maps.importLibrary('places').then(({Autocomplete})=>{
    const ac=new Autocomplete(el,{componentRestrictions:{country:'us'},fields:['address_components','formatted_address'],types:['address']});
    ac.addListener('place_changed',()=>{const p=ac.getPlace();if(!p)return;
      if(!p.address_components){if(p.formatted_address)el.value=p.formatted_address;return}
      const c={};for(const a of p.address_components)for(const t of (a.types||[]))c[t]={l:a.long_name,s:a.short_name};
      const line1=(((c.street_number||{}).l||'')+' '+((c.route||{}).l||'')).trim();
      const city=(c.locality||c.sublocality||c.postal_town||c.administrative_area_level_3||{}).l||'';
      const set=(fid,v)=>{const e=fid&&document.getElementById(fid);if(e&&v){e.value=v;try{e.dispatchEvent(new Event('input',{bubbles:true}))}catch(x){}}};
      el.value=line1||p.formatted_address||el.value;
      set(f.unit,(c.subpremise||{}).l);set(f.city,city);set(f.state,(c.administrative_area_level_1||{}).s);set(f.zip,(c.postal_code||{}).l);
    });
  });}
setTimeout(()=>{gmAC('fAddr',{unit:'fAddr2',city:'fCity',state:'fState',zip:'fZip'});gmAC('fBillAddr',{unit:'fBillAddr2',city:'fBillCity',state:'fBillState',zip:'fBillZip'})},1000);