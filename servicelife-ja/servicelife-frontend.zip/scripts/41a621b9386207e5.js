const API='/api/v1/contest';
function csrf(){const m=document.cookie.match(/csrftoken=([^;]+)/);return m?m[1]:'';}
function esc(s){return (s==null?'':String(s)).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function api(path,opts){
  const o=Object.assign({credentials:'same-origin',headers:{'X-CSRFToken':csrf(),'Content-Type':'application/json'}},opts||{});
  const r=await fetch(API+path,o);
  if(!r.ok){let d={};try{d=await r.json()}catch(e){} throw new Error(d.error||('HTTP '+r.status));}
  if(r.status===204)return null; return r.json();
}
function toast(msg,err){const t=document.getElementById('toast');t.textContent=msg;t.className='toast show'+(err?' err':'');setTimeout(()=>t.className='toast',2600);}
function initials(n){return (n||'?').split(' ').map(x=>x[0]).slice(0,2).join('').toUpperCase();}
function fmtDate(s){if(!s)return '';const d=new Date(s+(s.length<=10?'T00:00:00':''));return d.toLocaleDateString('en-US',{month:'short',day:'numeric'});}

let STATE={rules:[],standings:[],contest:null,weeks:[],week:''};

async function load(){
  let data;
  try{ data=await api('/standings/'+(STATE.week?('?week='+STATE.week):'')); }
  catch(e){ document.getElementById('standingsContent').innerHTML='<div class="empty-state"><i class="fas fa-triangle-exclamation"></i><br>'+esc(e.message)+'</div>'; return; }
  STATE.rules=data.rules||[]; STATE.standings=data.standings||[]; STATE.contest=data.contest; STATE.weeks=data.weeks||[];
  renderHeader(); renderWeekSel(); renderTable(); renderRules(); renderTechOptions(); renderMpRules();
  loadReviews();
}

function timeAgo(iso){if(!iso)return '';const s=Math.max(1,Math.floor((Date.now()-new Date(iso).getTime())/1000));if(s<60)return 'just now';const m=Math.floor(s/60);if(m<60)return m+'m ago';const h=Math.floor(m/60);if(h<24)return h+'h ago';return Math.floor(h/24)+'d ago';}

async function loadReviews(){
  const el=document.getElementById('reviewQueue');
  let d;
  try{ d=await api('/reviews/?status=needs_review'); }
  catch(e){ el.innerHTML='<div class="muted">Could not load reviews.</div>'; return; }
  STATE.reviewTechs=d.technicians||[];
  const items=d.reviews||[];
  if(!items.length){ el.innerHTML='<div class="muted" style="padding:8px 0">No 5-star reviews awaiting confirmation. 🎉</div>'; return; }
  const techOpts=(sel)=>'<option value="">— pick technician —</option>'+STATE.reviewTechs.map(t=>`<option value="${t.id}" ${t.id===sel?'selected':''}>${esc(t.name)}</option>`).join('');
  el.innerHTML=items.map(r=>`
    <div class="rq-item" id="rq-${r.id}">
      <div class="rq-top">
        <span class="rq-name">${esc(r.reviewer||'Anonymous')}</span>
        <span class="rq-stars">★★★★★</span>
        <span class="rq-meta">${esc((r.source||'').toUpperCase())}${r.customer?` · matched: ${esc(r.customer)} (${r.customer_confidence})`:''}</span>
        <span class="rq-when">${esc(timeAgo(r.submitted_at))}</span>
      </div>
      ${r.text?`<div class="rq-text">${esc(r.text)}</div>`:''}
      <div class="rq-actions">
        <select id="rqtech-${r.id}">${techOpts(r.suggested_technician_id)}</select>
        ${r.suggested_technician?`<span class="rq-meta">suggested: ${esc(r.suggested_technician)} (${esc(r.technician_source)})</span>`:''}
        <button class="btn btn-primary btn-sm" onclick="confirmReview('${r.id}')"><i class="fas fa-check"></i> Confirm +100</button>
        <button class="btn btn-light btn-sm" onclick="dismissReview('${r.id}')">Dismiss</button>
      </div>
    </div>`).join('');
}

async function confirmReview(id){
  const tech=document.getElementById('rqtech-'+id).value;
  if(!tech){toast('Pick a technician to credit.',true);return;}
  try{ const r=await api('/reviews/',{method:'POST',body:JSON.stringify({id,action:'confirm',technician_id:tech})});
    toast(`Awarded ${r.points} to ${r.technician}.`); await load(); }
  catch(e){ toast(e.message,true); }
}
async function dismissReview(id){
  if(!confirm('Dismiss this review (no points)?'))return;
  try{ await api('/reviews/',{method:'POST',body:JSON.stringify({id,action:'dismiss'})}); toast('Dismissed.'); await loadReviews(); }
  catch(e){ toast(e.message,true); }
}

function renderHeader(){
  const c=STATE.contest;
  if(!c){document.getElementById('ctSub').textContent='No active contest.';return;}
  document.getElementById('ctName').textContent=c.name;
  const lr=c.last_recomputed_at?('Last recomputed '+new Date(c.last_recomputed_at).toLocaleString()):'Not yet recomputed';
  document.getElementById('ctSub').textContent=
    fmtDate(c.starts_at.slice(0,10))+' – '+fmtDate(c.ends_at.slice(0,10))+
    ' · weekly bonus needs ≥'+c.weekly_min_days_worked+' days worked · '+lr;
}

function renderWeekSel(){
  const sel=document.getElementById('weekSel');
  sel.innerHTML='<option value="">All weeks</option>'+STATE.weeks.map(w=>
    `<option value="${w}" ${w===STATE.week?'selected':''}>Week of ${esc(fmtDate(w))}</option>`).join('');
}

function renderTable(){
  const el=document.getElementById('standingsContent');
  if(!STATE.standings.length){el.innerHTML='<div class="empty-state"><i class="fas fa-trophy"></i><br>No points recorded yet. Click “Recompute now”.</div>';return;}
  const cols=STATE.rules.slice().sort((a,b)=>a.sort_order-b.sort_order);
  let h='<div class="table-container"><table class="ct-table"><thead><tr>';
  h+='<th class="num">#</th><th>Technician</th><th class="num">Total</th>';
  cols.forEach(r=>{h+=`<th class="num" title="${esc(r.label)} (${r.points}${r.unit==='per_dollar'?'/$':''})">${esc(shortLabel(r.code))}</th>`;});
  h+='</tr></thead><tbody>';
  STATE.standings.forEach((t,i)=>{
    h+=`<tr onclick="openEv('${t.technician_id}','${esc(t.name)}')">`;
    h+=`<td class="num rank rank-${i+1}">${i+1}</td>`;
    h+=`<td><div class="tech-cell"><div class="tech-avatar" style="background:${esc(t.color)}">${esc(initials(t.name))}</div>${esc(t.name)}</div></td>`;
    h+=`<td class="num total-pts">${t.total}</td>`;
    cols.forEach(r=>{const v=t.by_rule[r.code]||0;h+=`<td class="num ${v?'':'muted'}">${v||'·'}</td>`;});
    h+='</tr>';
  });
  h+='</tbody></table></div>';
  el.innerHTML=h;
}

function shortLabel(code){return ({done:'Done',ontime:'On-Time',payment:'Pay',nps10:'NPS10',upsell:'Upsell$',dur30:'Dur>30',durwin:'DurWin',review5star:'Reviews',allsubmitted:'Submit'})[code]||code;}

function renderRules(){
  const el=document.getElementById('rulesEditor');
  el.innerHTML=STATE.rules.slice().sort((a,b)=>a.sort_order-b.sort_order).map(r=>
    `<div class="rule-row">
       <div class="rule-label">${esc(r.label)}<span class="tag">${r.is_manual?'manual':'auto'} · ${r.unit==='per_dollar'?'per $':r.unit==='per_week'?'per week':'per event'}</span></div>
       <div class="rule-pts">
         <input type="number" id="rp_${r.code}" value="${r.points}">
         <button class="btn btn-light btn-sm" onclick="saveRule('${r.code}')">Save</button>
       </div>
     </div>`).join('');
}

function renderTechOptions(){
  const sel=document.getElementById('mpTech');
  const cur=sel.value;
  // technicians come from current standings; if empty, leave the prompt only
  const opts=STATE.standings.map(t=>`<option value="${t.technician_id}">${esc(t.name)}</option>`).join('');
  sel.innerHTML='<option value="">Select technician…</option>'+opts;
  if(cur)sel.value=cur;
}

function unitTag(u){return u==='per_dollar'?'per $':u==='per_week'?'per week':'per event';}

function renderMpRules(){
  const sel=document.getElementById('mpRule');
  const cur=sel.value;
  const rules=STATE.rules.slice().sort((a,b)=>a.sort_order-b.sort_order);
  sel.innerHTML=rules.map(r=>
    `<option value="${r.code}">${esc(r.label)} (+${r.points}, ${esc(unitTag(r.unit))})</option>`).join('');
  if(cur&&rules.some(r=>r.code===cur))sel.value=cur;
  syncMpRule();
}

function syncMpRule(){
  const code=document.getElementById('mpRule').value;
  const r=STATE.rules.find(x=>x.code===code);
  const pts=document.getElementById('mpPoints');
  const dateEl=document.getElementById('mpDate');
  const hint=document.getElementById('mpHint');
  if(!r){hint.textContent='';return;}
  // Default the points field to the rule value (operator can override).
  pts.value=r.points;
  const weekly=r.unit==='per_week';
  dateEl.title=weekly?'Any day in the target week (required)':'Date of the event (optional)';
  hint.textContent=weekly
    ? 'Weekly award — pick any day in the target week. One per tech per week (re-submitting updates it).'
    : 'Stacking award — each submission adds a separate event. Date is optional.';
}

async function saveRule(code){
  const pts=parseInt(document.getElementById('rp_'+code).value,10);
  try{ await api('/rules/',{method:'PATCH',body:JSON.stringify({code,points:pts})}); toast('Saved “'+code+'” = '+pts+'. Recompute to apply.'); }
  catch(e){ toast(e.message,true); }
}

document.getElementById('recomputeBtn').addEventListener('click',async function(){
  const b=this; b.disabled=true; const old=b.innerHTML; b.innerHTML='<i class="fas fa-spinner fa-spin"></i> Recomputing…';
  try{ const r=await api('/recompute/',{method:'POST'}); toast('Recomputed: '+r.events+' events.'); await load(); }
  catch(e){ toast(e.message,true); }
  finally{ b.disabled=false; b.innerHTML=old; }
});

document.getElementById('weekSel').addEventListener('change',function(){STATE.week=this.value;load();});
document.getElementById('mpRule').addEventListener('change',syncMpRule);

document.getElementById('mpAdd').addEventListener('click',async function(){
  const technician_id=document.getElementById('mpTech').value;
  const rule_code=document.getElementById('mpRule').value;
  const dateVal=document.getElementById('mpDate').value;
  const ptsVal=document.getElementById('mpPoints').value;
  const note=document.getElementById('mpNote').value;
  const rule=STATE.rules.find(x=>x.code===rule_code);
  const weekly=rule&&rule.unit==='per_week';
  if(!technician_id){toast('Select a technician.',true);return;}
  if(!rule_code){toast('Select a scoring category.',true);return;}
  if(weekly&&!dateVal){toast('Pick a date in the target week.',true);return;}
  const body={rule_code,technician_id,note};
  if(ptsVal!=='')body.points=ptsVal;
  if(weekly)body.week=dateVal; else if(dateVal)body.date=dateVal;
  try{ const r=await api('/manual-points/',{method:'POST',body:JSON.stringify(body)}); toast('Awarded +'+r.points+'.'); document.getElementById('mpNote').value=''; await load(); }
  catch(e){ toast(e.message,true); }
});

async function openEv(tid,name){
  document.getElementById('evTitle').textContent=name+' — Point History';
  document.getElementById('evModal').classList.add('show');
  const body=document.getElementById('evBody');
  body.innerHTML='<div class="loading"><i class="fas fa-spinner fa-spin"></i></div>';
  try{
    const d=await api('/events/?technician='+encodeURIComponent(tid)+(STATE.week?('&week='+STATE.week):''));
    const evs=d.events||[];
    if(!evs.length){body.innerHTML='<div class="empty-state"><i class="fas fa-inbox"></i><br>No point events.</div>';return;}
    let h='<table class="ev-table"><thead><tr><th>Rule</th><th>Pts</th><th>Week</th><th>Src</th><th>Note / Ref</th><th></th></tr></thead><tbody>';
    evs.forEach(e=>{
      h+=`<tr><td>${esc(shortLabel(e.rule_code))}</td><td><b>${e.points}</b></td><td>${esc(fmtDate(e.week_start))}</td>`;
      h+=`<td><span class="badge ${e.source}">${e.source}</span></td>`;
      h+=`<td>${esc(e.note||e.source_ref||'')}${e.created_by?('<div class="muted">by '+esc(e.created_by)+'</div>'):''}</td>`;
      h+=`<td>${e.source==='manual'?`<button class="btn btn-light btn-sm" onclick="delEv('${e.id}')">Remove</button>`:''}</td></tr>`;
    });
    h+='</tbody></table>';
    body.innerHTML=h;
  }catch(e){ body.innerHTML='<div class="empty-state">'+esc(e.message)+'</div>'; }
}
async function delEv(id){
  if(!confirm('Remove this manual point event?'))return;
  try{ await api('/manual-points/?id='+encodeURIComponent(id),{method:'DELETE'}); toast('Removed.'); closeEv(); await load(); }
  catch(e){ toast(e.message,true); }
}
function closeEv(){document.getElementById('evModal').classList.remove('show');}
document.getElementById('evModal').addEventListener('click',function(e){if(e.target===this)closeEv();});

load();