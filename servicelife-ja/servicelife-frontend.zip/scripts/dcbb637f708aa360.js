const API='/api/v1/routing';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
let map,markers=[],polylines=[],directionsRenderers=[],allRoutes=[];
const STATUS_COLORS={scheduled:'#1565c0',confirmed:'#2e7d32',in_progress:'#e65100',completed:'#4caf50',cancelled:'#999'};

function goToday(){document.getElementById('routeDate').value=localDateStr();loadRoutes();}
function changeDate(d){const el=document.getElementById('routeDate');const dt=new Date(el.value);dt.setDate(dt.getDate()+d);el.value=localDateStr(dt);loadRoutes();}

window.initRouteMap=function(){
  map=new google.maps.Map(document.getElementById('routeMap'),{
    center:{lat:39.95,lng:-75.16},zoom:10,
    mapTypeControl:false,streetViewControl:false,fullscreenControl:true,
    mapId:'DEMO_MAP_ID',
    styles:[{featureType:'poi',stylers:[{visibility:'off'}]},{featureType:'transit',stylers:[{visibility:'off'}]}]
  });
  goToday();
};

async function loadRoutes(){
  const date=document.getElementById('routeDate').value;
  const d=new Date(date+'T12:00:00');
  document.getElementById('dateLabel').textContent=d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});
  
  try{
    const r=await fetch(API+'/daily-routes/?date='+date,{credentials:'same-origin'});
    const data=await r.json();
    allRoutes=data.routes||[];
    renderSidebar(allRoutes);
    renderMap(allRoutes);
    // KPIs
    let totalStops=0,totalTravel=0,totalDist=0;
    allRoutes.forEach(rt=>{totalStops+=rt.total_stops;totalTravel+=rt.total_travel_minutes;totalDist+=rt.total_distance_km;});
    document.getElementById('kTechs').textContent=allRoutes.length;
    document.getElementById('kStops').textContent=totalStops;
    document.getElementById('kTravel').textContent=totalTravel>60?Math.round(totalTravel/60)+'h '+totalTravel%60+'m':totalTravel+'m';
    document.getElementById('kDist').textContent=Math.round(totalDist*0.621371); // km to miles
  }catch(e){console.error(e);}
}

function renderSidebar(routes){
  const sb=document.getElementById('sidebar');
  if(!routes.length){
    sb.innerHTML='<div class="empty-state"><i class="fas fa-route"></i><div style="font-weight:600;font-size:15px;margin-bottom:4px">No routes for this date</div><div style="font-size:12px">No technicians have appointments scheduled.</div></div>';
    return;
  }
  sb.innerHTML=routes.map((rt,ri)=>{
    const t=rt.technician;
    const stops=rt.stops.filter(s=>s.type==='appointment');
    let html=`<div class="tech-route-card">
      <div class="tech-route-header" onclick="toggleStops(${ri})">
        <div class="tech-av" style="background:${t.color}">${t.initials}</div>
        <div class="info"><h4>${t.name}</h4><div class="meta">${stops.length} stop${stops.length!==1?'s':''} &bull; ${rt.total_travel_minutes} min travel &bull; ${Math.round(rt.total_distance_km*0.621371)} mi</div></div>
        <div class="stats"><div class="big">${stops.length}</div>jobs</div>
      </div>
      <div class="stop-list" id="stops-${ri}">`;
    rt.stops.forEach((s,si)=>{
      if(s.type==='start'||s.type==='end'){
        html+=`<div class="stop-item"><div class="stop-marker" style="background:#607d8b">${s.type==='start'?'<i class="fas fa-home" style="font-size:10px"></i>':'<i class="fas fa-flag-checkered" style="font-size:10px"></i>'}</div><div class="stop-info"><div class="name">${s.label}</div><div class="addr">${s.address}</div></div></div>`;
      } else {
        const sc=STATUS_COLORS[s.status]||'#999';
        html+=`<div class="stop-item" onclick="focusStop(${ri},${si})" style="cursor:pointer">
          <div class="stop-marker" style="background:${t.color}">${si}</div>
          <div class="stop-info">
            <div class="name"><span class="status-dot" style="background:${sc}"></span>${s.label}</div>
            <div class="addr">${s.address}</div>
            <div>${s.time?'<span class="time-badge"><i class="fas fa-clock"></i> '+s.time+' - '+s.end_time+'</span>':''} <span class="job-badge">${s.job_type}</span></div>
          </div></div>`;
      }
      if(si<rt.stops.length-1&&rt.stops[si+1].travel_from_prev_min){
        html+=`<div class="travel-arrow"><i class="fas fa-arrow-down"></i> ${rt.stops[si+1].travel_from_prev_min} min drive &bull; ${Math.round((rt.stops[si+1].travel_from_prev_km||0)*0.621371)} mi</div>`;
      }
    });
    html+=`</div></div>`;
    return html;
  }).join('');
  // Auto-open first
  if(routes.length)toggleStops(0);
}

function toggleStops(i){
  const el=document.getElementById('stops-'+i);
  if(el)el.classList.toggle('open');
}

function focusStop(ri,si){
  const s=allRoutes[ri].stops[si];
  if(s.lat&&s.lng&&map){map.panTo({lat:s.lat,lng:s.lng});map.setZoom(15);}
}

function renderMap(routes){
  if(!map)return;
  // Clear
  markers.forEach(m=>{if(m.setMap)m.setMap(null);else m.map=null;});markers=[];
  polylines.forEach(p=>p.setMap(null));polylines=[];
  directionsRenderers.forEach(r=>r.setMap(null));directionsRenderers=[];

  if(!routes.length)return;
  // Only fit bounds to appointment stops, not start/end depot stops.
  // Start/end are always at the office (Mount Holly NJ) and would pull the
  // center away from the actual job locations when appointments lack coords.
  const apptBounds=new google.maps.LatLngBounds();
  const apptCoords=[];

  routes.forEach((rt,ri)=>{
    const t=rt.technician;
    const coords=[];
    rt.stops.forEach((s,si)=>{
      if(!s.lat||!s.lng)return;
      const pos={lat:s.lat,lng:s.lng};
      coords.push(pos);
      if(s.type==='appointment'){apptBounds.extend(pos);apptCoords.push(pos);}
      
      const isDepot=s.type==='start'||s.type==='end';
      const markerTitle=s.label+' — '+s.address;
      const content=`<div style="font-size:13px;line-height:1.6;min-width:200px"><strong>${s.label}</strong><br><span style="color:#666">${s.address}</span>${s.time?'<br><span style="color:#2e7d32;font-weight:600">'+s.time+' - '+(s.end_time||'')+'</span>':''}${s.job_type?'<br>'+s.job_type:''}${s.travel_from_prev_min?'<br><i class="fas fa-car" style="color:#999"></i> '+s.travel_from_prev_min+' min from prev':''}</div>`;
      const iw=new google.maps.InfoWindow({content:content});
      let m;
      {
        const pinColor=isDepot?'#607d8b':t.color;
        const labelText=isDepot?(s.type==='start'?'S':'E'):String(si);
        const pinSize=isDepot?20:28;
        const el=document.createElement('div');
        el.style.cssText=`width:${pinSize}px;height:${pinSize}px;border-radius:50%;background:${pinColor};border:2px solid #fff;box-shadow:0 1px 3px rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center;color:#fff;font-size:${isDepot?'9':'10'}px;font-weight:700;cursor:pointer;`;
        el.textContent=labelText;
        m=new google.maps.marker.AdvancedMarkerElement({position:pos,map:map,title:markerTitle,content:el,zIndex:s.type==='appointment'?10:5});
      }
      m.addListener('click',()=>iw.open(map,m));
      markers.push(m);
    });
    
    // Draw polyline
    if(coords.length>1){
      const pl=new google.maps.Polyline({path:coords,geodesic:true,strokeColor:t.color,strokeOpacity:0.7,strokeWeight:3,map:map});
      polylines.push(pl);
    }
  });
  
  if(apptCoords.length===1){map.setCenter(apptCoords[0]);map.setZoom(13);}
  else if(apptCoords.length>1){map.fitBounds(apptBounds,{padding:50});}
  // No geocoded appointment stops: keep the initial map center (Philadelphia area).
}

document.addEventListener('DOMContentLoaded',function(){
  document.getElementById('routeDate').value=localDateStr();
});