(function(){
  var KEY = 'sl_demo_tour_v1';
  var SIGNUP = 'https://servicelife.app/signup/';
  var STEPS = [
    { sel:null, title:"👋 Welcome to the ServiceLife demo",
      body:"You're looking at a product demo of a pest-control company running live and in real-time on ServiceLife. It's read-only, so explore freely. Want a 30-second tour of the highlights?" },
    { sel:".demo-roles", title:"See it from every seat",
      body:"Switch between the Owner, Customer Service, and Technician views right up here — the whole app adapts to each role. Other roles out-of-the-box include Billing Rep, Accountant, HR Manager, Senior Tech, Tech Manager." },
    { sel:"#main-content", title:"Your whole operation, live",
      body:"Today's jobs, techs on route, revenue, and AR — all on one board that updates as the day runs. This is the owner's cockpit." },
    { sel:".sidebar", mobileSel:"#cbpHamburger", title:"Everything in one place",
      body:"Scheduling & dispatch, the CSR inbox, billing & payments, route optimization, contracts, and business intelligence — click into any of it.",
      mobileBody:"Tap the menu ☰ to jump into scheduling, the CSR inbox, billing, routes, contracts, and business intelligence." },
    { sel:".demo-offer", title:"Ready to run your own?",
      body:"Start a free 14-day trial — no card required. You'll be live at your own address in minutes.",
      cta:{ href:SIGNUP, label:"Start free trial →" } }
  ];

  var root, hole, tip, i=0, steps=STEPS;
  function $(id){ return document.getElementById(id); }
  // On narrow screens some anchors move/hide (e.g. the sidebar → hamburger),
  // so steps may declare a mobileSel/mobileBody used below 640px.
  function mobileVW(){ return window.innerWidth <= 640; }
  function curSel(s){ return (mobileVW() && s.mobileSel) ? s.mobileSel : s.sel; }
  function curBody(s){ return (mobileVW() && s.mobileBody) ? s.mobileBody : s.body; }
  function isElVisible(el){
    var cs = getComputedStyle(el);
    if(cs.display==='none' || cs.visibility==='hidden') return false;
    var r = el.getBoundingClientRect();
    if(r.width < 2 || r.height < 2) return false;
    if(r.right <= 0 || r.left >= window.innerWidth || r.bottom <= 0 || r.top >= window.innerHeight) return false;
    return true;
  }

  function done(){
    try{ localStorage.setItem(KEY,'1'); }catch(e){}
    root.classList.remove('on');
    $('slt-fab').classList.add('on');
    window.removeEventListener('resize', reflow);
    document.removeEventListener('keydown', onKey);
  }
  function onKey(e){ if(e.key==='Escape') done(); }

  function place(){
    var s = steps[i];
    var sel = curSel(s);
    var el = sel ? document.querySelector(sel) : null;
    if(el && !isElVisible(el)) el = null;  // hidden/off-screen → centered card
    var vw = window.innerWidth, vh = window.innerHeight;
    if(el){
      // Only scroll if the target is genuinely off-screen — the tour anchors
      // (fixed demo bar, sidebar, top of main) are usually already visible, and
      // scrolling visible elements makes the page jump/strobe between steps.
      var r0 = el.getBoundingClientRect();
      // Scroll only when the element's TOP edge is off-screen (above the fold or
      // below the viewport). Tall elements (e.g. #main-content) whose top is
      // already visible must NOT trigger a centering scroll — that made the page
      // jump between steps.
      if(r0.top < 8 || r0.top > vh - 120){
        try{ el.scrollIntoView({block:'nearest',behavior:'instant'}); }catch(e){ try{el.scrollIntoView();}catch(_){} }
      }
      var r = el.getBoundingClientRect(), pad=6;
      var hw = Math.min(r.width, vw-24), hh = Math.min(r.height, vh-24);
      hole.style.width=(hw+pad*2)+'px'; hole.style.height=(hh+pad*2)+'px';
      hole.style.top=(r.top-pad)+'px'; hole.style.left=(Math.max(4,r.left)-pad)+'px';
      // tooltip: below the anchor if room, else above, else centered
      var tipH=tip.offsetHeight||220, tipW=tip.offsetWidth||320;
      var top, left = Math.min(Math.max(12, r.left), vw - tipW - 12);
      if(r.bottom + tipH + 16 < vh){ top = r.bottom + 12; }
      else if(r.top - tipH - 16 > 0){ top = r.top - tipH - 12; }
      else { top = Math.max(12,(vh-tipH)/2); left=(vw-tipW)/2; }
      tip.style.top=top+'px'; tip.style.left=left+'px';
    } else {
      // no anchor → full dark, centered card
      hole.style.width='0px'; hole.style.height='0px';
      hole.style.top=(vh/2)+'px'; hole.style.left=(vw/2)+'px';
      var th=tip.offsetHeight||220, twd=tip.offsetWidth||320;
      tip.style.top=Math.max(12,(vh-th)/2)+'px'; tip.style.left=((vw-twd)/2)+'px';
    }
  }
  function reflow(){ if(root.classList.contains('on')) place(); }

  function render(){
    var s = steps[i], last = (i===steps.length-1);
    $('slt-stepno').textContent = 'Step '+(i+1)+' of '+steps.length;
    $('slt-title').textContent = s.title;
    $('slt-body').textContent = curBody(s);
    var dots=''; for(var k=0;k<steps.length;k++){ dots+='<span class="slt-dot'+(k===i?' on':'')+'"></span>'; }
    $('slt-dots').innerHTML = dots;
    $('slt-back').style.display = i===0 ? 'none' : 'inline-block';
    var adv = $('slt-adv');
    if(last && s.cta){
      adv.innerHTML = '<a class="slt-btn slt-cta" href="'+s.cta.href+'">'+s.cta.label+'</a> '+
                      '<button class="slt-next" id="slt-fin" type="button">Done</button>';
      $('slt-fin').onclick = done;
    } else if(i===0){
      adv.innerHTML = '<button class="slt-next" id="slt-go" type="button">Start tour →</button>';
      $('slt-go').onclick = next;
    } else {
      adv.innerHTML = '<button class="slt-next" id="slt-nx" type="button">'+(last?'Done':'Next →')+'</button>';
      $('slt-nx').onclick = last ? done : next;
    }
    // reposition after DOM/height settles
    place(); setTimeout(place, 30);
  }
  function next(){ if(i<steps.length-1){ i++; render(); } else { done(); } }
  function back(){ if(i>0){ i--; render(); } }

  function start(){
    i=0; root.classList.add('on'); $('slt-fab').classList.remove('on');
    window.addEventListener('resize', reflow);
    document.addEventListener('keydown', onKey);
    render();
  }

  function init(){
    root=$('slt-root'); hole=$('slt-hole'); tip=$('slt-tip');
    if(!root) return;
    // The app <body> is display:flex; move the overlay to the END of <body> so
    // it can never sit among the flex children and shift the layout. (Both are
    // position:fixed, so this is purely defensive against flex ordering.)
    try{ document.body.appendChild($('slt-fab')); document.body.appendChild(root); }catch(e){}
    $('slt-skip').onclick = done;
    $('slt-back').onclick = back;
    $('slt-fab').onclick = start;
    $('slt-fab').classList.add('on');
  }
  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', init); }
  else { init(); }
})();