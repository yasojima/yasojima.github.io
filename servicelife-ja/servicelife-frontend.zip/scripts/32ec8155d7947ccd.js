(function(){
  // Format helpers — keep self-contained so this partial can be dropped on
  // any page without dragging in a wider JS bundle.
  function fmtMoney(s){
    if (s == null) return '0.00';
    var n = Number(s);
    if (!isFinite(n)) return s;
    return n.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
  }
  function fmtDensity(v){
    if (v == null) return '—';
    return Number(v).toFixed(2);
  }
  function fmtPct(v){
    if (v == null) return '—';
    return Number(v).toFixed(1) + '%';
  }
  function fmtInt(v){
    if (v == null) return '—';
    return String(v);
  }
  async function loadOpKPIs(){
    var grid = document.getElementById('opKpiTiles');
    if (!grid) return; // partial not on page
    try {
      var r = await fetch('/api/v1/reporting/dashboard/kpis/', {credentials: 'same-origin'});
      if (!r.ok) return;
      var d = await r.json();
      var _revEl = document.getElementById('opKpiRevenueVal'); if (_revEl) { _revEl.textContent = fmtMoney(d.revenue_mtd); }
      var _revYtdEl = document.getElementById('opKpiRevenueYtdVal'); if (_revYtdEl) { _revYtdEl.textContent = fmtMoney(d.revenue_ytd); }
      document.getElementById('opKpiARVal').textContent = fmtMoney(d.ar_aging_total);
      // Color escalation: AR > 0 amber, > $5k red.
      var arWrap = document.getElementById('opKpiARWrap');
      var arN = Number(d.ar_aging_total) || 0;
      arWrap.style.color = arN > 5000 ? '#c62828' : (arN > 0 ? '#e65100' : '#2e7d32');
      document.getElementById('opKpiJobsVal').textContent = d.jobs_completed_today;
      document.getElementById('opKpiActiveCustVal').textContent = d.active_customers;
      document.getElementById('opKpiLicenseVal').textContent = d.license_expiring_soon;
      var licWrap = document.getElementById('opKpiLicenseWrap');
      var licN = Number(d.license_expiring_soon) || 0;
      licWrap.style.color = licN > 5 ? '#c62828' : (licN > 0 ? '#e65100' : '#2e7d32');
      document.getElementById('opKpiDensityVal').textContent = fmtDensity(d.avg_route_density_today);
      // F2 tiles
      document.getElementById('opKpiAvgTicketVal').textContent = fmtMoney(d.avg_ticket_30d);
      document.getElementById('opKpiRecurringPctVal').textContent = fmtPct(d.recurring_revenue_pct);
      document.getElementById('opKpiDunningVal').textContent = fmtInt(d.dunning_queue_depth);
      var dunWrap = document.getElementById('opKpiDunningWrap');
      var dunN = Number(d.dunning_queue_depth) || 0;
      dunWrap.style.color = dunN > 5 ? '#c62828' : (dunN > 0 ? '#e65100' : '#2e7d32');
      // C10 — Stripe Connect tile/banner toggle.
      var sc = d.stripe_connect || null;
      var banner = document.getElementById('opKpiStripeBanner');
      var tile = document.getElementById('opKpiStripeTile');
      if (sc && banner && tile) {
        var status = sc.status || 'red';
        var label = sc.label || '';
        var detail = sc.detail || '';
        var link = sc.link || '/api/v1/billing/stripe-connect/';
        // Wire links so the banner/tile point at the operator-facing page.
        banner.setAttribute('href', link);
        tile.setAttribute('href', link);
        // Always populate the inline tile values so the markup stays
        // truthful even while hidden.
        document.getElementById('opKpiStripeLabel').textContent = label;
        document.getElementById('opKpiStripeDetail').textContent = detail;
        var stripeWrap = document.getElementById('opKpiStripeWrap');
        if (status === 'green') {
          tile.style.display = '';
          tile.style.borderLeftColor = '#2e7d32';
          stripeWrap.style.color = '#2e7d32';
          banner.style.display = 'none';
        } else {
          // Non-green: hide the in-grid tile, show the banner with the
          // appropriate severity color. Operators see this above the
          // grid the moment Stripe degrades.
          tile.style.display = 'none';
          var color = status === 'red' ? '#c62828' : '#e65100';
          var bg = status === 'red' ? '#fff3f3' : '#fff8ec';
          var fg = status === 'red' ? '#b71c1c' : '#7a4400';
          banner.style.display = 'flex';
          banner.style.borderLeftColor = color;
          banner.style.background = bg;
          banner.style.color = fg;
          document.getElementById('opKpiStripeBannerLabel').textContent = label;
          document.getElementById('opKpiStripeBannerDetail').textContent = detail;
        }
      }
    } catch (e) {
      if (e && e.name === 'AbortError') return;
      console.error('Operator KPI load error', e);
    }
  }
  // Expose loader so the host page's existing 60s poll can call it
  // alongside the other tile loaders. Also fire once on insert.
  window.loadOperatorKPIs = loadOpKPIs;
  document.addEventListener('DOMContentLoaded', loadOpKPIs);
  if (document.readyState !== 'loading') loadOpKPIs();

  // Slice F3 — click / keyboard activation: navigate to the drilldown
  // page named in data-drilldown.  Bound once on the grid; survives
  // re-renders because individual tiles are static markup.
  // Tiles the user asked to trend open the chart modal (defined on /dashboard/);
  // the rest keep navigating to their detail-table drilldown page. The modal
  // itself links onward to the table, so nothing is lost.
  var TREND_SLUGS = {'revenue-mtd':1,'revenue-ytd':1,'ar-aging':1,'jobs-today':1,'recurring-revenue':1,
                     'active-customers':1,'route-density':1,'avg-ticket-30d':1};
  function navDrilldown(el){
    var slug = el && el.getAttribute && el.getAttribute('data-drilldown');
    if (!slug) return;
    if (TREND_SLUGS[slug] && typeof window.openKpiTrend === 'function') {
      window.openKpiTrend(slug);
      return;
    }
    window.location.href = '/dashboard/drilldown/' + encodeURIComponent(slug) + '/';
  }
  function bindTileNav(){
    var grid = document.getElementById('opKpiTiles');
    if (!grid) return;
    grid.addEventListener('click', function(e){
      var tile = e.target.closest && e.target.closest('.kpi[data-drilldown]');
      if (tile) navDrilldown(tile);
    });
    grid.addEventListener('keydown', function(e){
      if (e.key !== 'Enter' && e.key !== ' ') return;
      var tile = e.target.closest && e.target.closest('.kpi[data-drilldown]');
      if (tile) { e.preventDefault(); navDrilldown(tile); }
    });
  }
  document.addEventListener('DOMContentLoaded', bindTileNav);
  if (document.readyState !== 'loading') bindTileNav();
})();