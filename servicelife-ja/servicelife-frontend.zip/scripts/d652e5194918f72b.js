(function(){
  const PAGE_SIZE = 25;
  let currentPage = 1;
  let totalCount = 0;

  const csrf = () => document.cookie.match(/csrftoken=([^;]+)/)?.[1] || '';

  function timeAgo(iso){
    if(!iso) return '';
    const d = new Date(iso);
    const sec = Math.max(1, Math.floor((Date.now() - d.getTime())/1000));
    if(sec < 60) return sec + 's ago';
    const min = Math.floor(sec/60); if(min < 60) return min + 'm ago';
    const hr  = Math.floor(min/60); if(hr  < 24) return hr  + 'h ago';
    const day = Math.floor(hr/24);  if(day < 7)  return day + 'd ago';
    return d.toLocaleDateString();
  }

  function typeBadge(t){
    const cls = ({info:'badge-info',success:'badge-success',warning:'badge-warning',error:'badge-error',action:'badge-action'})[t] || 'badge-gray';
    return '<span class="badge ' + cls + '">' + escHTML(t || 'info') + '</span>';
  }

  async function fetchJSON(url, opts){
    const r = await fetch(url, Object.assign({credentials:'same-origin', headers:{'X-CSRFToken': csrf()}}, opts || {}));
    if(!r.ok){
      const e = new Error('HTTP ' + r.status);
      e.status = r.status;
      throw e;
    }
    if(r.status === 204) return null;
    return r.json();
  }

  function buildListUrl(page){
    const params = new URLSearchParams();
    params.set('page', page);
    params.set('page_size', PAGE_SIZE);
    const unread = document.getElementById('filterUnread').value;
    if(unread === 'true') params.set('unread_only', 'true');
    const cat = document.getElementById('filterCategory').value;
    if(cat) params.set('category', cat);
    return '/api/v1/notifications/?' + params.toString();
  }

  async function loadPage(page){
    currentPage = page;
    let data;
    try { data = await fetchJSON(buildListUrl(page)); }
    catch(e){
      document.getElementById('notifTbody').innerHTML = '<tr><td colspan="5"><div class="empty-state"><i class="fas fa-triangle-exclamation"></i><p>Could not load notifications.</p></div></td></tr>';
      document.getElementById('pagination').style.display = 'none';
      return;
    }
    const rows = (data && data.results) ? data.results : (Array.isArray(data) ? data : []);
    totalCount = (data && typeof data.count === 'number') ? data.count : rows.length;
    renderRows(rows);
    renderPagination();
  }

  function renderRows(rows){
    const tbody = document.getElementById('notifTbody');
    if(!rows.length){
      tbody.innerHTML = '<tr><td colspan="5"><div class="empty-state"><i class="fas fa-bell-slash"></i><p>No notifications.</p></div></td></tr>';
      return;
    }
    tbody.innerHTML = rows.map(function(n){
      const unreadCls = n.is_read ? '' : 'unread';
      const status = n.is_read
        ? '<span class="badge badge-gray">Read</span>'
        : '<button type="button" class="btn-sm" data-id="' + escHTML(n.id) + '" onclick="markOne(this)"><i class="fas fa-check"></i> Mark read</button>';
      const titleHtml = n.link
        ? '<a href="' + escHTML(n.link) + '" class="notif-title">' + escHTML(n.title || '') + '</a>'
        : '<span class="notif-title">' + escHTML(n.title || '') + '</span>';
      const msg = (n.message || '').slice(0, 200);
      return '<tr class="' + unreadCls + '">'
        + '<td>' + typeBadge(n.notification_type) + '</td>'
        + '<td>' + titleHtml + '<br><span class="notif-message">' + escHTML(msg) + '</span></td>'
        + '<td>' + escHTML(n.category || '') + '</td>'
        + '<td title="' + escHTML(n.created_at || '') + '">' + escHTML(timeAgo(n.created_at)) + '</td>'
        + '<td>' + status + '</td>'
        + '</tr>';
    }).join('');
  }

  function renderPagination(){
    const container = document.getElementById('pagination');
    if(totalCount <= PAGE_SIZE){
      container.style.display = 'none';
      container.innerHTML = '';
      return;
    }
    const totalPages = Math.max(1, Math.ceil(totalCount / PAGE_SIZE));
    let html = '';
    html += '<button type="button" onclick="loadPage(' + (currentPage - 1) + ')"' + (currentPage <= 1 ? ' disabled' : '') + '>Prev</button>';
    html += '<span class="summary">Page ' + currentPage + ' of ' + totalPages + ' &mdash; ' + totalCount + ' total</span>';
    html += '<button type="button" onclick="loadPage(' + (currentPage + 1) + ')"' + (currentPage >= totalPages ? ' disabled' : '') + ' style="margin-left:auto">Next</button>';
    container.innerHTML = html;
    container.style.display = 'flex';
  }

  window.markOne = async function(btn){
    const id = btn.getAttribute('data-id');
    if(!id) return;
    btn.disabled = true;
    try {
      await fetchJSON('/api/v1/notifications/' + id + '/mark-read/', {method:'POST'});
      // Refresh in place. Cheap and keeps server as the source of truth.
      loadPage(currentPage);
      // Bell badge live-updates via its 60s poll; nudge it now.
      if(window.cbpRefreshNotifBell) window.cbpRefreshNotifBell();
    } catch(e){
      btn.disabled = false;
    }
  };

  window.markAllReadFull = async function(){
    try {
      await fetchJSON('/api/v1/notifications/mark-all-read/', {method:'POST'});
      loadPage(currentPage);
      if(window.cbpRefreshNotifBell) window.cbpRefreshNotifBell();
    } catch(e){}
  };

  window.loadPage = loadPage;

  document.addEventListener('DOMContentLoaded', function(){ loadPage(1); });
  // Trigger directly too — the SPA shim re-injects this script after DCL has fired.
  loadPage(1);
})();