(function(){
    if (window.__cbpMobileNav) return;
    window.__cbpMobileNav = true;

    function getEls(){
      return {
        sb: document.querySelector(".sidebar"),
        bd: document.getElementById("cbpSidebarBackdrop"),
        ham: document.getElementById("cbpHamburger")
      };
    }
    function close(){
      var e = getEls();
      if (e.sb) e.sb.classList.remove("cbp-open");
      if (e.bd) e.bd.classList.remove("cbp-show");
      if (e.ham) e.ham.setAttribute("aria-expanded", "false");
    }
    function open(){
      var e = getEls();
      if (e.sb) e.sb.classList.add("cbp-open");
      if (e.bd) e.bd.classList.add("cbp-show");
      if (e.ham) e.ham.setAttribute("aria-expanded", "true");
    }
    window.cbpToggleSidebar = function(){
      var sb = document.querySelector(".sidebar");
      if (!sb) return;
      if (sb.classList.contains("cbp-open")) close(); else open();
    };

    // Delegated click handlers — survive SPA nav since they're on document.
    document.addEventListener("click", function(ev){
      var t = ev.target;
      if (!t || !t.closest) return;
      if (t.closest("#cbpHamburger")) { ev.preventDefault(); cbpToggleSidebar(); return; }
      if (t.closest("#cbpSidebarBackdrop")) { close(); return; }
      // Sidebar link tap → close drawer. SPA shim still navigates because we
      // don't preventDefault. Covers same-page links the SPA event won't fire for.
      if (t.closest(".sidebar a")) { close(); return; }
    });

    document.addEventListener("keydown", function(ev){
      if (ev.key === "Escape") close();
    });

    // Programmatic SPA nav — close drawer after content swap completes.
    window.addEventListener("cbp:spa-navigated", close);

    // Rotate-to-landscape past breakpoint → ensure clean state.
    window.addEventListener("resize", function(){
      if (window.matchMedia('(min-width: 768px)').matches) close();
    });
  })();