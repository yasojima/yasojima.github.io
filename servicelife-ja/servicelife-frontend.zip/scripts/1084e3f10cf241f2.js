function nydecSubmit(ev) {
  ev.preventDefault();
  const form = document.getElementById('nydec-form');
  const start = form.start.value.trim();
  const end = form.end.value.trim();
  const tech = form.technician_id.value.trim();
  const cust = form.customer_id.value.trim();
  const prod = form.product_id.value.trim();
  const status = document.getElementById('nydec-status');
  status.className = 'nydec-status';
  status.textContent = '';

  if (!start || !end) {
    status.className = 'nydec-status is-error';
    status.textContent = 'Start and end dates are required.';
    return false;
  }
  if (end < start) {
    status.className = 'nydec-status is-error';
    status.textContent = 'End must be on or after start.';
    return false;
  }

  const params = new URLSearchParams({start: start, end: end});
  if (tech) params.set('technician_id', tech);
  if (cust) params.set('customer_id', cust);
  if (prod) params.set('product_id', prod);

  status.className = 'nydec-status is-info';
  status.textContent = 'Generating CSV — large date ranges may take a few seconds…';

  const url = '/api/v1/compliance/reports/ny-dec/csv/?' + params.toString();
  window.location.href = url;
  return false;
}