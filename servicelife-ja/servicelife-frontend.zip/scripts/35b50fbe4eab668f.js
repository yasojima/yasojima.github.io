const API='/api/v1/reporting/bi';
const COLORS=['#A5CE3A','#2196F3','#FF9800','#9C27B0','#F44336','#00BCD4','#795548','#E91E63','#4CAF50','#607D8B'];
let charts={};
const VALID_TABS=['revenue','recurring','retention','ar','sales','geo','operations'];
const _loaded={};

function q(){
  const p={};
  const s=document.getElementById('filterStart').value;
  const e=document.getElementById('filterEnd').value;
  const g=document.getElementById('filterGran').value;
  if(s)p.start_date=s;
  if(e)p.end_date=e;
  if(g)p.granularity=g;
  const qs=new URLSearchParams(p).toString();
  return qs?'?'+qs:'';
}
async function api(slug){const r=await fetch(API+slug+q(),{credentials:'same-origin'});if(!r.ok)throw new Error(r.status);return r.json();}
function exportUrl(slug){const sep=q()?'&':'?';return API+slug+q()+sep+'export=csv';}
function money(n){return '$'+(Number(n)||0).toLocaleString(undefined,{maximumFractionDigits:0});}

function makeChart(id,type,labels,datasets,opts={}){
  if(charts[id])charts[id].destroy();
  const ctx=document.getElementById(id);if(!ctx)return;
  charts[id]=new Chart(ctx,{type,data:{labels,datasets},options:{responsive:true,maintainAspectRatio:true,plugins:{legend:{display:datasets.length>1||type==='pie'||type==='doughnut',position:'bottom',labels:{font:{size:11}}}},scales:type==='pie'||type==='doughnut'?{}:{y:{beginAtZero:true,ticks:{font:{size:11}}},x:{ticks:{font:{size:10}}}},...opts}});
}

function showTab(name,updateUrl=true){
  if(!VALID_TABS.includes(name))return;
  document.querySelectorAll('.report-tabs button').forEach(b=>b.classList.remove('active'));
  document.querySelectorAll('.report-section').forEach(s=>s.classList.remove('active'));
  const btn=[...document.querySelectorAll('.report-tabs button')].find(b=>b.getAttribute('onclick')===`showTab('${name}')`);
  if(btn)btn.classList.add('active');
  document.getElementById('tab-'+name).classList.add('active');
  if(updateUrl)history.replaceState(null,'',`?tab=${name}`);
  if(!_loaded[name])load(name);
}
function applyFilters(){const a=document.querySelector('.report-section.active');if(a)load(a.id.replace('tab-',''));}
function resetFilters(){document.getElementById('filterStart').value='';document.getElementById('filterEnd').value='';document.getElementById('filterGran').value='month';applyFilters();}
function load(name){if(name==='revenue')loadRevenue();else if(name==='recurring')loadRecurring();else if(name==='retention')loadRetention();else if(name==='ar')loadAR();else if(name==='sales')loadSales();else if(name==='geo')loadGeo();else if(name==='operations')loadOperations();}

async function loadRevenue(){
  _loaded.revenue=true;
  document.getElementById('revExport').href=exportUrl('/revenue-trend/');
  try{
    const d=await api('/revenue-trend/');
    const s=d.series||[];
    const total=s.reduce((a,r)=>a+r.revenue,0);
    const nonzero=s.filter(r=>r.revenue>0);
    const avg=nonzero.length?total/nonzero.length:0;
    const last=s.length?s[s.length-1].revenue:0;
    document.getElementById('revKPIs').innerHTML=`
      <div class="kpi"><div class="lbl">Total (range)</div><div class="val" style="color:#2e7d32">${money(total)}</div></div>
      <div class="kpi"><div class="lbl">Avg / ${d.granularity}</div><div class="val">${money(avg)}</div></div>
      <div class="kpi"><div class="lbl">Latest ${d.granularity}</div><div class="val">${money(last)}</div></div>`;
    makeChart('chartRevTrend','bar',s.map(r=>r.bucket),[{label:'Collected',data:s.map(r=>r.revenue),backgroundColor:'#A5CE3A',borderRadius:4}]);
  }catch(e){console.error('revenue-trend',e);}
  try{
    const y=await api('/revenue-yoy/');
    makeChart('chartRevYoY','line',y.labels,[
      {label:y.current_year,data:y.current,borderColor:'#A5CE3A',backgroundColor:'rgba(165,206,58,.1)',tension:.3},
      {label:y.prior_year,data:y.prior,borderColor:'#9C27B0',borderDash:[5,4],tension:.3}]);
  }catch(e){console.error('yoy',e);}
  try{
    const a=await api('/avg-ticket-trend/');
    const s=a.series||[];
    makeChart('chartAvgTicket','line',s.map(r=>r.bucket),[{label:'Avg Ticket',data:s.map(r=>r.avg_ticket),borderColor:'#2196F3',backgroundColor:'rgba(33,150,243,.1)',fill:true,tension:.3}]);
  }catch(e){console.error('avg-ticket',e);}
  try{
    const sv=await api('/revenue-by-service/');
    const rows=(sv.rows||[]).filter(r=>r.jobs>0).slice(0,10);
    makeChart('chartRevService','doughnut',rows.map(r=>r.job_type),[{data:rows.map(r=>r.jobs),backgroundColor:rows.map((_,i)=>COLORS[i%COLORS.length])}]);
  }catch(e){console.error('by-service',e);}
  try{
    const tc=await api('/top-customers/');
    const rows=tc.rows||[];
    document.getElementById('topCustBody').innerHTML=rows.length?rows.map(r=>`<tr><td><strong>${r.customer}</strong></td><td>${r.type}</td><td style="text-align:right">${money(r.revenue)}</td></tr>`).join(''):`<tr><td colspan="3" style="text-align:center;color:var(--text-light);padding:20px">No revenue in range</td></tr>`;
  }catch(e){console.error('top-cust',e);}
}

async function loadRecurring(){
  _loaded.recurring=true;
  document.getElementById('mrrExport').href=exportUrl('/mrr-movement/');
  try{
    const [m,s]=await Promise.all([api('/mrr/'),api('/square-recurring/')]);
    document.getElementById('mrrKPIs').innerHTML=`
      <div class="kpi"><div class="lbl">Collected MRR <span style="color:#2196F3">◆</span></div><div class="val" style="color:#2e7d32">${money(s.mrr)}</div><div class="sub">Square run-rate</div></div>
      <div class="kpi"><div class="lbl">Collected ARR</div><div class="val">${money(s.arr)}</div></div>
      <div class="kpi"><div class="lbl">Active Payers</div><div class="val">${(s.active_customers||0).toLocaleString()}</div><div class="sub">paying on cadence</div></div>
      <div class="kpi"><div class="lbl">Avg / Payer</div><div class="val">${money(s.avg_per_customer)}</div><div class="sub">per month</div></div>
      <div class="kpi"><div class="lbl">Booked MRR</div><div class="val" style="color:#607D8B">${money(m.mrr)}</div><div class="sub">${(m.contract_count||0).toLocaleString()} sites</div></div>
      <div class="kpi"><div class="lbl">Avg MRR / site</div><div class="val" style="color:#607D8B">${money(m.contract_count?m.mrr/m.contract_count:0)}</div><div class="sub">per month</div></div>`;
    document.getElementById('mrrNote').innerHTML=`<i class="fas fa-circle-info"></i> <b>Collected MRR</b> (${money(s.mrr)}) is the real run-rate from ~${s.avg_customer_age_months?Math.round(s.avg_customer_age_months):15}mo of Square payment history — customers actually paying on their observed cadence. <b>Booked MRR</b> (${money(m.mrr)}) is the maintenance book value (= Active TCV ÷ 12, one row per recurring site); the gap is sites not yet auto-billing or paying irregularly. <b>Avg MRR / site</b> is a monthly figure, so quarterly-billed sites sit below their ≥$65 per-treatment price.`;
    const bc=m.by_cadence||[];
    makeChart('chartMrrCadence','doughnut',bc.map(r=>r.cadence),[{data:bc.map(r=>r.mrr),backgroundColor:bc.map((_,i)=>COLORS[i%COLORS.length])}]);
  }catch(e){console.error('mrr',e);}
  try{
    const d=await api('/mrr-movement/');
    const s=d.series||[];
    makeChart('chartMrrMovement','bar',s.map(r=>r.bucket),[
      {type:'line',label:'MRR',data:s.map(r=>r.mrr),borderColor:'#2e7d32',backgroundColor:'rgba(46,125,50,.08)',fill:true,tension:.3,yAxisID:'y'},
      {label:'New MRR',data:s.map(r=>r.new),backgroundColor:'#A5CE3A',yAxisID:'y1'},
      {label:'Churned MRR',data:s.map(r=>r.churned),backgroundColor:'#F44336',yAxisID:'y1'}],
      {scales:{y:{position:'left',beginAtZero:true},y1:{position:'right',beginAtZero:true,grid:{drawOnChartArea:false}},x:{ticks:{font:{size:10}}}}});
  }catch(e){console.error('mrr-movement',e);}
  try{
    const f=await api('/revenue-forecast/');
    makeChart('chartForecast','line',f.labels,[
      {label:'Actual',data:f.actual,borderColor:'#2196F3',backgroundColor:'rgba(33,150,243,.1)',tension:.3,spanGaps:false},
      {label:'Forecast',data:f.forecast,borderColor:'#FF9800',borderDash:[6,4],tension:.3,spanGaps:true}]);
  }catch(e){console.error('forecast',e);}
  try{
    const b=await api('/bookings-trend/');
    const s=b.series||[];
    makeChart('chartBookings','bar',s.map(r=>r.bucket),[{label:'Contract Value Booked',data:s.map(r=>r.booked),backgroundColor:'#9C27B0',borderRadius:4}]);
  }catch(e){console.error('bookings',e);}
}

async function loadRetention(){
  _loaded.retention=true;
  document.getElementById('churnExport').href=exportUrl('/square-churn-trend/');
  try{
    const s=await api('/square-recurring/');
    document.getElementById('retKPIs').innerHTML=`
      <div class="kpi"><div class="lbl">Active Payers</div><div class="val" style="color:#2e7d32">${(s.active_customers||0).toLocaleString()}</div><div class="sub">of ${(s.total_paying_customers||0).toLocaleString()} ever</div></div>
      <div class="kpi"><div class="lbl">Avg Customer Age <span style="color:#2196F3">◆</span></div><div class="val">${s.avg_customer_age_months||0} mo</div><div class="sub">1st Square payment</div></div>
      <div class="kpi"><div class="lbl">Lapse / Churn</div><div class="val" style="color:#c62828">${s.churn_rate||0}%</div><div class="sub">${s.lapsed_customers||0} lapsed</div></div>
      <div class="kpi"><div class="lbl">Recurring Base</div><div class="val">${(s.recurring_customers||0).toLocaleString()}</div><div class="sub">&ge;2 payments</div></div>`;
    document.getElementById('retNote').innerHTML=`<i class="fas fa-circle-info"></i> <span style="color:#2196F3">◆</span> Derived from Square payment history (since ${s.history_start||'—'}), which is deeper than the CRM record — a customer is "active" while paying on their observed cadence and "lapsed" once a payment interval is missed past a grace window.`;
  }catch(e){console.error('square-recurring',e);}
  try{
    const d=await api('/square-churn-trend/');
    const s=d.series||[];
    makeChart('chartGrowth','bar',s.map(r=>r.bucket),[
      {label:'Lapsed',data:s.map(r=>r.churned),backgroundColor:'#F44336',borderRadius:3},
      {type:'line',label:'Active Payers',data:s.map(r=>r.active_base),borderColor:'#2196F3',backgroundColor:'rgba(33,150,243,.08)',fill:true,tension:.3,yAxisID:'y1'}],
      {scales:{y:{position:'left',beginAtZero:true},y1:{position:'right',beginAtZero:true,grid:{drawOnChartArea:false}},x:{ticks:{font:{size:10}}}}});
    makeChart('chartChurnRate','line',s.map(r=>r.bucket),[{label:'Churn %',data:s.map(r=>r.churn_rate),borderColor:'#F44336',backgroundColor:'rgba(244,67,54,.1)',fill:true,tension:.3}]);
  }catch(e){console.error('square-churn',e);}
  try{
    const c=await api('/cancellation-reasons/');
    const rows=c.totals||[];
    if(rows.length){document.getElementById('cancelEmpty').style.display='none';
      makeChart('chartCancelReasons','doughnut',rows.map(r=>r.reason),[{data:rows.map(r=>r.count),backgroundColor:rows.map((_,i)=>COLORS[i%COLORS.length])}]);
    }else{document.getElementById('chartCancelReasons').style.display='none';document.getElementById('cancelEmpty').style.display='block';}
  }catch(e){console.error('cancel-reasons',e);}
  try{
    const co=await api('/cohort-retention/');
    renderCohort(co);
  }catch(e){console.error('cohort',e);}
}

function renderCohort(co){
  const offs=co.offsets||[];const cohorts=co.cohorts||[];
  let h='<table class="data-table"><thead><tr><th>Cohort</th><th>Size</th>'+offs.map(o=>`<th>M${o}</th>`).join('')+'</tr></thead><tbody>';
  cohorts.forEach(c=>{
    h+=`<tr><td><strong>${c.cohort}</strong></td><td>${c.size}</td>`;
    c.pct.forEach(p=>{
      if(p===null){h+='<td style="color:#ccc">–</td>';}
      else{const g=Math.round(165*p/100),r=Math.round(206-(206-46)*p/100);const bg=`rgba(${255-Math.round(p*0.9)},${180+Math.round(p*0.3)},${Math.round(p*0.6)},0.35)`;h+=`<td style="background:rgba(165,206,58,${(p/100*0.6+0.05).toFixed(2)})">${p}%</td>`;}
    });
    h+='</tr>';
  });
  h+='</tbody></table>';
  document.getElementById('cohortWrap').innerHTML=h;
}

async function loadAR(){
  _loaded.ar=true;
  document.getElementById('balExport').href=exportUrl('/client-balances/');
  try{
    const a=await api('/ar-aging/');
    const b=a.buckets||[];
    document.getElementById('arKPIs').innerHTML=`
      <div class="kpi"><div class="lbl">Total AR</div><div class="val" style="color:#e65100">${money(a.total)}</div></div>`+
      b.map(x=>`<div class="kpi"><div class="lbl">${x.bucket} days</div><div class="val">${money(x.amount)}</div></div>`).join('');
    makeChart('chartArAging','bar',b.map(x=>x.bucket+' d'),[{label:'Balance',data:b.map(x=>x.amount),backgroundColor:['#4CAF50','#FF9800','#FF5722','#c62828']}]);
  }catch(e){console.error('ar-aging',e);}
  try{
    const d=await api('/collection-efficiency/');
    const s=d.series||[];
    makeChart('chartCollection','bar',s.map(r=>r.bucket),[
      {label:'Invoiced (CRM)',data:s.map(r=>r.invoiced),backgroundColor:'#2196F3',borderRadius:3},
      {label:'Collected (Square)',data:s.map(r=>r.collected),backgroundColor:'#A5CE3A',borderRadius:3}]);
  }catch(e){console.error('collection',e);}
  try{
    const c=await api('/client-balances/');
    const rows=c.rows||[];
    document.getElementById('balBody').innerHTML=rows.length?rows.map(r=>`<tr><td><strong>${r.customer}</strong></td><td style="text-align:right">${money(r.balance)}</td></tr>`).join(''):`<tr><td colspan="2" style="text-align:center;color:var(--text-light);padding:20px">No outstanding balances</td></tr>`;
  }catch(e){console.error('balances',e);}
}

async function loadSales(){
  _loaded.sales=true;
  try{
    const r=await api('/renewals-pipeline/');
    document.getElementById('renKPIs').innerHTML=`
      <div class="kpi"><div class="lbl">Due 30d</div><div class="val">${r.next_30||0}</div></div>
      <div class="kpi"><div class="lbl">Due 60d</div><div class="val">${r.next_60||0}</div></div>
      <div class="kpi"><div class="lbl">Due 90d</div><div class="val">${r.next_90||0}</div></div>
      <div class="kpi"><div class="lbl">Auto-Renew</div><div class="val" style="color:#2e7d32">${r.auto_renew||0}</div></div>
      <div class="kpi"><div class="lbl">Manual</div><div class="val">${r.manual_renew||0}</div></div>`;
    document.getElementById('salesNote').innerHTML=`<i class="fas fa-circle-info"></i> ${r.total_with_end_date||0} contracts carry an end date; ${r.auto_renew||0} auto-renew. None fall due within 90 days. Lead/estimate volume is low — the CRM isn't the primary top-of-funnel yet.`;
    makeChart('chartRenewal','doughnut',['Auto-renew','Manual'],[{data:[r.auto_renew||0,r.manual_renew||0],backgroundColor:['#A5CE3A','#FF9800']}]);
  }catch(e){console.error('renewals',e);}
  try{
    const p=await api('/sales-pipeline/');
    const st=p.stages||[];
    if(st.length&&p.total>0){document.getElementById('pipeEmpty').style.display='none';document.getElementById('chartPipeline').style.display='';
      makeChart('chartPipeline','bar',st.map(s=>s.stage),[{label:'Leads',data:st.map(s=>s.count),backgroundColor:'#2196F3',borderRadius:4}]);
    }else{document.getElementById('chartPipeline').style.display='none';document.getElementById('pipeEmpty').style.display='block';}
  }catch(e){console.error('pipeline',e);}
}

async function loadGeo(){
  _loaded.geo=true;
  document.getElementById('zipExport').href=exportUrl('/geo-top-zips/');
  try{
    const z=await api('/geo-top-zips/');
    const rows=z.rows||[];
    const known=rows.filter(r=>r.zip!=='(unknown)');
    document.getElementById('geoKPIs').innerHTML=`
      <div class="kpi"><div class="lbl">ZIPs Served</div><div class="val">${known.length}</div></div>
      <div class="kpi"><div class="lbl">Top ZIP</div><div class="val">${known[0]?known[0].zip:'—'}</div><div class="sub">${known[0]?known[0].jobs+' jobs':''}</div></div>
      <div class="kpi"><div class="lbl">Top ZIP Revenue</div><div class="val" style="color:#2e7d32">${known[0]?money(known[0].revenue):'—'}</div></div>`;
    makeChart('chartTopZips','bar',rows.map(r=>r.zip),[
      {label:'Jobs',data:rows.map(r=>r.jobs),backgroundColor:'#2196F3',borderRadius:3,yAxisID:'y'},
      {type:'line',label:'Revenue',data:rows.map(r=>r.revenue),borderColor:'#2e7d32',tension:.3,yAxisID:'y1'}],
      {scales:{y:{position:'left',beginAtZero:true},y1:{position:'right',beginAtZero:true,grid:{drawOnChartArea:false}},x:{ticks:{font:{size:10}}}}});
  }catch(e){console.error('top-zips',e);}
  try{
    const s=await api('/pest-seasonality/');
    const series=(s.series||[]).map((sp,i)=>({label:sp.pest,data:sp.counts,borderColor:COLORS[i%COLORS.length],backgroundColor:'transparent',tension:.4}));
    makeChart('chartSeasonality','line',s.months,series);
  }catch(e){console.error('seasonality',e);}
  try{
    const pz=await api('/pest-by-zip/');
    renderPestZip(pz);
  }catch(e){console.error('pest-by-zip',e);}
  try{
    const em=await api('/pest-emerging/');
    const rows=(em||[]).slice(0,12);
    document.getElementById('emergeBody').innerHTML=rows.length?rows.map(r=>{const col=r.change>0?'#2e7d32':r.change<0?'#c62828':'#888';const sign=r.change>0?'+':'';return `<tr><td><strong>${r.pest}</strong></td><td>${r.recent}</td><td>${r.prior}</td><td style="color:${col};font-weight:600">${sign}${r.change}</td></tr>`;}).join(''):`<tr><td colspan="4" style="text-align:center;color:var(--text-light);padding:20px">Not enough history</td></tr>`;
  }catch(e){console.error('emerging',e);}
}

function renderPestZip(pz){
  const zips=pz.zips||[],pests=pz.pests||[],matrix=pz.matrix||[];
  let max=1;matrix.forEach(row=>row.forEach(v=>{if(v>max)max=v;}));
  let h='<table class="data-table"><thead><tr><th>ZIP</th>'+pests.map(p=>`<th title="${p}">${p.length>16?p.slice(0,15)+'…':p}</th>`).join('')+'</tr></thead><tbody>';
  zips.forEach((z,i)=>{
    h+=`<tr><td><strong>${z}</strong></td>`;
    (matrix[i]||[]).forEach(v=>{const a=(v/max*0.7+0.03).toFixed(2);h+=`<td style="background:rgba(33,150,243,${v?a:0})">${v||''}</td>`;});
    h+='</tr>';
  });
  h+='</tbody></table>';
  document.getElementById('pestZipWrap').innerHTML=h;
}

async function loadOperations(){
  _loaded.operations=true;
  document.getElementById('opsExport').href=exportUrl('/production-trend/');
  try{
    const d=await api('/production-trend/');
    const s=d.series||[];
    makeChart('chartProduction','line',s.map(r=>r.bucket),[
      {label:'Completed',data:s.map(r=>r.completed),borderColor:'#4CAF50',tension:.3},
      {label:'Cancelled',data:s.map(r=>r.cancelled),borderColor:'#F44336',tension:.3},
      {label:'Total',data:s.map(r=>r.total),borderColor:'#607D8B',borderDash:[5,4],tension:.3}]);
    makeChart('chartCompletion','line',s.map(r=>r.bucket),[{label:'Completion %',data:s.map(r=>r.completion_rate),borderColor:'#A5CE3A',backgroundColor:'rgba(165,206,58,.1)',fill:true,tension:.3}],{scales:{y:{beginAtZero:true,max:100,ticks:{font:{size:11}}},x:{ticks:{font:{size:10}}}}});
  }catch(e){console.error('production',e);}
  try{
    const t=await api('/tech-production/');
    const rows=t.rows||[];
    makeChart('chartTechProd','bar',rows.map(r=>r.technician),[
      {label:'Completed',data:rows.map(r=>r.completed),backgroundColor:'#A5CE3A',borderRadius:4},
      {label:'Total',data:rows.map(r=>r.total),backgroundColor:'#2196F3',borderRadius:4}]);
    document.getElementById('techBody').innerHTML=rows.length?rows.map(r=>{const pct=r.total?Math.round(r.completed/r.total*100):0;return `<tr><td><strong>${r.technician}</strong></td><td>${r.completed}</td><td>${r.total}</td><td>${pct}%</td></tr>`;}).join(''):`<tr><td colspan="4" style="text-align:center;color:var(--text-light);padding:20px">No jobs in range</td></tr>`;
  }catch(e){console.error('tech-prod',e);}
}

document.addEventListener('DOMContentLoaded',()=>{
  const params=new URLSearchParams(window.location.search);
  const tab=params.get('tab');
  if(tab&&VALID_TABS.includes(tab)){showTab(tab,false);}else{loadRevenue();}
});