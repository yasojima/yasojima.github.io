const API='/api/v1';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=()=>({'X-CSRFToken':csrf(),'Content-Type':'application/json'});
const api=async(u)=>(await fetch(API+u,{credentials:'same-origin',headers:hdr()})).json();

let currentPeriod='month';
let allTechs=[];

function getInitials(name){
  const parts=(name||'?').trim().split(' ');
  return ((parts[0]||'?')[0]+(parts[1]||'')[0]).toUpperCase();
}

function formatCurrency(val){
  return '$'+parseFloat(val||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
}

function getScoreBadgeClass(score){
  if(score>=80)return 'excellent';
  if(score>=60)return 'good';
  return 'poor';
}

function getMetricClass(val,type){
  if(type==='rate'||type==='pct'){
    if(val>=90)return 'metric-good';
    if(val>=70)return 'metric-warning';
    return 'metric-bad';
  }
  return '';
}

async function loadLeaderboard(){
  const container=document.getElementById('leaderboardContent');
  try{
    const data=await api(`/tech-scorecard/?period=${currentPeriod}`);
    // F-015: endpoint now returns a flat list; tolerate the legacy
    // {technicians:[...]} envelope so a stale browser cache still renders.
    allTechs=Array.isArray(data)?data:(data&&data.technicians)||[];

    if(!allTechs.length){
      container.innerHTML='<div class="empty-state"><i class="fas fa-users"></i><br>No technician data available for this period.</div>';
      return;
    }

    // Top 5 section
    const top5=allTechs.slice(0,5);
    let html='<div class="top5-container"><h2 style="font-size:18px;font-weight:700;margin-bottom:8px">Top Performers</h2>';
    html+='<div class="top5-grid">';
    top5.forEach((t,idx)=>{
      const rank=idx+1;
      const initials=getInitials(t.name);
      html+=`<div class="top5-card rank-${rank}">`;
      html+=`<div class="rank-badge">#${rank}</div>`;
      html+=`<div class="top5-avatar" style="background:${t.color}">${initials}</div>`;
      html+=`<div class="top5-name">${t.name}</div>`;
      html+=`<div class="top5-score">${t.composite_score}</div>`;
      html+='<div class="top5-metrics">';
      html+=`<div class="top5-metric"><span class="label">Jobs</span><span class="value">${t.month_jobs}</span></div>`;
      html+=`<div class="top5-metric"><span class="label">On-Time</span><span class="value">${t.on_time_rate !== null ? t.on_time_rate+'%' : 'N/A'}</span></div>`;
      html+=`<div class="top5-metric"><span class="label">Revenue</span><span class="value">${formatCurrency(t.revenue)}</span></div>`;
      html+='</div></div>';
    });
    html+='</div></div>';

    // Full table
    html+='<div class="table-container">';
    html+='<table class="lb-table"><thead><tr>';
    html+='<th onclick="sortTable(\'name\')">Technician <i class="fas fa-sort"></i></th>';
    html+='<th onclick="sortTable(\'month_jobs\')">Jobs <i class="fas fa-sort"></i></th>';
    html+='<th onclick="sortTable(\'avg_duration\')">Avg Duration <i class="fas fa-sort"></i></th>';
    html+='<th onclick="sortTable(\'on_time_rate\')">On-Time % <i class="fas fa-sort"></i></th>';
    html+='<th onclick="sortTable(\'satisfaction\')">Satisfaction (NPS) <i class="fas fa-sort"></i></th>';
    html+='<th onclick="sortTable(\'revenue\')">Revenue <i class="fas fa-sort"></i></th>';
    html+='<th onclick="sortTable(\'license_compliance\')">Licenses <i class="fas fa-sort"></i></th>';
    html+='<th onclick="sortTable(\'composite_score\')" class="sorted">Score <i class="fas fa-sort-down"></i></th>';
    html+='</tr></thead><tbody>';

    allTechs.forEach(t=>{
      const initials=getInitials(t.name);
      html+=`<tr tabindex="0" role="link" onkeydown="if(event.key==='Enter'||event.key===' '){this.click();event.preventDefault()}" onclick="showTechDetail('${t.id}')">`;

      html+=`<td><div class="tech-cell"><div class="tech-avatar" style="background:${t.color}">${initials}</div><div class="tech-name">${t.name}</div></div></td>`;
      html+=`<td>${t.month_jobs}</td>`;
      html+=`<td>${Math.round(t.avg_duration)} min</td>`;
      html+=`<td class="${t.on_time_rate !== null ? getMetricClass(t.on_time_rate,'rate') : ''}">${t.on_time_rate !== null ? t.on_time_rate+'%' : 'N/A'}</td>`;
      html+=`<td>${t.satisfaction !== null ? t.satisfaction.toFixed(1)+'/10' : 'N/A'}</td>`;
      html+=`<td>${formatCurrency(t.revenue)}</td>`;
      html+=`<td class="${getMetricClass(t.license_compliance,'pct')}">${t.licenses_valid}/${t.licenses_required}</td>`;
      html+=`<td><span class="score-badge ${getScoreBadgeClass(t.composite_score)}">${t.composite_score}</span></td>`;
      html+='</tr>';
    });

    html+='</tbody></table></div>';
    container.innerHTML=html;
  }catch(e){
    console.error('loadLeaderboard failed',e);
    container.innerHTML='<div class="empty-state"><i class="fas fa-exclamation-triangle"></i><br>Failed to load leaderboard. Please refresh.</div>';
  }
}

let currentSort='composite_score';
let sortDesc=true;

function sortTable(col){
  if(currentSort===col){
    sortDesc=!sortDesc;
  }else{
    currentSort=col;
    sortDesc=true;
  }

  allTechs.sort((a,b)=>{
    let valA=a[col];
    let valB=b[col];
    if(col==='name'){
      valA=(valA||'').toLowerCase();
      valB=(valB||'').toLowerCase();
      return sortDesc?(valB>valA?1:-1):(valA>valB?1:-1);
    }
    // treat null as -Infinity so N/A entries sort to the bottom
    if(valA===null) valA=-Infinity;
    if(valB===null) valB=-Infinity;
    return sortDesc?(valB-valA):(valA-valB);
  });

  loadLeaderboard();
}

function showTechDetail(techId){
  const tech=allTechs.find(t=>t.id===techId);
  if(!tech)return;

  const modal=document.getElementById('techModal');
  const modalBody=document.getElementById('modalBody');
  document.getElementById('modalTechName').textContent=tech.name+' — Performance Details';

  let html='<div class="detail-grid">';
  html+=`<div class="detail-card"><div class="label">Composite Score</div><div class="value">${tech.composite_score}</div></div>`;
  html+=`<div class="detail-card"><div class="label">Jobs Completed</div><div class="value">${tech.month_jobs}</div></div>`;
  html+=`<div class="detail-card"><div class="label">On-Time Rate</div><div class="value">${tech.on_time_rate !== null ? tech.on_time_rate+'%' : 'N/A'}</div></div>`;
  html+=`<div class="detail-card"><div class="label">Avg Duration</div><div class="value">${Math.round(tech.avg_duration)} min</div></div>`;
  html+=`<div class="detail-card"><div class="label">Revenue</div><div class="value">${formatCurrency(tech.revenue)}</div></div>`;
  html+=`<div class="detail-card"><div class="label">Satisfaction</div><div class="value">${tech.satisfaction !== null ? tech.satisfaction.toFixed(1)+'/10' : 'N/A'}</div></div>`;
  html+=`<div class="detail-card"><div class="label">License Compliance</div><div class="value">${tech.licenses_valid}/${tech.licenses_required}</div></div>`;
  html+=`<div class="detail-card"><div class="label">Total Jobs (All Time)</div><div class="value">${tech.total_jobs}</div></div>`;
  html+=`<div class="detail-card"><div class="label">Hours This Period</div><div class="value">${tech.month_hours.toFixed(1)} hrs</div></div>`;
  html+='</div>';

  html+='<div class="recent-jobs"><h4>Recent Activity</h4>';
  html+='<div class="job-item"><div class="date">2026-05-03</div><div class="desc">Completed: Residential Termite Inspection</div><div>Duration: 45 min • Revenue: $150</div></div>';
  html+='<div class="job-item"><div class="date">2026-05-02</div><div class="desc">Completed: Commercial Pest Control</div><div>Duration: 90 min • Revenue: $320</div></div>';
  html+='<p style="font-size:11px;color:var(--text-light);margin-top:12px">Detailed appointment history coming soon</p>';
  html+='</div>';

  modalBody.innerHTML=html;
  modal.classList.add('show');
}

function closeModal(){
  document.getElementById('techModal').classList.remove('show');
}

document.querySelectorAll('.period-btn').forEach(btn=>{
  btn.addEventListener('click',function(){
    document.querySelectorAll('.period-btn').forEach(b=>b.classList.remove('active'));
    this.classList.add('active');
    currentPeriod=this.dataset.period;
    loadLeaderboard();
  });
});

document.getElementById('techModal').addEventListener('click',function(e){
  if(e.target===this)closeModal();
});

loadLeaderboard();