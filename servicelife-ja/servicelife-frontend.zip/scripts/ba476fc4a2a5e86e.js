const API='/api/v1';
async function api(u){const r=await fetch(API+u,{credentials:'same-origin'});return r.json();}
const COLORS=['#A5CE3A','#2196F3','#FF9800','#9C27B0','#F44336','#00BCD4','#795548','#E91E63','#4CAF50','#607D8B'];
let charts={};

// Per-tab extra filter element IDs
const TAB_EXTRA_FILTERS={customers:'filterCustomerType',technicians:'filterTechId'};

const VALID_TABS=['revenue','customers','technicians','leads','commercial','accounting','sales','csr'];
function showTab(name,updateUrl=true){
  if(!VALID_TABS.includes(name))return;
  document.querySelectorAll('.report-tabs button').forEach(b=>b.classList.remove('active'));
  document.querySelectorAll('.report-section').forEach(s=>s.classList.remove('active'));
  const btn=[...document.querySelectorAll('.report-tabs button')].find(b=>b.getAttribute('onclick')===`showTab('${name}')`);
  if(btn)btn.classList.add('active');
  document.getElementById('tab-'+name).classList.add('active');
  // Show/hide per-tab filter elements
  Object.entries(TAB_EXTRA_FILTERS).forEach(([tab,elId])=>{
    const el=document.getElementById(elId);
    if(el)el.style.display=(tab===name?'':'none');
  });
  if(updateUrl)history.replaceState(null,'',`?tab=${name}`);
}

function makeChart(id,type,labels,datasets,opts={}){
  if(charts[id])charts[id].destroy();
  const ctx=document.getElementById(id);
  if(!ctx)return;
  charts[id]=new Chart(ctx,{type,data:{labels,datasets},options:{responsive:true,maintainAspectRatio:true,plugins:{legend:{display:datasets.length>1||type==='pie'||type==='doughnut',position:'bottom',labels:{font:{size:11}}}},scales:type==='pie'||type==='doughnut'?{}:{y:{beginAtZero:true,ticks:{font:{size:11}}},x:{ticks:{font:{size:10}}}},...opts}});
}

function getTabFilterQuery(tab){
  const p={};
  const s=document.getElementById('filterStart').value;
  const e=document.getElementById('filterEnd').value;
  if(s)p.start_date=s;
  if(e)p.end_date=e;
  if(tab==='customers'){const v=document.getElementById('filterCustomerType').value;if(v)p.customer_type=v;}
  if(tab==='technicians'){const v=document.getElementById('filterTechId').value;if(v)p.tech_id=v;}
  const qs=new URLSearchParams(p).toString();
  return qs?'?'+qs:'';
}

function applyFilters(){
  const active=document.querySelector('.report-section.active');
  if(!active)return;
  const tab=active.id.replace('tab-','');
  _reloadTab(tab);
}

function resetFilters(){
  document.getElementById('filterStart').value='';
  document.getElementById('filterEnd').value='';
  document.getElementById('filterCustomerType').value='';
  document.getElementById('filterTechId').value='';
  applyFilters();
}

function _reloadTab(tab){
  if(tab==='revenue')loadRevenue();
  else if(tab==='customers')loadCustomers();
  else if(tab==='technicians')loadTechnicians();
  else if(tab==='leads')loadLeads();
  else if(tab==='commercial')loadCommercial();
}

function _exportUrl(base,tab,fmt){
  const p={};
  const s=document.getElementById('filterStart').value;
  const e=document.getElementById('filterEnd').value;
  if(s)p.start_date=s;
  if(e)p.end_date=e;
  p.export=fmt;
  return base+'?'+new URLSearchParams(p).toString();
}

async function loadRevenue(){
  try{
    const q=getTabFilterQuery('revenue');
    document.getElementById('revExportCsv').href=_exportUrl('/api/v1/billing/reports/revenue/','revenue','csv');
    document.getElementById('revExportXlsx').href=_exportUrl('/api/v1/billing/reports/revenue/','revenue','xlsx');
    document.getElementById('revExportPdf').href=_exportUrl('/api/v1/billing/reports/revenue/','revenue','pdf');
    const d=await api('/billing/reports/revenue/'+q);
    // KPIs
    const inv=d.invoices||{};
    document.getElementById('revKPIs').innerHTML=`
      <div class="kpi"><div class="lbl">Total Invoiced</div><div class="val">$${(inv.total_invoiced||0).toLocaleString()}</div></div>
      <div class="kpi"><div class="lbl">Total Paid</div><div class="val" style="color:#2e7d32">$${(inv.total_paid||0).toLocaleString()}</div></div>
      <div class="kpi"><div class="lbl">Outstanding</div><div class="val" style="color:#e65100">$${(inv.outstanding||0).toLocaleString()}</div></div>
      <div class="kpi"><div class="lbl">Overdue</div><div class="val" style="color:#c62828">${inv.overdue||0}</div></div>
      <div class="kpi"><div class="lbl">In Range</div><div class="val">${inv.this_month||0} invoices</div></div>`;
    // Monthly chart
    const months=d.monthly_revenue||[];
    makeChart('chartRevenue','bar',months.map(m=>m.month),[{label:'Revenue',data:months.map(m=>m.revenue),backgroundColor:'#A5CE3A',borderRadius:4}]);
    // Job type chart — F-013: use the dedicated /reporting/jobs-by-type/
    // endpoint (counts all appointments in the period, not just completed)
    // so the chart reflects the actual job mix instead of just the one or
    // two rows where status='completed'.
    try{
      const jt=await api('/reporting/jobs-by-type/?period=month');
      if(Array.isArray(jt)&&jt.length){
        // F-047: keep every sector with count>0; cycle COLORS if we have
        // more sectors than palette entries so the last slice always
        // gets a colour (Chart.js skips slices with undefined fill).
        const rows=jt.filter(j=>(j.count||0)>0);
        if(rows.length){
          const palette=rows.map((_,i)=>COLORS[i%COLORS.length]);
          makeChart('chartJobType','doughnut',rows.map(j=>j.name||'Unknown'),
            [{data:rows.map(j=>j.count),backgroundColor:palette}]);
        }
      }
    }catch(_){}
  }catch(e){console.error('Revenue report error',e);}
}

async function loadCustomers(){
  try{
    const q=getTabFilterQuery('customers');
    document.getElementById('custExportCsv').href=_exportUrl('/api/v1/billing/reports/customers/','customers','csv');
    document.getElementById('custExportXlsx').href=_exportUrl('/api/v1/billing/reports/customers/','customers','xlsx');
    document.getElementById('custExportPdf').href=_exportUrl('/api/v1/billing/reports/customers/','customers','pdf');
    const d=await api('/billing/reports/customers/'+q);
    document.getElementById('custKPIs').innerHTML=`
      <div class="kpi"><div class="lbl">Total Customers</div><div class="val">${d.total}</div></div>
      <div class="kpi"><div class="lbl">Residential</div><div class="val">${d.by_type?.residential||0}</div></div>
      <div class="kpi"><div class="lbl">Commercial</div><div class="val">${d.by_type?.commercial||0}</div></div>`;
    const months=d.monthly_growth||[];
    makeChart('chartCustGrowth','line',months.map(m=>m.month),[{label:'New Customers',data:months.map(m=>m.new_customers),borderColor:'#A5CE3A',backgroundColor:'rgba(165,206,58,0.1)',fill:true,tension:.3}]);
    const types=d.by_type||{};
    makeChart('chartCustType','pie',Object.keys(types).map(k=>k.charAt(0).toUpperCase()+k.slice(1)),
      [{data:Object.values(types),backgroundColor:['#2196F3','#FF9800']}]);
  }catch(e){}
}

async function loadTechnicians(){
  try{
    const q=getTabFilterQuery('technicians');
    document.getElementById('techExportCsv').href=_exportUrl('/api/v1/billing/reports/technicians/','technicians','csv');
    document.getElementById('techExportXlsx').href=_exportUrl('/api/v1/billing/reports/technicians/','technicians','xlsx');
    document.getElementById('techExportPdf').href=_exportUrl('/api/v1/billing/reports/technicians/','technicians','pdf');
    const d=await api('/billing/reports/technicians/'+q);
    const techs=d.technicians||[];
    // Populate tech select if not already populated (use all-technicians response)
    if(!getTabFilterQuery('technicians').includes('tech_id')){
      const sel=document.getElementById('filterTechId');
      if(sel&&sel.options.length<=1&&techs.length){
        techs.forEach(t=>{
          const opt=document.createElement('option');
          opt.value=t.id;opt.textContent=t.name;
          sel.appendChild(opt);
        });
      }
    }
    if(techs.length){
      makeChart('chartTechProd','bar',techs.map(t=>t.name),
        [{label:'Total Jobs',data:techs.map(t=>t.total_jobs),backgroundColor:'#A5CE3A',borderRadius:4},
         {label:'In Range',data:techs.map(t=>t.month_jobs),backgroundColor:'#2196F3',borderRadius:4}]);
      document.getElementById('techBody').innerHTML=techs.map(t=>`<tr><td><strong>${t.name}</strong></td><td>${t.total_jobs}</td><td>${t.month_jobs}</td><td>${t.month_scheduled}</td><td>${Math.round(t.avg_duration)} min</td></tr>`).join('');
    }
  }catch(e){}
}

async function loadLeads(){
  try{
    const q=getTabFilterQuery('leads');
    document.getElementById('leadExportCsv').href=_exportUrl('/api/v1/billing/reports/leads/','leads','csv');
    document.getElementById('leadExportXlsx').href=_exportUrl('/api/v1/billing/reports/leads/','leads','xlsx');
    document.getElementById('leadExportPdf').href=_exportUrl('/api/v1/billing/reports/leads/','leads','pdf');
    const d=await api('/billing/reports/leads/'+q);
    document.getElementById('leadKPIs').innerHTML=`
      <div class="kpi"><div class="lbl">Total Leads</div><div class="val">${d.total}</div></div>
      <div class="kpi"><div class="lbl">Avg Deal Value</div><div class="val">$${(d.avg_value||0).toLocaleString()}</div></div>`;
    const months=d.monthly_funnel||[];
    makeChart('chartLeadFunnel','line',months.map(m=>m.month),
      [{label:'New',data:months.map(m=>m.new),borderColor:'#2196F3',tension:.3},
       {label:'Won',data:months.map(m=>m.won),borderColor:'#4CAF50',tension:.3},
       {label:'Lost',data:months.map(m=>m.lost),borderColor:'#F44336',tension:.3}]);
    const src=d.by_source||[];
    if(src.length)makeChart('chartLeadSource','bar',src.map(s=>s.name||'Unknown'),
      [{label:'Total',data:src.map(s=>s.total),backgroundColor:'#2196F3',borderRadius:4},
       {label:'Won',data:src.map(s=>s.won),backgroundColor:'#4CAF50',borderRadius:4},
       {label:'Lost',data:src.map(s=>s.lost),backgroundColor:'#F44336',borderRadius:4}]);
  }catch(e){}
}

async function loadCommercial(){
  try{
    const q=getTabFilterQuery('commercial');
    document.getElementById('commExportCsv').href=_exportUrl('/api/v1/billing/reports/commercial/','commercial','csv');
    document.getElementById('commExportXlsx').href=_exportUrl('/api/v1/billing/reports/commercial/','commercial','xlsx');
    document.getElementById('commExportPdf').href=_exportUrl('/api/v1/billing/reports/commercial/','commercial','pdf');
    const d=await api('/billing/reports/commercial/'+q);
    const k=d.kpis||{};
    const fmt=n=>(n||0).toLocaleString(undefined,{maximumFractionDigits:0});
    const diff=(k.avg_ticket-k.avg_ticket_residential);
    const diffPct=k.avg_ticket_residential?Math.round((diff/k.avg_ticket_residential)*100):0;
    const diffStr=k.avg_ticket_residential?` (${diff>=0?'+':''}${diffPct}% vs res.)`:'';
    document.getElementById('commKPIs').innerHTML=`
      <div class="kpi"><div class="lbl">Active Accounts</div><div class="val">${k.active_accounts||0}</div><div class="sub">of ${k.total_accounts||0} total</div></div>
      <div class="kpi"><div class="lbl">Service Locations</div><div class="val">${k.service_locations||0}</div></div>
      <div class="kpi"><div class="lbl">Revenue</div><div class="val" style="color:#2e7d32">$${fmt(k.revenue_12mo)}</div></div>
      <div class="kpi"><div class="lbl">Last 30 Days</div><div class="val">$${fmt(k.revenue_30d)}</div></div>
      <div class="kpi"><div class="lbl">Avg Ticket</div><div class="val">$${fmt(k.avg_ticket)}</div><div class="sub">${diffStr}</div></div>
      <div class="kpi"><div class="lbl">Outstanding</div><div class="val" style="color:#e65100">$${fmt(k.outstanding)}</div></div>`;
    // Monthly chart
    const mo=d.monthly_revenue||[];
    makeChart('chartCommRev','bar',mo.map(m=>m.month),[{label:'Revenue',data:mo.map(m=>m.revenue),backgroundColor:'#9C27B0',borderRadius:4}]);
    // Property type pie
    const pt=d.by_property_type||[];
    if(pt.length)makeChart('chartCommProp','doughnut',pt.map(p=>p.label),
      [{data:pt.map(p=>p.revenue_12mo),backgroundColor:COLORS.slice(0,pt.length)}]);
    // Top accounts table
    const ta=d.top_accounts||[];
    document.getElementById('commTopBody').innerHTML=ta.length?ta.map(a=>`<tr><td><a href="/customers/?id=${a.id}" style="color:var(--accent);font-weight:600">${a.name}</a></td><td>${a.property_type}</td><td>${a.invoice_count}</td><td style="text-align:right"><strong>$${fmt(a.revenue_12mo)}</strong></td></tr>`).join(''):`<tr><td colspan="4" style="text-align:center;color:var(--text-light);padding:20px">No commercial revenue in selected range</td></tr>`;
    // Property type breakdown table
    document.getElementById('commPropBody').innerHTML=pt.length?pt.map(p=>`<tr><td><strong>${p.label}</strong></td><td>${p.accounts}</td><td style="text-align:right">$${fmt(p.revenue_12mo)}</td></tr>`).join(''):`<tr><td colspan="3" style="text-align:center;color:var(--text-light);padding:20px">No commercial accounts</td></tr>`;
  }catch(e){console.error('Commercial report error',e);}
}

document.addEventListener('DOMContentLoaded',()=>{
  loadRevenue();loadCustomers();loadTechnicians();loadLeads();loadCommercial();
  const params=new URLSearchParams(window.location.search);
  const tab=params.get('tab');
  if(tab&&VALID_TABS.includes(tab))showTab(tab,false);
});