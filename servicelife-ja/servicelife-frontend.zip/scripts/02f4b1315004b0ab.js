const API = '/api/v1';
let pageNum = 1;
const pageSize = 50;
// BUG-pagination: hasNext/hasPrev mirror the API's d.next / d.previous so
// nextPage()/prevPage() can refuse to walk off the ends. The Next/Prev
// <button>s also get a `disabled` attribute, but defending in both layers
// blocks force-clicks, stale-DOM races, and accidental console invocation.
let hasNext = false, hasPrev = false;

const escHTML = s => String(s == null ? '' : s)
  .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
  .replace(/"/g,'&quot;').replace(/'/g,'&#39;');

async function api(path){
  const r = await fetch(API + path, {credentials:'same-origin'});
  if (!r.ok) throw new Error('API ' + r.status);
  return r.json();
}

function buildQuery(){
  const q = new URLSearchParams();
  q.set('page', pageNum);
  q.set('page_size', pageSize);
  const s = document.getElementById('search').value.trim();
  if (s) q.set('search', s);
  const state = document.getElementById('filterState').value;
  if (state) q.set('category__state', state);
  const status = document.getElementById('filterStatus').value;
  if (status) q.set('status', status);
  const cat = document.getElementById('filterCategory').value;
  if (cat) q.set('category', cat);
  const tech = document.getElementById('filterTechnician').value;
  if (tech) q.set('technician', tech);
  return q.toString();
}

function bandClass(band){
  // Maps the serializer's status_band string to a badge class.
  if (band === 'expired_active' || band === 'expired') return 'badge-red';
  if (band === 'expiring_30') return 'badge-red';
  if (band === 'expiring_60') return 'badge-orange';
  if (band === 'expiring_90') return 'badge-gray';
  if (band === 'active') return 'badge-green';
  return 'badge-purple';  // suspended / revoked / pending
}

function bandLabel(band, daysLeft, status){
  if (status !== 'active') return status.charAt(0).toUpperCase() + status.slice(1);
  if (daysLeft == null) return 'Active';
  if (daysLeft < 0) return 'Expired (' + (-daysLeft) + 'd)';
  if (daysLeft <= 30) return 'Expires in ' + daysLeft + 'd';
  if (daysLeft <= 60) return 'Expires in ' + daysLeft + 'd';
  if (daysLeft <= 90) return 'Expires in ' + daysLeft + 'd';
  return 'Active (' + daysLeft + 'd)';
}

async function loadData(){
  try{
    const d = await api('/compliance/licenses/?' + buildQuery());
    const tbody = document.getElementById('tableBody');
    if (!d.results || d.results.length === 0){
      tbody.innerHTML = '<tr><td colspan="8"><div class="empty-state"><i class="fas fa-inbox"></i><p>No licenses match these filters.</p></div></td></tr>';
      document.getElementById('pagination').style.display = 'none';
      document.getElementById('licCount').textContent = '0 licenses';
      return;
    }
    tbody.innerHTML = d.results.map(r => {
      const cls = bandClass(r.status_band);
      const lbl = bandLabel(r.status_band, r.days_until_expiration, r.status);
      const days = r.days_until_expiration == null ? '—' :
                   r.days_until_expiration < 0 ? '<span style="color:#c62828;font-weight:600">' + r.days_until_expiration + '</span>' :
                   r.days_until_expiration;
      return '<tr>' +
        '<td>' + escHTML(r.technician_name) + '</td>' +
        '<td>' + escHTML(r.state) + ' &middot; ' + escHTML(r.license_number) + '</td>' +
        '<td>' + escHTML(r.category_label) + '</td>' +
        '<td>' + escHTML(r.license_tier_display || r.license_tier) + '</td>' +
        '<td>' + escHTML(r.expires_at || '—') + '</td>' +
        '<td>' + days + '</td>' +
        '<td><span class="badge ' + cls + '">' + escHTML(lbl) + '</span></td>' +
        '<td><a class="renew-link" href="' + escHTML(r.admin_url) + '">Renew / Edit &rsaquo;</a></td>' +
      '</tr>';
    }).join('');
    document.getElementById('licCount').textContent = d.count + ' license' + (d.count === 1 ? '' : 's');
    renderPagination(d);
  }catch(e){
    console.error('License list load error', e);
    document.getElementById('tableBody').innerHTML = '<tr><td colspan="8"><div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Could not load licenses.</p></div></td></tr>';
  }
}

function renderPagination(d){
  const el = document.getElementById('pagination');
  const totalPages = Math.max(1, Math.ceil(d.count / pageSize));
  hasNext = !!d.next;
  hasPrev = !!d.previous;
  if (d.count <= pageSize){ el.style.display = 'none'; return; }
  el.style.display = 'flex';
  el.innerHTML =
    '<button onclick="prevPage()" ' + (d.previous ? '' : 'disabled') + '>&laquo; Prev</button>' +
    '<span class="summary">Page ' + pageNum + ' of ' + totalPages + ' &middot; ' + d.count + ' total</span>' +
    '<button onclick="nextPage()" ' + (d.next ? '' : 'disabled') + '>Next &raquo;</button>';
}
function prevPage(){ if (hasPrev && pageNum > 1){ pageNum -= 1; loadData(); } }
function nextPage(){ if (hasNext){ pageNum += 1; loadData(); } }
function loadDataReset(){ pageNum = 1; loadData(); }

async function loadFilters(){
  // Categories — the regulatory taxonomy is shared, not tenant-scoped. We
  // expose the dropdown by harvesting categories that already appear on
  // this tenant's licenses (server-side ordering), keeping the list short
  // and relevant. Falls back gracefully if the response is empty.
  try{
    const d = await api('/compliance/licenses/?page_size=200');
    const seenCat = new Map();
    const seenTech = new Map();
    (d.results || []).forEach(r => {
      if (r.category_id && !seenCat.has(r.category_id)) seenCat.set(r.category_id, r.category_label);
      if (r.technician_id && !seenTech.has(r.technician_id)) seenTech.set(r.technician_id, r.technician_name);
    });
    const catSel = document.getElementById('filterCategory');
    [...seenCat.entries()].sort((a,b)=>a[1].localeCompare(b[1])).forEach(([id,lbl])=>{
      const o = document.createElement('option'); o.value = id; o.textContent = lbl; catSel.appendChild(o);
    });
    const techSel = document.getElementById('filterTechnician');
    [...seenTech.entries()].sort((a,b)=>a[1].localeCompare(b[1])).forEach(([id,nm])=>{
      const o = document.createElement('option'); o.value = id; o.textContent = nm; techSel.appendChild(o);
    });
  }catch(e){ /* filters degrade silently */ }
}

const CSRF = '';
function openAddLic(){ var e=document.getElementById('addLicError'); if(e){e.style.display='none';} var ov=document.getElementById('addLicOverlay'); if(ov){ov.style.display='flex'; alTierChange();} }
function closeAddLic(){ var ov=document.getElementById('addLicOverlay'); if(ov){ov.style.display='none';} }
function alTierChange(){ var t=document.getElementById('al-tier'); var f=document.getElementById('al-supervisor-field'); if(t&&f){ f.style.display=(t.value==='registered_technician')?'flex':'none'; } }
function alShowErr(msg){ var e=document.getElementById('addLicError'); if(e){ e.textContent=msg; e.style.display='block'; } }
function alFmtErr(data, st){
  if(!data) return 'Could not add license (HTTP '+st+').';
  if(data.detail && typeof data.detail==='object'){ return Object.entries(data.detail).map(function(kv){return kv[0]+': '+(Array.isArray(kv[1])?kv[1].join(' '):kv[1]);}).join('  |  '); }
  if(data.detail) return data.detail;
  if(typeof data==='object'){ var parts=Object.entries(data).filter(function(kv){return kv[0]!=='error';}).map(function(kv){return kv[0]+': '+(Array.isArray(kv[1])?kv[1].join(' '):kv[1]);}); if(parts.length) return parts.join('  |  '); }
  return data.error || ('HTTP '+st);
}
async function submitAddLic(){
  var tier=document.getElementById('al-tier').value;
  var payload={
    technician:document.getElementById('al-technician').value,
    category:document.getElementById('al-category').value,
    license_tier:tier,
    license_number:document.getElementById('al-number').value.trim(),
    issued_at:document.getElementById('al-issued').value,
    expires_at:document.getElementById('al-expires').value,
    status:document.getElementById('al-status').value || 'active',
    notes:document.getElementById('al-notes').value.trim()
  };
  var sup=document.getElementById('al-supervisor').value;
  if(sup) payload.supervisor=sup;
  var missing=[];
  if(!payload.technician) missing.push('technician');
  if(!payload.category) missing.push('category');
  if(!payload.license_number) missing.push('license number');
  if(!payload.issued_at) missing.push('issued date');
  if(!payload.expires_at) missing.push('expiration date');
  if(tier==='registered_technician' && !payload.supervisor) missing.push('supervisor');
  if(missing.length){ alShowErr('Please fill in: '+missing.join(', ')+'.'); return; }
  var btn=document.getElementById('al-submit'); btn.disabled=true; btn.textContent='Adding...';
  try{
    var r=await fetch(API+'/compliance/licenses/create/', {
      method:'POST',
      headers:{'Content-Type':'application/json','X-CSRFToken':CSRF,'Accept':'application/json'},
      credentials:'same-origin',
      body:JSON.stringify(payload)
    });
    if(r.status===201){
      closeAddLic();
      ['al-technician','al-category','al-number','al-issued','al-expires','al-notes','al-supervisor'].forEach(function(id){var el=document.getElementById(id); if(el) el.value='';});
      var sf=document.getElementById('al-supervisor-field'); if(sf) sf.style.display='none';
      loadDataReset();
    } else {
      var data=await r.json().catch(function(){return {};});
      alShowErr(alFmtErr(data, r.status));
    }
  } catch(e){ alShowErr('Network error: '+e.message); }
  finally{ btn.disabled=false; btn.textContent='Add License'; }
}
document.addEventListener('DOMContentLoaded', () => {
  loadFilters();
  loadData();
});