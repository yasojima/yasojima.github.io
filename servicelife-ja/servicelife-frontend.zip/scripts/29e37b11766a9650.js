(function(){
    if (window.__cbpModalHistoryShim) return;
    window.__cbpModalHistoryShim = true;

    var OVERLAY_SEL = '.modal-overlay, .modal-bg, .b9-modal-overlay, .appt-modal, .bp-modal, .cd-modal-bg';
    var SHOW_CLS    = ['show','open','is-open','active'];
    function hasShow(el){ return SHOW_CLS.some(function(c){ return el.classList.contains(c); }); }
    function hadShow(v){
      if (!v) return false;
      var old = v.split(/\s+/);
      return SHOW_CLS.some(function(c){ return old.indexOf(c) !== -1; });
    }
    function onOpen(){
      if (history.state && history.state.cbpModal) return;
      history.pushState({ cbpModal: true }, '', window.location.href);
    }
    function onClose(){
      if (history.state && history.state.cbpModal)
        history.replaceState(null, '', window.location.href);
    }
    var mo = new MutationObserver(function(mutations){
      mutations.forEach(function(m){
        if (m.type !== 'attributes' || m.attributeName !== 'class') return;
        var el = m.target;
        if (!el.matches(OVERLAY_SEL)) return;
        var was = hadShow(m.oldValue), is = hasShow(el);
        if (!was && is)  onOpen();
        if (was  && !is) onClose();
      });
    });
    function observe(root){
      root.querySelectorAll(OVERLAY_SEL).forEach(function(el){
        mo.observe(el, { attributes: true, attributeOldValue: true });
      });
    }
    // Watch for overlays dynamically added to DOM (SPA swaps)
    var domObs = new MutationObserver(function(mutations){
      mutations.forEach(function(m){
        m.addedNodes.forEach(function(n){
          if (n.nodeType !== 1) return;
          if (n.matches && n.matches(OVERLAY_SEL))
            mo.observe(n, { attributes: true, attributeOldValue: true });
          if (n.querySelectorAll) n.querySelectorAll(OVERLAY_SEL).forEach(function(el){
            mo.observe(el, { attributes: true, attributeOldValue: true });
          });
        });
      });
    });
    document.addEventListener('DOMContentLoaded', function(){
      observe(document);
      domObs.observe(document.body, { childList: true, subtree: true });
    });
    // Re-scan after SPA content swap
    window.addEventListener('cbp:spa-navigated', function(){ observe(document); });
  })();