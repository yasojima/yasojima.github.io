(function(){
  function getCookie(name){
    var v=null;
    if(document.cookie){
      document.cookie.split(";").forEach(function(c){
        c=c.trim();
        if(c.substring(0,name.length+1)===(name+"=")){ v=decodeURIComponent(c.substring(name.length+1)); }
      });
    }
    return v;
  }
  var toast=document.getElementById("resendToast");
  function showToast(msg,ok){
    if(!toast)return;
    toast.textContent=msg;
    toast.className="resend-toast show "+(ok?"ok":"err");
    setTimeout(function(){ toast.className="resend-toast"; },4500);
  }
  var STATUS_LABELS={sent:"sent",queued:"queued",deferred:"queued (quiet hours, delivers ~7:30am)",blocked_dry_run:"blocked (dry-run mode is on)",no_email_on_file:"no email on file",no_phone_on_file:"no phone on file",error:"send error"};
  function label(channel,results){
    var s=(results||{})[channel];
    return STATUS_LABELS[s]||s||"done";
  }
  document.addEventListener("click",function(e){
    var btn=e.target.closest(".resend-btn");
    if(!btn)return;
    var invoiceId=btn.getAttribute("data-invoice-id");
    var channel=btn.getAttribute("data-channel");
    if(!invoiceId||!channel)return;
    var orig=btn.textContent;
    btn.disabled=true; btn.textContent="Sending...";
    fetch("/api/v1/billing/resend-invoice-link/",{
      method:"POST",
      headers:{"Content-Type":"application/json","X-CSRFToken":getCookie("csrftoken")||""},
      credentials:"same-origin",
      body:JSON.stringify({invoice_id:invoiceId,channel:channel})
    }).then(function(resp){
      return resp.json().then(function(data){ return {ok:resp.ok,data:data}; }).catch(function(){ return {ok:resp.ok,data:{}}; });
    }).then(function(o){
      var d=o.data||{};
      var who=(channel==="sms")?"Text":"Email";
      if(o.ok && d.success){ showToast(who+" "+label(channel,d.results),true); }
      else { showToast("Could not send: "+((d.results&&label(channel,d.results))||d.error||"failed"),false); }
    }).catch(function(){
      showToast("Network error sending link",false);
    }).then(function(){
      btn.disabled=false; btn.textContent=orig;
    });
  });
})();