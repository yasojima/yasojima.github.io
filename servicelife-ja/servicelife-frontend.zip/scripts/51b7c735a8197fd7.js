(function(){
  // Shares PM_CUSTOMER_ID via the API path. We read customer_id again
  // from the template to keep this script independent of the IIFE above.
  var PM_CUSTOMER_ID = "cf629a6f-6f2a-481b-acf6-4d2400df76f4";

  // Cached config block from the most recent list-payment-methods call.
  // Repopulated by cdPmCacheConfig() inside the existing list handler
  // (wired below via a wrapper around cdLoadPaymentMethods).
  var PM_CONFIG = null;

  // Active add-card session state.
  var ADD_PROVIDER = null;        // 'stripe' | 'square'
  var ADD_TOKEN = '';             // produced by SDK tokenization
  var ADD_BUSY = false;           // POST in flight
  var STRIPE_HANDLE = null;       // Stripe(...) instance
  var STRIPE_CARD = null;         // Stripe Elements card element
  var SQUARE_CARD = null;         // Square card form
  var SDK_LOAD_PROMISES = {};     // memoized {provider: Promise<void>}

  function pmCsrf(){
    return (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';
  }

  function pmToast(msg, kind){
    if (typeof toast === 'function'){ toast(msg, kind); return; }
    // Fallback: noop. Customer detail page exposes toast() globally.
  }

  // ---------- SDK lazy-loaders ----------
  // We don't ship Stripe.js / Square.js on every customer page load.
  // Loaded on demand the first time an operator opens the Add modal.

  function loadScript(src){
    return new Promise(function(resolve, reject){
      // De-dupe — if a tag with this src already exists and loaded, resolve.
      var existing = document.querySelector('script[src="' + src + '"]');
      if (existing){
        if (existing.dataset.loaded === '1') return resolve();
        existing.addEventListener('load', function(){ resolve(); });
        existing.addEventListener('error', function(){ reject(new Error('failed: ' + src)); });
        return;
      }
      var s = document.createElement('script');
      s.src = src;
      s.async = true;
      s.onload = function(){ s.dataset.loaded = '1'; resolve(); };
      s.onerror = function(){ reject(new Error('failed: ' + src)); };
      document.head.appendChild(s);
    });
  }

  function loadStripeSdk(){
    if (SDK_LOAD_PROMISES.stripe) return SDK_LOAD_PROMISES.stripe;
    if (window.Stripe){ SDK_LOAD_PROMISES.stripe = Promise.resolve(); return SDK_LOAD_PROMISES.stripe; }
    SDK_LOAD_PROMISES.stripe = loadScript('https://js.stripe.com/v3/');
    return SDK_LOAD_PROMISES.stripe;
  }

  function loadSquareSdk(env){
    if (SDK_LOAD_PROMISES.square) return SDK_LOAD_PROMISES.square;
    // Reuse an already-present SDK (the page's static square.js for Take
    // Payment). Re-loading hits loadScript's de-dupe which waits for a 'load'
    // event that already fired on the static tag, hanging the mount.
    if (window.Square){ SDK_LOAD_PROMISES.square = Promise.resolve(); return SDK_LOAD_PROMISES.square; }
    var host = (env === 'production') ? 'web.squarecdn.com' : 'sandbox.web.squarecdn.com';
    SDK_LOAD_PROMISES.square = loadScript('https://' + host + '/v1/square.js');
    return SDK_LOAD_PROMISES.square;
  }

  // ---------- Config cache + Add-button rendering ----------
  // We hook into the existing cdLoadPaymentMethods so we get a fresh
  // config block on every refresh without duplicating fetch logic.

  window.cdPmCacheConfig = function(config){
    PM_CONFIG = config || null;
    renderAddBar();
  };

  function renderAddBar(){
    // Inject an Add bar at the TOP of cdPmContent. Re-running is fine —
    // we replace the existing element if already present.
    var box = document.getElementById('cdPmContent');
    if (!box) return;
    var bar = document.getElementById('cdPmAddBar');
    if (bar) bar.remove();

    if (!PM_CONFIG){
      return; // Config block missing from API response (older backend?)
    }

    var stripeOk = PM_CONFIG.stripe && PM_CONFIG.stripe.enabled;
    var squareOk = PM_CONFIG.square && PM_CONFIG.square.enabled;
    if (!stripeOk && !squareOk){
      // Tenant has nothing configured — render a hint.
      bar = document.createElement('div');
      bar.id = 'cdPmAddBar';
      bar.className = 'cd-pm-addbar';
      bar.innerHTML = '<span style="font-size:12px;color:var(--text-light)">' +
        '<i class="fas fa-info-circle"></i> No payment gateway is configured for this tenant. ' +
        'Configure Stripe or Square in billing settings to enable card storage.' +
        '</span>';
      box.insertBefore(bar, box.firstChild);
      return;
    }

    bar = document.createElement('div');
    bar.id = 'cdPmAddBar';
    bar.className = 'cd-pm-addbar';
    var parts = [];
    if (stripeOk){
      parts.push('<button type="button" class="cd-pm-addbtn" onclick="cdPmOpenAddModal(\'stripe\')">' +
                 '<i class="fas fa-plus"></i> Add Stripe card</button>');
    }
    if (squareOk){
      parts.push('<button type="button" class="cd-pm-addbtn square" onclick="cdPmOpenAddModal(\'square\')">' +
                 '<i class="fas fa-plus"></i> Add Square card</button>');
    }
    bar.innerHTML = parts.join('');
    box.insertBefore(bar, box.firstChild);
  }

  // Wrap cdLoadPaymentMethods to capture config every reload.
  // Original function lives on window.cdLoadPaymentMethods.
  var ORIGINAL_LOAD = window.cdLoadPaymentMethods;
  window.cdLoadPaymentMethods = async function(){
    // Mirror the original fetch so we can also stash config. We can't
    // just call ORIGINAL_LOAD without losing the response payload, so
    // re-implement the slim version here. This stays in sync with the
    // backend list endpoint shape (stripe / square / config).
    var box = document.getElementById('cdPmContent');
    if (!box){ return; }
    box.innerHTML = '<div class="cd-loading"><i class="fas fa-spinner fa-spin"></i> Loading payment methods...</div>';
    try {
      var r = await fetch('/api/v1/billing/admin/customers/' + PM_CUSTOMER_ID + '/payment-methods/', {
        method: 'GET', credentials: 'same-origin',
        headers: {'X-CSRFToken': pmCsrf(), 'Content-Type': 'application/json'},
      });
      if (!r.ok){
        if (r.status === 403) {
          var section = document.getElementById('cdPmSection');
          if (section) section.style.display = 'none';
          return;
        }
        box.innerHTML = '<div class="cd-empty">Could not load payment methods (HTTP ' + r.status + ').</div>';
        return;
      }
      var data = await r.json();
      // Cache config FIRST so renderAddBar can run after rows render.
      cdPmCacheConfig(data.config || null);

      // Hand the rest of the rendering back to the original logic by
      // synthesizing the same shape it expects. We re-run its row HTML
      // builders directly. But since those helpers live inside the
      // IIFE closure above, we instead just rebuild the rows here with
      // the public table helpers exposed on window-scope.
      var stripe = data.stripe || [];
      var square = data.square || [];

      var html = '';
      html += '<div style="margin-bottom:14px"><div style="font-size:12px;font-weight:600;color:var(--text-light);margin-bottom:6px">Stripe</div>';
      if (stripe.length){
        html += renderRowsTable('stripe', stripe);
      } else {
        html += '<div class="cd-pm-empty">No Stripe cards on file.</div>';
      }
      html += '</div>';

      html += '<div><div style="font-size:12px;font-weight:600;color:var(--text-light);margin-bottom:6px">Square</div>';
      if (square.length){
        html += renderRowsTable('square', square);
      } else {
        html += '<div class="cd-pm-empty">No Square cards on file.</div>';
      }
      html += '</div>';

      box.innerHTML = html;
      // Re-insert the Add bar AFTER row HTML has been written.
      renderAddBar();
    } catch (e){
      box.innerHTML = '<div class="cd-empty">Network error loading payment methods.</div>';
    }
  };

  // Lightweight row table — keeps the same column layout the original
  // IIFE renders. We can't reach into its closure helpers, so this is a
  // small duplication, but the columns are stable.
  function rowsEsc(s){
    if (s === null || s === undefined) return '';
    return String(s).replace(/[&<>"']/g, function(c){
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c];
    });
  }
  function rowsFmtExp(month, year){
    if (!month || !year) return '';
    return String(month).padStart(2,'0') + '/' + String(year).slice(-2);
  }
  function rowsIsExpired(month, year){
    if (!month || !year) return false;
    var now = new Date();
    var y = parseInt(year, 10), m = parseInt(month, 10);
    if (y < now.getFullYear()) return true;
    if (y === now.getFullYear() && m < (now.getMonth() + 1)) return true;
    return false;
  }
  function renderRowsTable(provider, rows){
    if (!rows.length) return '';
    var head = '<table class="cd-table"><thead><tr>' +
      '<th>Card</th><th>Expires</th><th>Status</th><th>Recurring use</th><th></th>' +
      '</tr></thead><tbody>';
    var body = rows.map(function(pm){
      var brand, last4, expMonth, expYear;
      if (provider === 'stripe'){
        brand = pm.brand || pm.payment_type || 'card';
        last4 = pm.last4 || '****';
        expMonth = pm.exp_month; expYear = pm.exp_year;
      } else {
        brand = pm.card_brand || 'card';
        last4 = pm.last_four || '****';
        expMonth = pm.exp_month; expYear = pm.exp_year;
      }
      var exp = rowsFmtExp(expMonth, expYear);
      var expCls = rowsIsExpired(expMonth, expYear) ? 'cd-pm-bad' : '';
      var label = (brand || '').toUpperCase() + ' ****' + last4;
      var badges = [];
      if (pm.is_default) badges.push('<span class="badge b-green">Default</span>');
      if (pm.is_active === false) badges.push('<span class="badge b-grey">Inactive</span>');
      var inUse = (pm.recurring_schedule_ids && pm.recurring_schedule_ids.length) || 0;
      var actions = '';
      if (pm.is_active !== false){
        if (!pm.is_default){
          actions += '<button type="button" onclick="cdMakePmDefault(\'' + provider + '\',\'' + pm.id + '\')">Make default</button>';
        }
        actions += '<button type="button" class="danger" onclick="cdConfirmDetachPm(\'' + provider + '\',\'' + pm.id + '\',\'' + rowsEsc(label) + '\',' + inUse + ')">Detach</button>';
      }
      return '<tr>' +
        '<td><strong>' + rowsEsc(brand.toUpperCase()) + '</strong> ****' + rowsEsc(last4) + '</td>' +
        '<td' + (expCls ? ' class="' + expCls + '"' : '') + '>' + rowsEsc(exp || '--') + (expCls ? ' (expired)' : '') + '</td>' +
        '<td>' + badges.join(' ') + '</td>' +
        '<td>' + (inUse > 0 ? '<span class="cd-pm-warn">' + inUse + ' recurring</span>' : '<span style="color:var(--text-light)">--</span>') + '</td>' +
        '<td class="cd-pm-actions">' + actions + '</td>' +
        '</tr>';
    }).join('');
    return head + body + '</tbody></table>';
  }

  // ---------- Modal open / close ----------
  window.cdPmOpenAddModal = function(provider){
    if (!PM_CONFIG){
      pmToast('Payment config not loaded — reload the page.', 'error');
      return;
    }
    if (provider !== 'stripe' && provider !== 'square'){
      return;
    }
    if (!PM_CONFIG[provider] || !PM_CONFIG[provider].enabled){
      pmToast(provider + ' is not configured for this tenant.', 'error');
      return;
    }

    ADD_PROVIDER = provider;
    ADD_TOKEN = '';
    ADD_BUSY = false;

    var modal = document.getElementById('cdPmAddModal');
    var label = document.getElementById('cdPmAddProviderLabel');
    var shortLabel = document.getElementById('cdPmAddProviderShort');
    var err = document.getElementById('cdPmAddCardErr');
    var submit = document.getElementById('cdPmAddSubmitBtn');
    var cardholderInput = document.getElementById('cdPmAddCardholder');
    var cardEl = document.getElementById('cdPmAddCardElement');

    label.textContent = (provider === 'stripe') ? 'Stripe' : 'Square';
    shortLabel.textContent = (provider === 'stripe') ? 'Stripe' : 'Square';
    document.getElementById('cdPmAddProviderRow').style.display = '';
    err.textContent = '';
    cardholderInput.value = '';
    submit.disabled = true;
    submit.textContent = 'Save card';
    cardEl.innerHTML = '<span><i class="fas fa-spinner fa-spin"></i> &nbsp;Loading secure card form…</span>';
    cardEl.classList.add('is-loading');

    modal.classList.add('open');

    // Mount the right SDK widget. Tear down any previous instance so a
    // user who switches providers mid-flow doesn't end up with stale
    // iframes.
    teardownCardWidgets().then(function(){
      if (provider === 'stripe'){
        return mountStripe();
      }
      return mountSquare();
    }).catch(function(e){
      err.textContent = 'Card form failed to load: ' + (e && e.message ? e.message : 'unknown error');
      cardEl.classList.remove('is-loading');
      cardEl.innerHTML = '<span style="color:#c62828">Could not load card form.</span>';
    });
  };

  window.cdPmCloseAddModal = function(){
    document.getElementById('cdPmAddModal').classList.remove('open');
    teardownCardWidgets();
    ADD_PROVIDER = null;
    ADD_TOKEN = '';
  };

  async function teardownCardWidgets(){
    try { if (STRIPE_CARD && STRIPE_CARD.unmount) STRIPE_CARD.unmount(); } catch(e){}
    try { if (SQUARE_CARD && SQUARE_CARD.destroy) await SQUARE_CARD.destroy(); } catch(e){}
    STRIPE_CARD = null;
    SQUARE_CARD = null;
    var cardEl = document.getElementById('cdPmAddCardElement');
    if (cardEl) cardEl.innerHTML = '';
  }

  // ---------- Stripe Elements mount ----------
  async function mountStripe(){
    await loadStripeSdk();
    if (!window.Stripe) throw new Error('Stripe SDK did not initialize');
    var pk = PM_CONFIG.stripe.publishable_key;
    if (!pk) throw new Error('No Stripe publishable key configured');
    STRIPE_HANDLE = STRIPE_HANDLE || window.Stripe(pk);
    var elements = STRIPE_HANDLE.elements();
    STRIPE_CARD = elements.create('card');

    var cardEl = document.getElementById('cdPmAddCardElement');
    cardEl.classList.remove('is-loading');
    cardEl.innerHTML = '';
    STRIPE_CARD.mount(cardEl);

    var err = document.getElementById('cdPmAddCardErr');
    var submit = document.getElementById('cdPmAddSubmitBtn');
    STRIPE_CARD.on('change', function(event){
      err.textContent = (event.error && event.error.message) || '';
      submit.disabled = !(event.complete);
    });
  }

  // ---------- Square Web Payments mount ----------
  async function mountSquare(){
    var env = PM_CONFIG.square.environment || 'sandbox';
    await loadSquareSdk(env);
    if (!window.Square) throw new Error('Square SDK did not initialize');
    var appId = PM_CONFIG.square.application_id;
    var locId = PM_CONFIG.square.location_id;
    if (!appId || !locId) throw new Error('Square application/location id missing');
    var payments = window.Square.payments(appId, locId);
    SQUARE_CARD = await payments.card();
    var cardEl = document.getElementById('cdPmAddCardElement');
    cardEl.classList.remove('is-loading');
    cardEl.innerHTML = '';
    await SQUARE_CARD.attach(cardEl);

    // Square doesn't expose a 'complete' event we can use to enable the
    // Save button before tokenize, so enable it on focus/blur.
    var submit = document.getElementById('cdPmAddSubmitBtn');
    submit.disabled = false;
  }

  // ---------- Submit ----------
  window.cdPmSubmitAdd = async function(){
    if (ADD_BUSY || !ADD_PROVIDER) return;
    var err = document.getElementById('cdPmAddCardErr');
    var submit = document.getElementById('cdPmAddSubmitBtn');
    var cardholder = (document.getElementById('cdPmAddCardholder').value || '').trim();
    err.textContent = '';

    ADD_BUSY = true;
    submit.disabled = true;
    submit.textContent = 'Saving…';

    try {
      // Tokenize.
      var token = '';
      if (ADD_PROVIDER === 'stripe'){
        if (!STRIPE_HANDLE || !STRIPE_CARD){
          throw new Error('Stripe form not ready');
        }
        var res = await STRIPE_HANDLE.createPaymentMethod({ type: 'card', card: STRIPE_CARD });
        if (res.error){
          err.textContent = res.error.message || 'Could not save card.';
          ADD_BUSY = false; submit.disabled = false; submit.textContent = 'Save card';
          return;
        }
        token = res.paymentMethod && res.paymentMethod.id;
      } else {
        if (!SQUARE_CARD){
          throw new Error('Square form not ready');
        }
        var sqRes = await SQUARE_CARD.tokenize();
        if (sqRes.status !== 'OK'){
          var msg = (sqRes.errors && sqRes.errors[0] && sqRes.errors[0].message) || 'Could not save card.';
          err.textContent = msg;
          ADD_BUSY = false; submit.disabled = false; submit.textContent = 'Save card';
          return;
        }
        token = sqRes.token;
      }

      if (!token){
        err.textContent = 'Card form did not return a token. Please retry.';
        ADD_BUSY = false; submit.disabled = false; submit.textContent = 'Save card';
        return;
      }

      // POST to backend.
      var body = { provider: ADD_PROVIDER, card_token: token };
      if (cardholder) body.cardholder_name = cardholder;

      var r = await fetch('/api/v1/billing/admin/customers/' + PM_CUSTOMER_ID + '/payment-methods/add/', {
        method: 'POST', credentials: 'same-origin',
        headers: {'X-CSRFToken': pmCsrf(), 'Content-Type': 'application/json'},
        body: JSON.stringify(body),
      });
      var data = await r.json().catch(function(){ return {}; });
      if (!r.ok){
        // 402 = card declined, 400 = bad request, 502/503 = gateway down
        err.textContent = data.error || ('Could not save card (HTTP ' + r.status + ').');
        ADD_BUSY = false; submit.disabled = false; submit.textContent = 'Save card';
        return;
      }

      // Success — close modal, refresh list, toast.
      pmToast('Card added on file.');
      cdPmCloseAddModal();
      if (typeof cdLoadPaymentMethods === 'function') cdLoadPaymentMethods();
    } catch (e){
      err.textContent = 'Unexpected error: ' + (e && e.message ? e.message : 'please retry');
      ADD_BUSY = false; submit.disabled = false; submit.textContent = 'Save card';
    }
  };
})();