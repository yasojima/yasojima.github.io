// ── KPI tile trend modal ────────────────────────────────────────────────
// Any tile with data-trend (scheduling grid) opens this; the operator KPI
// partial calls window.openKpiTrend(slug) for its supported tiles too. Series
// come from /dashboard/drilldown/trend/?metric=<slug>. Chart.js is lazy-loaded
// on first open so the dashboard's initial paint isn't blocked by the CDN.
(function(){
  var CHART_SRC='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js';
  var _chartLoading=null, _chart=null;
  // Slugs that also have a detail-table drilldown page (operator tiles).
  var HAS_TABLE={'revenue-mtd':1,'revenue-ytd':1,'ar-aging':1,'jobs-today':1,'recurring-revenue':1,
                 'active-customers':1,'route-density':1,'avg-ticket-30d':1};
  function loadChart(){
    if(typeof Chart!=='undefined')return Promise.resolve();
    if(_chartLoading)return _chartLoading;
    _chartLoading=new Promise(function(res,rej){
      var s=document.createElement('script');s.src=CHART_SRC;
      s.onload=res;s.onerror=function(){rej(new Error('chart load failed'));};
      document.head.appendChild(s);
    });
    return _chartLoading;
  }
  function accent(){
    var c=getComputedStyle(document.documentElement).getPropertyValue('--accent');
    return (c&&c.trim())||'#A5CE3A';
  }
  function fmt(unit,v){
    var n=Number(v);
    if(unit==='money')return '$'+n.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
    if(unit==='percent')return n.toFixed(1)+'%';
    if(unit==='ratio')return n.toFixed(2);
    return n.toLocaleString('en-US');
  }
  function fmtAxis(unit,v){
    var n=Number(v);
    if(unit==='money')return '$'+n.toLocaleString('en-US',{maximumFractionDigits:0});
    if(unit==='percent')return n+'%';
    if(unit==='ratio')return n.toFixed(1);
    return n.toLocaleString('en-US');
  }
  var overlay=document.getElementById('ktOverlay');
  var body=document.getElementById('ktBody');
  function close(){
    overlay.classList.remove('show');
    if(_chart){_chart.destroy();_chart=null;}
  }
  document.getElementById('ktClose').addEventListener('click',close);
  overlay.addEventListener('click',function(e){if(e.target===overlay)close();});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&overlay.classList.contains('show'))close();});

  function drawChart(d){
    var col=accent();
    if(_chart){_chart.destroy();_chart=null;}
    // Optional second series (values2/unit2/label2) on a right-hand axis,
    // e.g. recurring revenue $ (bars) + % of collected (line).
    var two=Array.isArray(d.values2);
    var datasets=[{
        label:d.label||d.title,data:d.values,yAxisID:'y',order:2,
        backgroundColor:d.kind==='bar'?col:'rgba(165,206,58,.15)',
        borderColor:col,borderWidth:2,borderRadius:d.kind==='bar'?4:0,
        pointRadius:d.kind==='bar'?0:2,tension:.25,fill:d.kind!=='bar',maxBarThickness:46
      }];
    if(two)datasets.push({type:'line',label:d.label2||'',data:d.values2,yAxisID:'y2',order:1,
        borderColor:'#1565c0',backgroundColor:'#1565c0',borderWidth:2,pointRadius:3,tension:.25,fill:false});
    var scales={
      x:{grid:{display:false},ticks:{font:{size:10},maxRotation:0,autoSkip:true,maxTicksLimit:12}},
      y:{beginAtZero:true,grid:{color:'rgba(0,0,0,.06)'},
         ticks:{font:{size:10},callback:function(v){return fmtAxis(d.unit,v);}}}
    };
    if(two)scales.y2={position:'right',beginAtZero:true,grid:{display:false},
         max:d.unit2==='percent'?100:undefined,
         ticks:{font:{size:10},callback:function(v){return fmtAxis(d.unit2,v);}}};
    _chart=new Chart(document.getElementById('ktCanvas').getContext('2d'),{
      type:d.kind==='bar'?'bar':'line',
      data:{labels:d.labels,datasets:datasets},
      options:{
        responsive:true,maintainAspectRatio:false,animation:{duration:250},
        plugins:{legend:{display:two,position:'bottom',labels:{boxWidth:12,font:{size:11}}},
          tooltip:{callbacks:{label:function(ctx){
            var u=ctx.dataset.yAxisID==='y2'?d.unit2:d.unit;
            return (two?ctx.dataset.label+': ':'')+fmt(u,ctx.parsed.y);}}}},
        scales:scales
      }
    });
  }
  function applyMeta(d){
    document.getElementById('ktTitle').textContent=d.title||'Trend';
    document.getElementById('ktSub').textContent=d.subtitle||'';
    var note=document.getElementById('ktNote'); if(note) note.textContent=d.note||'';
  }
  function spanLabel(d){
    var el=document.getElementById('ktSpanLabel');
    if(el) el.textContent='last '+d.span+' '+d.span_unit;
  }
  async function fetchTrend(slug,span){
    var q='/dashboard/drilldown/trend/?metric='+encodeURIComponent(slug)+(span!=null?('&span='+span):'');
    try{
      var r=await fetch(q,{credentials:'same-origin'});
      if(!r.ok)throw new Error('HTTP '+r.status);
      return await r.json();
    }catch(e){
      body.innerHTML='<div class="kt-loading">Could not load this trend ('+(e.message||e)+').</div>';
      return null;
    }
  }
  var _spanTimer=null;
  window.openKpiTrend=async function(slug){
    document.getElementById('ktTitle').textContent='…';
    document.getElementById('ktSub').textContent='';
    body.innerHTML='<div class="kt-loading">Loading…</div>';
    overlay.classList.add('show');
    var d=await fetchTrend(slug,null);
    if(!d)return;
    var detail=HAS_TABLE[slug]?('<div class="kt-foot"><a class="kt-details" href="/dashboard/drilldown/'+encodeURIComponent(slug)+'/">View detail table &rarr;</a></div>'):'';
    var slider=d.adjustable?(
      '<div class="kt-slider"><div class="kt-slider-lbl">Show <span id="ktSpanLabel"></span></div>'+
      '<input type="range" id="ktSpan" min="'+d.span_min+'" max="'+d.span_max+'" value="'+d.span+'" step="1">'+
      '<div class="kt-slider-ends"><span>less</span><span>more history</span></div></div>'):'';
    body.innerHTML='<div class="kt-canvas-wrap"><canvas id="ktCanvas"></canvas></div>'+
      slider+'<div class="kt-note" id="ktNote"></div>'+detail;
    try{ await loadChart(); }
    catch(e){ body.innerHTML='<div class="kt-loading">Chart library unavailable offline.</div>'; return; }
    applyMeta(d); drawChart(d);
    if(d.adjustable){
      var sp=document.getElementById('ktSpan');
      spanLabel(d);
      sp.addEventListener('input',function(){
        spanLabel({span:+sp.value,span_unit:d.span_unit});   // instant label feedback
        clearTimeout(_spanTimer);
        _spanTimer=setTimeout(async function(){
          var nd=await fetchTrend(slug,sp.value);
          if(!nd)return;
          applyMeta(nd); drawChart(nd);
        },220);
      });
    }
  };

  // Wire scheduling kpi-grid tiles (operator tiles wire themselves via the partial).
  function onActivate(e){
    var tile=e.target.closest&&e.target.closest('.kpi[data-trend]');
    if(!tile)return;
    if(e.type==='keydown'){if(e.key!=='Enter'&&e.key!==' ')return;e.preventDefault();}
    window.openKpiTrend(tile.getAttribute('data-trend'));
  }
  document.addEventListener('click',onActivate);
  document.addEventListener('keydown',onActivate);
})();