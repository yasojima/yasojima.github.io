var ROWS = JSON.parse(document.getElementById("mx-data").textContent);
var CSRF = "";
var BADGE = {
overdue:["b-overdue","Overdue"],
due:["b-due","Due"],
due_soon:["b-soon","Due Soon"],
scheduled:["b-sched","Scheduled"],
ok:["b-ok","OK"],
no_history:["b-nohist","No History"]
};
var RANK = {overdue:0,due:1,due_soon:2,no_history:3,ok:4,scheduled:5};
var state = {q:"",freq:"",bucket:"",ctype:"",sortK:"",sortDir:1};
function fmtDue(r){
  if(r.bucket==="scheduled"){
    return r.next_appointment?("booked "+r.next_appointment):"booked";
  }
  if(r.days_until_due==null){return "\u2014";}
  var d=r.days_until_due;
  if(d<0){return Math.abs(d)+"d overdue";}
  if(d===0){return "today";}
  return "in "+d+"d";
}
function esc(s){
  s=(s==null?"":String(s));
  s=s.replace(/&/g,"&amp;").replace(/</g,"&lt;");
  return s.replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function rowHtml(x){
  var bd=BADGE[x.bucket]||["b-ok",x.bucket];
  var ap="";
  if(x.multi_site_approx){
    ap=" <span class=\"approx\" title=\"matched by address\">~</span>";
  }
  var h="<tr>";
  if(CAN_EDIT){h+='<td class="mx-cb"><input type="checkbox" class="mx-rowcb" data-loc="'+esc(x.location_id)+'"></td>';}
  h+="<td class=\"cust\">"+esc(x.customer_name)+"</td>";
  h+="<td>"+(x.rep_sold?esc(x.rep_sold):"—")+"</td>";
  h+="<td><span class=\"addr\">"+esc(x.address)+ap+"</span></td>";
  h+="<td class=\"mx-edit-jt\" data-loc=\""+esc(x.location_id)+
     "\" data-jt=\""+esc(x.job_type_id||"")+"\">"+
     esc(x.job_type||"\u2014")+"</td>";
  h+="<td class=\"mx-edit-freq\" data-loc=\""+esc(x.location_id)+
     "\" data-freq=\""+esc(x.frequency||"")+"\">"+
     esc(x.frequency_label||"\u2014")+"</td>";
  h+="<td class=\""+(CAN_EDIT?"mx-edit-fee":"")+"\" data-loc=\""+esc(x.location_id)+
     "\" data-fee=\""+(x.recurring_fee==null?"":x.recurring_fee)+"\">"+
     feeCell(x)+"</td>";
  h+="<td>"+esc(x.last_service||"\u2014")+"</td>";
  var pay=x.multi_site_payment?"multi-site check payment":(x.last_payment||"\u2014");
  h+="<td>"+esc(pay)+"</td>";
  h+="<td>"+esc(x.next_due||"\u2014")+"</td>";
  h+="<td>"+(x.next_appointment?("<span class=\"sched-appt\">"+esc(x.next_appointment)+"</span>"):"\u2014")+"</td>";
  h+="<td>"+esc(fmtDue(x))+"</td>";
  h+="<td><span class=\"badge "+bd[0]+"\">"+bd[1]+"</span></td>";
  h+="<td class=\"lnkcell\">"+linkCell(x)+"</td>";
  h+="<td>"+outreachCell(x)+"</td>";
  h+="</tr>";
  return h;
}
function fmtShort(iso){
  var p=iso.split("-");
  if(p.length<3){return iso;}
  return (+p[1])+"/"+(+p[2])+"/"+p[0].slice(2);
}
// Yearly visit counts by cadence — mirrors scheduling.maintenance._PERIOD so
// the annualized value can be recomputed client-side after an inline edit.
var VPY = {weekly:52,bi_weekly:26,biweekly:26,tri_weekly:52/3,triweekly:52/3,
  monthly:12,bi_monthly:6,bimonthly:6,quarterly:4,semi_annual:2,semiannual:2,
  bi_annual:2,biannual:2,annual:1,annually:1,yearly:1};
function money(v,dp){
  dp=(dp==null?2:dp);
  return "$"+Number(v).toLocaleString(undefined,
    {minimumFractionDigits:dp,maximumFractionDigits:dp});
}
function feeCell(x){
  if(x.recurring_fee==null){ return "<span style=\"color:#9ca3af\">—</span>"; }
  var yr = (x.annual_value!=null)
    ? " <span style=\"color:#6b7280;font-size:11px\">· "+money(x.annual_value,0)+"/yr</span>" : "";
  var m = (x.recurring_fee_source==="manual")
    ? " <span title=\"manual override\" style=\"color:#b45309\">✎</span>" : "";
  return money(x.recurring_fee)+m+yr;
}
var JOBTYPES = JSON.parse(document.getElementById("mx-jobtypes").textContent);
var FREQS = JSON.parse(document.getElementById("mx-freqs").textContent);
var CAN_EDIT = JSON.parse(document.getElementById("mx-canedit").textContent);
var TECHS = JSON.parse(document.getElementById("mx-techs").textContent);
var FREQLBL = {};
FREQS.forEach(function(f){ FREQLBL[f.value] = f.label; });
function freqLabel(v){ return FREQLBL[v] || v || "\u2014"; }

document.addEventListener("click", function(ev){
  if(!CAN_EDIT) return;
  var td = ev.target.closest
    ? ev.target.closest("td.mx-edit-jt, td.mx-edit-freq, td.mx-edit-fee") : null;
  if(!td) return;
  if(td.querySelector("select") || td.querySelector("input")) return;
  if(td.classList.contains("mx-edit-freq")) mxOpenFreq(td);
  else if(td.classList.contains("mx-edit-fee")) mxOpenFee(td);
  else mxOpenJt(td);
});

function mxSelect(opts, cur){
  var sel = document.createElement("select");
  sel.className = "mx-edit-sel";
  opts.forEach(function(o){
    var op = document.createElement("option");
    op.value = o.value; op.textContent = o.label;
    if(String(o.value) === String(cur)) op.selected = true;
    sel.appendChild(op);
  });
  return sel;
}

function mxAttach(td, sel, prev, payloadFn, applyFn){
  td.innerHTML = ""; td.appendChild(sel); sel.focus();
  sel.addEventListener("change", function(){
    var val = sel.value;
    td.textContent = "Saving\u2026";
    var body = payloadFn(val);
    body.location_id = td.getAttribute("data-loc");
    fetch("/maintenance/update-recurring/", {
      method: "POST", credentials: "same-origin",
      headers: {"Content-Type": "application/json", "X-CSRFToken": CSRF},
      body: JSON.stringify(body)
    }).then(function(r){ return r.json(); }).then(function(d){
      if(d && d.ok){ applyFn(td, d); }
      else { td.innerHTML = prev; alert("Update failed: " + ((d && d.error) || "error")); }
    }).catch(function(){ td.innerHTML = prev; alert("Update failed"); });
  });
  sel.addEventListener("keydown", function(e){
    if(e.key === "Escape") td.innerHTML = prev;
  });
  sel.addEventListener("blur", function(){
    setTimeout(function(){
      if(td.querySelector("select") === sel) td.innerHTML = prev;
    }, 150);
  });
}

function mxOpenFreq(td){
  var prev = td.innerHTML;
  var sel = mxSelect(FREQS, td.getAttribute("data-freq") || "");
  mxAttach(td, sel, prev,
    function(v){ return {frequency: v}; },
    function(td, d){
      td.setAttribute("data-freq", d.frequency || "");
      td.textContent = freqLabel(d.frequency);
    });
}

function mxOpenJt(td){
  var prev = td.innerHTML;
  var opts = [{value: "", label: "\u2014 none \u2014"}];
  JOBTYPES.forEach(function(j){ opts.push({value: j.id, label: j.name}); });
  var sel = mxSelect(opts, td.getAttribute("data-jt") || "");
  mxAttach(td, sel, prev,
    function(v){ return {job_type_id: v || null}; },
    function(td, d){
      td.setAttribute("data-jt", d.job_type_id || "");
      td.textContent = d.job_type || "\u2014";
    });
}

function applyFee(td, d){
  var fee = (d.recurring_treatment_fee==null?null:d.recurring_treatment_fee);
  td.setAttribute("data-fee", fee==null?"":fee);
  var freq = "";
  var fr = td.parentNode.querySelector(".mx-edit-freq");
  if(fr){ freq = fr.getAttribute("data-freq") || ""; }
  var av = (fee!=null && VPY[freq]!=null) ? fee*VPY[freq] : null;
  td.innerHTML = feeCell({recurring_fee: fee, annual_value: av,
                          recurring_fee_source: d.recurring_fee_source});
}
function mxOpenFee(td){
  var prev = td.innerHTML;
  var inp = document.createElement("input");
  inp.type = "text"; inp.className = "mx-edit-sel";
  inp.value = td.getAttribute("data-fee") || "";
  inp.placeholder = "per visit"; inp.style.width = "78px";
  td.innerHTML = ""; td.appendChild(inp); inp.focus(); inp.select();
  function save(){
    var val = inp.value.trim();
    td.textContent = "Saving\u2026";
    fetch("/maintenance/update-recurring/", {
      method: "POST", credentials: "same-origin",
      headers: {"Content-Type": "application/json", "X-CSRFToken": CSRF},
      body: JSON.stringify({location_id: td.getAttribute("data-loc"),
                            recurring_treatment_fee: (val === "" ? null : val)})
    }).then(function(r){ return r.json(); }).then(function(d){
      if(d && d.ok){ applyFee(td, d); }
      else { td.innerHTML = prev; alert("Update failed: " + ((d && d.error) || "error")); }
    }).catch(function(){ td.innerHTML = prev; alert("Update failed"); });
  }
  inp.addEventListener("keydown", function(e){
    if(e.key === "Enter"){ e.preventDefault(); save(); }
    else if(e.key === "Escape"){ td.innerHTML = prev; }
  });
  inp.addEventListener("blur", function(){
    setTimeout(function(){
      if(td.querySelector("input") === inp) td.innerHTML = prev;
    }, 150);
  });
}
function linkCell(x){
  if(!x.location_id){return "\u2014";}
  var hist="";
  if(x.link_status){
    var st=x.link_status;
    var lbl=st.state==="used"?"Booked":st.state==="expired"?"Expired":
            st.state==="revoked"?"Revoked":"Sent";
    var col=st.state==="used"?"#16a34a":(st.state==="sent"?"#2563eb":"#9ca3af");
    var d=st.sent?fmtShort(st.sent):"";
    hist='<div style="font-size:11px;color:'+col+
         ';margin-bottom:3px">'+lbl+(d?(" "+d):"")+'</div>';
  }
  var label=x.link_status?"Resend":"Send link";
  var b='<button class="lnk-btn" data-loc="'+esc(x.location_id)+
        '" data-name="'+esc(x.customer_name)+
        '" onclick="sendLink(this)">'+label+'</button>';
  b+='<span class="lnk-stat"></span>';
  return hist+b;
}
function sendLink(btn){
  var loc=btn.getAttribute("data-loc");
  var name=btn.getAttribute("data-name")||"this customer";
  var msg="Send a booking link to "+name+
          "? This will text or email the customer now.";
  if(!confirm(msg)){return;}
  var stat=btn.parentNode.querySelector(".lnk-stat");
  var orig=btn.textContent;
  btn.disabled=true; btn.textContent="Sending\u2026";
  if(stat){stat.textContent="";}
  fetch("/maintenance/send-link/",{
    method:"POST",
    headers:{"Content-Type":"application/json","X-CSRFToken":CSRF},
    body:JSON.stringify({location_id:loc})
  }).then(function(r){
    return r.json().then(function(j){return {s:r.status,j:j};});
  }).then(function(o){
    var j=o.j||{};
    if(o.s===200 && j.ok && j.sent){
      btn.textContent="Sent \u2713";
      btn.classList.add("sent");
      var via=j.channel?("via "+j.channel):"";
      var who=j.contact_masked?(" "+j.contact_masked):"";
      if(stat){stat.textContent=via+who;}
    }else if(o.s===200 && j.ok && !j.sent){
      btn.disabled=false; btn.textContent=orig;
      var rs="not sent";
      if(j.reason==="no_contact_method"){rs="no phone/email";}
      else if(j.reason==="no_slots_available"){rs="no open slots";}
      else if(j.reason){rs=j.reason;}
      if(stat){stat.style.color="#b45309"; stat.textContent=rs;}
    }else{
      btn.disabled=false; btn.textContent=orig;
      if(stat){stat.style.color="#dc2626";
               stat.textContent="error: "+(j.error||o.s);}
    }
  }).catch(function(){
    btn.disabled=false; btn.textContent=orig;
    if(stat){stat.style.color="#dc2626"; stat.textContent="network error";}
  });
}
function cmp(a,b){
  if(state.sortK){
    var va=a[state.sortK], vb=b[state.sortK];
    if(va==null){va="";}
    if(vb==null){vb="";}
    if(va<vb){return -1*state.sortDir;}
    if(va>vb){return 1*state.sortDir;}
    return 0;
  }
  var ra=(RANK[a.bucket]==null?9:RANK[a.bucket]);
  var rb=(RANK[b.bucket]==null?9:RANK[b.bucket]);
  if(ra!==rb){return ra-rb;}
  var da=(a.days_until_due==null?99999:a.days_until_due);
  var db=(b.days_until_due==null?99999:b.days_until_due);
  return da-db;
}
function matchQ(x,q){
  var n=(x.customer_name||"").toLowerCase();
  var a=(x.address||"").toLowerCase();
  var r=(x.rep_sold||"").toLowerCase();
  return n.indexOf(q)>=0 || a.indexOf(q)>=0 || r.indexOf(q)>=0;
}
function outreachCell(x){
  var o=x.outreach;
  if(!o){return "\u2014";}
  if(o.status==="booked"){return '<span class="mx-or mx-or-booked">Booked</span>';}
  if(o.status==="opted_out"){return '<span class="mx-or mx-or-out">Opted out</span>';}
  if(o.status==="stopped"){return '<span class="mx-or mx-or-out">Stopped</span>';}
  if(o.status==="exhausted"){return '<span class="mx-or mx-or-done">No response</span>';}
  var t=o.touch||0;
  return '<span class="mx-or mx-or-active">Touch '+t+'/5</span>';
}
(function(){
  var seg=document.getElementById("mxOrSeg");
  if(!seg){return;}
  var cur="off";
  try{cur=JSON.parse(document.getElementById("mx-ormode").textContent)||"off";}catch(e){}
  var hint=document.getElementById("mxOrHint");
  var HINTS={off:"Outreach paused. No messages scheduled.",dry_run:"Dry run: logs would-be messages, sends nothing.",live:"Live: real messages send on the daily schedule to opted-in customers."};
  function paint(m){
    var bs=seg.querySelectorAll("button");
    for(var i=0;i<bs.length;i++){bs[i].classList.toggle("active",bs[i].getAttribute("data-mode")===m);}
    if(hint){hint.textContent=HINTS[m]||"";}
  }
  paint(cur);
  seg.addEventListener("click",function(e){
    var b=e.target.closest?e.target.closest("button[data-mode]"):null;
    if(!b){return;}
    var m=b.getAttribute("data-mode");
    if(m===cur){return;}
    if(m==="live"&&!confirm("Switch maintenance rebooking outreach to LIVE? Real SMS/email will be sent to opted-in maintenance customers on the daily schedule.")){return;}
    var bs=seg.querySelectorAll("button");for(var i=0;i<bs.length;i++){bs[i].disabled=true;}
    fetch("/maintenance/outreach-mode/",{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json","X-CSRFToken":CSRF},body:JSON.stringify({mode:m})})
      .then(function(r){return r.json();})
      .then(function(d){var b2=seg.querySelectorAll("button");for(var i=0;i<b2.length;i++){b2[i].disabled=false;}if(d&&d.ok){cur=d.mode;paint(cur);}else{alert("Could not change mode: "+((d&&d.error)||"error"));}})
      .catch(function(){var b3=seg.querySelectorAll("button");for(var i=0;i<b3.length;i++){b3[i].disabled=false;}alert("Could not change mode.");});
  });
})();
function filteredRows(){
  var r=ROWS.slice();
  if(state.bucket){
    r=r.filter(function(x){return x.bucket===state.bucket;});
  }
  if(state.freq){
    r=r.filter(function(x){return x.frequency===state.freq;});
  }
  if(state.ctype){
    r=r.filter(function(x){return x.customer_type===state.ctype;});
  }
  if(state.q){
    var q=state.q.toLowerCase();
    r=r.filter(function(x){return matchQ(x,q);});
  }
  return r;
}
function render(){
  var r=filteredRows();
  r.sort(cmp);
  document.getElementById("mxBody").innerHTML=r.map(rowHtml).join("");
  document.getElementById("mxEmpty").style.display=r.length?"none":"block";
  if(window.mxReapplyChecks)mxReapplyChecks();
  if(window.mxOnFilterChange)mxOnFilterChange();
}
function setBucket(b){
  state.bucket=(state.bucket===b)?"":b;
  var els=document.querySelectorAll(".mx-kpi");
  for(var i=0;i<els.length;i++){els[i].classList.remove("active");}
  var sel=document.querySelector(".mx-kpi[data-b=\""+state.bucket+"\"]");
  if(sel){sel.classList.add("active");}
  render();
}
var kpis=document.querySelectorAll(".mx-kpi");
for(var i=0;i<kpis.length;i++){
  kpis[i].addEventListener("click",function(){
    setBucket(this.getAttribute("data-b"));
  });
}
document.getElementById("mxSearch").addEventListener("input",function(e){
  state.q=e.target.value; render();
});
document.getElementById("mxFreq").addEventListener("change",function(e){
  state.freq=e.target.value; render();
});
document.getElementById("mxCtype").addEventListener("change",function(e){
  state.ctype=e.target.value; render();
});
var ths=document.querySelectorAll("table.mx th");
for(var j=0;j<ths.length;j++){
  ths[j].addEventListener("click",function(){
    var k=this.getAttribute("data-k");
    if(!k)return;
    if(state.sortK===k){state.sortDir*=-1;}
    else{state.sortK=k;state.sortDir=1;}
    render();
  });
}

/* Maintenance density map: Google heatmap + zoom-aware customer clusters.
   Both layers are driven by the same filteredRows() the table uses, so the
   status (KPI bucket) and frequency filters apply to the map live. */
(function(){
  var MAPS_KEY = "";
  var PHILLY = {lat:39.9526, lng:-75.1652};
  var HEAT_CFG = {radius:22, maxOpacity:0.6, minOpacity:0, blur:0.9,
    scaleRadius:false, useLocalExtrema:false,
    latField:'lat', lngField:'lng', valueField:'value'};
  var map=null, heat=null, clusterer=null, markers=[], info=null;
  var ready=false, heatReady=false, showing=false, mapsP=null, loaded={};
  var showHeat=true, showClusters=true;

  function pts(){
    return filteredRows().filter(function(x){
      return x.latitude!=null && x.longitude!=null;
    });
  }
  function weight(x){
    if(x.bucket==="overdue") return 3;
    if(x.bucket==="due") return 2;
    if(x.bucket==="due_soon") return 1.5;
    return 1;
  }
  function radiusForZoom(z){
    if(z>=16) return 44;
    if(z>=15) return 34;
    if(z>=13) return 24;
    if(z>=11) return 16;
    return 11;
  }
  function infoHtml(x){
    var bd=(BADGE[x.bucket]||["",x.bucket]);
    return '<div class="mx-mapinfo"><b>'+esc(x.customer_name||"—")+'</b>'+
      '<div class="a">'+esc(x.address||"")+'</div>'+
      '<div><span class="s">'+esc(bd[1])+'</span>'+
      (x.next_due?(' · due '+esc(x.next_due)):'')+'</div>'+
      '<div class="a">'+esc(x.frequency_label||"")+
      (x.job_type?(' · '+esc(x.job_type)):'')+'</div></div>';
  }

  // Load a self-hosted script once; resolves on load. `optional` scripts resolve
  // even on error so a missing add-on never breaks the base map.
  function loadScript(cacheKey, src, optional){
    if(loaded[cacheKey]) return loaded[cacheKey];
    loaded[cacheKey] = new Promise(function(resolve, reject){
      var s=document.createElement("script");
      s.src=src;
      s.onload=function(){ resolve(); };
      s.onerror=function(){ optional ? resolve() : reject(new Error("failed to load "+src)); };
      document.head.appendChild(s);
    });
    return loaded[cacheKey];
  }
  // Google Maps via the modern importLibrary bootstrap (Google removed the old
  // visualization HeatmapLayer in v3.65, so we only need maps + marker and render
  // the heatmap ourselves via heatmap.js).
  function loadMaps(){
    function libs(){
      return Promise.all([
        google.maps.importLibrary("maps"),
        google.maps.importLibrary("marker")
      ]);
    }
    if(window.google && window.google.maps && window.google.maps.importLibrary) return libs();
    if(mapsP) return mapsP;
    mapsP = new Promise(function(resolve, reject){
      window.__mxMapsCb = function(){ libs().then(resolve, reject); };
      var s=document.createElement("script");
      s.src="https://maps.googleapis.com/maps/api/js?key="+
        encodeURIComponent(MAPS_KEY)+"&v=weekly&loading=async&callback=__mxMapsCb";
      s.async=true;
      s.onerror=function(){ reject(new Error("Google Maps script failed to load")); };
      document.head.appendChild(s);
    });
    return mapsP;
  }
  // heatmap.js core (defines window.h337). Self-hosted; best-effort.
  function loadHeatCore(){ return loadScript("h337", "/static/js/heatmap.min.6d0aea1c55f0.js", true); }
  // heatmap.js → Google Maps overlay (window.HeatmapOverlay). MUST load after
  // both h337 and google.maps exist (it reads them at execution time).
  function loadHeatOverlay(){
    if(window.HeatmapOverlay) return Promise.resolve();
    if(!window.h337 || !window.google || !window.google.maps) return Promise.resolve();
    return loadScript("heatoverlay", "/static/js/gmaps-heatmap.08ea55b3dbbb.js", true);
  }
  // Marker clusterer (window.markerClusterer). Self-hosted; best-effort.
  function loadClusterer(){ return loadScript("clusterer", "/static/js/markerclusterer.min.45cfdcdb9e05.js", true); }

  function build(){
    var el=document.getElementById("mxMap");
    map=new google.maps.Map(el,{
      center:PHILLY, zoom:11, mapTypeControl:false, streetViewControl:false,
      fullscreenControl:true
    });
    el.classList.add("ready");
    info=new google.maps.InfoWindow();
    // Heatmap layer (heatmap.js overlay). Best-effort: the clusters still work
    // if the heat add-on failed to load.
    if(window.HeatmapOverlay){
      try { heat=new HeatmapOverlay(map, HEAT_CFG); } catch(e){ console.error("heat overlay init failed", e); heat=null; }
    }
    // heatmap.js's overlay creates its canvas on the map's first idle; render the
    // heat only after that so setData has a live renderer.
    google.maps.event.addListenerOnce(map, "idle", function(){ heatReady=true; drawHeat(); });
    // Grow the heat radius as you zoom in so density stays legible at street level.
    map.addListener("zoom_changed", function(){ HEAT_CFG.radius=radiusForZoom(map.getZoom()); });
    ready=true;
    update();
  }

  function drawHeat(){
    if(!heat || !heatReady) return;
    var P=pts();
    var data=P.map(function(x){ return {lat:x.latitude, lng:x.longitude, value:weight(x)}; });
    var maxv=data.reduce(function(m,d){ return Math.max(m, d.value); }, 1);
    try { heat.setData({max:maxv, min:0, data: showHeat ? data : []}); }
    catch(e){ console.error("heat setData failed", e); }
  }

  function update(){
    if(!ready) return;
    var P=pts();
    // Cluster / marker layer — rebuilt from the filtered set
    if(clusterer){ clusterer.clearMarkers(); clusterer.setMap(null); clusterer=null; }
    markers.forEach(function(m){ m.setMap(null); });
    markers = P.map(function(x){
      var m=new google.maps.Marker({position:{lat:x.latitude, lng:x.longitude}, title:x.customer_name||""});
      m.addListener("click", function(){ info.setContent(infoHtml(x)); info.open(map, m); });
      return m;
    });
    if(showClusters && window.markerClusterer && window.markerClusterer.MarkerClusterer){
      try {
        clusterer=new markerClusterer.MarkerClusterer({map:map, markers:markers});
      } catch(e){
        console.error("maintenance map: cluster layer failed, showing plain markers", e);
        markers.forEach(function(m){ m.setMap(map); });
      }
    } else {
      markers.forEach(function(m){ m.setMap(map); });
    }
    // Heat layer follows the same filtered set
    drawHeat();
    // Fit to visible points on first draw / when the set changes meaningfully
    if(P.length){
      var b=new google.maps.LatLngBounds();
      P.forEach(function(x){ b.extend({lat:x.latitude, lng:x.longitude}); });
      map.fitBounds(b);
    }
    // "N of M mapped" note
    var total=filteredRows().length, missing=total-P.length;
    var note=P.length+" of "+total+" location"+(total===1?"":"s")+" mapped";
    if(missing>0) note += " · "+missing+" not yet geocoded";
    document.getElementById("mxMapNote").textContent=note;
  }

  function ensureMap(){
    if(ready){ update(); return; }
    var el=document.getElementById("mxMap");
    if(el) el.textContent="Loading map…";
    if(!MAPS_KEY){ if(el) el.textContent="Map unavailable (no Google Maps key configured)."; return; }
    // Load Maps + heatmap core + clusterer, THEN the heat overlay (needs the
    // first two present), then build.
    Promise.all([loadMaps(), loadHeatCore(), loadClusterer()])
      .then(loadHeatOverlay)
      .then(build)
      .catch(function(err){
        console.error("maintenance map failed to load:", err);
        if(el) el.textContent="Map failed to load. See console for details.";
      });
  }

  function showView(which){
    showing = (which==="map");
    document.getElementById("mxMapPanel").style.display = showing?"block":"none";
    document.getElementById("mxTableWrap").style.display = showing?"none":"block";
    document.getElementById("mxViewMap").classList.toggle("active", showing);
    document.getElementById("mxViewTable").classList.toggle("active", !showing);
    if(showing) ensureMap();
  }

  // Re-run map update on any filter change, but only while the map is visible.
  window.mxOnFilterChange = function(){ if(showing && ready) update(); };

  var vT=document.getElementById("mxViewTable"), vM=document.getElementById("mxViewMap");
  if(vT) vT.addEventListener("click", function(){ showView("table"); });
  if(vM) vM.addEventListener("click", function(){ showView("map"); });
  var lH=document.getElementById("mxLayerHeat"), lC=document.getElementById("mxLayerClusters");
  if(lH) lH.addEventListener("change", function(){ showHeat=lH.checked; drawHeat(); });
  if(lC) lC.addEventListener("change", function(){
    showClusters=lC.checked;
    if(clusterer){ clusterer.clearMarkers(); clusterer.setMap(null); clusterer=null; }
    markers.forEach(function(m){ m.setMap(null); });
    if(showClusters && window.markerClusterer && window.markerClusterer.MarkerClusterer){
      try { clusterer=new markerClusterer.MarkerClusterer({map:map, markers:markers}); }
      catch(e){ markers.forEach(function(m){ m.setMap(map); }); }
    } else {
      markers.forEach(function(m){ m.setMap(map); });
    }
  });
})();

render();

/* S7c maintenance bulk-edit module */
(function(){
  if(typeof CAN_EDIT==="undefined" || !CAN_EDIT) return;
  var selected = {};
  var bar = document.getElementById("mxBulkBar");
  var nLbl = document.getElementById("mxBulkN");
  var sa = document.getElementById("mxSelectAll");
  if(!bar) return;
  function refreshBar(){
    var n = Object.keys(selected).length;
    if(nLbl) nLbl.textContent = n;
    bar.style.display = n>0 ? "flex" : "none";
    var cbs = document.querySelectorAll(".mx-rowcb");
    var vis = cbs.length, chk = 0;
    Array.prototype.forEach.call(cbs, function(cb){ if(selected[cb.getAttribute("data-loc")]) chk++; });
    if(sa){ sa.checked = vis>0 && chk===vis; sa.indeterminate = chk>0 && chk<vis; }
  }
  window.mxReapplyChecks = function(){
    Array.prototype.forEach.call(document.querySelectorAll(".mx-rowcb"), function(cb){
      cb.checked = !!selected[cb.getAttribute("data-loc")];
    });
    refreshBar();
  };
  var body = document.getElementById("mxBody");
  if(body) body.addEventListener("change", function(ev){
    var cb = ev.target;
    if(!cb || !cb.classList || !cb.classList.contains("mx-rowcb")) return;
    var loc = cb.getAttribute("data-loc");
    if(cb.checked) selected[loc]=true; else delete selected[loc];
    refreshBar();
  });
  if(sa){
    sa.addEventListener("click", function(e){ e.stopPropagation(); });
    sa.addEventListener("change", function(){
      Array.prototype.forEach.call(document.querySelectorAll(".mx-rowcb"), function(cb){
        var loc=cb.getAttribute("data-loc");
        cb.checked = sa.checked;
        if(sa.checked) selected[loc]=true; else delete selected[loc];
      });
      refreshBar();
    });
  }
  var clr = document.getElementById("mxBulkClear");
  if(clr) clr.addEventListener("click", function(){ selected={}; window.mxReapplyChecks(); });

  var modal = document.getElementById("mxBulkModal");
  var mTitle = document.getElementById("mxModalTitle");
  var mBody = document.getElementById("mxModalBody");
  var mPrev = document.getElementById("mxModalPreview");
  var mApply = document.getElementById("mxModalApply");
  var mCancel = document.getElementById("mxModalCancel");
  var curOp = null;
  var OPLABEL = {change_frequency:"Change frequency", change_job_type:"Change job type",
    reassign_tech:"Reassign technician", shift_future:"Shift appointment dates",
    pause:"Pause recurring", cancel:"Cancel series"};
  function ids(){ return Object.keys(selected); }
  function closeModal(){ modal.style.display="none"; curOp=null; if(mPrev)mPrev.textContent=""; if(mApply)mApply.disabled=true; }
  if(mCancel) mCancel.addEventListener("click", closeModal);
  if(modal) modal.addEventListener("click", function(ev){ if(ev.target===modal) closeModal(); });

  function esc2(s){ return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"); }
  function buildBody(op){
    var s;
    if(op==="change_frequency"){
      s='<label>New frequency</label><select id="mxParam">';
      FREQS.forEach(function(f){ if(f.value) s+='<option value="'+esc2(f.value)+'">'+esc2(f.label)+'</option>'; });
      return s+'</select>';
    }
    if(op==="change_job_type"){
      s='<label>New job type</label><select id="mxParam"><option value="">(none)</option>';
      JOBTYPES.forEach(function(j){ s+='<option value="'+esc2(j.id)+'">'+esc2(j.name)+'</option>'; });
      return s+'</select>';
    }
    if(op==="reassign_tech"){
      if(!TECHS || !TECHS.length) return '<p class="mx-warn">No active technicians available to assign.</p>';
      s='<label>Assign to technician</label><select id="mxParam">';
      TECHS.forEach(function(t){ s+='<option value="'+esc2(t.id)+'">'+esc2(t.name)+'</option>'; });
      return s+'</select><p class="mx-note">Applies to future appointments (scheduled / confirmed / reminded).</p>';
    }
    if(op==="shift_future"){
      return '<label>Shift by (days, +/-)</label><input type="number" id="mxParam" value="7" step="1"><p class="mx-note">Moves all future appointments by this many days. A shift crossing a daylight-saving change can move the time by an hour.</p>';
    }
    if(op==="pause"){
      return '<p>This removes the recurring cadence from the selected location(s); they will no longer show as due. Existing appointments are not changed.</p>';
    }
    if(op==="cancel"){
      return '<p class="mx-warn">This pauses recurring AND cancels every future appointment (scheduled / confirmed / reminded) for the selected location(s). This cannot be undone in bulk.</p>';
    }
    return "";
  }
  function paramVal(op){
    var el = document.getElementById("mxParam");
    if(op==="change_frequency") return {frequency: el?el.value:""};
    if(op==="change_job_type") return {job_type_id: (el&&el.value)?el.value:null};
    if(op==="reassign_tech") return {technician_id: el?el.value:null};
    if(op==="shift_future") return {shift_days: el?parseInt(el.value,10):0};
    return {};
  }
  function callBulk(op, extra, dry, cb){
    var b = {operation:op, location_ids:ids(), dry_run:!!dry};
    for(var k in extra) b[k]=extra[k];
    fetch("/maintenance/bulk-recurring/", {
      method:"POST", credentials:"same-origin",
      headers:{"Content-Type":"application/json","X-CSRFToken":CSRF},
      body: JSON.stringify(b)
    }).then(function(r){return r.json();}).then(cb).catch(function(){ cb({ok:false,error:"network"}); });
  }
  function runPreview(){
    if(!curOp) return;
    if(mPrev){ mPrev.textContent="Checking impact..."; }
    if(mApply) mApply.disabled=true;
    callBulk(curOp, paramVal(curOp), true, function(d){
      if(!d || !d.ok){ if(mPrev)mPrev.textContent="Cannot preview: "+((d&&d.error)||"error"); return; }
      var msg;
      if(curOp==="change_frequency"||curOp==="change_job_type"||curOp==="pause"){
        msg = d.locations_affected+" of "+d.locations_selected+" selected location(s) will change.";
      } else {
        var verb = (curOp==="cancel")?"cancelled":((curOp==="reassign_tech")?"reassigned":"shifted");
        msg = d.appointments_affected+" future appointment(s) across "+d.locations_selected+" location(s) will be "+verb+".";
        if(d.multisite_approx) msg += " Multi-site matches are approximate.";
      }
      if(mPrev) mPrev.textContent = msg;
      if(mApply) mApply.disabled = false;
    });
  }
  function openModal(op){
    if(!ids().length) return;
    curOp = op;
    if(mTitle) mTitle.textContent = OPLABEL[op]||op;
    if(mBody) mBody.innerHTML = buildBody(op);
    if(mPrev) mPrev.textContent="";
    if(mApply) mApply.disabled=true;
    modal.style.display="flex";
    var el = document.getElementById("mxParam");
    if(el) el.addEventListener("change", runPreview);
    runPreview();
  }
  if(mApply) mApply.addEventListener("click", function(){
    if(!curOp) return;
    mApply.disabled=true; mApply.textContent="Applying...";
    callBulk(curOp, paramVal(curOp), false, function(d){
      mApply.textContent="Apply";
      if(d && d.ok){ window.location.reload(); }
      else { alert("Bulk action failed: "+((d&&d.error)||"error")); mApply.disabled=false; }
    });
  });
  Array.prototype.forEach.call(document.querySelectorAll(".mx-bulk-btn"), function(b){
    b.addEventListener("click", function(){ openModal(b.getAttribute("data-op")); });
  });
})();