(function () {
    if (window.__cbpPwaShell) return;
    window.__cbpPwaShell = true;

    var DISMISS_KEY = 'cbp:pwa-install-dismissed';
    var deferredPrompt = null;

    function banner() { return document.getElementById('cbp-pwa-install-banner'); }

    function showBanner() {
      var el = banner();
      if (!el) return;
      try {
        if (window.sessionStorage && sessionStorage.getItem(DISMISS_KEY) === '1') return;
      } catch (e) { /* sessionStorage may throw in private mode — fail open */ }
      el.classList.add('cbp-pwa-show');
    }
    function hideBanner() {
      var el = banner();
      if (el) el.classList.remove('cbp-pwa-show');
    }

    window.cbpPwaInstall = function () {
      if (!deferredPrompt) { hideBanner(); return; }
      var p = deferredPrompt;
      deferredPrompt = null;
      try {
        p.prompt();
        if (p.userChoice && typeof p.userChoice.then === 'function') {
          p.userChoice.then(function () { hideBanner(); }, function () { hideBanner(); });
        } else {
          hideBanner();
        }
      } catch (e) {
        hideBanner();
      }
    };

    window.cbpPwaDismiss = function () {
      hideBanner();
      try { sessionStorage.setItem(DISMISS_KEY, '1'); } catch (e) {}
    };

    window.addEventListener('beforeinstallprompt', function (ev) {
      // Stash the event so we can fire .prompt() on user gesture.
      // Calling preventDefault() suppresses the browser's mini-infobar
      // on Chrome desktop so our banner is the only entry point.
      try { ev.preventDefault(); } catch (e) {}
      deferredPrompt = ev;
      showBanner();
    });

    window.addEventListener('appinstalled', function () {
      deferredPrompt = null;
      hideBanner();
    });

    // ── Service-worker registration ────────────────────────────────
    // Served at /sw.js by core.views_pwa.service_worker so its scope
    // can be `/`. Registration is best-effort: on browsers without
    // serviceWorker support (or in non-secure dev contexts), we
    // silently skip — the page itself works regardless.
    function registerSw() {
      if (!('serviceWorker' in navigator)) return;
      try {
        navigator.serviceWorker.register('/sw.js', { scope: '/' })
          .then(function (reg) {
            try { console.log('[pwa] service worker registered:', reg.scope); } catch (e) {}
          })
          .catch(function (err) {
            try { console.warn('[pwa] service worker registration failed:', err); } catch (e) {}
          });
      } catch (e) {
        // Defense in depth — never let a registration error break the page.
      }
    }

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
      registerSw();
    } else {
      window.addEventListener('load', registerSw);
    }

    // ── Continuous mobile-device location heartbeat ────────────────
    // While the field app is open, send the technician's phone position
    // ~once/minute to /api/v1/scheduling/device-ping/. The server updates
    // Technician.device_* (last-known) + a DeviceLocationPing trail, and
    // respects the tech's gps_tracking_enabled flag. Battery-conscious:
    // low accuracy, cached fixes, and only while the tab is visible.
    (function () {
      if (!('geolocation' in navigator)) return;
      function csrf() { var m = document.cookie.match(/csrftoken=([^;]+)/); return m ? m[1] : ''; }
      function ping() {
        if (document.visibilityState !== 'visible') return;
        navigator.geolocation.getCurrentPosition(function (pos) {
          if (!pos || !pos.coords) return;
          fetch('/api/v1/scheduling/device-ping/', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrf() },
            body: JSON.stringify({
              lat: pos.coords.latitude, lng: pos.coords.longitude,
              accuracy: pos.coords.accuracy
            })
          }).catch(function () {});
        }, function () {}, { enableHighAccuracy: false, maximumAge: 60000, timeout: 20000 });
      }
      setTimeout(ping, 4000);
      setInterval(ping, 60000);
      document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') ping();
      });
    })();

    // ── Slice G3: VAPID public key for push.js ─────────────────────
    // push.js reads window.CBP_VAPID_PUBLIC_KEY when it calls
    // pushManager.subscribe(applicationServerKey=...). Empty string
    // (push unconfigured) makes push.js silently disable itself.
    window.CBP_VAPID_PUBLIC_KEY = "";

    // ── Slice G2: connection-status + write-queue affordances ─────────
    // The badges live in the DOM unconditionally (rendered below in
    // the page-content block). This script wires them up:
    //   - flips the connection pill on online/offline events
    //   - polls IndexedDB queue length so the queue badge shows N
    //     pending writes
    //   - listens for SW postMessage('cbp-queue-drained') and shows a
    //     toast on success
    // All best-effort: any browser without IndexedDB / SW just sees
    // a static "Online" pill, which is the right behaviour for a
    // tablet that's always on WiFi.
    function setConn(online) {
      var el = document.getElementById('cbp-pwa-conn');
      if (!el) return;
      el.classList.remove('online', 'offline');
      el.classList.add(online ? 'online' : 'offline');
      el.textContent = online ? 'Online' : 'Offline';
    }
    function setQueueBadge(n) {
      var el = document.getElementById('cbp-pwa-queue');
      if (!el) return;
      if (n > 0) {
        el.textContent = n + ' queued';
        el.classList.add('show');
      } else {
        el.classList.remove('show');
      }
    }
    function showToast(msg) {
      var el = document.getElementById('cbp-pwa-toast');
      if (!el) return;
      el.textContent = msg;
      el.classList.add('show');
      setTimeout(function () { el.classList.remove('show'); }, 2800);
    }
    function refreshQueueBadge() {
      if (!window.CbpPwaQueue || typeof window.CbpPwaQueue.count !== 'function') return;
      try {
        window.CbpPwaQueue.count().then(function (n) { setQueueBadge(n || 0); }, function () {});
      } catch (e) {}
    }

    setConn(navigator.onLine !== false);
    window.addEventListener('online', function () {
      setConn(true);
      // Ask the SW to drain immediately rather than wait for the
      // browser's sync heuristics — techs reconnecting after a long
      // gap want their saves to land NOW.
      if (navigator.serviceWorker && navigator.serviceWorker.controller) {
        try { navigator.serviceWorker.controller.postMessage({ type: 'cbp-drain-now' }); } catch (e) {}
      }
    });
    window.addEventListener('offline', function () { setConn(false); });

    // Pull in the page-side copy of the queue helper so we can poll
    // queue length. The SW also imports it but a worker module is
    // not visible to the page DOM.
    var qScript = document.createElement('script');
    qScript.src = '/static/js/sw-queue.js';
    qScript.async = true;
    qScript.onload = function () {
      refreshQueueBadge();
      setInterval(refreshQueueBadge, 5000);
    };
    document.head.appendChild(qScript);

    if (navigator.serviceWorker) {
      navigator.serviceWorker.addEventListener('message', function (ev) {
        if (!ev.data || ev.data.type !== 'cbp-queue-drained') return;
        refreshQueueBadge();
        var s = ev.data.summary || {};
        if (s.drained) showToast(s.drained + ' queued save' + (s.drained === 1 ? '' : 's') + ' synced');
        if (s.auth_failed) showToast('Some saves failed — please re-login and retry');
        else if (s.dropped) showToast(s.dropped + ' save' + (s.dropped === 1 ? '' : 's') + ' rejected by server');
      });
    }
  })();