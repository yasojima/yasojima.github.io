// Slice 16.1: hoisted office IANA timezone, available on every page.
  // Pages composing datetimes from naive inputs MUST route them through
  // window.localToUTC(naive, window._tenantTz) before POSTing — see §16.1.
  // The value comes from rbac_context (core.context_processors).
  window._tenantTz = 'America/New_York';