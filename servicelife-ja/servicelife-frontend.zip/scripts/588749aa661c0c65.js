const API='/api/v1',csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
let editId=null;
function toast(m,t='success'){const e=document.getElementById('toast');e.textContent=m;e.className='toast '+t;setTimeout(()=>e.className='toast',3000)}
async function apiFetch(u,m='GET',b=null){return fetch(API+u,{method:m,credentials:'same-origin',headers:{'X-CSRFToken':csrf(),'Content-Type':'application/json'},body:b?JSON.stringify(b):null})}
async function api(u,m='GET',b=null){return(await apiFetch(u,m,b)).json()}
function fmtDT(s){if(!s)return'\u2014';const d=new Date(s);const tz=window._tenantTz||'America/New_York';return d.toLocaleDateString('en-US',{timeZone:tz,month:'short',day:'numeric'})+' '+d.toLocaleTimeString('en-US',{timeZone:tz,hour:'numeric',minute:'2-digit'})}
const DIR_ICON={inbound:'<i class="fas fa-phone-alt dir-icon dir-in"></i>',outbound:'<i class="fas fa-phone dir-icon dir-out"></i>',missed:'<i class="fas fa-phone-slash dir-icon dir-miss"></i>'};
const OUT_BADGE={answered:'green',voicemail:'blue',no_answer:'red',busy:'orange',callback_scheduled:'blue'};
async function loadData(){
  let u='/communications/call-logs/?ordering=-call_datetime';
  const s=document.getElementById('search').value,d=document.getElementById('fDir').value,o=document.getElementById('fOutcome').value;
  if(s)u+='&search='+encodeURIComponent(s);if(d)u+='&direction='+d;if(o)u+='&outcome='+o;
  const data=await api(u);const items=data.results||data;
  const tb=document.getElementById('tableBody');
  if(!items.length){tb.innerHTML='<tr><td colspan="9" style="text-align:center;padding:40px;color:var(--text-light)">No calls logged</td></tr>';return}
  tb.innerHTML=items.map(c=>{
    const custCell = c.customer_name
      ? escHTML(c.customer_name)
      : '<em style="color:var(--text-light)">Unknown caller</em>';
    return `<tr>
    <td>${DIR_ICON[c.direction]||''}</td><td>${fmtDT(c.called_at)}</td>
    <td>${custCell}</td><td>${escHTML(c.phone_number)||'\u2014'}</td>
    <td>${escHTML(c.display_duration)||'\u2014'}</td>
    <td><span class="badge badge-${OUT_BADGE[c.outcome]||'gray'}">${escHTML((c.outcome||'').replace(/_/g,' '))}</span></td>
    <td>${escHTML(c.agent_name)||'\u2014'}</td>
    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHTML(c.notes||'')}</td>
    <td><button type="button" class="btn-sm" onclick="openEdit('${c.id}')"><i class="fas fa-edit"></i></button></td>
  </tr>`;
  }).join('')}
// Phone-aware search: if input is mostly digits, search by phone; otherwise by name.
// Always shows a "Create new customer" CTA when zero results.
let _searchTimer=null;
function searchCust(){
  clearTimeout(_searchTimer);
  _searchTimer=setTimeout(_doSearchCust,250); // debounce
}
async function _doSearchCust(){
  const q=document.getElementById('fCustSearch').value.trim();
  const wrap=document.getElementById('custResults');
  if(q.length<2){wrap.innerHTML='';return}
  // Detect phone-mode: if input is mostly digits/spaces/dashes/parens
  const digitCount=(q.match(/\d/g)||[]).length;
  const isPhone=digitCount>=4 && digitCount/q.length>=0.5;
  const url='/customers/?search='+encodeURIComponent(q)+'&page_size=5';
  let items=[];
  try{
    const d=await api(url);
    items=d.results||d||[];
  }catch(e){items=[]}
  if(items.length){
    wrap.innerHTML=items.map(c=>`<div style="padding:6px 8px;cursor:pointer;border-bottom:1px solid var(--border)" onclick="pickCust('${c.id}','${(c.first_name||'').replace(/'/g,'&#39;')} ${(c.last_name||'').replace(/'/g,'&#39;')}','${c.phone||''}')">${escHTML(c.first_name||'')} ${escHTML(c.last_name||'')} <span style="color:var(--text-light)">${escHTML(c.phone||'')}</span></div>`).join('');
  }else{
    // Empty state with inline "Create new" CTA
    const phoneVal=isPhone?q:'';
    const nameVal=isPhone?'':q;
    wrap.innerHTML=`<div style="padding:10px 8px;color:var(--text-light);border-bottom:1px solid var(--border)">No matching customer.</div>
      <div style="padding:8px;cursor:pointer;background:rgba(165,206,58,0.08);color:var(--primary,#5a7a1a);font-weight:500" onclick="createCustFromCall('${nameVal.replace(/'/g,'&#39;')}','${phoneVal.replace(/'/g,'&#39;')}')">
        <i class="fas fa-user-plus"></i> Create new customer ${isPhone?'with phone '+q:'"'+q+'"'}
      </div>`;
  }
}
async function createCustFromCall(name,phone){
  // Quick-create: split name on first space; backend phone normalization handles formatting
  const parts=(name||'').trim().split(/\s+/);
  const first=parts[0]||'New';
  const last=parts.slice(1).join(' ')||'Customer';
  const body={first_name:first,last_name:last,phone:phone||document.getElementById('fPhone').value||''};
  try{
    const r=await apiFetch('/customers/','POST',body);
    if(r.ok){
      const c=await r.json();
      pickCust(c.id, (c.first_name||'')+' '+(c.last_name||''), c.phone||body.phone||'');
      toast('Customer created — finish the call form and Save');
    }else{
      const d=await r.json().catch(()=>({}));
      toast('Could not create customer: '+(Object.values(d).flat().join(', ')||'unknown error'),'error');
    }
  }catch(e){toast('Network error creating customer','error')}
}
function pickCust(id,name,phone){document.getElementById('fCustId').value=id;document.getElementById('fCustSearch').value=name;document.getElementById('fPhone').value=phone;document.getElementById('custResults').innerHTML=''}
function openNew(){editId=null;document.getElementById('modalTitle').textContent='Log Call';['fCustSearch','fCustId','fPhone','fNotes','fReason'].forEach(i=>{const el=document.getElementById(i);if(el)el.value=''});document.getElementById('fDuration').value='0';document.getElementById('callModal').classList.add('open')}
async function openEdit(id){editId=id;const c=await api('/communications/call-logs/'+id+'/');document.getElementById('modalTitle').textContent='Edit Call';document.getElementById('fCustId').value=c.customer||'';document.getElementById('fCustSearch').value=c.customer_name||'';document.getElementById('fPhone').value=c.phone_number||'';document.getElementById('fCallDir').value=c.direction||'inbound';document.getElementById('fDuration').value=Math.round((c.duration_seconds||0)/60);document.getElementById('fCallOut').value=c.outcome||'answered';document.getElementById('fNotes').value=c.notes||'';document.getElementById('callModal').classList.add('open')}
function closeModal(){document.getElementById('callModal').classList.remove('open')}
async function saveCall(){const b={customer:document.getElementById('fCustId').value||null,phone_number:document.getElementById('fPhone').value,direction:document.getElementById('fCallDir').value,duration_minutes:parseInt(document.getElementById('fDuration').value)||0,outcome:document.getElementById('fCallOut').value,notes:((document.getElementById('fReason')?.value)?'Reason: '+document.getElementById('fReason').value+'\n\n':'')+(document.getElementById('fNotes').value||'')};
  try{let r;if(editId)r=await apiFetch('/communications/call-logs/'+editId+'/','PATCH',b);else r=await apiFetch('/communications/call-logs/','POST',b);if(r.ok){toast(editId?'Call updated':'Call logged');closeModal();loadData()}else{const d=await r.json();toast('Error: '+Object.values(d).flat().join(', '),'error')}}catch(e){toast('Error','error')}}
document.addEventListener('DOMContentLoaded',loadData);