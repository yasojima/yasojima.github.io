(function(){
    if (window.__cbpSearchDebounce) return;
    window.__cbpSearchDebounce = true;

    var DELAY_MS = 250;

    window.cbpAutoDebounceSearch = function(rootEl) {
      var root = rootEl || document;
      var inputs = root.querySelectorAll("input.search-box[oninput]");
      for (var i = 0; i < inputs.length; i++) {
        var inp = inputs[i];
        if (inp.dataset.cbpDebounced === "1") continue;
        var origAttr = inp.getAttribute("oninput");
        if (!origAttr) continue;
        inp.dataset.cbpDebounced = "1";
        inp.removeAttribute("oninput"); // disable browser auto-binding
        inp.oninput = null;             // belt-and-suspenders
        // Compile original attribute body once (per element). Original
        // inline handlers run with `this` = the element and `event` in scope.
        var compiled;
        try {
          compiled = new Function("event", origAttr);
        } catch (e) {
          console.warn("[cbp-debounce] could not compile handler:", origAttr, e);
          continue;
        }
        (function(el, fn){
          var t = null;
          el.addEventListener("input", function(ev){
            if (t) clearTimeout(t);
            t = setTimeout(function(){
              try { fn.call(el, ev); }
              catch (e) { console.error("[cbp-debounce] handler error:", e); }
            }, DELAY_MS);
          });
        })(inp, compiled);
      }
    };

    // First page load
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", function(){ cbpAutoDebounceSearch(document); });
    } else {
      cbpAutoDebounceSearch(document);
    }
    // Every SPA navigation re-renders .content — new inputs need wiring
    window.addEventListener("cbp:spa-navigated", function(){ cbpAutoDebounceSearch(document); });
  })();