const API='/api/v1';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(method)=>{
  const h={'X-CSRFToken':csrf()};
  if(method!=='GET') h['Content-Type']='application/json';
  return h;
};
async function api(url,method='GET',body=null){
  const opts={method,credentials:'same-origin',headers:hdr(method)};
  if(body) opts.body=JSON.stringify(body);
  const r=await fetch(API+url,opts);
  if(r.status===204) return null;
  return r.json();
}
function toast(msg,kind){
  let e=document.getElementById('_apiToast');
  if(!e){e=document.createElement('div');e.id='_apiToast';e.style.cssText='position:fixed;top:20px;right:20px;padding:10px 16px;border-radius:6px;color:#fff;z-index:99999;font-size:13px;font-weight:500;box-shadow:0 4px 12px rgba(0,0,0,.15);max-width:380px;display:none';document.body.appendChild(e);}
  e.style.background=kind==='error'?'#e53935':'#43a047';
  e.textContent=msg;e.style.display='block';
  clearTimeout(e._t);e._t=setTimeout(()=>{e.style.display='none'},3000);
}
function _parseErr(d){
  if(!d) return 'Save failed';
  if(typeof d==='string') return d;
  if(d.detail) return d.detail;
  try{return Object.entries(d).map(([k,v])=>(k==='non_field_errors'?'':k.replace(/_/g,' ')+': ')+(Array.isArray(v)?v[0]:v)).filter(Boolean).join(' • ')||'Save failed';}catch(_){return 'Save failed';}
}

function fmtDate(s){if(!s)return'—';const d=new Date(s);return d.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
function fmtDateTime(s){if(!s)return'—';const d=new Date(s);return d.toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});}
function fmtTime(s){if(!s)return'—';const d=new Date(s);return d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'});}
function statusBadge(s){const m={scheduled:'blue',confirmed:'blue',in_progress:'orange',completed:'green',cancelled:'red',no_show:'gray'};return `<span class="badge badge-${m[s]||'gray'}">${(s||'').replace(/_/g,' ')}</span>`;}
function showModal(id){document.getElementById(id).classList.add('show');}
function hideModal(id){document.getElementById(id).classList.remove('show');}

let editId=null;
async function loadData(){
  const d=await api('/job-types/');
  const items=d.results||d;
  const grid=document.getElementById('grid');
  if(!items.length){grid.innerHTML='<div class="empty-state" style="grid-column:1/-1"><i class="fas fa-tags"></i><p>No job types configured — click Add Job Type to create one.</p></div>';return;}
  // F-056: dot reflects active/inactive status (green/gray), not the
  // user-chosen job-type color — the left-border already carries the
  // colour, and previously a red job-type colour on an Active row read
  // like an "off" indicator next to the word "Active".
  grid.innerHTML=items.map(j=>`<div class="jt-card clickable" style="border-left-color:${j.color||'var(--accent)'}" onclick="openEdit('${j.id}')"><div><div class="color-dot" style="background:${j.is_active?'#2e7d32':'#9e9e9e'}" title="${j.is_active?'Active':'Inactive'}"></div></div><div><h4>${j.name}${j.has_prep_sheet?' <i class="fas fa-paperclip" title="Prep sheet is emailed to customers on scheduling" style="color:var(--accent);font-size:11px;margin-left:4px"></i>':''}</h4><p>${j.default_duration_minutes||60} min &bull; $${j.default_price||'0'} &bull; ${j.is_active?'Active':'Inactive'}</p>${j.description?'<p>'+j.description+'</p>':''}</div><button type="button" class="btn-sm" style="position:absolute;top:8px;right:8px;color:#ccc;background:none;border:none;cursor:pointer;font-size:13px;padding:4px 6px" onclick="event.stopPropagation();deleteJob('${j.id}','${j.name}')" title="Delete"><i class="fas fa-trash-alt"></i></button></div>`).join('');
}
function _renderPrepSheet(j){
  const cur=document.getElementById('prepSheetCurrent');
  const link=document.getElementById('prepSheetLink');
  document.getElementById('fPrepSheet').value='';
  if(j&&j.has_prep_sheet){
    link.textContent=j.prep_sheet_name||'View current prep sheet';
    link.href=j.prep_sheet_url||'#';
    cur.style.display='flex';
  }else{
    cur.style.display='none';link.textContent='';link.href='#';
  }
}
function openNew(){editId=null;document.getElementById('modalTitle').textContent='New Job Type';['fName','fDesc'].forEach(id=>document.getElementById(id).value='');document.getElementById('fColor').value='#A5CE3A';document.getElementById('fDuration').value='60';document.getElementById('fPrice').value='0';document.getElementById('fActive').value='true';_renderPrepSheet(null);cbpAttachClearOnInput(document.getElementById('modal'));showModal('modal');}
async function openEdit(id){editId=id;const j=await api('/job-types/'+id+'/');document.getElementById('modalTitle').textContent='Edit Job Type';document.getElementById('fName').value=j.name||'';document.getElementById('fColor').value=j.color||'#A5CE3A';document.getElementById('fDuration').value=j.default_duration_minutes||60;document.getElementById('fPrice').value=j.default_price||0;document.getElementById('fActive').value=j.is_active?'true':'false';document.getElementById('fDesc').value=j.description||'';_renderPrepSheet(j);cbpAttachClearOnInput(document.getElementById('modal'));showModal('modal');}
async function uploadPrepSheet(jtId){
  const inp=document.getElementById('fPrepSheet');
  if(!inp||!inp.files||!inp.files.length) return true;
  const fd=new FormData();fd.append('prep_sheet',inp.files[0]);
  const r=await fetch(API+'/job-types/'+jtId+'/prep-sheet/',{method:'POST',credentials:'same-origin',headers:{'X-CSRFToken':csrf()},body:fd});
  if(!r.ok){let d=null;try{d=await r.json();}catch(_){}toast(_parseErr(d)||'Prep sheet upload failed','error');return false;}
  return true;
}
async function removePrepSheet(){
  if(!editId) return;
  if(!await cbpConfirm('Remove the prep sheet for this job type? It will no longer be emailed to customers.')) return;
  const r=await fetch(API+'/job-types/'+editId+'/prep-sheet/',{method:'DELETE',credentials:'same-origin',headers:{'X-CSRFToken':csrf()}});
  if(r.ok){let d=null;try{d=await r.json();}catch(_){}_renderPrepSheet(d||null);toast('Prep sheet removed');loadData();}
  else{toast('Error removing prep sheet','error');}
}
async function save(){
  const btn=document.getElementById('jobTypeSaveBtn');
  await cbpSubmit(btn, async () => {
    const body={name:document.getElementById('fName').value,color:document.getElementById('fColor').value,default_duration_minutes:parseInt(document.getElementById('fDuration').value),default_price:document.getElementById('fPrice').value,is_active:document.getElementById('fActive').value==='true',description:document.getElementById('fDesc').value};
    const url=editId?`/job-types/${editId}/`:'/job-types/';
    const method=editId?'PATCH':'POST';
    const r=await fetch(API+url,{method,credentials:'same-origin',headers:hdr(method),body:JSON.stringify(body)});
    let d=null;try{d=await r.json();}catch(_){}
    if(!r.ok){toast(_parseErr(d),'error');return;}
    const jtId=editId||(d&&d.id);
    if(jtId){const ok=await uploadPrepSheet(jtId);if(!ok){loadData();return;}}
    hideModal('modal');toast(editId?'Job type updated':'Job type created');loadData();
  });
}
async function deleteJob(id,name){
  if(!await cbpConfirm('Delete job type "'+name+'"? This cannot be undone.')) return;
  try{
    const r=await fetch(API+'/job-types/'+id+'/',{method:'DELETE',credentials:'same-origin',headers:{'X-CSRFToken':csrf()}});
    if(r.ok||r.status===204){toast('Deleted: '+name);loadData();}
    else{let d=null;try{d=await r.json();}catch(_){}toast((d&&d.detail)||'Error deleting','error');}
  }catch(e){if(e&&e.name==='AbortError')return;toast('Error: '+e.message,'error');}
}
document.addEventListener('DOMContentLoaded',loadData);