(function(){
  if (window.__cbpChatPop) return; window.__cbpChatPop = true;
  if (location.pathname.indexOf('/chat')===0) return; // already in chat
  function csrf(){ return (document.cookie.match(/csrftoken=([^;]+)/)||[])[1]||''; }
  function api(url,opts){ return fetch(url, Object.assign({credentials:'same-origin', headers:{'X-CSRFToken':csrf(),'Content-Type':'application/json'}}, opts||{})); }
  function esc(s){ var d=document.createElement('div'); d.textContent=(s==null?'':String(s)); return d.innerHTML; }
  function parseLink(link){
    var c=(link.match(/[?&]c=([^&]+)/)||[])[1], m=(link.match(/[?&]m=([^&]+)/)||[])[1];
    return { c:c?decodeURIComponent(c):null, m:m?decodeURIComponent(m):null };
  }
  function markRead(id){ return api('/api/v1/notifications/'+id+'/mark-read/', {method:'POST'}).catch(function(){}); }
  function show(n, moreCount){
    var lk=parseLink(n.link||''); if(!lk.c) return;
    var ov=document.createElement('div');
    ov.setAttribute('style','position:fixed;left:0;right:0;bottom:0;z-index:100001;display:flex;justify-content:center;padding:12px;pointer-events:none;');
    var card=document.createElement('div');
    card.setAttribute('style','pointer-events:auto;background:#fff;color:#1a1a1a;max-width:440px;width:100%;border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.35);padding:14px 16px;font-size:14px;');
    card.innerHTML =
      '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">'+
        '<div style="font-weight:700;"><i class="fas fa-comment-dots" style="color:var(--accent,#2e7d32);margin-right:6px;"></i>'+esc(n.title||'New message')+'</div>'+
        '<button type="button" id="cp-x" aria-label="Dismiss" style="border:none;background:none;font-size:20px;cursor:pointer;color:#999;line-height:1;">&times;</button>'+
      '</div>'+
      '<div style="color:#444;margin:6px 0 10px;white-space:pre-wrap;word-break:break-word;">'+esc(n.message||'')+'</div>'+
      (moreCount>0?'<div style="color:#888;font-size:12px;margin-bottom:8px;">+'+moreCount+' more unread</div>':'')+
      '<textarea id="cp-reply" rows="2" placeholder="Reply…" style="width:100%;padding:8px;border:1px solid #ccc;border-radius:8px;box-sizing:border-box;margin-bottom:8px;font-family:inherit;"></textarea>'+
      '<div style="display:flex;gap:8px;justify-content:flex-end;">'+
        '<button type="button" id="cp-open" style="padding:8px 12px;border:1px solid #ccc;background:#f5f5f5;color:#333;border-radius:8px;cursor:pointer;">Open chat</button>'+
        '<button type="button" id="cp-send" style="padding:8px 14px;border:none;background:var(--accent,#2e7d32);color:#fff;border-radius:8px;font-weight:600;cursor:pointer;">Send reply</button>'+
      '</div>'+
      '<div id="cp-err" style="color:#E53935;font-size:12px;min-height:14px;margin-top:4px;"></div>';
    ov.appendChild(card); document.body.appendChild(ov);
    function close(){ try{document.body.removeChild(ov);}catch(_){} }
    card.querySelector('#cp-x').onclick=function(){ markRead(n.id); close(); };
    card.querySelector('#cp-open').onclick=function(){ window.location.href=n.link; };
    card.querySelector('#cp-send').onclick=function(){
      var body=(card.querySelector('#cp-reply').value||'').trim(), err=card.querySelector('#cp-err');
      if(!body){ err.textContent='Type a reply first.'; return; }
      var payload={channel:lk.c, body:body}; if(lk.m) payload.reply_to=lk.m;
      var btn=card.querySelector('#cp-send'); btn.disabled=true;
      api('/api/v1/chat-rooms/messages/', {method:'POST', body:JSON.stringify(payload)})
        .then(function(r){ if(!r.ok) throw new Error('HTTP '+r.status); return r.json(); })
        .then(function(){ markRead(n.id); close(); })
        .catch(function(){ err.textContent='Could not send — tap Open chat to reply.'; btn.disabled=false; });
    };
    setTimeout(function(){ try{card.querySelector('#cp-reply').focus();}catch(_){} }, 60);
  }
  function run(){
    api('/api/v1/notifications/?unread_only=1').then(function(r){ return r.ok?r.json():null; }).then(function(d){
      if(!d) return;
      var rows = Array.isArray(d) ? d : (d.results||[]);
      var chat = rows.filter(function(n){ return !n.is_read && (n.link||'').indexOf('/chat/')===0; });
      if(!chat.length) return;
      chat.sort(function(a,b){ return (b.created_at||'').localeCompare(a.created_at||''); });
      show(chat[0], chat.length-1);
    }).catch(function(){});
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', run); else run();
})();