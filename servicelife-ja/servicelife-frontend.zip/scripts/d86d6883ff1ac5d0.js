window.OfficeUI = (() => {
  const api=window.SL_VIEW.office;
  const $=s=>document.querySelector(s);
  const dialog=$("#office-dialog"), body=$("#office-body");
  const escape=value=>String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  function choices(items, current="", first=null) {
    const all=first===null?items:[["",first],...items];
    return all.map(item=>{
      const [value,label]=Array.isArray(item)?item:[item,item];
      return '<option value="'+escape(value)+'"'+(String(current)===String(value)?' selected':'')+'>'+escape(label)+'</option>';
    }).join("");
  }
  function setChoices(el,items,first) {
    const selected=el.value, markup=choices(items,selected,first);
    if(el.innerHTML!==markup)el.innerHTML=markup;
  }
  function textInput(label,name,value="",attrs="") {
    return '<label>'+escape(label)+'<input name="'+name+'" value="'+escape(value)+'" '+attrs+'></label>';
  }
  function selectInput(label,name,options) {
    return '<label>'+escape(label)+'<select name="'+name+'" required>'+options+'</select></label>';
  }
  const notesInput=value=>'<label class="wide">メモ<textarea name="notes" maxlength="1100">'+escape(value)+'</textarea></label>';
  const cell=(label,html)=>'<td data-label="'+escape(label)+'"><span>'+html+'</span></td>';
  const button=(label,attribute,value)=>'<button type="button" class="link" '+attribute+'="'+escape(value)+'">'+escape(label)+'</button>';
  const sorted=values=>[...new Set(values)].sort((a,b)=>a.localeCompare(b,"ja",{numeric:true}));
  const status=message=>{$("#office-feedback").textContent=message;};
  function open(title,html){
    $("#office-title").textContent=title;body.innerHTML=html;
    if(!dialog.open)dialog.showModal();
  }
  function form(title,fields,submit,save) {
    open(title,'<form><div class="office-fields">'+fields+'</div><p class="error" role="alert"></p><div class="office-actions"><button type="button" data-close>キャンセル</button><button class="primary" type="submit">'+escape(submit)+'</button></div></form>');
    const element=body.querySelector("form"), action=element.querySelector('[type="submit"]');
    element.addEventListener("submit",async event=>{
      event.preventDefault();if(action.disabled)return;action.disabled=true;
      element.querySelector(".error").textContent="";
      try{
        await save(Object.fromEntries(new FormData(element)));
        if(element.isConnected && dialog.open)dialog.close();
        status("保存しました。");
      }catch(error){element.querySelector(".error").textContent=error.message;}
      finally{action.disabled=false;}
    });
  }
  dialog.addEventListener("click",e=>{if(e.target.closest("[data-close]"))dialog.close();});
  // The reference frames disallow native form navigation. Run only our local form handlers.
  $("#office").addEventListener("click",event=>{
    const submit=event.target.closest('button[type="submit"]');
    if(!submit?.form)return;
    event.preventDefault();
    if(submit.form.reportValidity())submit.form.dispatchEvent(new Event("submit",{bubbles:true,cancelable:true}));
  });
  $("#office").addEventListener("keydown",event=>{
    if(event.key==="Enter" && !event.isComposing && event.target.matches('input:not([type="file"])')){
      event.preventDefault();event.target.form?.querySelector('button[type="submit"]')?.click();
    }
  });
  function filters(form,render) {
    function apply(){
      const start=form.elements.from, end=form.elements.to;
      if(end){end.setCustomValidity(start.value && end.value && start.value>end.value?"終了日は開始日以降を選んでください。":"");}
      if(form.reportValidity())render();
    }
    form.addEventListener("submit",e=>{e.preventDefault();apply();});
    form.addEventListener("change",apply);
    form.addEventListener("reset",event=>{
      event.preventDefault();
      for(const field of form.querySelectorAll("input,select"))field.value="";
      apply();
    });
  }
  return {api,$,escape,choices,setChoices,textInput,selectInput,notesInput,cell,button,sorted,status,open,form,filters,body,dialog};
})();