(function(){
  const csrf = () => document.cookie.match(/csrftoken=([^;]+)/)?.[1] || '';
  const POLL_MS = 3000;
  let pollTimer = null;
  // Track which job rows currently have their error panel expanded so
  // a poll-driven re-render doesn't collapse the user's view.
  const expanded = new Set();

  function escHTML(s){
    return String(s == null ? '' : s)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  function fmtDt(iso){ if(!iso) return ''; const d=new Date(iso); return d.toLocaleString(); }
  function statusBadge(s){
    return '<span class="badge badge-' + escHTML(s) + '">' + escHTML(s.replace(/_/g,' ')) + '</span>';
  }

  async function fetchJSON(url, opts){
    opts = Object.assign({credentials:'same-origin', headers:{}}, opts || {});
    if(opts.method && opts.method !== 'GET'){
      opts.headers['X-CSRFToken'] = csrf();
    }
    const r = await fetch(url, opts);
    if(!r.ok){
      let body = ''; try { body = await r.text(); } catch(e) {}
      const e = new Error('HTTP ' + r.status + (body ? ': ' + body : ''));
      e.status = r.status;
      throw e;
    }
    if(r.status === 204) return null;
    return r.json();
  }

  function rowHTML(j){
    const validCount = j.valid_rows == null ? '–' : j.valid_rows;
    const invalidCount = j.invalid_rows == null ? '–' : j.invalid_rows;
    const totalCount = j.total_rows == null ? '–' : j.total_rows;
    const counts = totalCount + ' (<span style="color:#2e7d32">' + validCount + '</span> / <span style="color:#c62828">' + invalidCount + '</span>)';
    const canValidate = j.status === 'uploaded' || j.status === 'failed';
    const canCommit = j.status === 'ready_to_commit';
    const isBusy = j.status === 'validating' || j.status === 'committing';
    const hasErrors = j.error_summary && Object.keys(j.error_summary).length > 0;
    const isExpanded = expanded.has(j.id);

    let html = '<tr data-job="' + escHTML(j.id) + '">' +
      '<td>' + escHTML(fmtDt(j.created_at)) + '</td>' +
      '<td>' + escHTML(j.entity_type) + '</td>' +
      '<td title="' + escHTML(j.file_name) + '">' + escHTML(j.file_name) + '</td>' +
      '<td>' + statusBadge(j.status) + (isBusy ? ' <i class="fas fa-spinner fa-spin"></i>' : '') + '</td>' +
      '<td>' + counts + '</td>' +
      '<td>' + escHTML(j.created_by_username || '') + '</td>' +
      '<td><div class="row-actions">' +
        '<button class="btn-sm" data-action="validate" data-id="' + escHTML(j.id) + '"' + (canValidate ? '' : ' disabled') + '>Validate</button>' +
        '<button class="btn-sm" data-action="commit" data-id="' + escHTML(j.id) + '"' + (canCommit ? '' : ' disabled') + '>Commit</button>' +
        (hasErrors
          ? '<button class="btn-sm" data-action="toggle" data-id="' + escHTML(j.id) + '">' + (isExpanded ? 'Hide' : 'Errors') + '</button>'
          : '') +
      '</div></td>' +
    '</tr>';

    if(hasErrors && isExpanded){
      const errRows = Object.entries(j.error_summary)
        .sort((a,b) => parseInt(a[0],10) - parseInt(b[0],10))
        .slice(0, 100)
        .map(([row, errs]) =>
          '<tr><td>' + escHTML(row) + '</td><td>' +
          (Array.isArray(errs) ? errs.map(escHTML).join('<br>') : escHTML(errs)) +
          '</td></tr>'
        ).join('');
      html += '<tr class="errors-row"><td colspan="7">' +
        '<table class="errors-table"><thead><tr><th style="width:80px">Row</th><th>Errors</th></tr></thead>' +
        '<tbody>' + errRows + '</tbody></table>' +
        '</td></tr>';
    }
    return html;
  }

  async function loadJobs(){
    const tbody = document.getElementById('jobsBody');
    try {
      const data = await fetchJSON('/api/v1/migrations/jobs/');
      const rows = data.results || data;
      if(!rows.length){
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state"><i class="fas fa-inbox"></i><p>No imports yet. Upload a CSV above.</p></td></tr>';
        stopPoll();
        return;
      }
      tbody.innerHTML = rows.map(rowHTML).join('');

      // If anything is mid-validation/commit, keep polling.
      const anyBusy = rows.some(j => j.status === 'validating' || j.status === 'committing');
      if(anyBusy){ startPoll(); } else { stopPoll(); }
    } catch(e) {
      tbody.innerHTML = '<tr><td colspan="7" class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Failed to load: ' + escHTML(e.message) + '</p></td></tr>';
    }
  }

  function startPoll(){
    if(pollTimer) return;
    pollTimer = setInterval(loadJobs, POLL_MS);
  }
  function stopPoll(){
    if(!pollTimer) return;
    clearInterval(pollTimer);
    pollTimer = null;
  }

  async function trigger(action, id){
    const url = '/api/v1/migrations/jobs/' + encodeURIComponent(id) + '/' + action + '/';
    try {
      await fetchJSON(url, {method:'POST'});
      await loadJobs();
      startPoll();
    } catch(e){
      alert(action + ' failed: ' + e.message);
    }
  }

  // Event delegation: action buttons live inside #jobsBody and re-render
  // every poll, so binding once on the container is the right scope.
  document.addEventListener('click', function(ev){
    const btn = ev.target.closest('button[data-action]');
    if(!btn) return;
    const action = btn.dataset.action;
    const id = btn.dataset.id;
    if(action === 'toggle'){
      if(expanded.has(id)) expanded.delete(id); else expanded.add(id);
      loadJobs();
      return;
    }
    if(action === 'validate' || action === 'commit'){
      trigger(action, id);
    }
  });

  window.loadJobs = loadJobs;

  window.submitUpload = async function(ev){
    ev.preventDefault();
    const btn = document.getElementById('uploadBtn');
    const status = document.getElementById('uploadStatus');
    status.className = 'upload-status';
    status.textContent = 'Uploading…';
    btn.disabled = true;
    try {
      const fd = new FormData(document.getElementById('uploadForm'));
      const r = await fetch('/api/v1/migrations/jobs/', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {'X-CSRFToken': csrf()},
        body: fd,
      });
      const body = await r.text();
      if(!r.ok){
        status.className = 'upload-status error';
        status.textContent = 'Upload failed (HTTP ' + r.status + '): ' + body;
        return false;
      }
      status.className = 'upload-status success';
      status.textContent = 'Uploaded.';
      document.getElementById('uploadForm').reset();
      loadJobs();
    } catch(e) {
      status.className = 'upload-status error';
      status.textContent = 'Upload failed: ' + e.message;
    } finally {
      btn.disabled = false;
    }
    return false;
  };

  document.addEventListener('DOMContentLoaded', loadJobs);
})();