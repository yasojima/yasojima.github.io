const API='/api/v1';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(m)=>{const h={'X-CSRFToken':csrf()};if(m!=='GET')h['Content-Type']='application/json';return h;};
async function api(u,m='GET',b=null){const o={method:m,credentials:'same-origin',headers:hdr(m)};if(b)o.body=JSON.stringify(b);const r=await fetch(API+u,o);if(r.status===204)return null;return r.json();}
function toast(msg,kind){
  let e=document.getElementById('_apiToast');
  if(!e){e=document.createElement('div');e.id='_apiToast';e.style.cssText='position:fixed;top:20px;right:20px;padding:10px 16px;border-radius:6px;color:#fff;z-index:99999;font-size:13px;font-weight:500;box-shadow:0 4px 12px rgba(0,0,0,.15);max-width:380px;display:none';document.body.appendChild(e);}
  e.style.background=kind==='error'?'#e53935':'#43a047';
  e.textContent=msg;e.style.display='block';
  clearTimeout(e._t);e._t=setTimeout(()=>{e.style.display='none'},3000);
}
function _parseErr(d){
  if(!d) return 'Save failed';
  if(typeof d==='string') return d;
  if(d.detail) return d.detail;
  try{return Object.entries(d).map(([k,v])=>(k==='non_field_errors'?'':k.replace(/_/g,' ')+': ')+(Array.isArray(v)?v[0]:v)).filter(Boolean).join(' • ')||'Save failed';}catch(_){return 'Save failed';}
}

function fmtDate(s){if(!s)return'—';return new Date(s).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
function showModal(id){document.getElementById(id).classList.add('show');}
function hideModal(id){document.getElementById(id).classList.remove('show');}

let editId=null;
async function loadData(){let url='/pricebook/items/?ordering=name';const s=document.getElementById('search').value,t=document.getElementById('filterType').value;if(s)url+='&search='+encodeURIComponent(s);if(t)url+='&item_type='+t;const d=await api(url);const items=d.results||d;const tb=document.getElementById('tableBody');if(!items.length){tb.innerHTML='<tr><td colspan="10" style="text-align:center;padding:40px;color:var(--text-light)">No items yet</td></tr>';return;}
tb.innerHTML=items.map(i=>`<tr class="clickable" tabindex="0" role="link" onkeydown="if(event.key==='Enter'||event.key===' '){this.click();event.preventDefault()}" onclick="openEdit('${i.id}')"><td><strong>${i.code||'—'}</strong></td><td>${i.name}</td><td><span class="badge badge-blue">${i.item_type}</span></td><td>$${p(i.price)}</td><td>$${p(i.price_tier2)}</td><td>$${p(i.price_tier3)}</td><td>$${p(i.cost)}</td><td>${i.margin||0}%</td><td>${i.unit}</td><td>${i.is_active?'<span class="badge badge-green">Yes</span>':'<span class="badge badge-gray">No</span>'}</td></tr>`).join('');}
function p(v){return parseFloat(v||0).toFixed(2);}
function openNew(){editId=null;document.getElementById('modalTitle').textContent='Add Item';['fCode','fName','fDesc','fUnit'].forEach(id=>document.getElementById(id).value='');document.getElementById('fUnit').value='each';['fPrice','fPrice2','fPrice3','fCost','fDur'].forEach(id=>document.getElementById(id).value='0');document.getElementById('fType').value='service';document.getElementById('fTax').value='true';document.getElementById('fActive').value='true';showModal('modal');}
async function openEdit(id){editId=id;const i=await api('/pricebook/items/'+id+'/');document.getElementById('modalTitle').textContent='Edit — '+i.name;document.getElementById('fCode').value=i.code||'';document.getElementById('fName').value=i.name;document.getElementById('fDesc').value=i.description||'';document.getElementById('fType').value=i.item_type;document.getElementById('fPrice').value=i.price;document.getElementById('fPrice2').value=i.price_tier2;document.getElementById('fPrice3').value=i.price_tier3;document.getElementById('fCost').value=i.cost;document.getElementById('fUnit').value=i.unit;document.getElementById('fDur').value=i.duration_minutes;document.getElementById('fTax').value=i.taxable?'true':'false';document.getElementById('fActive').value=i.is_active?'true':'false';showModal('modal');}
async function save(){
  const btn=document.getElementById('pricebookSaveBtn');
  await cbpSubmit(btn, async () => {
    const body={code:document.getElementById('fCode').value,name:document.getElementById('fName').value,description:document.getElementById('fDesc').value,item_type:document.getElementById('fType').value,price:document.getElementById('fPrice').value,price_tier2:document.getElementById('fPrice2').value,price_tier3:document.getElementById('fPrice3').value,cost:document.getElementById('fCost').value,unit:document.getElementById('fUnit').value,duration_minutes:parseInt(document.getElementById('fDur').value),taxable:document.getElementById('fTax').value==='true',is_active:document.getElementById('fActive').value==='true'};
    const url=editId?`/pricebook/items/${editId}/`:'/pricebook/items/';
    const method=editId?'PATCH':'POST';
    const r=await fetch(API+url,{method,credentials:'same-origin',headers:hdr(method),body:JSON.stringify(body)});
    let d=null;try{d=await r.json();}catch(_){}
    if(!r.ok){toast(_parseErr(d),'error');return;}
    hideModal('modal');toast(editId?'Item updated':'Item created');loadData();
  });
}
document.addEventListener('DOMContentLoaded',loadData);