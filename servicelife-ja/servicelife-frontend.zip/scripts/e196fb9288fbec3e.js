const API='/api/v1';
let map=null;
let markers=[];
let polylines=[];
let routesData=null;
let selectedTechId=null;

const $=id=>document.getElementById(id);
const KM_TO_MI=0.621371;
const iso=d=>d.toISOString().split('T')[0];
const fmtMi=km=>Math.round(km*KM_TO_MI).toLocaleString();
const fmtHm=min=>`${Math.floor(min/60)}h ${Math.round(min%60)}m`;

// Default window: today only. Presets rewrite both ends; touching either date
// input directly flips the preset to Custom so the two never contradict.
function applyPreset(){
  const v=$('rangePreset').value;
  if(v==='custom')return;
  const days=parseInt(v,10);
  const end=new Date();
  const start=new Date();
  if(days===1){ start.setDate(start.getDate()-1); end.setDate(end.getDate()-1); }
  else if(days>1){ start.setDate(start.getDate()-(days-1)); }
  $('routeStart').value=iso(start);
  $('routeEnd').value=iso(end);
}
applyPreset();

// Initialize Google Map — called by the Maps API via callback=initMap once all
// library modules have loaded. Defers loadRoutes to the first 'idle' event so
// fitBounds() is never called before the map has rendered its first frame (the
// Maps API silently ignores fitBounds on an uninitialised map).
function initMap(){
  map=new google.maps.Map($('map'),{
    center:{lat:39.9526,lng:-75.1652},  // Philadelphia — where the work is
    zoom:10,
    mapId:'DEMO_MAP_ID',
    styles:[{featureType:'poi',stylers:[{visibility:'off'}]}]
  });
  $('mapLoading').style.display='none';
  google.maps.event.addListenerOnce(map,'idle',async()=>{
    await loadRoutes();
    maybeAutoSuggest();   // default view is a single day (Today) -> show suggestions
  });
}

async function loadRoutes(){
  const start=$('routeStart').value;
  const end=$('routeEnd').value;
  if(!start||!end)return;
  // Backstop only — the date-field change handler self-corrects a reversed
  // window, so this should never be user-visible. Warn, don't nag with a modal.
  if(end<start){ console.warn('routes: "To" precedes "From"; skipping load until corrected'); return; }

  // A technician selected either in the filter or by clicking a card makes the
  // API return stop lists, which is what the map polyline needs.
  const techId=selectedTechId||$('techFilter').value;
  let url=`${API}/routing/daily-routes/?start=${start}&end=${end}`;
  if(techId)url+=`&technician=${techId}`;

  try{
    const res=await fetch(url,{credentials:'same-origin'});
    if(!res.ok){
      const err=await res.json().catch(()=>({}));
      console.error('daily-routes failed',res.status,err);
      alert(err.error||`Could not load routes (HTTP ${res.status})`);
      return;
    }
    const data=await res.json();
    routesData=data;
    renderStats(data);
    renderTechList(data);
    renderMap(data);
  }catch(e){
    console.error('Failed to load routes:',e);
  }
}

// Prev/Next day: collapse the window to a SINGLE day and step by one. Flipping a
// day re-loads the routes and auto-loads the rebalance + pack-windows previews.
function stepDay(delta){
  const base=$('routeStart').value||iso(new Date());
  const d=new Date(base+'T00:00:00');
  d.setDate(d.getDate()+delta);
  const s=iso(d);
  $('routeStart').value=s;
  $('routeEnd').value=s;              // single day
  $('rangePreset').value='custom';
  loadRoutes();                       // keeps any technician filter, so you can follow one tech
  maybeAutoSuggest();
}

// Auto-load the rebalance + pack suggestions, but only for a single-day view —
// a multi-day range would fire one live drive-time preview per day.
// Optimize Day is heavier (reassign + retime, spends routing budget), so it is
// only auto-refreshed when its panel is already open — flipping dates while
// looking at the optimizer updates it, but a date change never fires an
// optimize preview when that panel is closed.
function maybeAutoSuggest(){
  const start=$('routeStart').value, end=$('routeEnd').value||start;
  if(!start||start!==end)return;
  runRebalance();
  runPack();
  if($('optimizeSection').classList.contains('show'))
    runOptimize();
}

function renderStats(data){
  const t=data.totals||{};
  $('statActiveTechs').textContent=t.technician_count||0;
  $('statTechDays').textContent=t.tech_days||0;
  $('statTotalStops').textContent=(t.total_stops||0).toLocaleString();
  $('statAvgStops').textContent=t.avg_stops_per_tech??0;
  $('statTotalMiles').textContent=fmtMi(t.total_distance_km||0)+' mi';
  $('statAvgMiles').textContent=fmtMi(t.avg_distance_km_per_tech||0);
  $('statTotalDrive').textContent=fmtHm(t.total_travel_minutes||0);
  $('statAvgDrive').textContent=fmtHm(t.avg_travel_minutes_per_tech||0);

  // An un-geocoded stop contributes no leg, so the mileage above is a floor.
  // Say so rather than quietly under-reporting.
  const un=t.ungeocoded_stops||0;
  const warn=$('geoWarning');
  if(un>0){
    $('geoWarningText').textContent=
      `${un} stop${un===1?'':'s'} in this range ${un===1?'has':'have'} no coordinates, `+
      `so ${un===1?'its':'their'} travel legs are not counted. Miles and drive time are a lower bound.`;
    warn.style.display='block';
  }else{
    warn.style.display='none';
  }
}

function renderTechList(data){
  const container=$('techList');
  const perTech=data.per_tech||[];
  if(!perTech.length){
    container.innerHTML='<div style="text-align:center;padding:40px;color:var(--text-light);font-size:12px"><i class="fas fa-calendar-times" style="font-size:32px;margin-bottom:8px;opacity:.3"></i><br>No routes in this date range</div>';
    return;
  }
  const multiDay=(data.days||1)>1;

  container.innerHTML=perTech.map(p=>{
    const t=p.technician;
    const stopsForTech=(data.routes||[])
      .filter(r=>r.technician.id===t.id)
      .flatMap(r=>r.stops.map(s=>({...s,date:r.date})));
    const preview=stopsForTech.slice(0,5);
    const extra=stopsForTech.length-preview.length;

    return `
    <div class="tech-card${selectedTechId===t.id?' active':''}" onclick="selectTech('${t.id}')" data-tech-id="${t.id}">
      <div class="tech-header">
        <div class="tech-avatar" style="background:${t.color}">${t.initials}</div>
        <div class="tech-info">
          <div class="tech-name">${t.name}${t.is_dispatchable?'':' <span style="font-weight:400;color:var(--text-light);font-size:10px">(inactive)</span>'}</div>
          <div class="tech-meta">
            <span><i class="fas fa-map-marker-alt"></i> ${p.total_stops} stops</span>
            <span><i class="fas fa-road"></i> ${fmtMi(p.total_distance_km)} mi</span>
            <span><i class="fas fa-clock"></i> ${fmtHm(p.total_travel_minutes)}</span>
          </div>
          ${multiDay?`<div class="tech-meta" style="opacity:.75">
            <span>${p.days_worked} days</span>
            <span>${p.avg_stops_per_day}/day</span>
            <span>${fmtMi(p.avg_distance_km_per_day)} mi/day</span>
          </div>`:''}
        </div>
      </div>
      <div class="stop-list">
        ${preview.map(s=>`
          <div class="stop">
            <span class="time">${multiDay?s.date.slice(5):''} ${s.time||'—'}</span>
            <span class="addr">${s.label} • ${s.address}</span>
          </div>
        `).join('')}
        ${extra>0?`<div class="stop" style="color:var(--accent);font-weight:600">+${extra} more</div>`:''}
        ${!data.include_stops?`<div class="stop" style="color:var(--text-light);font-style:italic">Click to see stops and draw the route</div>`:''}
      </div>
    </div>`;
  }).join('');
}

// Selecting a tech refetches, because the API only ships stop lists (which the
// polyline is drawn from) for a single-technician or single-day window.
function selectTech(techId){
  selectedTechId=selectedTechId===techId?null:techId;
  $('techFilter').value=selectedTechId||'';
  loadRoutes();
}

function renderMap(data){
  if(!map)return;
  markers.forEach(m=>{if(m.setMap)m.setMap(null);else m.map=null;});
  markers=[];
  polylines.forEach(p=>p.setMap(null));
  polylines=[];

  const routes=data.routes||[];
  const bounds=new google.maps.LatLngBounds();
  let hasMarkers=false;

  routes.forEach(route=>{
    if(selectedTechId&&route.technician.id!==selectedTechId)return;
    const color=route.technician.color;
    const path=[];

    route.stops.forEach((stop,idx)=>{
      if(stop.lat==null||stop.lng==null)return;   // 0 is a valid coordinate
      const pos={lat:stop.lat,lng:stop.lng};
      path.push(pos);

      const infoWindow=new google.maps.InfoWindow({content:`
        <div style="font-family:Inter,sans-serif;font-size:12px;padding:4px">
          <strong style="color:${color}">${route.technician.name}</strong><br>
          <strong>${idx+1}. ${stop.label}</strong><br>
          ${stop.address}<br>
          ${stop.time?`<span style="color:#666">${route.date} · ${stop.time}${stop.end_time?' - '+stop.end_time:''}</span><br>`:''}
          ${stop.travel_from_prev_km?`<span style="color:#666">${(stop.travel_from_prev_km*KM_TO_MI).toFixed(1)} mi · ${stop.travel_from_prev_min} min from previous</span><br>`:''}
          ${stop.job_type?`<span style="color:#666">${stop.job_type}</span>`:''}
        </div>`});

      const el=document.createElement('div');
      el.style.cssText=`display:flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:50%;background:${color};color:#fff;font:600 10px/1 Inter,sans-serif;border:2px solid #fff;box-shadow:0 1px 3px rgba(0,0,0,.4);`;
      el.textContent=idx+1;
      const marker=new google.maps.marker.AdvancedMarkerElement({
        position:pos,map:map,title:`${route.technician.name}: ${stop.label}`,content:el});
      marker.addListener('click',()=>infoWindow.open(map,marker));

      markers.push(marker);
      bounds.extend(pos);
      hasMarkers=true;
    });

    // The route itself: first stop → last stop, in visit order. One polyline
    // per tech-day, so a multi-day selection doesn't draw a phantom overnight
    // leg from one day's last stop to the next day's first.
    if(path.length>1){
      const line=new google.maps.Polyline({
        path,map,geodesic:false,
        strokeColor:color,strokeOpacity:0.85,strokeWeight:3,
        icons:[{icon:{path:google.maps.SymbolPath.FORWARD_CLOSED_ARROW,scale:2.5},
                offset:'50%',repeat:'120px'}],
      });
      polylines.push(line);
    }
  });

  if(hasMarkers){
    map.fitBounds(bounds);
    const listener=google.maps.event.addListener(map,'idle',()=>{
      if(map.getZoom()>15)map.setZoom(12);
      google.maps.event.removeListener(listener);
    });
  }
}

async function loadTechnicianFilter(){
  try{
    const res=await fetch(`${API}/technicians/?is_available=true`,{credentials:'same-origin'});
    if(!res.ok) throw new Error(`technicians fetch failed: ${res.status}`);
    const data=await res.json();
    const techs=data.results||data;
    const select=$('techFilter');
    select.innerHTML='<option value="">All Technicians</option>'+
      techs.map(t=>`<option value="${t.id}">${t.name}</option>`).join('');
  }catch(e){console.error('loadTechnicianFilter:', e);}
}

// Drive-time rebalance — reassign appointments between technicians to cut
// windshield time. Appointment dates/times never change; only the assigned
// tech does. Runs per day over the selected date range.
let driveRebalanceData=null;

async function runRebalance(){
  const start=$('routeStart').value;
  const end=$('routeEnd').value||start;
  if(!start)return;

  const section=$('rebalanceSection');
  const content=$('rebalanceContent');
  section.classList.add('show');
  content.innerHTML='<div class="rebalance-empty">Calculating drive-time savings…</div>';

  try{
    const res=await fetch(`${API}/routing/drive-rebalance/preview/?start=${start}&end=${end}`,{credentials:'same-origin'});
    if(!res.ok){const e=await res.json().catch(()=>({}));throw new Error(e.error||('HTTP '+res.status));}
    const data=await res.json();
    if($('routeStart').value!==start)return;   // navigated to another day mid-flight; drop stale
    driveRebalanceData=data;
    renderDriveRebalance(driveRebalanceData);
    renderConflicts(driveRebalanceData);
  }catch(e){
    console.error('Rebalance failed:',e);
    if($('routeStart').value===start)
      content.innerHTML=`<div class="rebalance-empty">Failed to load rebalance preview: ${e.message||e}</div>`;
  }
}
document.getElementById('btnRebalance').addEventListener('click',()=>{
  if(!$('routeStart').value)return alert('Select a date first');
  runRebalance();
});

function renderDriveRebalance(data){
  const content=$('rebalanceContent');
  const days=data.days||{};
  const dates=Object.keys(days).sort();
  const totalMoves=data.total_moves||0;
  const totalLunch=data.total_lunch_moves||0;

  if(!totalMoves && !totalLunch){
    content.innerHTML='<div class="rebalance-empty">Nothing to optimize for the selected date(s). Routes are already efficient (or the only candidates are locked to a preferred tech / missing a location) and every lunch is already as early as it can be.</div>';
    return;
  }

  let html=`<div class="rebalance-summary" style="margin-bottom:12px;font-size:13px">
    <strong>${totalMoves}</strong> technician reassignment(s) saving <strong>${data.total_minutes_saved} min</strong> of drive time,
    and <strong>${totalLunch}</strong> lunch time change(s) to close pre-lunch gaps.
    Appointment times are <strong>unchanged</strong> — only the assigned technician and (where noted) the lunch time change.
  </div>`;

  for(const d of dates){
    const day=days[d];
    const moves=day.moves||[];
    const lunchMoves=day.lunch_moves||[];
    const skip=day.skipped||[];
    if(!moves.length && !lunchMoves.length && !skip.length) continue;
    const s=day.summary;
    const label=new Date(d+'T00:00:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
    html+=`<div class="reb-day" style="margin-bottom:16px">
      <div style="font-weight:600;margin-bottom:6px">${label}
        <span style="font-weight:400;color:var(--text-light)">— ${s.baseline_drive_minutes} → ${s.projected_drive_minutes} min drive
        (${s.minutes_saved>0?'saves '+s.minutes_saved+' min':'no change'})${s.degraded?' · estimates degraded (budget cap)':''}</span>
      </div>`;
    if(moves.length){
      html+=`<table class="rebalance-table"><thead><tr>
        <th><input type="checkbox" class="reb-all" data-date="${d}" checked></th>
        <th>Time</th><th>Customer</th><th>From &rarr; To</th><th>Saves</th><th>Notes</th>
      </tr></thead><tbody>`;
      moves.forEach((mv,i)=>{
        const w=(mv.warnings||[]).join('; ');
        const warn=w?`<span title="${w}" style="color:#b26a00">⚠ ${w}</span>`:'';
        html+=`<tr>
          <td><input type="checkbox" class="reb-move" data-date="${d}" data-i="${i}" checked></td>
          <td>${mv.time}</td>
          <td><strong>${mv.customer_name}</strong><br><span style="color:var(--text-light);font-size:11px">${mv.address}</span></td>
          <td>${mv.from_technician_name} &rarr; <strong>${mv.to_technician_name}</strong></td>
          <td style="color:#2e7d32;font-weight:600">${mv.minutes_saved} min</td>
          <td style="font-size:11px">${warn}</td>
        </tr>`;
      });
      html+=`</tbody></table>`;
    }
    if(lunchMoves.length){
      html+=`<table class="rebalance-table" style="margin-top:6px"><thead><tr>
        <th><input type="checkbox" class="reb-lunch-all" data-date="${d}" checked></th>
        <th>Technician</th><th colspan="4">Move lunch earlier (closes a gap)</th>
      </tr></thead><tbody>`;
      lunchMoves.forEach((lm,i)=>{
        html+=`<tr>
          <td><input type="checkbox" class="reb-lunch" data-date="${d}" data-i="${i}" checked></td>
          <td><strong>${lm.technician_name}</strong></td>
          <td colspan="4"><i class="fas fa-utensils" style="opacity:.5"></i>
            ${lm.from_time}–${lm.from_end_time} &rarr; <strong>${lm.to_time}–${lm.to_end_time}</strong></td>
        </tr>`;
      });
      html+=`</tbody></table>`;
    }
    if(skip.length){
      const locked=skip.filter(x=>/preferred/.test(x.reason||'')).length;
      const noloc=skip.filter(x=>/location/.test(x.reason||'')).length;
      const bits=[];
      if(locked)bits.push(`${locked} locked to preferred tech`);
      if(noloc)bits.push(`${noloc} missing a location`);
      if(bits.length)html+=`<div style="font-size:11px;color:var(--text-light);margin-top:4px">Skipped: ${bits.join(', ')}</div>`;
    }
    html+=`</div>`;
  }

  html+=`<div style="margin-top:12px;display:flex;gap:10px;align-items:center">
    <button class="btn-apply" id="btnApplyDriveRebalance">Approve &amp; Apply Selected</button>
    <span id="rebApplyStatus" style="font-size:12px;color:var(--text-light)"></span>
  </div>`;

  content.innerHTML=html;

  content.querySelectorAll('.reb-all').forEach(cb=>cb.addEventListener('change',()=>{
    content.querySelectorAll(`.reb-move[data-date="${cb.dataset.date}"]`).forEach(x=>{x.checked=cb.checked;});
  }));
  content.querySelectorAll('.reb-lunch-all').forEach(cb=>cb.addEventListener('change',()=>{
    content.querySelectorAll(`.reb-lunch[data-date="${cb.dataset.date}"]`).forEach(x=>{x.checked=cb.checked;});
  }));
  $('btnApplyDriveRebalance').addEventListener('click',applyDriveRebalance);
}

document.getElementById('btnCloseRebalance').addEventListener('click',()=>{
  document.getElementById('rebalanceSection').classList.remove('show');
});

// Appointment / lunch conflicts — booked stops already overlapping a tech's
// scheduled break. Flag-only (a human reschedules the stop or moves the break);
// piggybacks on the drive-rebalance preview payload so it needs no extra fetch.
document.getElementById('btnCloseConflict')?.addEventListener('click',()=>{
  document.getElementById('conflictSection').classList.remove('show');
});
function renderConflicts(data){
  const section=$('conflictSection'), content=$('conflictContent');
  const days=data.days||{}, dates=Object.keys(days).sort();
  const total=data.total_conflicts||0;
  if(!total){ section.classList.remove('show'); content.innerHTML=''; return; }
  let html=`<div style="margin-bottom:12px;font-size:13px"><strong>${total}</strong> appointment(s) overlap a technician's scheduled lunch. These stops are double-booked against the break — reschedule the appointment or move the lunch to resolve.</div>`;
  for(const d of dates){
    const conflicts=days[d].conflicts||[];
    if(!conflicts.length)continue;
    const label=new Date(d+'T00:00:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
    html+=`<div style="margin-bottom:14px"><div style="font-weight:600;margin-bottom:6px">${label}</div>`;
    html+=`<table class="rebalance-table"><thead><tr><th>Technician</th><th>Customer</th><th>Appointment</th><th>Lunch</th><th>Overlap</th></tr></thead><tbody>`;
    conflicts.forEach(c=>{
      html+=`<tr>
        <td><strong>${c.technician_name}</strong></td>
        <td>${c.customer_name}</td>
        <td>${c.appt_time}</td>
        <td><i class="fas fa-utensils" style="opacity:.5"></i> ${c.lunch_time}</td>
        <td style="color:#d32f2f;font-weight:600">${c.overlap_minutes} min</td>
      </tr>`;
    });
    html+=`</tbody></table></div>`;
  }
  content.innerHTML=html;
  section.classList.add('show');
}

async function applyDriveRebalance(){
  const content=$('rebalanceContent');
  const days=driveRebalanceData.days||{};
  const boxes=[...content.querySelectorAll('.reb-move:checked')];
  const lunchBoxes=[...content.querySelectorAll('.reb-lunch:checked')];
  if(!boxes.length && !lunchBoxes.length)return alert('Nothing selected');

  const moves=boxes.map(b=>{
    const mv=days[b.dataset.date].moves[parseInt(b.dataset.i,10)];
    return {appointment_id:mv.appointment_id,from_technician_id:mv.from_technician_id,
            to_technician_id:mv.to_technician_id,estimated_minutes_saved:mv.minutes_saved};
  });
  const lunch_moves=lunchBoxes.map(b=>{
    const lm=days[b.dataset.date].lunch_moves[parseInt(b.dataset.i,10)];
    return {technician_id:lm.technician_id,date:b.dataset.date};
  });
  const dayCount=new Set([...boxes,...lunchBoxes].map(b=>b.dataset.date)).size;
  if(!confirm(`Apply ${moves.length} technician reassignment(s) and ${lunch_moves.length} lunch change(s) across ${dayCount} day(s)? Appointment times are unchanged.`))return;

  const btn=$('btnApplyDriveRebalance');btn.disabled=true;
  const status=$('rebApplyStatus');status.textContent='Applying…';
  try{
    const res=await fetch(`${API}/routing/drive-rebalance/apply/`,{
      method:'POST',
      headers:{'Content-Type':'application/json','X-CSRFToken':getCsrfToken()},
      credentials:'same-origin',
      body:JSON.stringify({moves,lunch_moves})
    });
    const data=await res.json();
    if(!res.ok)throw new Error(data.error||('HTTP '+res.status));
    status.textContent=`Applied ${data.applied_count} move(s), ${data.lunch_applied_count} lunch change(s).`;
    const allSkips=[...(data.skipped||[]),...(data.lunch_skipped||[])];
    if(allSkips.length){
      alert(`Applied ${data.applied_count} move(s) + ${data.lunch_applied_count} lunch change(s). Skipped ${allSkips.length}:\n`+
        allSkips.map(sk=>`• ${sk.reason}`).join('\n'));
    }
    loadRoutes();
    document.getElementById('btnRebalance').click();  // refresh preview; applied items drop off
  }catch(e){
    status.textContent='';
    alert('Failed to apply: '+(e.message||e));
  }finally{
    btn.disabled=false;
  }
}

function getCsrfToken(){
  return document.cookie.split('; ').find(r=>r.startsWith('csrftoken='))?.split('=')[1]||'';
}

// Joint optimizer — reassign to other techs AND slide times within arrival
// windows (which also resequences the day) to cut total drive time. Preview ->
// approve -> apply. Heavier + spends routing budget, so unlike Rebalance/Pack it
// is not auto-run on the FIRST date change — but once its panel is open it
// auto-refreshes on subsequent date changes (see maybeAutoSuggest).
let optimizeData=null;
document.getElementById('btnCloseOptimize')?.addEventListener('click',()=>$('optimizeSection').classList.remove('show'));
document.getElementById('btnOptimizeDay').addEventListener('click',()=>{
  if(!$('routeStart').value)return alert('Select a date first');
  runOptimize();
});
async function runOptimize(){
  const start=$('routeStart').value, end=$('routeEnd').value||start;
  if(!start)return;
  const section=$('optimizeSection'), content=$('optimizeContent');
  section.classList.add('show');
  content.innerHTML='<div class="rebalance-empty">Optimizing routes (reassign + retime within windows)…</div>';
  try{
    const res=await fetch(`${API}/routing/optimize/preview/?start=${start}&end=${end}`,{credentials:'same-origin'});
    if(!res.ok){const e=await res.json().catch(()=>({}));throw new Error(e.error||('HTTP '+res.status));}
    const data=await res.json();
    if($('routeStart').value!==start)return;   // navigated away mid-flight
    optimizeData=data;
    renderOptimize(data);
  }catch(e){
    console.error('Optimize failed:',e);
    if($('routeStart').value===start)
      content.innerHTML=`<div class="rebalance-empty">Failed to load optimizer preview: ${e.message||e}</div>`;
  }
}
function renderOptimize(data){
  const content=$('optimizeContent');
  const days=data.days||{}; const dates=Object.keys(days).sort();
  const totalMoves=data.total_moves||0;
  if(!totalMoves){
    content.innerHTML='<div class="rebalance-empty">Nothing to optimize for the selected date(s). Routes are already efficient, or the only movable stops are fixed exact-time (commercial / one-time), locked to a preferred tech, or missing a location.</div>';
    return;
  }
  let html=`<div class="rebalance-summary" style="margin-bottom:12px;font-size:13px">
    <strong>${totalMoves}</strong> joint move(s) saving <strong>${data.total_minutes_saved} min</strong> of drive time.
    Each may reassign the technician <em>and</em> shift the arrival time within the customer's booked 2-hour window.
  </div>`;
  for(const d of dates){
    const day=days[d]; const moves=day.moves||[]; const skip=day.skipped||[];
    if(!moves.length && !skip.length) continue;
    const s=day.summary;
    const label=new Date(d+'T00:00:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
    html+=`<div class="reb-day" style="margin-bottom:16px">
      <div style="font-weight:600;margin-bottom:6px">${label}
        <span style="font-weight:400;color:var(--text-light)">— ${s.baseline_drive_minutes} → ${s.projected_drive_minutes} min drive
        (${s.minutes_saved>0?'saves '+s.minutes_saved+' min':'no change'})${s.degraded?' · estimates degraded (budget cap)':''}</span>
      </div>`;
    if(moves.length){
      html+=`<table class="rebalance-table"><thead><tr>
        <th><input type="checkbox" class="opt-all" data-date="${d}" checked></th>
        <th>Customer</th><th>Arrival time</th><th>From &rarr; To</th><th>Saves</th>
      </tr></thead><tbody>`;
      moves.forEach((mv,i)=>{
        const timeCell = mv.retimed
          ? `<span style="text-decoration:line-through;color:var(--text-light)">${mv.time}</span> &rarr; <strong>${mv.new_time}</strong>${mv.window?`<br><span style="color:var(--text-light);font-size:11px">within ${mv.window}</span>`:''}`
          : mv.time;
        const techCell = mv.reassigned
          ? `${mv.from_technician_name} &rarr; <strong>${mv.to_technician_name}</strong>`
          : `<span style="color:var(--text-light)">${mv.to_technician_name} (same tech)</span>`;
        html+=`<tr>
          <td><input type="checkbox" class="opt-move" data-date="${d}" data-i="${i}" checked></td>
          <td><strong>${mv.customer_name}</strong><br><span style="color:var(--text-light);font-size:11px">${mv.address}</span></td>
          <td>${timeCell}</td>
          <td>${techCell}</td>
          <td style="color:#2e7d32;font-weight:600">${mv.minutes_saved} min</td>
        </tr>`;
      });
      html+=`</tbody></table>`;
    }
    if(skip.length){
      const exact=skip.filter(x=>/exact-time/.test(x.reason||'')).length;
      const locked=skip.filter(x=>/preferred/.test(x.reason||'')).length;
      const noloc=skip.filter(x=>/location/.test(x.reason||'')).length;
      const bits=[];
      if(exact)bits.push(`${exact} fixed exact-time`);
      if(locked)bits.push(`${locked} locked to preferred tech`);
      if(noloc)bits.push(`${noloc} missing a location`);
      if(bits.length)html+=`<div style="font-size:11px;color:var(--text-light);margin-top:4px">Not movable: ${bits.join(', ')}</div>`;
    }
    html+=`</div>`;
  }
  html+=`<div style="margin-top:12px;display:flex;gap:10px;align-items:center">
    <button class="btn-apply" id="btnApplyOptimize">Approve &amp; Apply Selected</button>
    <span id="optApplyStatus" style="font-size:12px;color:var(--text-light)"></span>
  </div>`;
  content.innerHTML=html;
  content.querySelectorAll('.opt-all').forEach(cb=>cb.addEventListener('change',()=>{
    content.querySelectorAll(`.opt-move[data-date="${cb.dataset.date}"]`).forEach(x=>{x.checked=cb.checked;});
  }));
  $('btnApplyOptimize').addEventListener('click',applyOptimize);
}
async function applyOptimize(){
  const content=$('optimizeContent'); const days=optimizeData.days||{};
  const boxes=[...content.querySelectorAll('.opt-move:checked')];
  if(!boxes.length)return alert('Nothing selected');
  const moves=boxes.map(b=>{
    const mv=days[b.dataset.date].moves[parseInt(b.dataset.i,10)];
    return {appointment_id:mv.appointment_id,from_technician_id:mv.from_technician_id,
            to_technician_id:mv.to_technician_id,new_start_iso:mv.new_start_iso,
            estimated_minutes_saved:mv.minutes_saved};
  });
  const dayCount=new Set(boxes.map(b=>b.dataset.date)).size;
  if(!confirm(`Apply ${moves.length} joint move(s) across ${dayCount} day(s)? This reassigns technicians and shifts arrival times within each customer's booked window.`))return;
  const btn=$('btnApplyOptimize');btn.disabled=true;
  const status=$('optApplyStatus');status.textContent='Applying…';
  try{
    const res=await fetch(`${API}/routing/optimize/apply/`,{
      method:'POST',
      headers:{'Content-Type':'application/json','X-CSRFToken':getCsrfToken()},
      credentials:'same-origin',
      body:JSON.stringify({moves})
    });
    const data=await res.json();
    if(!res.ok)throw new Error(data.error||('HTTP '+res.status));
    status.textContent=`Applied ${data.applied_count} move(s).`;
    if((data.skipped||[]).length){
      alert(`Applied ${data.applied_count} move(s). Skipped ${data.skipped.length}:\n`+
        data.skipped.map(sk=>`• ${sk.reason}`).join('\n'));
    }
    loadRoutes();
    document.getElementById('btnOptimizeDay').click();  // refresh; applied items drop off
  }catch(e){
    status.textContent='';
    alert('Failed to apply: '+(e.message||e));
  }finally{ btn.disabled=false; }
}

// Route packing — pull windowed appointments EARLIER within their 2-hour arrival
// window (order-preserving) to close idle gaps. Preview -> apply, per day.
let packData=null;
document.getElementById('btnClosePack')?.addEventListener('click',()=>$('packSection').classList.remove('show'));
async function runPack(){
  const start=$('routeStart').value, end=$('routeEnd').value||start;
  if(!start)return;
  const section=$('packSection'), content=$('packContent');
  section.classList.add('show');
  content.innerHTML='<div class="rebalance-empty">Finding stops that can move earlier…</div>';
  try{
    const res=await fetch(`${API}/routing/pack/preview/?start=${start}&end=${end}`,{credentials:'same-origin'});
    if(!res.ok){const e=await res.json().catch(()=>({}));throw new Error(e.error||('HTTP '+res.status));}
    const data=await res.json();
    if($('routeStart').value!==start)return;   // navigated away mid-flight; drop stale
    packData=data;
    renderPack(packData);
  }catch(e){if($('routeStart').value===start)content.innerHTML=`<div class="rebalance-empty">Failed to load pack preview: ${e.message||e}</div>`;}
}
document.getElementById('btnPackDay')?.addEventListener('click',()=>{
  if(!$('routeStart').value)return alert('Select a date first');
  runPack();
});
function renderPack(data){
  const content=$('packContent'), days=data.days||{}, dates=Object.keys(days).sort();
  if(!(data.total_moves>0)){content.innerHTML='<div class="rebalance-empty">Nothing to pack — windowed stops are already as early as their window and route allow.</div>';return;}
  let html=`<div style="margin-bottom:12px;font-size:13px"><strong>${data.total_moves}</strong> stop(s) can move earlier, reclaiming <strong>${data.total_minutes_reclaimed} min</strong> of idle time. Customers stay within the arrival window they were given.</div>`;
  for(const d of dates){
    const day=days[d], moves=day.moves||[];
    if(!moves.length)continue;
    const label=new Date(d+'T00:00:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
    html+=`<div style="margin-bottom:14px"><div style="font-weight:600;margin-bottom:6px">${label} <span style="font-weight:400;color:var(--text-light)">— reclaims ${day.summary.minutes_reclaimed} min</span></div>`;
    html+=`<table class="rebalance-table"><thead><tr><th>Tech</th><th>Customer</th><th>Window</th><th>Move</th></tr></thead><tbody>`;
    moves.forEach(mv=>{html+=`<tr><td>${mv.technician_name}</td><td><strong>${mv.customer_name}</strong></td><td>${mv.window||''}</td><td>${mv.from_time} &rarr; <strong>${mv.to_time}</strong> (${mv.minutes_earlier}m earlier)</td></tr>`;});
    html+=`</tbody></table><button class="btn-apply" style="margin-top:8px" onclick="applyPack('${d}')">Apply ${label}</button></div>`;
  }
  content.innerHTML=html;
}
async function applyPack(dateStr){
  const day=(packData.days||{})[dateStr]; if(!day)return;
  const ids=(day.moves||[]).map(m=>m.appointment_id);
  if(!ids.length)return;
  if(!confirm(`Pull ${ids.length} stop(s) earlier on ${dateStr}? Customers remain within their arrival window.`))return;
  try{
    const res=await fetch(`${API}/routing/pack/apply/`,{method:'POST',credentials:'same-origin',
      headers:{'Content-Type':'application/json','X-CSRFToken':getCsrfToken()},
      body:JSON.stringify({date:dateStr,appointment_ids:ids})});
    const d=await res.json();
    if(!res.ok)throw new Error(d.error||('HTTP '+res.status));
    alert(`Applied ${d.applied_count} move(s).`);
    location.reload();
  }catch(e){alert('Failed to apply: '+(e.message||e));}
}

// Event listeners
$('btnPrevDay').addEventListener('click',()=>stepDay(-1));
$('btnNextDay').addEventListener('click',()=>stepDay(1));
// Editing either end of the window means the preset no longer describes it.
// If an edit reverses the window (e.g. bumping "From" to the next day past a
// "To" that's still today), pull the OTHER end to match the one just edited
// rather than blocking — so stepping "From" forward a day just shows that day.
['routeStart','routeEnd'].forEach(id=>$(id).addEventListener('change',()=>{
  $('rangePreset').value='custom';
  const s=$('routeStart').value, e=$('routeEnd').value;
  if(s&&e&&e<s){
    if(id==='routeStart') $('routeEnd').value=s;   // moved From past To -> To follows
    else $('routeStart').value=e;                   // moved To before From -> From follows
  }
  loadRoutes();
  maybeAutoSuggest();
}));
$('rangePreset').addEventListener('change',()=>{applyPreset();loadRoutes();maybeAutoSuggest();});
$('techFilter').addEventListener('change',()=>{
  selectedTechId=$('techFilter').value||null;
  loadRoutes();
});

// initMap is invoked automatically by &callback=initMap in the Maps script URL.
loadTechnicianFilter();