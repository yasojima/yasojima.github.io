(function() {
  function getCsrf(form) {
    var el = form.querySelector('input[name=csrfmiddlewaretoken]');
    return el ? el.value : '';
  }
  function setStatus(licenseId, msg, ok) {
    var box = document.getElementById('upload-status-' + licenseId);
    if (!box) return;
    box.textContent = msg;
    box.classList.remove('ok', 'err');
    box.classList.add(ok ? 'ok' : 'err');
  }
  document.querySelectorAll('.doc-upload-form').forEach(function(form) {
    form.addEventListener('submit', function(ev) {
      ev.preventDefault();
      var licenseId = form.dataset.licenseId;
      var url = form.dataset.uploadUrl;
      var fileInput = form.querySelector('input[type=file]');
      if (!fileInput.files || !fileInput.files[0]) {
        setStatus(licenseId, 'Pick a file first.', false);
        return;
      }
      var fd = new FormData();
      fd.append('file', fileInput.files[0]);
      setStatus(licenseId, 'Uploading…', true);
      fetch(url, {
        method: 'POST',
        headers: { 'X-CSRFToken': getCsrf(form) },
        credentials: 'same-origin',
        body: fd,
      }).then(function(r) {
        return r.json().then(function(j) { return { status: r.status, body: j }; });
      }).then(function(res) {
        if (res.status === 200) {
          setStatus(licenseId, 'Uploaded. Reloading…', true);
          setTimeout(function() { window.location.reload(); }, 600);
        } else {
          setStatus(licenseId, (res.body && res.body.error) || ('Upload failed (' + res.status + ').'), false);
        }
      }).catch(function() {
        setStatus(licenseId, 'Network error.', false);
      });
    });
  });
})();