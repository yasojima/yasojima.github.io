(function(){
  // showRefundModal(payment): payment is the row dict from /billing/payments/.
  window.showRefundModal = function(payment){
    document.getElementById('refundPaymentId').value = payment.id;
    document.getElementById('refundAmountDollars').value = parseFloat(payment.amount || 0).toFixed(2);
    document.getElementById('refundAmountDollars').max = parseFloat(payment.amount || 0).toFixed(2);
    document.getElementById('refundReason').value = '';
    document.getElementById('refundError').style.display = 'none';
    var ctx = document.getElementById('refundContext');
    var who = payment.customer_name || '—';
    var card = payment.card_brand ? (payment.card_brand.toUpperCase() + ' ****' + payment.card_last_four) : (payment.payment_method_type || '—');
    ctx.innerHTML = '<strong>Refunding payment from</strong> ' + who +
      '<br><strong>Charged:</strong> $' + parseFloat(payment.amount || 0).toFixed(2) +
      ' on ' + (payment.created_at || '').slice(0,10) +
      '<br><strong>Method:</strong> ' + card;
    showModal('refundModal');
  };

  window.submitRefund = async function(){
    var btn = document.getElementById('refundSubmitBtn');
    var errBox = document.getElementById('refundError');
    errBox.style.display = 'none';
    var pid = document.getElementById('refundPaymentId').value;
    var dollars = parseFloat(document.getElementById('refundAmountDollars').value);
    var reason = document.getElementById('refundReason').value.trim();
    if (!pid || !dollars || dollars <= 0){
      errBox.textContent = 'Enter a positive refund amount.';
      errBox.style.display = 'block';
      return;
    }
    var amount_cents = Math.round(dollars * 100);
    btn.disabled = true; btn.textContent = 'Refunding…';
    try {
      var token = (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';
      var r = await fetch('/api/v1/billing/payments/' + pid + '/refund/', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-CSRFToken': token },
        body: JSON.stringify({ amount_cents: amount_cents, reason: reason }),
      });
      var data = await r.json().catch(function(){ return {}; });
      if (!r.ok){
        errBox.textContent = (data.error || 'Refund failed') + (data.detail ? ': ' + data.detail : '');
        errBox.style.display = 'block';
        btn.disabled = false; btn.innerHTML = '<i class="fas fa-undo"></i> Issue Refund';
        return;
      }
      hideModal('refundModal');
      if (typeof loadData === 'function') loadData();
    } catch(e){
      errBox.textContent = 'Network error: ' + e.message;
      errBox.style.display = 'block';
    } finally {
      btn.disabled = false; btn.innerHTML = '<i class="fas fa-undo"></i> Issue Refund';
    }
  };
})();