const API='/api/v1';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=()=>({'X-CSRFToken':csrf(),'Content-Type':'application/json'});
const api=async(u)=>(await fetch(API+u,{credentials:'same-origin',headers:hdr()})).json();

const IS_ADMIN='company_admin'==='company_admin'||'False'==='True';
const POST=async(u,body)=>{const r=await fetch(API+u,{method:'POST',credentials:'same-origin',headers:hdr(),body:JSON.stringify(body||{})});return r.ok?(r.status===204?null:r.json()):Promise.reject(await r.text());};

async function loadTeam(){
  const container=document.getElementById('teamContent');
  try {
  // TI4 Phase 4: single fetch against /technicians/ — replaces the prior
  // /users/?role=technician + /users/?role=senior_tech pair. The Technician
  // endpoint respects employment_status natively (TI1's .active() manager),
  // so inactive techs no longer leak into "My Team".
  // include_inactive=true is still useful for admins who want the full set;
  // the per-card status badge surfaces it. For non-admins we keep the
  // active-only view by default.
  const params=IS_ADMIN ? 'include_inactive=true&page_size=200' : 'page_size=200';
  const [me, techProfilesR] = await Promise.all([
    api('/users/?search=demo_owner'),
    api('/technicians/?'+params),
  ]);
  const myUser=(me.results||[])[0];
  // Each row is now a Technician with denormalised user fields. Map for the
  // lifecycle modal lookups (keyed by user_id).
  const allTechs=(techProfilesR.results||techProfilesR||[]);
  const techList=IS_ADMIN ? allTechs : allTechs.filter(t=>t.manager===myUser?.id);
  window.LC_PROFILES={};
  for(const tp of allTechs){
    if(tp.user_id) window.LC_PROFILES[tp.user_id]={id:tp.id, employment_status:tp.employment_status};
  }

  if(!techList.length){
    container.innerHTML='<div class="empty-team"><i class="fas fa-users"></i>No technicians assigned to your team yet.<br>Assign techs to this manager from the Users page.</div>';
    return;
  }

  // Parallel fetch all abilities at once (F-071: was serial per-tech).
  // Abilities endpoint is keyed by user_id, which we read off the
  // denormalised Technician row (t.user_id).
  const abilitiesMap={};
  await Promise.all(techList.map(async t=>{
    try{
      const ab=await api('/tech-abilities/?user='+t.user_id);
      abilitiesMap[t.id]=ab.abilities||[];
    }catch(e){ abilitiesMap[t.id]=[]; }
  }));

  let html='<div class="team-grid">';
  for(const t of techList){
    const abilities=abilitiesMap[t.id]||[];
    const topAbilities=abilities.slice(0,6);

    const color=t.color||'#2196F3';
    const fn=(t.first_name||'').trim();
    const ln=(t.last_name||'').trim();
    const displayName=t.name||(fn+' '+ln).trim()||t.username||'Name not set';
    const initials=((fn[0]||(t.username||'?')[0]||'?')+(ln[0]||'')).toUpperCase();
    const roleLabel=t.role_display||(t.role||'').replace(/_/g,' ');
    const phone=(t.phone||'').trim();
    const phonePart=phone?' &bull; '+phone:'';
    const empStatus=t.employment_status||'active';
    const techId=t.id;  // t IS the technician row now
    const statusBadge='<span class="tc-badge '+empStatus+'">'+empStatus.replace('_',' ')+'</span>';

    html+='<div class="tc">';
    html+='<div class="tc-hdr">';
    html+='<div class="tc-av" style="background:'+color+'">'+initials+'</div>';
    html+='<div style="flex:1"><div class="tc-name">'+displayName+statusBadge+'</div><div class="tc-role">'+roleLabel+phonePart+'</div></div>';
    html+='</div>';
    
    html+='<div class="tc-stats">';
    html+='<div class="tc-stat"><span class="v">'+abilities.length+'</span> job types</div>';
    const certified=abilities.filter(a=>a.is_certified).length;
    html+='<div class="tc-stat"><span class="v">'+certified+'</span> certified</div>';
    const avgScore=abilities.length?Math.round(abilities.reduce((s,a)=>s+a.score,0)/abilities.length):0;
    html+='<div class="tc-stat">Avg score: <span class="v">'+avgScore+'</span></div>';
    html+='</div>';
    
    if(topAbilities.length){
      html+='<div class="tc-abilities">';
      for(const a of topAbilities){
        const bg=a.proficiency>=4?'#E8F5E9':'#FFF8E1';
        const fg=a.proficiency>=4?'#2E7D32':'#F57F17';
        html+='<span class="tc-ab" style="background:'+bg+';color:'+fg+';border-color:'+bg+'">'+a.job_type_name+' L'+a.proficiency+'</span>';
      }
      if(abilities.length>6) html+='<span class="tc-ab">+' +(abilities.length-6)+' more</span>';
      html+='</div>';
    }
    
    html+='<div class="tc-actions">';
    html+='<button type="button" onclick="window.location.href=\'/calendar/\'"><i class="fas fa-calendar"></i>Schedule</button>';
    html+='<button type="button" onclick="window.location.href=\'/users/\'"><i class="fas fa-star-half-alt"></i>Abilities</button>';
    html+='<button type="button" onclick="window.location.href=\'/equipment/\'"><i class="fas fa-toolbox"></i>Equipment</button>';
    if(IS_ADMIN && techId){
      html+='<button type="button" onclick="lcOpen(\''+techId+'\',\''+displayName.replace(/\'/g,"&#39;")+'\',\''+empStatus+'\')"><i class="fas fa-user-clock"></i>Status</button>';
    }
    html+='</div>';
    html+='</div>';
  }
  html+='</div>';
  container.innerHTML=html;
  } catch(e) {
    console.error('tech-team loadTeam failed', e);
    container.innerHTML='<div class="empty-team"><i class="fas fa-exclamation-triangle"></i>Could not load team. Please refresh or contact support if this persists.</div>';
  }
}

loadTeam();

// ─── TI4 lifecycle modal ──────────────────────────────────────────────
const LC_REASONS=[
  ['parental_leave','Parental leave'],['medical_leave','Medical leave'],
  ['seasonal_layoff','Seasonal layoff'],['voluntary_resignation','Voluntary resignation'],
  ['performance_termination','Performance termination'],['mutual_separation','Mutual separation'],
  ['returning_from_leave','Returning from leave'],['rehire','Rehire'],
  ['administrative_correction','Administrative correction'],['other','Other'],
];
let LC_STATE={};

function lcOpen(techId, name, currentStatus){
  LC_STATE={techId, name, currentStatus, step:1, mode: currentStatus==='active' ? 'deactivate':'reactivate'};
  document.getElementById('lcTitle').textContent='Status: '+name+' ('+currentStatus.replace('_',' ')+')';
  document.getElementById('lcDialog').showModal();
  lcLoadPending().then(()=>lcRender());
}
function lcClose(){document.getElementById('lcDialog').close();}
async function lcLoadPending(){
  try { LC_STATE.pending=await api('/technicians/'+LC_STATE.techId+'/lifecycle/pending/'); } catch(e){ LC_STATE.pending=[]; }
}

async function lcRender(){
  const body=document.getElementById('lcBody'), ftr=document.getElementById('lcFtr');
  let html='', ftrHtml='';

  // Pending banner (always at top)
  if((LC_STATE.pending||[]).length){
    for(const p of LC_STATE.pending){
      html+='<div class="tc-pending"><b>Pending '+p.to_status.replace('_',' ')+'</b> scheduled '+new Date(p.effective_at).toLocaleString()+' ('+p.reason+') — <a href="#" onclick="lcCancelPending(\''+p.id+'\');return false;">Cancel</a></div>';
    }
  }

  if(LC_STATE.mode==='deactivate'){
    if(LC_STATE.step===1){
      html+='<p>Choose new state, reason, and when it takes effect.</p>';
      html+='<label>Target status</label>';
      for(const [v,l] of [['on_leave','On Leave (paused, keeps access)'],['inactive','Inactive (off, retains access for reports)'],['terminated','Terminated (fired, revokes SIP + sessions)']]){
        html+='<label class="lc-radio"><input type="radio" name="lc_target" value="'+v+'"'+(v==='inactive'?' checked':'')+'> '+l+'</label>';
      }
      html+='<label>Reason</label><select id="lc_reason">';
      for(const [v,l] of LC_REASONS) html+='<option value="'+v+'">'+l+'</option>';
      html+='</select>';
      html+='<label>Notes (optional)</label><textarea id="lc_text" rows="2"></textarea>';
      html+='<label>Effective at (blank = now)</label><input type="datetime-local" id="lc_eff">';
      ftrHtml='<button onclick="lcClose()">Cancel</button><button class="primary" onclick="lcStep1Next()">Next →</button>';
    } else if(LC_STATE.step===2){
      const p=LC_STATE.preview||{};
      html+='<div class="lc-counts">';
      html+='<div>Future appointments: <b>'+p.open_appointments+'</b></div>';
      html+='<div>Open time entries: <b>'+p.open_time_entries+'</b></div>';
      html+='<div>Open invoices: <b>'+p.open_invoices+'</b></div>';
      html+='<div>Equipment assigned: <b>'+p.equipment_assigned+'</b></div>';
      html+='<div>Active licenses: <b>'+p.license_records_active+'</b></div>';
      html+='<div>Active sessions: <b>'+p.active_sessions+'</b></div>';
      html+='<div>SIP active: <b>'+(p.sip_credentials_active?'yes':'no')+'</b></div>';
      html+='<div>Push tokens: <b>'+p.push_tokens+'</b></div>';
      html+='</div>';
      if(p.open_appointments>0){
        html+='<label>What to do with '+p.open_appointments+' future appointment'+(p.open_appointments===1?'':'s')+'?</label>';
        html+='<label class="lc-radio"><input type="radio" name="lc_disp" value="release_to_pool" checked> Release to unassigned pool</label>';
        html+='<label class="lc-radio"><input type="radio" name="lc_disp" value="bulk_reassign_one_tech"> Reassign all to one tech</label>';
        html+='<label class="lc-radio"><input type="radio" name="lc_disp" value="reassign_individually"> Reassign individually (per-appointment)</label>';
        html+='<div id="lc_disp_extra" style="margin-top:8px"></div>';
      }
      ftrHtml='<button onclick="LC_STATE.step=1;lcRender()">← Back</button><button class="primary" onclick="lcStep2Next()">Next →</button>';
    } else if(LC_STATE.step===3){
      html+='<p>Confirm: <b>'+LC_STATE.name+'</b> → <b>'+LC_STATE.target_status.replace('_',' ')+'</b></p>';
      html+='<p>Reason: '+LC_STATE.reason+(LC_STATE.reason_text?' — '+LC_STATE.reason_text:'')+'</p>';
      if(LC_STATE.effective_at) html+='<p>Effective: '+new Date(LC_STATE.effective_at).toLocaleString()+(new Date(LC_STATE.effective_at)>new Date()?' <b>(future — pending)</b>':'')+'</p>';
      html+='<p>Appointment disposition: '+(LC_STATE.appointment_disposition||'release_to_pool')+'</p>';
      ftrHtml='<button onclick="LC_STATE.step=2;lcRender()">← Back</button><button class="danger" onclick="lcSubmit()">Apply</button>';
    } else if(LC_STATE.step==='done'){
      html+='<p>✓ '+(LC_STATE.result.is_pending?'Pending row written — will apply at scheduled time.':'Deactivation applied.')+'</p>';
      if((LC_STATE.result.warnings||[]).length){
        html+='<details><summary>Warnings ('+LC_STATE.result.warnings.length+')</summary><ul>';
        for(const w of LC_STATE.result.warnings) html+='<li>'+w+'</li>';
        html+='</ul></details>';
      }
      ftrHtml='<span></span><button class="primary" onclick="lcCloseAndReload()">OK</button>';
    }
  } else if(LC_STATE.mode==='reactivate'){
    if(LC_STATE.step===1){
      html+='<p>Bring <b>'+LC_STATE.name+'</b> back to <b>active</b>.</p>';
      html+='<label>Reason</label><select id="lc_reason">';
      for(const [v,l] of LC_REASONS) html+='<option value="'+v+'"'+(v==='returning_from_leave'?' selected':'')+'>'+l+'</option>';
      html+='</select>';
      html+='<label>Notes (optional)</label><textarea id="lc_text" rows="2"></textarea>';
      html+='<label>What to restore?</label>';
      html+='<label class="lc-radio"><input type="radio" name="lc_mode" value="restore_all"> Restore everything (re-assign released appointments)</label>';
      html+='<label class="lc-radio"><input type="radio" name="lc_mode" value="cherry_pick"> Cherry-pick (review past changes — manual ID list)</label>';
      html+='<label class="lc-radio"><input type="radio" name="lc_mode" value="clean_slate" checked> Clean slate (restore access only)</label>';
      ftrHtml='<button onclick="lcClose()">Cancel</button><button class="primary" onclick="lcStep1Next()">Next →</button>';
    } else if(LC_STATE.step===2){
      html+='<p>Confirm reactivation: <b>'+LC_STATE.name+'</b> → <b>active</b></p>';
      html+='<p>Restore mode: <b>'+LC_STATE.restore_mode+'</b></p>';
      html+='<p>Reason: '+LC_STATE.reason+(LC_STATE.reason_text?' — '+LC_STATE.reason_text:'')+'</p>';
      ftrHtml='<button onclick="LC_STATE.step=1;lcRender()">← Back</button><button class="primary" onclick="lcSubmit()">Apply</button>';
    } else if(LC_STATE.step==='done'){
      html+='<p>✓ Reactivation applied.</p>';
      ftrHtml='<span></span><button class="primary" onclick="lcCloseAndReload()">OK</button>';
    }
  }

  body.innerHTML=html; ftr.innerHTML=ftrHtml;

  // Hook up disposition extra UI in deactivation step 2
  if(LC_STATE.mode==='deactivate' && LC_STATE.step===2){
    document.querySelectorAll('input[name=lc_disp]').forEach(r=>r.addEventListener('change',lcUpdateDispExtra));
    lcUpdateDispExtra();
  }
}

async function lcStep1Next(){
  if(LC_STATE.mode==='deactivate'){
    const sel=document.querySelector('input[name=lc_target]:checked');
    if(!sel){alert('Pick a target status');return;}
    LC_STATE.target_status=sel.value;
    LC_STATE.reason=document.getElementById('lc_reason').value;
    LC_STATE.reason_text=document.getElementById('lc_text').value;
    const eff=document.getElementById('lc_eff').value;
    LC_STATE.effective_at=eff?new Date(eff).toISOString():null;
    // Fetch preview
    try { LC_STATE.preview=await api('/technicians/'+LC_STATE.techId+'/lifecycle/preview/'); }
    catch(e){ alert('Preview failed: '+e); return; }
    LC_STATE.step=2; lcRender();
  } else {
    const sel=document.querySelector('input[name=lc_mode]:checked');
    LC_STATE.restore_mode=sel?sel.value:'clean_slate';
    LC_STATE.reason=document.getElementById('lc_reason').value;
    LC_STATE.reason_text=document.getElementById('lc_text').value;
    LC_STATE.step=2; lcRender();
  }
}

function lcStep2Next(){
  const dispSel=document.querySelector('input[name=lc_disp]:checked');
  LC_STATE.appointment_disposition=dispSel?dispSel.value:'release_to_pool';
  if(LC_STATE.appointment_disposition==='bulk_reassign_one_tech'){
    const tgt=document.getElementById('lc_bulk_to');
    LC_STATE.bulk_reassign_to=tgt?tgt.value:'';
    if(!LC_STATE.bulk_reassign_to){alert('Pick a tech for bulk reassignment');return;}
  }
  LC_STATE.step=3; lcRender();
}

function lcUpdateDispExtra(){
  const sel=document.querySelector('input[name=lc_disp]:checked');
  const extra=document.getElementById('lc_disp_extra'); if(!extra) return;
  if(sel && sel.value==='bulk_reassign_one_tech'){
    let opts='<option value="">— pick a tech —</option>';
    for(const uid in window.LC_PROFILES){
      const p=window.LC_PROFILES[uid]; if(p.id===LC_STATE.techId) continue;
      if(p.employment_status!=='active') continue;
      opts+='<option value="'+p.id+'">'+(p.id.slice(0,8))+' ('+p.employment_status+')</option>';
    }
    extra.innerHTML='<label>Reassign all to:</label><select id="lc_bulk_to">'+opts+'</select>';
  } else {
    extra.innerHTML='';
  }
}

async function lcSubmit(){
  const url='/technicians/'+LC_STATE.techId+'/lifecycle/'+(LC_STATE.mode==='deactivate'?'deactivate':'reactivate')+'/';
  const body=LC_STATE.mode==='deactivate' ? {
    target_status:LC_STATE.target_status, reason:LC_STATE.reason, reason_text:LC_STATE.reason_text,
    effective_at:LC_STATE.effective_at, appointment_disposition:LC_STATE.appointment_disposition,
    bulk_reassign_to:LC_STATE.bulk_reassign_to||null,
  } : {
    reason:LC_STATE.reason, reason_text:LC_STATE.reason_text, restore_mode:LC_STATE.restore_mode,
  };
  try { LC_STATE.result=await POST(url,body); }
  catch(e){ alert('Failed: '+e); return; }
  LC_STATE.step='done'; lcRender();
}

async function lcCancelPending(historyId){
  if(!confirm('Cancel this pending status change?')) return;
  try{ await POST('/technicians/'+LC_STATE.techId+'/lifecycle/cancel-pending/'+historyId+'/'); }
  catch(e){ alert('Cancel failed: '+e); return; }
  await lcLoadPending(); lcRender();
}

function lcCloseAndReload(){ lcClose(); loadTeam(); }