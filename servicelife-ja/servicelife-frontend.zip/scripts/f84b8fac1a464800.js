(() => {
  const {api,$,escape,choices,setChoices,textInput,selectInput,cell,button,sorted,form,filters}=OfficeUI;
  const filter=$("#expense-filters"), rowsElement=$("#expense-rows");
  const custom="__custom__";
  const money=cents=>"A$"+(cents/100).toLocaleString("ja-JP",{minimumFractionDigits:2,maximumFractionDigits:2});
  const cars=()=>new Map((api.state.cars||[]).map(car=>[car.key,car]));
  const carName=car=>[car.id,car.model,car.plate].join(" · ");
  const vehicleChoices=()=>(api.state.cars||[]).map(car=>[car.key,carName(car)]);
  function carLabel(key) {
    if (!key) return "車両指定なし";
    const car=cars().get(key);
    return car ? carName(car) : "車両ID "+key;
  }
  function totals(selector, rows, key, label) {
    const groups=new Map();
    for (const row of rows) groups.set(row[key],(groups.get(row[key])||0)+row.cents);
    const pairs=[...groups].sort((a,b)=>b[1]-a[1]||label(a[0]).localeCompare(label(b[0]),"ja"));
    $(selector).innerHTML=pairs.map(([value,sum])=>'<div><dt>'+escape(label(value))+'</dt><dd>'+money(sum)+'</dd></div>').join("")
      || '<div class="muted"><dt>明細なし</dt><dd>—</dd></div>';
  }
  let appliedFilters;
  function render() {
    const {records,categories,statuses,destinations,error}=api.state, fields=filter.elements;
    setChoices(fields.team,sorted(records.map(r=>r.team).filter(Boolean)),"すべての班");
    const vehicles=vehicleChoices();
    setChoices(fields.vehicle,vehicles,"すべての車両");
    const draftVehicle=OfficeUI.body.querySelector('form select[name="vehicle"]');
    if(draftVehicle)setChoices(draftVehicle,vehicles,"指定しない");
    setChoices(fields.category,sorted([...categories,...records.map(r=>r.category)]),"すべての種類");
    setChoices(fields.destination,destinations||[],"すべての承認先");
    setChoices(fields.status,statuses,"すべての状況");
    if (!appliedFilters) {
      if (api.state.vehicle) fields.vehicle.value=String(api.state.vehicle);
      appliedFilters=Object.fromEntries(new FormData(filter));
    }
    $("#expense-new").disabled=!!error;
    if (error) OfficeUI.status(error);
    const f=appliedFilters;
    const rows=records.filter(r=>(!f.team||r.team===f.team)&&(!f.vehicle||r.vehicle===Number(f.vehicle))&&
      (!f.category||r.category===f.category)&&(!f.destination||r.destination===f.destination)&&
      (!f.status||r.status===f.status)&&(!f.from||r.date>=f.from)&&(!f.to||r.date<=f.to))
      .sort((a,b)=>b.date.localeCompare(a.date)||(a.team||"").localeCompare(b.team||"","ja"));
    $("#expense-total").textContent=money(rows.reduce((sum,r)=>sum+r.cents,0));
    $("#expense-count").textContent=rows.length+"件";
    totals("#expense-teams",rows,"team",value=>value||"班指定なし");
    totals("#expense-cars",rows,"vehicle",carLabel);
    rowsElement.innerHTML=rows.map(r=>{
      let vehicle=escape(carLabel(r.vehicle));
      if (r.vehicle && api.canOpenFleet) vehicle='<a href="/maintenance/?vehicle='+Number(r.vehicle)+'">'+vehicle+'</a>';
      return "<tr>"+cell("支払日",escape(r.date))+cell("経費の種類",escape(r.category))+cell("金額",money(r.cents))+
        cell("申請者",escape(r.person))+cell("承認先",escape(r.destination||"未登録"))+
        cell("班・車両",escape(r.team||"班指定なし")+"<small>"+vehicle+"</small>")+cell("対応状況",escape(r.status))+
        cell("明細",button("詳細","data-expense",r.id))+"</tr>";
    }).join("");
    $("#expense-empty").hidden=rows.length>0;
  }
  const optionalSelect=(label,name,items,value,hint)=>'<label>'+label+'<select name="'+name+'">'+choices(items,value,hint)+'</select></label>';
  function edit(row) {
    const s=api.state;
    const correcting=Boolean(row && !s.admin && row.status==="修正依頼");
    const category=row?.category||"";
    const unusual=!!category && !s.categories.includes(category);
    const vehicle=row ? row.vehicle : appliedFilters.vehicle;
    const legacyVehicle=Boolean(row?.vehicle && category!=="ガソリン代");
    const categoryOptions=[...s.categories,[custom,"自分で入力"]];
    const message=row?.correctionReason?'<p class="wide expense-note"><strong>管理者からの修正理由</strong><br>'+escape(row.correctionReason)+'</p>':"";
    const statusControl=s.admin && row ? selectInput("対応状況","status",choices(s.statuses,row.status)) :
      '<div><span class="muted">提出時の対応状況</span><div>確認待ち</div></div>';
    const destinationOptions=choices(s.destinations,row?.destination||"","承認先を選択");
    const fields=message+
      '<div><span class="muted">申請者</span><div>'+escape(row?.person||s.person)+'</div></div>'+
      textInput("支払日","date",row?.date||s.today,'type="date" required')+
      '<label class="wide"><span class="expense-type-label">経費の種類 <span class="expense-hint" id="expense-gas-hint">ガソリン代を選ぶと、登録車両を選べます。</span></span>'+
      '<select name="category" aria-describedby="expense-gas-hint" required>'+choices(categoryOptions,unusual?custom:category,"選択してください")+'</select></label>'+
      '<label data-custom hidden>経費の種類を入力<input name="customCategory" maxlength="90" value="'+escape(unusual?category:"")+'" placeholder="例：倉庫の賃料"></label>'+
      '<label data-vehicle hidden>車両（任意）<select name="vehicle">'+choices(vehicleChoices(),vehicle||"","指定しない")+'</select></label>'+
      textInput("金額（AUD）","amount",row?(row.cents/100).toFixed(2):"",'type="number" inputmode="decimal" min="0.01" max="9999999999.99" step="0.01" required')+
      optionalSelect("支払方法（任意）","payment",s.payments,row?.payment||"","選択してください")+
      '<label>承認先<select name="destination" required>'+destinationOptions+'</select></label>'+
      textInput("班（任意）","team",row ? row.team : appliedFilters.team,'maxlength="70" list="existing-teams" placeholder="例：A班"')+
      '<datalist id="existing-teams">'+choices(sorted(s.records.map(r=>r.team).filter(Boolean)))+'</datalist>'+
      '<label class="wide">用途・備考<textarea name="notes" maxlength="2000" placeholder="例：○○商店で、現場の梱包に使う資材を購入">'+escape(row?.notes||"")+'</textarea></label>'+
      '<label class="wide">領収書（PDF・JPEG・PNG）<input type="file" name="receiptFile" accept="application/pdf,image/jpeg,image/png">'+
      (row?.receipt?'<small>添付済み：'+escape(row.receipt.name)+'。新しいファイルを選ぶと差し替えます。</small>':"")+'</label>'+
      statusControl+(s.admin && row?'<label class="wide" data-reason hidden>修正理由<textarea name="correctionReason" maxlength="1000" placeholder="どこをどう直してほしいか入力">'+escape(row.status==="修正依頼"?row.correctionReason:"")+'</textarea></label>':"");
    const caption=correcting?"修正して再提出":row?"経費明細を編集":"経費を申請";
    form(caption,fields,correcting?"再提出":row?"保存":"申請する",async draft=>{
      const file=draft.receiptFile;
      delete draft.receiptFile;
      if (file?.name) {
        draft.receiptBytes=await file.arrayBuffer();
        draft.receiptName=file.name;
      }
      if (draft.category===custom) draft.category=draft.customCategory;
      await api.save({...draft,id:row?.id,revision:row?.revision});
    });
    const el=OfficeUI.body.querySelector("form"), input=el.elements;
    function toggle(selector,visible,required) {
      const label=el.querySelector(selector);
      if (!label) return;
      label.hidden=!visible;
      const control=label.querySelector("select,input,textarea");
      control.disabled=!visible;
      control.required=visible && required;
    }
    function updateFields(){
      const manual=input.category.value===custom;
      toggle("[data-custom]",manual,true);
      const value=manual?input.customCategory.value.trim():input.category.value;
      toggle("[data-vehicle]",value==="ガソリン代" || (legacyVehicle && value===category),false);
      toggle("[data-reason]",s.admin && input.status?.value==="修正依頼",true);
    }
    el.addEventListener("input",updateFields);el.addEventListener("change",updateFields);updateFields();
  }
  function details(id) {
    const row=api.state.records.find(r=>r.id===id);
    if (!row) return;
    const pairs=[["支払日",row.date],["経費の種類",row.category],["申請金額",money(row.cents)],["申請者",row.person],
      ["支払方法",row.payment],["承認先",row.destination||"未登録"],["班",row.team||"指定なし"],["車両",carLabel(row.vehicle)],
      ["用途・備考",row.notes],["対応状況",row.status]];
    if (row.correctionReason) pairs.push([row.status==="修正依頼"?"修正理由":"前回の修正理由",row.correctionReason]);
    const correct=row.status==="修正依頼" && !api.state.admin;
    const canEdit=api.state.admin || correct || row.status==="確認待ち";
    const receipt=row.receipt ? button(row.receipt.name,"data-receipt",row.receipt.id) : "添付なし";
    OfficeUI.open("経費の詳細",'<dl class="office-fields">'+pairs.map(([k,v])=>'<div><dt class="muted">'+escape(k)+'</dt><dd class="expense-note">'+escape(v||"—")+'</dd></div>').join("")+
      '<div><dt class="muted">領収書</dt><dd>'+receipt+'</dd></div></dl><p class="error" role="alert"></p>'+
      (canEdit?'<div class="office-actions"><button type="button" class="primary" id="expense-edit">'+(correct?"修正して再提出":"編集")+'</button></div>':""));
    $("#expense-edit")?.addEventListener("click",()=>edit(row));
    OfficeUI.body.querySelector("[data-receipt]")?.addEventListener("click",async()=>{
      try{await api.pdf(row.receipt.id);}catch(error){OfficeUI.body.querySelector(".error").textContent=error.message;}
    });
  }
  $("#expense-new").addEventListener("click",()=>edit(null));
  rowsElement.addEventListener("click",event=>{
    const button=event.target.closest("[data-expense]");
    if (button) details(button.dataset.expense);
  });
  filters(filter,()=>{
    appliedFilters=Object.fromEntries(new FormData(filter));
    render();
  },{searchOnChange:false});
  document.addEventListener("office-updated",render);
  document.addEventListener("expense-open",event=>details(event.detail));
  render();
  if (api.selectedExpense) details(api.selectedExpense);
})();