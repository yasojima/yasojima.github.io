(function(){
  const csrftoken = (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';

  // Wire row click → detail page
  document.querySelectorAll('tr.row-link').forEach(tr => {
    tr.addEventListener('click', () => { window.location = tr.dataset.href; });
  });

  // Load KPI strip
  fetch('/api/v1/billing/disputes/stats/', {
    headers: {'X-CSRFToken': csrftoken, 'Accept': 'application/json'},
    credentials: 'same-origin',
  })
    .then(r => r.ok ? r.json() : null)
    .then(data => {
      if (!data) return;
      document.getElementById('kpi-open').textContent = data.open_count;
      document.getElementById('kpi-at-risk').textContent = '$' + parseFloat(data.at_risk_amount || '0').toFixed(2);
      document.getElementById('kpi-due-week').textContent = data.due_this_week;
      const wr = document.getElementById('kpi-win-rate');
      const wrs = document.getElementById('kpi-win-rate-sub');
      if (data.win_rate_pct === null) {
        wr.textContent = '—';
        wrs.textContent = 'no decided disputes';
      } else {
        wr.textContent = data.win_rate_pct + '%';
        wrs.textContent = data.won_last_90d + ' won / ' + (data.won_last_90d + data.lost_last_90d) + ' decided';
      }
    })
    .catch(() => {});


})();