(() => {
  const {api,$,escape,choices,setChoices,textInput,notesInput,cell,button,sorted,status,open,form,filters}=OfficeUI;
  const filter=$("#document-filters");
  const latest=r=>r.history.at(-1);
  const state=v=>!v.due?"none":v.due<api.state.today?"expired":"valid";
  function deadline(v){
    if(!v.due)return "期限なし";
    return state(v)==="expired"?'<span class="overdue">'+escape(v.due)+' · 期限超過</span>':escape(v.due);
  }
  function fileButtons(v){
    const pdf=button("PDFを開く","data-pdf",v.fileId);
    const photo=v.photoId?button("元の写真を開く","data-pdf",v.photoId):"";
    return '<span class="document-files">'+pdf+photo+'</span>';
  }
  function render(){
    const records=api.state.records;
    setChoices(filter.elements.office,sorted(records.map(r=>latest(r).office)),"すべての事業所");
    const f=Object.fromEntries(new FormData(filter)), q=f.q.trim().normalize("NFKC").toLowerCase();
    const rows=records.filter(record=>{
      const v=latest(record);return (!f.office||f.office===v.office)&&(!f.status||f.status===state(v))&&
        (!q||[v.office,v.title,v.number,v.filename,v.pdfName||""].some(x=>x.normalize("NFKC").toLowerCase().includes(q)));
    }).sort((a,b)=>latest(b).savedAt.localeCompare(latest(a).savedAt));
    $("#document-rows").innerHTML=rows.map(r=>{
      const v=latest(r);
      return "<tr>"+cell("事業所",escape(v.office))+cell("書類名",button(v.title,"data-document",r.id))+cell("登録・許可番号",escape(v.number||"—"))+
        cell("提出・登録日",escape(v.date))+cell("更新期限",deadline(v))+cell("最新版",r.revision+"版")+
        cell("控え",fileButtons(v))+"</tr>";
    }).join("");
    $("#document-empty").hidden=rows.length>0;$("#document-count").textContent=rows.length+"件 · このブラウザに保存";
    $("#document-new").disabled=!!api.state.error;if(api.state.error)status(api.state.error);
  }
  function edit(record){
    const v=record?latest(record):{};
    const fields=textInput("事業所名","office",v.office||filter.elements.office.value,'required maxlength="110" list="offices"')+
      '<datalist id="offices">'+choices(sorted(api.state.records.map(r=>latest(r).office)))+'</datalist>'+
      textInput("書類名","title",v.title,'required maxlength="150" placeholder="例：事業登録の控え"')+
      textInput("登録・許可番号（任意）","number",v.number,'maxlength="100"')+
      textInput("提出・登録日","date",api.state.today,'type="date" required')+
      textInput("更新期限（期限がある場合）","due","",'type="date"')+
      '<label>書類の控え（PDF・JPEG・PNG）<input type="file" name="file" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" aria-describedby="document-photo-hint" required>'+
      '<small id="document-photo-hint">写真を選ぶと、元の画像と提出用のPDFを両方保管します。</small></label>'+notesInput("");
    form(record?"新版を追加":"書類を登録",fields,"保存",async draft=>{
      const file=draft.file;
      return api.save({...draft,file:await file.arrayBuffer(),filename:file.name,id:record?.id,revision:record?.revision});
    });
  }
  function details(id){
    const record=api.state.records.find(x=>x.id===id);
    if(!record)return;
    open("書類の詳細・更新履歴",'<h3>'+escape(latest(record).title)+'</h3>'+
      record.history.slice().reverse().map((v,i)=>'<section class="history"><h3>第'+(record.revision-i)+'版'+(i===0?' · 最新版':'')+'</h3>'+
        '<p>'+escape(v.office)+' · '+escape(v.title)+'</p><p>登録・許可番号　'+escape(v.number||"—")+'</p><p>提出・登録日　'+escape(v.date)+
        '　更新期限　'+deadline(v)+'</p>'+(v.notes?'<p>'+escape(v.notes)+'</p>':'')+'<p class="muted">'+escape(v.filename)+'</p>'+
        fileButtons(v)+'</section>').join("")+
      '<p class="error" role="alert"></p><div class="office-actions"><button type="button" class="primary" id="document-revise">新版を追加</button></div>');
    $("#document-revise").addEventListener("click",()=>edit(record));
  }
  $("#document-new").addEventListener("click",()=>edit(null));
  $("#office").addEventListener("click",async e=>{
    const detail=e.target.closest("[data-document]"),pdf=e.target.closest("[data-pdf]");
    if(detail)details(detail.dataset.document);
    if(pdf){try{await api.pdf(pdf.dataset.pdf);}catch(err){const error=OfficeUI.body.querySelector(".error");if(error && OfficeUI.dialog.open)error.textContent=err.message;else status(err.message);}}
  });
  filters(filter,render);document.addEventListener("office-updated",render);render();
})();