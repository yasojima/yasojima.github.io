const API='/api/v1';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(m)=>{const h={'X-CSRFToken':csrf()};if(m!=='GET')h['Content-Type']='application/json';return h;};
async function api(u,m='GET',b=null){const o={method:m,credentials:'same-origin',headers:hdr(m)};if(b)o.body=JSON.stringify(b);const r=await fetch(API+u,o);if(r.status===204)return null;return r.json();}
function toast(msg,kind){
  let e=document.getElementById('_apiToast');
  if(!e){e=document.createElement('div');e.id='_apiToast';e.style.cssText='position:fixed;top:20px;right:20px;padding:10px 16px;border-radius:6px;color:#fff;z-index:99999;font-size:13px;font-weight:500;box-shadow:0 4px 12px rgba(0,0,0,.15);max-width:380px;display:none';document.body.appendChild(e);}
  e.style.background=kind==='error'?'#e53935':'#43a047';
  e.textContent=msg;e.style.display='block';
  clearTimeout(e._t);e._t=setTimeout(()=>{e.style.display='none'},3000);
}
function _parseErr(d){
  if(!d) return 'Save failed';
  if(typeof d==='string') return d;
  if(d.detail) return d.detail;
  try{return Object.entries(d).map(([k,v])=>(k==='non_field_errors'?'':k.replace(/_/g,' ')+': ')+(Array.isArray(v)?v[0]:v)).filter(Boolean).join(' • ')||'Save failed';}catch(_){return 'Save failed';}
}

function fmtDate(s){if(!s)return'—';return new Date(s).toLocaleDateString('en-US',{month:'short',day:'numeric'});}
function showModal(id){document.getElementById(id).classList.add('show');}
function hideModal(id){document.getElementById(id).classList.remove('show');}

const STAGES=[{k:'new',l:'New',c:'#2196F3'},{k:'contacted',l:'Contacted',c:'#9C27B0'},{k:'qualified',l:'Qualified',c:'#FF9800'},{k:'estimate_sent',l:'Estimate Sent',c:'#00BCD4'},{k:'follow_up',l:'Follow Up',c:'#FF5722'},{k:'won',l:'Won',c:'#4CAF50'},{k:'lost',l:'Lost',c:'#9E9E9E'}];
const PRIO_BADGE={urgent:'badge-red',high:'badge-orange',medium:'badge-blue',low:'badge-gray'};
let currentView='board', editId=null, allLeads=[];

async function loadKPIs(){
  try{
    const d=await api('/leads/pipeline/');
    const s=document.getElementById('kpiStrip');
    s.innerHTML=`
      <div class="kpi"><div class="lbl">Total leads</div><div class="val">${d.total}</div></div>
      <div class="kpi"><div class="lbl">Pipeline value</div><div class="val">$${(d.total_value||0).toLocaleString()}</div></div>
      <div class="kpi"><div class="lbl">New this month</div><div class="val">${d.month.new_leads}</div></div>
      <div class="kpi"><div class="lbl">Won</div><div class="val" style="color:#2e7d32">${d.month.won}</div></div>
      <div class="kpi"><div class="lbl">Conversion</div><div class="val">${d.month.conversion_rate}%</div></div>
      <div class="kpi"><div class="lbl">Overdue F/U</div><div class="val" style="color:#c62828">${d.overdue_follow_ups}</div></div>`;
  }catch(e){}
}

async function loadData(){
  const tb=document.getElementById('tableBody');
  let url='/leads/leads/?ordering=-created_at';
  const s=document.getElementById('search').value;
  const src=document.getElementById('filterSource').value;
  const pri=document.getElementById('filterPriority').value;
  if(s) url+='&search='+encodeURIComponent(s);
  if(src) url+='&source='+src;
  if(pri) url+='&priority='+pri;
  try{
    const d=await api(url);
    allLeads=d.results||d;
    if(currentView==='board') renderBoard(); else renderList();
    loadKPIs();
  }catch(e){if(e&&e.name==='AbortError')return;tb.innerHTML='<tr><td colspan="9"><div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Could not load leads.</p></div></td></tr>';}
}

function renderBoard(){
  const board=document.getElementById('boardView');
  board.innerHTML=STAGES.map(st=>{
    const cards=allLeads.filter(l=>l.stage===st.k);
    return `<div class="pipeline-col"><div class="pipeline-col-header" style="border-bottom-color:${st.c}">${st.l}<span class="count">${cards.length}</span></div><div class="pipeline-cards" data-stage="${st.k}">${
      cards.length?cards.map(l=>`<div class="lead-card" draggable="true" data-id="${l.id}" style="border-left-color:${st.c}" onclick="if(!window._dndDone)openEdit('${l.id}')"><div class="lc-name">${escHTML(l.full_name||l.first_name+' '+l.last_name)}</div><div class="lc-meta">${escHTML(l.phone)||''} ${l.source_name?'• '+escHTML(l.source_name):''}</div>${l.estimated_value>0?`<div class="lc-val">$${parseFloat(l.estimated_value).toLocaleString()}</div>`:''}
        <div class="lc-tags"><span class="badge ${PRIO_BADGE[l.priority]||'badge-gray'}">${l.priority}</span>${l.assigned_to_name?`<span class="badge badge-purple">${escHTML(l.assigned_to_name)}</span>`:''}</div></div>`).join(''):'<div style="padding:20px;text-align:center;color:var(--text-light);font-size:11px">No leads</div>'
    }</div></div>`;
  }).join('');
  wireDnD();
}

// BUG-022 (R2): Wire HTML5 drag-and-drop on kanban board.
// Called after every renderBoard() since innerHTML destroys prior listeners.
function wireDnD(){
  window._dndDone = false;
  document.querySelectorAll('.lead-card[draggable]').forEach(card => {
    card.addEventListener('dragstart', e => {
      window._dndDone = true;
      card.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', card.dataset.id);
      setTimeout(() => { window._dndDone = false; }, 300);
    });
    card.addEventListener('dragend', () => {
      card.classList.remove('dragging');
      document.querySelectorAll('.pipeline-cards.drag-over').forEach(el => el.classList.remove('drag-over'));
    });
  });
  document.querySelectorAll('.pipeline-cards[data-stage]').forEach(col => {
    col.addEventListener('dragover', e => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; col.classList.add('drag-over'); });
    col.addEventListener('dragleave', e => { if (!col.contains(e.relatedTarget)) col.classList.remove('drag-over'); });
    col.addEventListener('drop', async e => {
      e.preventDefault();
      col.classList.remove('drag-over');
      const leadId = e.dataTransfer.getData('text/plain');
      const newStage = col.dataset.stage;
      if (!leadId || !newStage) return;
      const lead = allLeads.find(l => l.id === leadId);
      if (lead && lead.stage === newStage) return;
      const oldStage = lead ? lead.stage : null;
      if (lead) lead.stage = newStage;
      renderBoard();
      try {
        await api('/leads/leads/' + leadId + '/', 'PATCH', { stage: newStage });
      } catch (err) {
        if (lead && oldStage) { lead.stage = oldStage; renderBoard(); }
        if (typeof toast === 'function') toast('Could not move lead: ' + (err.message || 'Network error'), 'error');
      }
    });
  });
}

function renderList(){
  const tb=document.getElementById('tableBody');
  if(!allLeads.length){tb.innerHTML='<tr><td colspan="9"><div class="empty-state"><i class="fas fa-funnel-dollar"></i><p>No leads found</p></div></td></tr>';return;}
  tb.innerHTML=allLeads.map(l=>`<tr class="clickable" tabindex="0" role="link" onkeydown="if(event.key==='Enter'||event.key===' '){this.click();event.preventDefault()}" onclick="openEdit('${l.id}')"><td><strong>${escHTML(l.full_name)}</strong>${l.company_name?'<br><small style="color:var(--text-light)">'+escHTML(l.company_name)+'</small>':''}</td><td>${l.phone||'—'}</td><td>${l.source_name||'—'}</td><td>${l.service_type_name||'—'}</td><td><span class="badge badge-${l.stage==='won'?'green':l.stage==='lost'?'gray':'blue'}">${l.stage.replace(/_/g,' ')}</span></td><td><span class="badge ${PRIO_BADGE[l.priority]||'badge-gray'}">${l.priority}</span></td><td>$${parseFloat(l.estimated_value||0).toLocaleString()}</td><td>${l.assigned_to_name||'—'}</td><td>${fmtDate(l.created_at)}</td></tr>`).join('');
}

function setView(v){
  currentView=v;
  document.getElementById('btnBoard').classList.toggle('active',v==='board');
  document.getElementById('btnList').classList.toggle('active',v==='list');
  document.getElementById('boardView').style.display=v==='board'?'flex':'none';
  document.getElementById('listView').style.display=v==='list'?'block':'none';
  if(allLeads.length){if(v==='board')renderBoard();else renderList();}
}

async function loadSources(){
  const d=await api('/leads/sources/');
  const items=d.results||d;
  document.getElementById('filterSource').innerHTML='<option value="">All sources</option>'+items.map(s=>`<option value="${s.id}">${escHTML(s.name)}</option>`).join('');
  document.getElementById('fSource').innerHTML='<option value="">Select...</option>'+items.map(s=>`<option value="${s.id}">${escHTML(s.name)}</option>`).join('');
}

function openNew(){editId=null;document.getElementById('modalTitle').textContent='New Lead';['fFirst','fLast','fPhone','fEmail','fCompany','fAddr','fCity','fZip','fDesc','fNotes'].forEach(id=>document.getElementById(id).value='');document.getElementById('fState').value='PA';document.getElementById('fPriority').value='medium';document.getElementById('fValue').value='0';document.getElementById('fSource').value='';document.getElementById('activitySection').style.display='none';document.getElementById('convertBtn').style.display='none';clearLeadFieldErrors();cbpAttachClearOnInput(document.getElementById('modal'));showModal('modal');}

async function openEdit(id){
  editId=id;const l=await api('/leads/leads/'+id+'/');
  document.getElementById('modalTitle').textContent='Edit Lead — '+l.full_name;
  document.getElementById('fFirst').value=l.first_name||'';document.getElementById('fLast').value=l.last_name||'';
  document.getElementById('fPhone').value=l.phone||'';document.getElementById('fEmail').value=l.email||'';
  document.getElementById('fCompany').value=l.company_name||'';document.getElementById('fSource').value=l.source||'';
  document.getElementById('fAddr').value=l.address||'';document.getElementById('fCity').value=l.city||'';
  document.getElementById('fState').value=l.state||'PA';document.getElementById('fZip').value=l.zip_code||'';
  document.getElementById('fPriority').value=l.priority||'medium';document.getElementById('fValue').value=l.estimated_value||0;
  document.getElementById('fDesc').value=l.service_description||'';document.getElementById('fNotes').value=l.notes||'';
  document.getElementById('activitySection').style.display='block';
  document.getElementById('convertBtn').style.display=l.stage!=='won'&&!l.converted_customer?'block':'none';
  loadActivities(id);clearLeadFieldErrors();cbpAttachClearOnInput(document.getElementById('modal'));showModal('modal');
}

const LEAD_FIELD_MAP={first_name:'fFirst',last_name:'fLast',phone:'fPhone',email:'fEmail',company_name:'fCompany',source:'fSource',address:'fAddr',city:'fCity',state:'fState',zip_code:'fZip',priority:'fPriority',estimated_value:'fValue',service_description:'fDesc',notes:'fNotes'};
function clearLeadFieldErrors(){document.querySelectorAll('#modal .field-error').forEach(el=>el.remove());document.querySelectorAll('#modal .field-invalid').forEach(el=>el.classList.remove('field-invalid'));}
function showLeadFieldErrors(d){clearLeadFieldErrors();if(!d||typeof d!=='object')return;Object.entries(d).forEach(([k,v])=>{const id=LEAD_FIELD_MAP[k];if(!id)return;const inp=document.getElementById(id);if(!inp)return;inp.classList.add('field-invalid');const err=document.createElement('div');err.className='field-error';err.style.cssText='color:#c0392b;font-size:12px;margin-top:2px;';err.textContent=Array.isArray(v)?v[0]:String(v);inp.parentNode.appendChild(err);});}

// Lead save — direct fetch + r.ok check (api() helper doesn't throw on !ok),
// wrapped in cbpSubmit for button disable + spinner + AbortError swallow.
async function save(){
  const btn=document.getElementById('leadSaveBtn');
  await cbpSubmit(btn, async () => {
    // Client-side required-field check so the user gets immediate inline feedback
    // without waiting for a server round-trip (or an AbortError swallowing the error).
    const _req={first_name:'fFirst',last_name:'fLast',phone:'fPhone'};
    const _clientErr={};
    Object.entries(_req).forEach(([field,id])=>{const el=document.getElementById(id);if(el&&!el.value.trim())_clientErr[field]=['This field is required.'];});
    if(Object.keys(_clientErr).length){toast(_parseErr(_clientErr),'error');showLeadFieldErrors(_clientErr);return;}

    const body={first_name:document.getElementById('fFirst').value,last_name:document.getElementById('fLast').value,phone:document.getElementById('fPhone').value,email:document.getElementById('fEmail').value,company_name:document.getElementById('fCompany').value,source:document.getElementById('fSource').value||null,address:document.getElementById('fAddr').value,city:document.getElementById('fCity').value,state:document.getElementById('fState').value,zip_code:document.getElementById('fZip').value,priority:document.getElementById('fPriority').value,estimated_value:document.getElementById('fValue').value,service_description:document.getElementById('fDesc').value,notes:document.getElementById('fNotes').value};
    const url=editId?`/leads/leads/${editId}/`:'/leads/leads/';
    const method=editId?'PATCH':'POST';
    const r=await fetch(API+url,{method,credentials:'same-origin',headers:hdr(method),body:JSON.stringify(body)});
    let d=null;try{d=await r.json();}catch(_){}
    if(!r.ok){toast(_parseErr(d),'error');showLeadFieldErrors(d);return;} // keep modal open on error
    clearLeadFieldErrors();hideModal('modal');toast(editId?'Lead updated':'Lead created');loadData();
  });
}

async function loadActivities(id){
  const acts=await api('/leads/leads/'+id+'/activities/');
  document.getElementById('actList').innerHTML=(acts||[]).map(a=>`<div class="act-item"><span class="act-type">${a.activity_type.replace(/_/g,' ')}</span> — ${a.description}<div class="act-time">${escHTML(a.created_by_name)||''} • ${new Date(a.created_at).toLocaleString()}</div></div>`).join('')||'<div style="color:var(--text-light);font-size:12px">No activities yet</div>';
}

async function addActivity(){
  if(!editId)return;
  const t=document.getElementById('actType').value,d=document.getElementById('actDesc').value;
  if(!d)return;
  await api('/leads/leads/'+editId+'/add_activity/','POST',{activity_type:t,description:d});
  document.getElementById('actDesc').value='';
  loadActivities(editId);
}

async function convertLead(){
  if(!editId) return;
  if(!await cbpConfirm('Convert this lead to a customer?')) return;
  const btn=document.getElementById('leadConvertBtn');
  await cbpSubmit(btn, async () => {
    const r=await fetch(`${API}/leads/leads/${editId}/convert_to_customer/`,{method:'POST',credentials:'same-origin',headers:hdr('POST'),body:'{}'});
    let d=null;try{d=await r.json();}catch(_){}
    if(r.ok && d && d.status==='converted'){
      toast(`Lead converted! Customer: ${d.customer_name||'created'}`);
      hideModal('modal');loadData();
    } else {
      toast('Convert failed: '+((d&&(d.error||d.detail))||r.status),'error');
    }
  });
}

document.addEventListener('DOMContentLoaded',()=>{loadSources();loadData();});

// ── Discard-confirm guard for create/edit modals ─────────────────────
// Tracks 'dirty' by listening for any input/change inside the modal.
// Exposes el._cbpIsDirty()/el._cbpResetDirty() so base.html's
// closeModalEl() can prompt before closing on backdrop click or ESC.
// X/Cancel buttons close immediately (call hideModal directly) — by design,
// since those are intentional clicks. Reset dirty whenever the modal
// transitions from hidden to visible (new openNew/openEdit invocation).
(function(){
  const MODAL_IDS = ['modal'];
  MODAL_IDS.forEach(function(id){
    const el = document.getElementById(id);
    if (!el) return;
    let dirty = false;
    const mark = function(){ dirty = true; };
    el.addEventListener('input',  mark);
    el.addEventListener('change', mark);
    // Reset dirty when the modal becomes visible (class .show or .open added)
    new MutationObserver(function(muts){
      muts.forEach(function(m){
        if (m.attributeName !== 'class') return;
        const oldCls = (m.oldValue || '').split(/\s+/);
        const wasHidden = !oldCls.includes('show') && !oldCls.includes('open');
        const isShown  = el.classList.contains('show') || el.classList.contains('open');
        if (wasHidden && isShown) dirty = false;
      });
    }).observe(el, { attributes: true, attributeFilter: ['class'], attributeOldValue: true });
    el.dataset.discardConfirm = '1';
    el._cbpIsDirty    = function(){ return dirty; };
    el._cbpResetDirty = function(){ dirty = false; };
  });
})();