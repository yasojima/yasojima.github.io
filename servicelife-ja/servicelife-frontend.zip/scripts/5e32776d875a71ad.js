// BUG-67a44d6b: Force mm/dd/yyyy across the app regardless of the user's
// browser locale. Bare Date.prototype.toLocaleDateString() / toLocaleString()
// calls otherwise inherit the OS locale (en-GB shows dd/mm/yyyy, etc.).
// We default the locale arg to 'en-US' only when the caller passed nothing —
// explicit locales remain untouched. Runs first so every later inline script
// sees the patched prototype. Number.prototype.toLocaleString is unaffected.
(function(){
  if (window.__cbpForceEnUSDates) return;
  window.__cbpForceEnUSDates = true;
  var _origDate     = Date.prototype.toLocaleDateString;
  var _origDateTime = Date.prototype.toLocaleString;
  var _origTime     = Date.prototype.toLocaleTimeString;
  Date.prototype.toLocaleDateString = function(locales, options){
    return _origDate.call(this, locales == null ? 'en-US' : locales, options);
  };
  Date.prototype.toLocaleString = function(locales, options){
    return _origDateTime.call(this, locales == null ? 'en-US' : locales, options);
  };
  Date.prototype.toLocaleTimeString = function(locales, options){
    return _origTime.call(this, locales == null ? 'en-US' : locales, options);
  };
})();