const API='/api/v1';
const hdr=()=>({'Content-Type':'application/json','X-CSRFToken':document.cookie.match(/csrftoken=([^;]+)/)?.[1]||''});
const api=async u=>(await fetch(API+u,{credentials:'same-origin',headers:hdr()})).json();

// Module-level timer handle so loadKPIs can self-clear if the dashboard
// has been SPA-nav'd away and the cleanup in base.html missed it.
window.__dashKPITimer = window.__dashKPITimer || null;

async function loadKPIs(){
  const dashTimeEl = document.getElementById('dashTime');
  if (!dashTimeEl) {
    // Dashboard DOM is gone — kill our interval so we don't keep firing
    // against null nodes. SPA-nav back to /dashboard/ will re-register.
    if (window.__dashKPITimer) {
      clearInterval(window.__dashKPITimer);
      window.__dashKPITimer = null;
    }
    return;
  }
  dashTimeEl.textContent = 'Updated: ' + new Date().toLocaleTimeString();
  try{
    const d=await api('/scheduling/kpis/');

    // KPI cards
    document.getElementById('kToday').textContent=d.today.total;
    document.getElementById('kTodaySub').textContent=d.today.completed+' done, '+d.today.in_progress+' active';
    document.getElementById('kWeek').textContent=d.week.total;
    document.getElementById('kWeekSub').textContent=d.week.completed+' completed';
    document.getElementById('kMonth').textContent=d.month.total;
    document.getElementById('kMonthSub').textContent=d.month.completed+' done, '+d.month.cancelled+' cancelled';
    document.getElementById('kRate').textContent=d.month.completion_rate+'%';
    document.getElementById('kCust').textContent=d.customers.total;
    document.getElementById('kCustSub').textContent=d.customers.residential+' residential, '+d.customers.commercial+' commercial';
    document.getElementById('kTechs').textContent=d.technicians.active;
    document.getElementById('kTechSub').textContent='~'+d.technicians.avg_jobs_per_day+' jobs/tech/day';

    // Status pills
    const sp=document.getElementById('statusPills');
    sp.innerHTML=`
      <div class="st-pill sch"><div class="n">${d.jobs_by_status.scheduled}</div>Scheduled</div>
      <div class="st-pill prog"><div class="n">${d.jobs_by_status.in_progress}</div>In progress</div>
      <div class="st-pill done"><div class="n">${d.jobs_by_status.completed}</div>Completed</div>
      <div class="st-pill canc"><div class="n">${d.jobs_by_status.cancelled}</div>Cancelled</div>`;

    // Jobs by type
    const jt=document.getElementById('jobTypes');
    const maxJT=Math.max(1,...d.jobs_by_type.map(j=>j.count));
    jt.innerHTML=d.jobs_by_type.map(j=>`<div class="jt-row"><span class="jt-name">${j.job_type__name}</span><div class="jt-bar"><div class="fill" style="width:${j.count/maxJT*100}%;background:${j.job_type__color||'var(--accent)'}"></div></div><span class="jt-num">${j.count}</span></div>`).join('')||'<div style="color:var(--text-light);font-size:12px">No data yet</div>';

    // Upcoming
    const ul=document.getElementById('upcoming');
    ul.innerHTML=d.upcoming.length?d.upcoming.map(u=>{
      const dt=new Date(u.start_datetime);
      const time=dt.toLocaleString('en-US',{weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});
      return `<li onclick="window.location.href='/calendar/'" title="View in calendar"><div class="up-dot" style="background:${u.technician_color||'#2196F3'}"></div><div><div class="t">${u.customer_name||'—'}</div><div class="m">${escHTML(u.job_type)||''} &bull; ${time}</div><div class="m">${escHTML(u.technician_name)||'Unassigned'} &bull; ${escHTML(u.location)||''}</div></div></li>`;
    }).join(''):'<li style="color:var(--text-light);font-size:12px">No upcoming appointments</li>';

    // Tech leaderboard
    const lb=document.getElementById('leaderboard');
    const maxLB=Math.max(1,...d.tech_leaderboard.map(t=>t.total));
    lb.innerHTML=d.tech_leaderboard.length?d.tech_leaderboard.map(t=>{
      const ini=(t.name||'??').split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2);
      return `<div class="lb-row"><div class="lb-av" style="background:${t.color||'#2196F3'}">${ini}</div><div style="flex:1"><div style="font-weight:500">${t.name}</div><div class="lb-bar"><div class="fill" style="width:${t.total/maxLB*100}%;background:${t.color||'#2196F3'}"></div></div></div><div class="lb-num">${t.completed}/${t.total}</div></div>`;
    }).join(''):'<div style="color:var(--text-light);font-size:12px">No data yet</div>';

    // Messages
    const ms=document.getElementById('msgStats');
    ms.innerHTML=`
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <div class="kpi" style="flex:1;min-width:80px;box-shadow:none;background:var(--bg)"><div class="lbl">SMS sent</div><div class="val" style="font-size:22px">${d.messages.sms_sent}</div></div>
        <div class="kpi" style="flex:1;min-width:80px;box-shadow:none;background:var(--bg)"><div class="lbl">Emails sent</div><div class="val" style="font-size:22px">${d.messages.email_sent}</div></div>
        <div class="kpi" style="flex:1;min-width:80px;box-shadow:none;background:var(--bg)"><div class="lbl">Failed</div><div class="val" style="font-size:22px;color:#e74c3c">${d.messages.failed}</div></div>
      </div>
      <div style="margin-top:12px;font-size:11px;color:var(--text-light)">New customers this month: <strong>${d.month.new_customers}</strong></div>`;

    // GPS
    loadGPS();
    // License compliance tile (Slice B1.2). Server gates the include via
    // show_license_tile; if the tile DOM is absent we no-op.
    loadLicenseTile();
    // Operator KPI tiles (Slice F1). Partial defines loadOperatorKPIs
    // and is always included on /dashboard/ — defensive null-check
    // so a missing partial never breaks the rest of the dashboard refresh.
    if (typeof window.loadOperatorKPIs === 'function') window.loadOperatorKPIs();
  }catch(e){
    if (e && e.name === 'AbortError') return;
    console.error('KPI load error', e);
  }
}

async function loadLicenseTile(){
  const tile = document.getElementById('licenseTile');
  if (!tile) return;  // role-gated off; nothing to do
  try{
    const r = await fetch('/api/v1/compliance/license-expiry-summary/', {credentials:'same-origin'});
    if (!r.ok) return;
    const d = await r.json();
    document.getElementById('licTile30').textContent = d.expiring_30;
    document.getElementById('licTile60').textContent = d.expiring_60;
    document.getElementById('licTile90').textContent = d.expiring_90;
    const banner = document.getElementById('licTileExpiredBanner');
    if (d.expired > 0){
      document.getElementById('licTileExpiredCount').textContent = d.expired;
      document.getElementById('licTileExpiredPlural').textContent = d.expired === 1 ? '' : 's';
      banner.style.display = 'block';
    } else {
      banner.style.display = 'none';
    }
    const total = d.expired + d.expiring_30 + d.expiring_60 + d.expiring_90;
    document.getElementById('licTileEmpty').style.display = total === 0 ? 'block' : 'none';
  }catch(e){
    if (e && e.name === 'AbortError') return;
    console.error('License tile load error', e);
  }
}

async function loadGPS(){
  try{
    const d=await api('/scheduling/gps-live/');
    const list=document.getElementById('gpsList');
    list.innerHTML=d.technicians.map(t=>{
      const status=t.current_job?'<span style="color:#e65100">On job</span>':t.next_job?'<span style="color:#1565c0">En route</span>':'<span style="color:#999">Idle</span>';
      const job=t.current_job?t.current_job.customer+' — '+t.current_job.job_type:t.next_job?'Next: '+t.next_job.customer+' at '+t.next_job.start_time:'No jobs';
      const loc=t.latitude?`${t.latitude.toFixed(4)}, ${t.longitude.toFixed(4)}`:'No GPS data';
      return `<div class="gi"><div class="lb-av" style="background:${t.color};width:24px;height:24px;font-size:9px">${t.initials}</div><div style="flex:1"><div style="font-weight:500">${t.name} ${status}</div><div style="color:var(--text-light);font-size:11px">${job}</div></div><div style="font-size:10px;color:var(--text-light)">${loc}</div></div>`;
    }).join('')||'<div style="color:var(--text-light);font-size:12px">No active technicians</div>';
    updateGPSMarkers(d.technicians);
  }catch(e){}
}


document.addEventListener('DOMContentLoaded',loadKPIs);
// Clear any prior timer (SPA re-execution would otherwise stack them).
if (window.__dashKPITimer) clearInterval(window.__dashKPITimer);
window.__dashKPITimer = setInterval(loadKPIs, 60000); // refresh every minute