(function(){
  var RF_CUSTOMER_ID = "c49c5777-ace8-4691-89ca-fa4c8f33717d";
  var RF_DAYS = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];

  function rfCsrf(){
    return (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';
  }

  async function rfApi(path, method, body){
    var opts = {
      method: method || 'GET',
      credentials: 'same-origin',
      headers: {'X-CSRFToken': rfCsrf()},
    };
    if (body){
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    return fetch(path, opts);
  }

  function rfSetStatus(text, cls){
    var el = document.getElementById('rfStatus');
    if (!el) return;
    el.textContent = text || '';
    el.classList.remove('ok','err');
    if (cls) el.classList.add(cls);
  }

  function rfPopulate(cust){
    var flag = document.getElementById('rfFlexFlag');
    if (flag) flag.checked = !!cust.flexibility_flag;
    var auto = document.getElementById('rfAutoRebalance');
    if (auto) auto.checked = !!cust.allow_auto_rebalance;
    var win = Array.isArray(cust.flexibility_window) ? cust.flexibility_window : [];
    document.querySelectorAll('.rf-day').forEach(function(cb){
      cb.checked = win.indexOf(cb.dataset.day) >= 0;
    });
  }

  window.rfLoadFlexibility = async function(){
    rfSetStatus('Loading...', null);
    try {
      var r = await rfApi('/api/v1/customers/' + RF_CUSTOMER_ID + '/');
      if (!r.ok){
        rfSetStatus('Could not load (' + r.status + ')', 'err');
        return;
      }
      var data = await r.json();
      rfPopulate(data);
      rfSetStatus('', null);
    } catch (e){
      rfSetStatus('Error: ' + e.message, 'err');
    }
  };

  window.rfSaveFlexibility = async function(){
    var btn = document.getElementById('rfSaveBtn');
    if (btn) btn.disabled = true;
    rfSetStatus('Saving...', null);
    try {
      var window_arr = Array.from(document.querySelectorAll('.rf-day'))
        .filter(function(cb){ return cb.checked; })
        .map(function(cb){ return cb.dataset.day; });
      var body = {
        flexibility_flag: document.getElementById('rfFlexFlag').checked,
        flexibility_window: window_arr,
        allow_auto_rebalance: document.getElementById('rfAutoRebalance').checked,
      };
      var r = await rfApi('/api/v1/customers/' + RF_CUSTOMER_ID + '/', 'PATCH', body);
      if (r.ok){
        rfSetStatus('Saved.', 'ok');
      } else {
        var detail = '';
        try { detail = JSON.stringify(await r.json()); } catch(_){ detail = String(r.status); }
        rfSetStatus('Error: ' + detail, 'err');
      }
    } catch (e){
      rfSetStatus('Error: ' + e.message, 'err');
    } finally {
      if (btn) btn.disabled = false;
    }
  };

  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', window.rfLoadFlexibility);
  } else {
    window.rfLoadFlexibility();
  }
})();