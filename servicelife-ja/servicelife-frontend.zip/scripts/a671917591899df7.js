(function(){
const API='/api/v1/chat-rooms';
const IS_ADMIN = false;
const ME = "eeb40003-0104-48df-8aff-e6b578838ad1";
const MY_ROLE = "csr";
const ROLE_LABELS = [
  ['company_admin','Company Admin'],['csr','CSR'],['billing_rep','Billing Rep'],
  ['technician','Technician'],['senior_tech','Senior Tech'],['tech_manager','Tech Manager'],
  ['hr','HR'],['accountant','Accountant'],['sales_rep','Sales Rep'],
];
// Per-role avatar/name colors so it's clear at a glance what role a poster holds.
// Each color is dark enough for white initials on top.
const ROLE_COLORS = {
  company_admin:'#6d28d9', csr:'#0f766e', billing_rep:'#b45309', technician:'#1d4ed8',
  senior_tech:'#0369a1', tech_manager:'#475569', hr:'#be185d', accountant:'#4d7c0f',
  sales_rep:'#b91c1c', developer:'#111827',
};
const ROLE_LABEL_MAP = Object.fromEntries(ROLE_LABELS); ROLE_LABEL_MAP.developer = 'Developer';
function roleColor(r){ return ROLE_COLORS[r] || '#64748b'; }
function roleLabel(r){ return ROLE_LABEL_MAP[r] || (r ? r.replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase()) : ''); }
// Tooltip listing who reacted with an emoji ("You, Alice and Bob reacted with 👍").
function rxnWho(r){
  const who = (r && Array.isArray(r.users)) ? r.users.slice() : [];
  if(!who.length) return '';
  const extra = Math.max(0, (r.count || who.length) - who.length);
  let names = who.length===1 ? who[0]
            : who.length===2 ? who[0]+' and '+who[1]
            : who.slice(0,-1).join(', ')+' and '+who[who.length-1];
  if(extra>0) names += ' and '+extra+' other'+(extra===1?'':'s');
  return names+' reacted with '+((r&&r.emoji)||'');
}
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
function toast(m,type){const e=document.getElementById('chToast');if(!e)return;e.textContent=m;e.className='show'+(type==='error'?' error':'');setTimeout(()=>e.className='',3200);}
async function api(path,method,body){
  const o={method:method||'GET',credentials:'same-origin',headers:{'X-CSRFToken':csrf()}};
  if(body!==undefined){o.headers['Content-Type']='application/json';o.body=JSON.stringify(body);}
  const r=await fetch(API+path,o);
  return r;
}
async function apiJson(path,method,body){const r=await api(path,method,body);if(!r.ok){let d={};try{d=await r.json();}catch(_){}throw new Error(Object.values(d).flat().join(', ')||('HTTP '+r.status));}try{return await r.json();}catch(_){return null;}}
function esc(s){return (s==null?'':String(s)).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function initials(name){return (name||'?').trim().split(/\s+/).slice(0,2).map(w=>w[0]||'').join('').toUpperCase()||'?';}
function fmtTime(iso){const d=new Date(iso);const now=new Date();const sameDay=d.toDateString()===now.toDateString();
  const t=d.toLocaleTimeString([], {hour:'numeric',minute:'2-digit'});
  return sameDay? t : d.toLocaleDateString([], {month:'short',day:'numeric'})+' '+t;}
function fmtSize(n){if(!n)return'';if(n<1024)return n+' B';if(n<1048576)return (n/1024).toFixed(0)+' KB';return (n/1048576).toFixed(1)+' MB';}

const S={channels:[],active:null,lastTs:null,seen:new Set(),reply:null,canPost:false,pending:[],msgTimer:null,unreadTimer:null,
  selUsers:{},selRoles:{},mbItems:[],mbActive:-1,mbAnchor:0,deepMsg:null,dmCollapsed:false};
try{ S.dmCollapsed = localStorage.getItem('cbpChatDmCollapsed')==='1'; }catch(_){}

// ── Channels ──────────────────────────────────────────────
async function loadChannels(){
  try{ S.channels = await apiJson('/channels/'); }catch(e){ toast('Could not load channels: '+e.message,'error'); return; }
  renderChannels();
  if(S.deepChannel && findChannel(S.deepChannel)){ const id=S.deepChannel; S.deepChannel=null; selectChannel(id); }
  else if(S.active===null && S.channels.length && window.innerWidth>768){ selectChannel(S.channels[0].id); }
}
function roomItem(c){
  const active = c.id===S.active ? ' active':'';
  const arch = c.is_archived ? ' archived':'';
  const badge = c.unread_count>0 ? `<span class="ch-badge">${c.unread_count>99?'99+':c.unread_count}</span>`:'';
  const gear = (IS_ADMIN && !badge) ? `<span class="gear" title="Manage" onclick="event.stopPropagation();ChatUI.openManage('${c.id}')"><i class="fas fa-cog"></i></span>`:'';
  return `<div class="ch-item${active}${arch}" onclick="ChatUI.select('${c.id}')"><span class="hash">#</span><span class="name">${esc(c.name)}</span>${badge}${gear}</div>`;
}
function dmItem(c){
  const active = c.id===S.active ? ' active':'';
  const badge = c.unread_count>0 ? `<span class="ch-badge">${c.unread_count>99?'99+':c.unread_count}</span>`:'';
  const title = c.dm_title || 'Direct Message';
  return `<div class="ch-item${active}" onclick="ChatUI.select('${c.id}')"><span class="ch-av">${esc(initials(title))}</span><span class="name">${esc(title)}</span>${badge}</div>`;
}
function renderChannels(){
  const box=document.getElementById('chChannelList'); if(!box)return;
  const rooms=S.channels.filter(c=>c.kind!=='dm');
  const dms=S.channels.filter(c=>c.kind==='dm');
  let html='<div class="ch-section-head"><span>Channels</span></div>';
  html += rooms.length ? rooms.map(roomItem).join('') : '<div class="ch-empty" style="margin:8px 12px;font-size:12px">No channels</div>';
  const col=S.dmCollapsed;
  const dmUnread=dms.reduce((n,c)=>n+(c.unread_count||0),0);
  const colBadge=(col && dmUnread>0) ? `<span class="ch-badge" style="margin-left:6px">${dmUnread>99?'99+':dmUnread}</span>` : '';
  html += `<div class="ch-section-head"><span style="cursor:pointer;display:inline-flex;align-items:center;gap:5px" onclick="ChatUI.toggleDm()" title="${col?'Show':'Hide'} direct messages"><i class="fas fa-chevron-${col?'right':'down'}" style="font-size:9px;width:9px"></i>Direct Messages${colBadge}</span><button title="New message" onclick="ChatUI.openNewDm()"><i class="fas fa-plus"></i></button></div>`;
  if(!col){ html += dms.length ? dms.map(dmItem).join('') : '<div class="ch-empty" style="margin:8px 12px;font-size:12px">No direct messages yet</div>'; }
  box.innerHTML=html;
}
function findChannel(id){return S.channels.find(c=>c.id===id);}
function toggleDm(){ S.dmCollapsed=!S.dmCollapsed; try{ localStorage.setItem('cbpChatDmCollapsed', S.dmCollapsed?'1':'0'); }catch(_){}; renderChannels(); }

async function selectChannel(id){
  S.active=id; S.lastTs=null; S.seen=new Set(); clearReply(); S.pending=[]; renderPending();
  S.oldestTs=null; S.hasMore=false; S.loadingOlder=false;
  S.selUsers={}; S.selRoles={}; closeMentionBox();
  const c=findChannel(id); if(!c)return;
  const isDm = c.kind==='dm';
  S.canPost = !!(c.my_access && c.my_access.post) && !c.is_archived;
  document.getElementById('chTitle').textContent = isDm ? (c.dm_title||'Direct Message') : ('# '+c.name);
  const topic=document.getElementById('chTopic');
  if(!isDm && c.description){ topic.textContent=c.description; topic.hidden=false; } else { topic.hidden=true; }
  renderChannels();
  document.getElementById('chatApp').classList.add('show-chat'); // mobile: slide to chat pane
  document.getElementById('chComposer').hidden = !S.canPost;
  document.getElementById('chReadonly').hidden = S.canPost;
  const list=document.getElementById('chMessages');
  list.innerHTML='<div class="ch-empty" id="chEmpty">Loading…</div>';
  await loadMessages(true);
  markRead(id);
  startPolling();
}

// ── Messages ──────────────────────────────────────────────
async function loadMessages(initial){
  const id=S.active; if(!id)return;
  let path=`/messages/?channel=${encodeURIComponent(id)}`;
  if(!initial && S.lastTs) path+=`&after=${encodeURIComponent(S.lastTs)}`;
  let data; try{ data=await apiJson(path); }catch(e){ if(initial) document.getElementById('chMessages').innerHTML='<div class="ch-empty">'+esc(e.message)+'</div>'; return; }
  if(S.active!==id) return; // channel changed while loading
  const msgs=(data&&data.results)||[];
  const list=document.getElementById('chMessages');
  const atBottom = list.scrollHeight-list.scrollTop-list.clientHeight < 80;
  if(initial){ list.innerHTML=''; if(!msgs.length){ list.innerHTML='<div class="ch-empty">No messages yet. Say hello 👋</div>'; } }
  let added=false, fromOther=false;
  msgs.forEach(m=>{ if(S.seen.has(m.id))return; S.seen.add(m.id); S.lastTs=m.created_at; list.insertAdjacentHTML('beforeend', renderMsg(m)); added=true; if(m.author_id && m.author_id!==ME) fromOther=true; });
  if(initial){ S.oldestTs = msgs.length ? msgs[0].created_at : null; S.hasMore = msgs.length >= 50; }
  if(initial || atBottom || added && atBottom){ list.scrollTop=list.scrollHeight; }
  else if(initial){ list.scrollTop=list.scrollHeight; }
  if(initial && S.deepMsg){ const el=document.getElementById('m-'+S.deepMsg); if(el){ el.scrollIntoView({block:'center'}); el.classList.add('flash'); } S.deepMsg=null; }
  if(!initial && fromOther){ const ac=findChannel(id); if(ac && ac.is_member) playPing(); }
  if(!initial && added && S.active===id){ markRead(id); }
}
// Load a page of OLDER messages when the user scrolls to the top, preserving
// their scroll position (Slack/Discord-style back-scroll history).
async function loadOlder(){
  if(S.loadingOlder || !S.hasMore || !S.active || !S.oldestTs) return;
  const id=S.active; S.loadingOlder=true;
  const list=document.getElementById('chMessages');
  const prevH=list.scrollHeight, prevTop=list.scrollTop;
  const loader=document.createElement('div'); loader.className='ch-empty'; loader.style.padding='8px'; loader.textContent='Loading earlier messages…';
  list.insertAdjacentElement('afterbegin', loader);
  try{
    const data=await apiJson(`/messages/?channel=${encodeURIComponent(id)}&before=${encodeURIComponent(S.oldestTs)}`);
    if(S.active!==id){ return; }
    const older=(data&&data.results)||[];
    loader.remove();
    let html='';
    older.forEach(m=>{ if(S.seen.has(m.id))return; S.seen.add(m.id); html+=renderMsg(m); });
    if(older.length){ S.oldestTs=older[0].created_at; }
    S.hasMore = older.length >= 50;
    if(html){ list.insertAdjacentHTML('afterbegin', html);
      list.scrollTop = prevTop + (list.scrollHeight - prevH); }
  }catch(_){ if(loader) loader.remove(); }
  finally{ S.loadingOlder=false; }
}
function renderMsg(m){
  const rc=roleColor(m.author_role), rl=roleLabel(m.author_role);
  const roleTag = rl ? `<span class="role-tag" style="color:${rc};border-color:${rc}">${esc(rl)}</span>` : '';
  const av=`<div class="avatar" style="background:${rc};color:#fff" title="${esc(rl)}">${esc(initials(m.author_name))}</div>`;
  let reply='';
  if(m.reply_preview){ reply=`<div class="reply-ctx"><i class="fas fa-reply"></i> <b>${esc(m.reply_preview.author_name)}</b>: ${esc(m.reply_preview.snippet)}</div>`; }
  const edited = m.edited_at ? '<span class="edited">(edited)</span>':'';
  const textCls = m.is_deleted ? 'text deleted':'text';
  let atts='';
  if(m.attachments && m.attachments.length){
    atts='<div class="att-wrap">'+m.attachments.map(a=>{
      if(a.is_image) return `<a href="${esc(a.url)}" target="_blank" rel="noopener"><img class="att-img" src="${esc(a.url)}" alt="${esc(a.filename)}"></a>`;
      return `<a class="att-file" href="${esc(a.url)}" target="_blank" rel="noopener"><i class="fas fa-file"></i> ${esc(a.filename)} <span style="color:var(--text-light)">${fmtSize(a.size)}</span></a>`;
    }).join('')+'</div>';
  }
  let rxns='';
  if(m.reactions && m.reactions.length){
    rxns='<div class="reactions">'+m.reactions.map(r=>`<button class="rxn${r.mine?' mine':''}" title="${esc(rxnWho(r))}" onclick="ChatUI.react('${m.id}','${r.emoji}')">${esc(r.emoji)} ${r.count}</button>`).join('')+'</div>';
  }
  let actions='';
  if(!m.is_deleted){
    let btns='';
    btns+=`<button title="React" onclick="ChatUI.openReact(event,'${m.id}')"><i class="far fa-face-smile"></i></button>`;
    if(S.canPost) btns+=`<button title="Reply" onclick="ChatUI.reply('${m.id}')"><i class="fas fa-reply"></i></button>`;
    if(m.can_edit) btns+=`<button title="Edit" onclick="ChatUI.edit('${m.id}')"><i class="fas fa-pen"></i></button>`;
    if(m.can_delete) btns+=`<button title="Delete" onclick="ChatUI.del('${m.id}')"><i class="fas fa-trash"></i></button>`;
    if(btns) actions=`<div class="actions">${btns}</div>`;
  }
  return `<div class="msg" id="m-${m.id}" data-body="${esc(m.body)}">${av}<div class="body">${reply}<div class="meta"><span class="who" style="color:${rc}" title="${esc(rl)}">${esc(m.author_name)}</span>${roleTag}<span class="when">${esc(fmtTime(m.created_at))}</span>${edited}</div><div class="${textCls}">${renderBody(m)}</div>${atts}${rxns}</div>${actions}</div>`;
}
function reEsc(s){ return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); }
function renderBody(m){
  let html=esc(m.body);
  if(m.is_deleted || !html) return html;
  const map={};
  (m.mentions||[]).forEach(u=>{ const t=esc('@'+u.name); if(!(t in map)) map[t]='mention'+(u.id===ME?' me':''); });
  (m.role_mentions||[]).forEach(r=>{ const t=esc('@'+r.name); if(!(t in map)) map[t]='mention role'+((r.id===MY_ROLE||r.id==='all')?' me':''); });
  const keys=Object.keys(map); if(!keys.length) return html;
  keys.sort((a,b)=>b.length-a.length);
  const re=new RegExp(keys.map(reEsc).join('|'),'g');
  return html.replace(re, s=>'<span class="'+(map[s]||'mention')+'">'+s+'</span>');
}

// ── Composer ──────────────────────────────────────────────
function onFiles(files){ for(const f of files){ S.pending.push(f); } renderPending(); document.getElementById('chFile').value=''; }
function renderPending(){
  const box=document.getElementById('chPending'); if(!box)return;
  box.innerHTML=S.pending.map((f,i)=>`<span class="pend-chip"><i class="fas fa-paperclip"></i>${esc(f.name)} <span style="color:var(--text-light)">${fmtSize(f.size)}</span><span class="x" onclick="ChatUI.rmFile(${i})"><i class="fas fa-times"></i></span></span>`).join('');
}
function rmFile(i){ S.pending.splice(i,1); renderPending(); }
async function send(){
  const ta=document.getElementById('chInput'); const body=ta.value.trim();
  if(!body && !S.pending.length){ return; }
  const btn=document.getElementById('chSendBtn');
  const fd=new FormData(); fd.append('channel',S.active); fd.append('body',body);
  if(S.reply) fd.append('reply_to',S.reply);
  S.pending.forEach(f=>fd.append('files',f));
  Object.keys(S.selUsers).forEach(id=>{ if(body.includes('@'+S.selUsers[id])) fd.append('mentions',id); });
  Object.keys(S.selRoles).forEach(r=>{ if(body.includes('@'+S.selRoles[r])) fd.append('mention_roles',r); });
  btn.disabled=true;
  try{
    const r=await fetch(API+'/messages/',{method:'POST',credentials:'same-origin',headers:{'X-CSRFToken':csrf()},body:fd});
    if(!r.ok){ let d={}; try{d=await r.json();}catch(_){}
      throw new Error(Object.values(d).flat().join(', ')||('HTTP '+r.status)); }
    const m=await r.json();
    ta.value=''; ta.style.height='auto'; S.pending=[]; renderPending(); clearReply();
    S.selUsers={}; S.selRoles={}; closeMentionBox();
    if(!S.seen.has(m.id)){ S.seen.add(m.id); S.lastTs=m.created_at;
      const list=document.getElementById('chMessages'); const empty=document.getElementById('chEmpty'); if(empty)empty.remove();
      list.insertAdjacentHTML('beforeend', renderMsg(m)); list.scrollTop=list.scrollHeight; }
  }catch(e){ toast('Send failed: '+e.message,'error'); }
  finally{ btn.disabled=false; ta.focus(); }
}
function reply(id){ const el=document.getElementById('m-'+id); const who=el?el.querySelector('.who').textContent:''; S.reply=id;
  document.getElementById('chReplyWho').textContent=who; document.getElementById('chReplyBar').style.display='flex'; document.getElementById('chInput').focus(); }
function clearReply(){ S.reply=null; const bar=document.getElementById('chReplyBar'); if(bar)bar.style.display='none'; }
async function edit(id){
  const el=document.getElementById('m-'+id); if(!el)return;
  const cur=el.getAttribute('data-body')||'';
  const next=prompt('Edit message:',cur);
  if(next===null || next.trim()===cur.trim()) return;
  try{ const m=await apiJson('/messages/'+id+'/','PATCH',{body:next.trim()});
    el.outerHTML=renderMsg(m);
  }catch(e){ toast('Edit failed: '+e.message,'error'); }
}
async function del(id){
  if(!confirm('Delete this message?')) return;
  try{ const r=await api('/messages/'+id+'/','DELETE'); if(!r.ok && r.status!==204) throw new Error('HTTP '+r.status);
    // Re-render as tombstone by refetching would be heavy; mark inline.
    const el=document.getElementById('m-'+id); if(el){ el.querySelector('.text').className='text deleted'; el.querySelector('.text').textContent='[message deleted]';
      const a=el.querySelector('.actions'); if(a)a.remove(); const w=el.querySelector('.att-wrap'); if(w)w.remove(); }
  }catch(e){ toast('Delete failed: '+e.message,'error'); }
}
async function markRead(id){ try{ await api('/channels/'+id+'/mark_read/','POST'); const c=findChannel(id); if(c){c.unread_count=0; renderChannels();} if(window.cbpRefreshNotifBell) window.cbpRefreshNotifBell(); }catch(_){} }

// ── Polling ───────────────────────────────────────────────
function startPolling(){ stopMsgPoll(); S.msgTimer=setInterval(()=>{ if(S.active) loadMessages(false); }, 3000); }
function stopMsgPoll(){ if(S.msgTimer){ clearInterval(S.msgTimer); S.msgTimer=null; } }
async function pollUnread(){ try{ const d=await apiJson('/unread/'); let changed=false, increased=false;
  S.channels.forEach(c=>{ const n=(d.channels&&d.channels[c.id])||0; if(c.id!==S.active && c.unread_count!==n){ if(n>(c.unread_count||0) && c.is_member) increased=true; c.unread_count=n; changed=true; } });
  if(changed) renderChannels();
  if(increased) playPing(); }catch(_){} }

// ── Manage channels (admin) ───────────────────────────────
function permRows(existing){
  const map={};
  (existing||[]).forEach(p=>{ map[p.role]=p; });
  return ROLE_LABELS.map(([role,label])=>{
    const p=map[role]||{}; const adm=role==='company_admin';
    const cb=(k)=>`<input type="checkbox" data-role="${role}" data-perm="${k}" ${p[k]?'checked':''} ${adm?'checked disabled':''}>`;
    return `<tr><td>${esc(label)}</td><td>${cb('can_view')}</td><td>${cb('can_post')}</td><td>${cb('can_manage')}</td></tr>`;
  }).join('');
}
function openManage(id){
  const c = id ? findChannel(id) : null;
  document.getElementById('chmTitle').textContent = c ? ('Manage # '+c.name) : 'New Channel';
  document.getElementById('chmName').value = c ? c.name : '';
  document.getElementById('chmDesc').value = c ? (c.description||'') : '';
  document.getElementById('chmPermBody').innerHTML = permRows(c?c.permissions:[]);
  const delBtn=document.getElementById('chmDeleteBtn'); const arcBtn=document.getElementById('chmArchiveBtn');
  if(c){ delBtn.hidden=false; arcBtn.hidden=false; arcBtn.innerHTML = c.is_archived?'<i class="fas fa-box-open"></i> Unarchive':'<i class="fas fa-box-archive"></i> Archive'; }
  else { delBtn.hidden=true; arcBtn.hidden=true; }
  S.editing = c ? c.id : null;
  document.getElementById('chmOverlay').classList.add('open');
}
function closeManage(){ document.getElementById('chmOverlay').classList.remove('open'); S.editing=null; }
function collectPerms(){
  const rows={};
  document.querySelectorAll('#chmPermBody input[type=checkbox]').forEach(cb=>{
    const role=cb.getAttribute('data-role'); const perm=cb.getAttribute('data-perm');
    rows[role]=rows[role]||{role:role,can_view:false,can_post:false,can_manage:false};
    rows[role][perm]=cb.checked;
  });
  return Object.values(rows).filter(r=>r.can_view||r.can_post||r.can_manage);
}
async function save(){
  const name=document.getElementById('chmName').value.trim();
  if(!name){ toast('Name is required','error'); return; }
  const payload={name:name, description:document.getElementById('chmDesc').value.trim(), permissions:collectPerms()};
  try{
    if(S.editing){ await apiJson('/channels/'+S.editing+'/','PATCH',payload); toast('Channel updated'); }
    else { await apiJson('/channels/','POST',payload); toast('Channel created'); }
    closeManage(); await loadChannels();
  }catch(e){ toast('Save failed: '+e.message,'error'); }
}
async function toggleArchive(){
  if(!S.editing)return; const c=findChannel(S.editing); if(!c)return;
  try{ await apiJson('/channels/'+S.editing+'/','PATCH',{is_archived:!c.is_archived}); toast(c.is_archived?'Unarchived':'Archived'); closeManage(); await loadChannels(); }
  catch(e){ toast('Failed: '+e.message,'error'); }
}
async function remove(){
  if(!S.editing)return; if(!confirm('Delete this channel and all its messages? This cannot be undone.'))return;
  try{ const r=await api('/channels/'+S.editing+'/','DELETE'); if(!r.ok && r.status!==204) throw new Error('HTTP '+r.status);
    toast('Channel deleted'); const wasActive=S.active===S.editing; closeManage();
    if(wasActive){ S.active=null; document.getElementById('chMessages').innerHTML='<div class="ch-empty">Pick a channel on the left.</div>'; document.getElementById('chComposer').hidden=true; document.getElementById('chReadonly').hidden=true; document.getElementById('chTitle').textContent='Select a channel'; }
    await loadChannels();
  }catch(e){ toast('Delete failed: '+e.message,'error'); }
}

// ── Wiring ────────────────────────────────────────────────
// ── Sound alerts ──────────────────────────────────────────
let audioCtx=null;
function ensureAudio(){ if(audioCtx) return audioCtx; try{ audioCtx=new (window.AudioContext||window.webkitAudioContext)(); }catch(_){ audioCtx=null; } return audioCtx; }
function soundMuted(){ try{ return localStorage.getItem('cbpChatMuted')==='1'; }catch(_){ return false; } }
function renderSoundBtn(){ const b=document.getElementById('chSoundBtn'); if(!b)return; const m=soundMuted(); b.innerHTML='<i class="fas '+(m?'fa-volume-mute':'fa-volume-up')+'"></i>'; b.title=m?'Chat sounds off — click to enable':'Chat sounds on — click to mute'; b.style.opacity=m?'.55':'1'; }
function toggleSound(){ const m=!soundMuted(); try{ localStorage.setItem('cbpChatMuted', m?'1':'0'); }catch(_){}; renderSoundBtn(); if(!m){ const c=ensureAudio(); if(c&&c.state==='suspended')c.resume(); playPing(true); } }
function playPing(force){
  if(!force && soundMuted()) return;
  const now=Date.now(); if(!force && now-(S.lastPing||0)<1200) return; S.lastPing=now;
  const ctx=ensureAudio(); if(!ctx) return;
  try{
    if(ctx.state==='suspended') ctx.resume();
    const t=ctx.currentTime, o=ctx.createOscillator(), g=ctx.createGain();
    o.type='sine'; o.frequency.setValueAtTime(880,t); o.frequency.setValueAtTime(1174.7,t+0.08);
    g.gain.setValueAtTime(0.0001,t); g.gain.exponentialRampToValueAtTime(0.16,t+0.02); g.gain.exponentialRampToValueAtTime(0.0001,t+0.22);
    o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t+0.24);
  }catch(_){}
}
// Browsers block audio until a user gesture — prime/resume the context on first interaction.
document.addEventListener('click',()=>{ const c=ensureAudio(); if(c&&c.state==='suspended')c.resume(); });

// ── @mention autocomplete ─────────────────────────────────
let mbTimer=null;
function autosize(ta){ ta.style.height='auto'; ta.style.height=Math.min(ta.scrollHeight,160)+'px'; }
function onComposerInput(){
  const ta=document.getElementById('chInput'); autosize(ta);
  const pos=ta.selectionStart, before=ta.value.slice(0,pos);
  const mm=before.match(/@([^\s@]{0,30})$/);
  if(mm){ S.mbAnchor=pos-mm[0].length; queryMentions(mm[1]); }
  else closeMentionBox();
}
function queryMentions(q){
  if(!S.active) return;
  if(mbTimer) clearTimeout(mbTimer);
  mbTimer=setTimeout(async()=>{
    try{ S.mbItems=await apiJson('/channels/'+S.active+'/members/?q='+encodeURIComponent(q)); S.mbActive=S.mbItems.length?0:-1; renderMentionBox(); }
    catch(_){ closeMentionBox(); }
  }, 120);
}
function renderMentionBox(){
  const box=document.getElementById('chMentionBox'); if(!box)return;
  if(!S.mbItems.length){ box.classList.remove('open'); box.innerHTML=''; return; }
  box.innerHTML=S.mbItems.map((it,i)=>{
    const act=i===S.mbActive?' active':'';
    if(it.type==='role') return `<div class="mb-item${act}" onmousedown="ChatUI.pickMention(event,${i})"><span class="mb-role-ic"><i class="fas fa-users"></i></span><span>${esc(it.name)}</span><span class="mb-sub">${esc(it.sub||'role')}</span></div>`;
    return `<div class="mb-item${act}" onmousedown="ChatUI.pickMention(event,${i})"><span class="mb-av">${esc(initials(it.name))}</span><span>${esc(it.name)}</span></div>`;
  }).join('');
  box.classList.add('open');
}
function closeMentionBox(){ const box=document.getElementById('chMentionBox'); if(box){ box.classList.remove('open'); box.innerHTML=''; } S.mbItems=[]; S.mbActive=-1; }
function pickMention(ev,i){
  if(ev) ev.preventDefault();
  const it=S.mbItems[i]; const ta=document.getElementById('chInput'); if(!it||!ta) return;
  const pos=ta.selectionStart;
  const before=ta.value.slice(0,S.mbAnchor), after=ta.value.slice(pos);
  const token='@'+it.name+' ';
  ta.value=before+token+after;
  const np=(before+token).length; ta.selectionStart=ta.selectionEnd=np;
  if(it.type==='role') S.selRoles[it.id]=it.name; else S.selUsers[it.id]=it.name;
  closeMentionBox(); ta.focus(); autosize(ta);
}
function mbNav(dir){ if(!S.mbItems.length)return; S.mbActive=(S.mbActive+dir+S.mbItems.length)%S.mbItems.length; renderMentionBox(); }

// ── New DM picker ─────────────────────────────────────────
let dmTimer=null;
function openNewDm(){ document.getElementById('dmOverlay').classList.add('open'); const s=document.getElementById('dmSearch'); s.value=''; dmSearch(''); setTimeout(()=>s.focus(),50); }
function closeNewDm(){ document.getElementById('dmOverlay').classList.remove('open'); }
function dmSearch(q){ if(dmTimer)clearTimeout(dmTimer); dmTimer=setTimeout(async()=>{
  try{ renderDmResults(await apiJson('/channels/dm-candidates/?q='+encodeURIComponent(q||''))); }
  catch(e){ document.getElementById('dmResults').innerHTML='<div class="ch-empty" style="margin:16px">'+esc(e.message)+'</div>'; } },150); }
function renderDmResults(users){ const box=document.getElementById('dmResults'); if(!box)return;
  if(!users.length){ box.innerHTML='<div class="ch-empty" style="margin:16px">No people found</div>'; return; }
  box.innerHTML=users.map(u=>`<div class="dm-result" onclick="ChatUI.startDm('${u.id}')"><span class="mb-av">${esc(initials(u.name))}</span><span>${esc(u.name)}</span><span class="r">${esc(u.role)}</span></div>`).join(''); }
async function startDm(uid){ try{ const ch=await apiJson('/channels/start-dm/','POST',{user_id:uid}); closeNewDm(); await loadChannels(); selectChannel(ch.id); }catch(e){ toast('Could not start DM: '+e.message,'error'); } }

// ── GIF picker ────────────────────────────────────────────
let gifTimer=null;
function toggleGif(){ const b=document.getElementById('chGifBox'); if(!b)return; if(b.classList.contains('open')){ closeGif(); } else { openGif(); } }
function openGif(){ const b=document.getElementById('chGifBox'); if(!b)return; closeMentionBox(); b.classList.add('open'); const s=document.getElementById('chGifSearch'); s.value=''; gifQuery(''); setTimeout(()=>s.focus(),50); }
function closeGif(){ const b=document.getElementById('chGifBox'); if(b) b.classList.remove('open'); }
function gifSearch(q){ gifQuery(q); }
function gifQuery(q){
  const grid=document.getElementById('chGifGrid'); if(!grid)return;
  grid.innerHTML='<div class="gif-empty">Searching…</div>';
  if(gifTimer) clearTimeout(gifTimer);
  gifTimer=setTimeout(async()=>{
    try{ const d=await apiJson('/gif-search/?q='+encodeURIComponent(q||''));
      const res=(d&&d.results)||[];
      if(d && d.enabled===false){ grid.innerHTML='<div class="gif-empty">GIFs are not configured.</div>'; return; }
      if(!res.length){ grid.innerHTML='<div class="gif-empty">No GIFs found.</div>'; return; }
      grid.innerHTML=res.map(g=>`<img loading="lazy" src="${esc(g.preview)}" alt="${esc(g.title)}" onclick="ChatUI.sendGif('${encodeURIComponent(g.url)}')">`).join('');
    }catch(e){ grid.innerHTML='<div class="gif-empty">GIF search is unavailable.</div>'; }
  }, 250);
}
async function sendGif(encUrl){
  if(!S.active) return;
  const url=decodeURIComponent(encUrl);
  const fd=new FormData(); fd.append('channel',S.active); fd.append('gif_url',url);
  if(S.reply) fd.append('reply_to',S.reply);
  try{
    const r=await fetch(API+'/messages/',{method:'POST',credentials:'same-origin',headers:{'X-CSRFToken':csrf()},body:fd});
    if(!r.ok){ let d={}; try{d=await r.json();}catch(_){}
      throw new Error(Object.values(d).flat().join(', ')||('HTTP '+r.status)); }
    const m=await r.json(); closeGif(); clearReply();
    if(!S.seen.has(m.id)){ S.seen.add(m.id); S.lastTs=m.created_at;
      const list=document.getElementById('chMessages'); const empty=document.getElementById('chEmpty'); if(empty)empty.remove();
      list.insertAdjacentHTML('beforeend', renderMsg(m)); list.scrollTop=list.scrollHeight; }
  }catch(e){ toast('Could not send GIF: '+e.message,'error'); }
}

// ── Emoji reactions ───────────────────────────────────────
const REACT_EMOJIS=['👍','❤️','😂','🎉','✅','👀','🙏','🔥'];
function openReact(ev,msgId){
  if(ev) ev.stopPropagation();
  S.rxnTarget=msgId;
  const box=document.getElementById('chRxnPicker'); if(!box)return;
  box.innerHTML=REACT_EMOJIS.map(e=>`<button type="button" onclick="ChatUI.pickReact('${e}')">${e}</button>`).join('');
  box.classList.add('open');
  const x=(ev&&ev.clientX)||120, y=(ev&&ev.clientY)||120;
  box.style.left=Math.max(8, Math.min(x-20, window.innerWidth-330))+'px';
  box.style.top=Math.max(8, y-52)+'px';
}
function pickReact(emoji){ const id=S.rxnTarget; closeReact(); if(id) react(id,emoji); }
function closeReact(){ const b=document.getElementById('chRxnPicker'); if(b) b.classList.remove('open'); }
async function react(msgId, emoji){
  try{
    const m=await apiJson('/messages/'+msgId+'/react/','POST',{emoji:emoji});
    const el=document.getElementById('m-'+msgId);
    if(el) el.outerHTML=renderMsg(m);
  }catch(e){ toast('Could not react: '+e.message,'error'); }
}
document.addEventListener('click',(e)=>{ const b=document.getElementById('chRxnPicker'); if(b&&b.classList.contains('open')&&!b.contains(e.target)) closeReact(); });

function initComposer(){
  const ta=document.getElementById('chInput'); if(!ta)return;
  ta.addEventListener('input', onComposerInput);
  ta.addEventListener('keydown',(e)=>{
    const open=document.getElementById('chMentionBox').classList.contains('open');
    if(open){
      if(e.key==='ArrowDown'){ e.preventDefault(); mbNav(1); return; }
      if(e.key==='ArrowUp'){ e.preventDefault(); mbNav(-1); return; }
      if(e.key==='Enter'||e.key==='Tab'){ e.preventDefault(); pickMention(null, S.mbActive<0?0:S.mbActive); return; }
      if(e.key==='Escape'){ e.preventDefault(); closeMentionBox(); return; }
    }
    if(e.key==='Enter' && !e.shiftKey){ e.preventDefault(); send(); }
  });
  ta.addEventListener('blur',()=>setTimeout(closeMentionBox,150));
  // Paste-to-attach (Discord-style): screen-grab then Ctrl/Cmd+V drops the image
  // straight into pending attachments — no save-as-file-then-paperclip needed.
  ta.addEventListener('paste',(e)=>{
    const items=(e.clipboardData && e.clipboardData.items) || [];
    const imgs=[];
    for(const it of items){
      if(it.kind==='file' && it.type && it.type.indexOf('image/')===0){
        const f=it.getAsFile(); if(f) imgs.push(f);
      }
    }
    if(!imgs.length) return;   // no image on the clipboard -> normal text paste
    e.preventDefault();
    const named=imgs.map(f=>{
      if(f.name && f.name!=='image.png' && f.name!=='blob') return f;
      const ext=((f.type.split('/')[1]||'png').split('+')[0]);
      try{ return new File([f], 'pasted-'+Date.now()+'.'+ext, {type:f.type}); }
      catch(_){ return f; }
    });
    onFiles(named);
  });
}
function teardown(){ stopMsgPoll(); if(S.unreadTimer){ clearInterval(S.unreadTimer); S.unreadTimer=null; } }
window.addEventListener('cbp:spa-before-leave', teardown, {once:true});

function back(){ document.getElementById('chatApp').classList.remove('show-chat'); }
window.ChatUI={ select:selectChannel, back, toggleDm, openManage, closeManage, save, remove, toggleArchive,
  onFiles, rmFile, send, reply, clearReply, edit, del,
  pickMention, openNewDm, closeNewDm, dmSearch, startDm,
  toggleGif, gifSearch, sendGif, toggleSound,
  openReact, pickReact, react };

// boot
try{ const p=new URLSearchParams(location.search); if(p.get('c')){ S.deepChannel=p.get('c'); S.deepMsg=p.get('m'); } }catch(_){}
renderSoundBtn();
initComposer();
(function(){ const l=document.getElementById('chMessages'); if(l) l.addEventListener('scroll', ()=>{ if(l.scrollTop < 60) loadOlder(); }); })();
loadChannels();
S.unreadTimer=setInterval(pollUnread, 8000);
})();