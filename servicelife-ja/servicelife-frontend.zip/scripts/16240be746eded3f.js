(function(){
const API='/api/v1/business-manager';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
function toast(m,t){const e=document.getElementById('bmToast');e.textContent=m;e.className='show'+(t==='error'?' error':'');setTimeout(()=>e.className='',3200);}
function esc(s){return (s==null?'':String(s)).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function api(path,method,body){const o={method:method||'GET',credentials:'same-origin',headers:{'X-CSRFToken':csrf()}};if(body!==undefined){o.headers['Content-Type']='application/json';o.body=JSON.stringify(body);}const r=await fetch(API+path,o);if(!r.ok){let d={};try{d=await r.json();}catch(_){}throw new Error(d.error||('HTTP '+r.status));}return r.json();}
function fmt(iso){ if(!iso) return '—'; const d=new Date(iso); return d.toLocaleString([], {month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}); }
const S={cfg:{},openChats:new Set()};

function bmEditingListId(){
  const a=document.activeElement, box=document.getElementById('bmList');
  if(a && box && box.contains(a) && (a.tagName==='TEXTAREA'||a.tagName==='INPUT')) return a.id||true;
  return null;
}
async function load(opts){
  try{
    const status=document.getElementById('bmFilter').value;
    const d=await api('/state/?status='+status);
    S.cfg=d.config||{};
    renderStatus(d.status, d.config);
    // Don't rebuild the list out from under someone typing in a Discuss box or
    // editing a draft — a background refresh would wipe their in-progress text.
    if(opts && opts.periodic && bmEditingListId()) return;
    renderList(d.recommendations||[]);
  }catch(e){ document.getElementById('bmList').innerHTML='<div class="bm-empty">'+esc(e.message)+'</div>'; }
}
function renderStatus(st, cfg){
  const bar=document.getElementById('bmStatusBar');
  const on=cfg.enabled;
  bar.innerHTML=`<span class="dot ${on?'on':'off'}"></span><b>${on?'Active':'Disabled'}</b>`
    +`<span class="meta">Model: ${esc(cfg.model)} · effort: impact-scaled (urgent ${esc((cfg.effort_by_impact||{}).urgent||'max')}/normal ${esc((cfg.effort_by_impact||{}).normal||'high')}/low ${esc((cfg.effort_by_impact||{}).low||'medium')}) · heartbeat ${cfg.heartbeat_minutes}m · quiet ${cfg.quiet_start_hour}:00–${cfg.quiet_end_hour}:00</span>`
    +`<span class="meta">Autonomy: ${cfg.autonomy_enabled?'ON (per-area)':'OFF — approval required'}</span>`
    +`<span class="spacer"></span><span class="meta">Last run: ${fmt(st.last_run)} · runs today: ${st.runs_today}</span>`;
}
function actionHtml(a){
  const kind=a.executable?'<span class="a-kind exec">executable</span>':'<span class="a-kind advisory">advisory</span>';
  const done=(a.status==='executed'||a.status==='approved'||a.status==='rejected'||a.status==='failed'||a.status==='advisory');
  let ctl='';
  if(a.status==='draft'){
    ctl=`<div class="bm-row"><button class="bm-btn primary" onclick="BM.approveAction('${a.id}')">Approve${a.executable?' & do it':''}</button>`
      +`<button class="bm-btn danger" onclick="BM.rejectAction('${a.id}')">Reject</button></div>`;
  } else {
    ctl=`<div class="a-status">Status: <b>${esc(a.status)}</b>${a.error?(' — '+esc(a.error)):''}</div>`;
  }
  const draft=a.draft_preview?`<textarea id="draft-${a.id}" ${a.status!=='draft'?'readonly':''}>${esc(a.draft_preview)}</textarea>`:'';
  return `<div class="bm-action"><div><span class="a-title">${esc(a.title)}</span>${kind}</div>${draft}${ctl}</div>`;
}
function renderList(recs){
  const box=document.getElementById('bmList');
  // Preserve any in-progress edits (Discuss inputs, draft textareas) + caret so a
  // re-render never erases what someone is typing.
  const saved={}; box.querySelectorAll('input,textarea').forEach(el=>{ if(el.id) saved[el.id]={v:el.value,s:el.selectionStart,e:el.selectionEnd}; });
  const focusId=(document.activeElement && box.contains(document.activeElement))?document.activeElement.id:null;
  const restore=()=>{ Object.keys(saved).forEach(id=>{ const el=document.getElementById(id); if(el) el.value=saved[id].v; });
    if(focusId){ const el=document.getElementById(focusId); if(el){ try{ el.focus(); const p=saved[focusId]; if(p&&el.setSelectionRange&&p.s!=null) el.setSelectionRange(p.s,p.e); }catch(_){} } } };
  if(!recs.length){ box.innerHTML='<div class="bm-empty">No recommendations. Maurice is watching — you\'ll see items here as they come up (or hit “Analyze now”).</div>'; return; }
  box.innerHTML=recs.map(r=>{
    const links=(r.links||[]).map(l=>`<a href="${esc(l.url)}">${esc(l.label)}</a>`).join('');
    const actions=(r.actions||[]).map(actionHtml).join('');
    const decided=r.status!=='new'&&r.status!=='snoozed';
    let decideRow;
    if(r.status==='new'||r.status==='snoozed'){
      decideRow=`<div class="bm-row"><button class="bm-btn primary" onclick="BM.decide('${r.id}','approved')">Approve</button>`
        +`<button class="bm-btn" onclick="BM.decide('${r.id}','snoozed')">Snooze</button>`
        +`<button class="bm-btn" onclick="BM.decide('${r.id}','done')">Mark done</button>`
        +`<button class="bm-btn danger" onclick="BM.decide('${r.id}','dismissed')">Dismiss</button></div>`;
    } else if(r.status==='approved'){
      // Approved but not yet closed out — still let the owner mark it done or dismiss it.
      decideRow=`<div class="bm-row"><span class="a-status" style="margin-right:auto">Status: <b>approved</b>${r.decided_by?(' by '+esc(r.decided_by)):''}</span>`
        +`<button class="bm-btn primary" onclick="BM.decide('${r.id}','done')">Mark done</button>`
        +`<button class="bm-btn danger" onclick="BM.decide('${r.id}','dismissed')">Dismiss</button></div>`;
    } else {
      decideRow=`<div class="a-status" style="margin-top:8px">Status: <b>${esc(r.status)}</b>${r.decided_by?(' by '+esc(r.decided_by)):''}</div>`;
    }
    const chatOpen=S.openChats.has(r.id);
    return `<div class="bm-card ${esc(r.severity)}">
      <div class="head"><span class="bm-badge ${esc(r.severity)}">${esc(r.severity)}</span><span class="bm-cat">${esc(r.category)}</span><span class="meta" style="margin-left:auto;font-size:11px;color:var(--text-light)">${fmt(r.created_at)}</span></div>
      <h3>${esc(r.title)}</h3>
      <div class="summary">${esc(r.summary)}</div>
      ${r.rationale?`<div class="rationale">${esc(r.rationale)}</div>`:''}
      ${links?`<div class="bm-links">${links}</div>`:''}
      ${actions}
      ${decideRow}
      <div class="bm-row"><button class="bm-btn" onclick="BM.toggleChat('${r.id}')"><i class="fas fa-comment-dots"></i> Discuss${r.message_count?(' ('+r.message_count+')'):''}</button></div>
      <div class="bm-chat" id="chat-${r.id}" ${chatOpen?'':'hidden'}><div class="msgs" id="msgs-${r.id}"></div><div class="composer"><input id="cin-${r.id}" placeholder="Ask Maurice about this…" onkeydown="if(event.key==='Enter')BM.sendRec('${r.id}')"><button class="bm-btn primary" onclick="BM.sendRec('${r.id}')">Send</button></div></div>
    </div>`;
  }).join('');
  S.openChats.forEach(id=>loadMsgs(id));
  restore();
}

async function decide(id,status){ let note=''; if(status==='dismissed'||status==='rejected'){ note=prompt('Optional note:')||''; } try{ await api('/recommendations/'+id+'/decide/','POST',{status,note}); toast('Saved'); load(); }catch(e){ toast(e.message,'error'); } }
async function approveAction(id){ const ta=document.getElementById('draft-'+id); const body={}; if(ta) body.draft_preview=ta.value; try{ await api('/actions/'+id+'/approve/','POST',body); toast('Approved'); load(); }catch(e){ toast(e.message,'error'); } }
async function rejectAction(id){ try{ await api('/actions/'+id+'/reject/','POST',{}); toast('Rejected'); load(); }catch(e){ toast(e.message,'error'); } }

function toggleChat(id){ if(S.openChats.has(id)){S.openChats.delete(id);} else {S.openChats.add(id); loadMsgs(id);} const el=document.getElementById('chat-'+id); if(el) el.hidden=!S.openChats.has(id); }
async function loadMsgs(recId){ try{ const d=await api('/messages/?recommendation_id='+recId); renderMsgs(document.getElementById('msgs-'+recId), d.messages); }catch(_){} }
function renderMsgs(box, msgs){ if(!box)return; box.innerHTML=(msgs||[]).map(m=>`<div class="bm-msg ${esc(m.role)}"><div class="who">${esc(m.who)}</div>${esc(m.body)}</div>`).join(''); box.scrollTop=box.scrollHeight; }
async function sendRec(recId){ const inp=document.getElementById('cin-'+recId); const body=inp.value.trim(); if(!body)return; inp.value=''; try{ await api('/messages/','POST',{recommendation_id:recId, body}); loadMsgs(recId); toast('Sent — Maurice is thinking…'); setTimeout(()=>loadMsgs(recId), 8000); }catch(e){ toast(e.message,'error'); } }

async function loadGen(){ try{ const d=await api('/messages/'); renderMsgs(document.getElementById('bmGenMsgs'), d.messages); }catch(_){} }
async function sendGen(){ const inp=document.getElementById('bmGenInput'); const body=inp.value.trim(); if(!body)return; inp.value=''; try{ await api('/messages/','POST',{body}); loadGen(); toast('Sent — Maurice is thinking…'); setTimeout(loadGen, 8000); setTimeout(loadGen, 20000); }catch(e){ toast(e.message,'error'); } }

async function analyzeNow(){ const b=document.getElementById('bmAnalyze'); b.disabled=true; try{ await api('/analyze-now/','POST',{}); toast('Analysis queued — recommendations will appear shortly.'); setTimeout(fetchStatus, 1500); }catch(e){ toast(e.message,'error'); } finally{ setTimeout(()=>b.disabled=false,2000); } }
async function reanalyzeFresh(){ if(!confirm('Re-analyze from scratch? This dismisses the current open recommendations and regenerates them (one full run).')) return; const b=document.getElementById('bmReanalyze'); b.disabled=true; try{ const r=await api('/analyze-now/','POST',{fresh:true}); toast('Dismissed '+(r.dismissed||0)+' — regenerating fresh…'); setTimeout(fetchStatus,1500); setTimeout(load,3000); }catch(e){ toast(e.message,'error'); } finally{ setTimeout(()=>b.disabled=false,2000); } }

// ── Progress: analyzing now / next scheduled check ──
async function fetchStatus(){ try{ const prev=S.status&&S.status.analyzing; S.status=await api('/status/'); renderProgress(); if(prev && !S.status.analyzing){ load(); } }catch(_){} }
function renderProgress(){
  const st=S.status||{}; const lab=document.getElementById('bmProgLabel'); const bar=document.getElementById('bmProg'); if(!lab||!bar)return;
  if(!st.enabled){ lab.textContent='Disabled'; bar.className='bm-prog'; bar.querySelector('i').style.width='0'; return; }
  if(st.analyzing){
    const el=st.analyzing_since?Math.max(0,Math.round((Date.now()-new Date(st.analyzing_since))/1000)):0;
    const what = st.analyzing_trigger==='chat' ? 'Maurice is thinking' : 'Maurice is analyzing';
    lab.innerHTML=`<span class="pulse"><i class="fas fa-circle-notch fa-spin"></i> ${what}…</span> ${el}s · effort ${esc(st.analyzing_effort||'')}`;
    bar.className='bm-prog indet';
  } else if(st.next_run_at){
    const nxt=new Date(st.next_run_at), now=Date.now(); const remaining=Math.round((nxt-now)/1000);
    const total=(st.heartbeat_minutes||7)*60;
    if(remaining<=0){ lab.textContent='Next check: due now (watching)…'; bar.className='bm-prog'; bar.querySelector('i').style.width='100%'; }
    else { const mm=Math.floor(remaining/60), ss=String(remaining%60).padStart(2,'0'); lab.innerHTML=`<i class="far fa-clock"></i> Next check in ${mm}:${ss} <span style="color:var(--text-light)">(watching continuously)</span>`; bar.className='bm-prog'; bar.querySelector('i').style.width=Math.max(2,Math.min(100,100*(1-remaining/total)))+'%'; }
  } else { lab.textContent='Watching…'; bar.className='bm-prog'; }
}

// ── Settings ──
const AREAS=[['ar','AR & Collections'],['scheduling','Scheduling & Routes'],['retention','Retention & Reviews'],['pricing','Pricing & Margins'],['staffing','Staffing'],['tickets','Tickets']];
function openSettings(){
  const c=S.cfg; const bd=document.getElementById('bmSettingsBody');
  const areaRows=AREAS.map(([k,lab])=>`<div class="bm-toggle-row"><input type="checkbox" id="wt-${k}" ${(c.watchers&&c.watchers[k]!==false)?'checked':''}><span style="flex:1">${lab} — watch</span><input type="checkbox" id="ap-${k}" ${(c.approval_required&&c.approval_required[k]!==false)?'checked':''}><span>needs approval</span></div>`).join('');
  bd.innerHTML=`
    <div class="bm-toggle-row"><input type="checkbox" id="set-enabled" ${c.enabled?'checked':''}><b>Enabled</b> — master on/off</div>
    <div class="bm-toggle-row"><input type="checkbox" id="set-autonomy" ${c.autonomy_enabled?'checked':''}><b>Autonomy</b> — allow graduated areas to act without approval (global brake OFF)</div>
    <div class="bm-toggle-row"><input type="checkbox" id="set-notify" ${c.notify!==false?'checked':''}>Notify company admins</div>
    <div class="bm-toggle-row"><input type="checkbox" id="set-filltom" ${(c.fill_tomorrow&&c.fill_tomorrow.enabled)?'checked':''}><b>Fill-tomorrow outreach</b> — hourly 9–6 ET, text due/overdue customers to fill tomorrow (skips Sundays)</div>
    <label>Heartbeat (minutes)</label><input type="number" id="set-hb" value="${c.heartbeat_minutes||7}" min="3" max="120">
    <label>Quiet hours (start / end, 24h)</label><input type="number" id="set-qs" value="${c.quiet_start_hour}" min="0" max="23"> to <input type="number" id="set-qe" value="${c.quiet_end_hour}" min="0" max="23">
    <label>Daily run cap</label><input type="number" id="set-cap" value="${c.daily_run_cap||60}" min="1" max="500">
    <label>Model</label><input type="text" id="set-model" value="${esc(c.model)}" style="width:160px;border:1px solid var(--border);border-radius:6px;padding:6px 8px">
    <label>Effort by business impact <span style="font-weight:400;color:var(--text-light)">(low·medium·high·xhigh·max)</span></label>
    <div style="display:flex;gap:10px;flex-wrap:wrap">${['urgent','normal','low','chat'].map(k=>`<span style="font-size:12px">${k}: <input type="text" id="eff-${k}" value="${esc((c.effort_by_impact||{})[k]||'')}" style="width:80px;border:1px solid var(--border);border-radius:6px;padding:5px 7px"></span>`).join('')}</div>
    <label style="margin-top:14px">Per-area (watch / needs approval)</label>${areaRows}
    <p style="font-size:11px;color:var(--text-light);margin-top:10px">To let Maurice act on its own in an area, turn Autonomy ON and uncheck that area's “needs approval”. The master brake (Autonomy OFF) always forces approval.</p>`;
  document.getElementById('bmSettingsOv').classList.add('open');
}
function closeSettings(){ document.getElementById('bmSettingsOv').classList.remove('open'); }
async function saveSettings(){
  const g=id=>document.getElementById(id);
  const watchers={},approval={};
  AREAS.forEach(([k])=>{ watchers[k]=g('wt-'+k).checked; approval[k]=g('ap-'+k).checked; });
  const body={ enabled:g('set-enabled').checked, autonomy_enabled:g('set-autonomy').checked, notify:g('set-notify').checked,
    heartbeat_minutes:parseInt(g('set-hb').value)||7, quiet_start_hour:parseInt(g('set-qs').value), quiet_end_hour:parseInt(g('set-qe').value),
    daily_run_cap:parseInt(g('set-cap').value)||60, model:g('set-model').value.trim()||'fable',
    effort_by_impact:{urgent:(g('eff-urgent').value.trim()||'max'), normal:(g('eff-normal').value.trim()||'high'), low:(g('eff-low').value.trim()||'medium'), chat:(g('eff-chat').value.trim()||'high')},
    watchers, approval_required:approval,
    fill_tomorrow:{ enabled:g('set-filltom').checked } };
  try{ await api('/settings/','POST',body); toast('Settings saved'); closeSettings(); load(); }catch(e){ toast(e.message,'error'); }
}

window.BM={ load, decide, approveAction, rejectAction, toggleChat, sendRec, sendGen, analyzeNow, reanalyzeFresh, openSettings, closeSettings, saveSettings };
loadGen(); load(); fetchStatus();
S.timer=setInterval(()=>load({periodic:true}), 20000);
S.statusTimer=setInterval(fetchStatus, 4000);       // fresh status every 4s
S.tick=setInterval(renderProgress, 1000);           // smooth countdown between polls
window.addEventListener('cbp:spa-before-leave', ()=>{ [S.timer,S.statusTimer,S.tick].forEach(t=>t&&clearInterval(t)); }, {once:true});
})();