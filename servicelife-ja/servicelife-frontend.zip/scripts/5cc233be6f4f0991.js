(function(){
  var root = document.getElementById('cdAutopaySection');
  if (!root) return;
  var AP_CID = root.dataset.customerId;
  var AP_CAN_EDIT = root.dataset.canEdit === '1';
  var AP_FREQS = [
    ['weekly','Weekly'], ['bi_weekly','Every 2 weeks'], ['monthly','Monthly'],
    ['bi_monthly','Every 2 months'], ['quarterly','Quarterly'],
    ['semi_annual','Semi-annual'], ['annual','Annual'], ['custom','Custom']
  ];
  var AP_STATE = {};   // schedule_id -> payload
  var AP_CARDS = [];   // [{gateway_card_id, label, is_default}] active cards on file

  function apCsrf(){ return (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || ''; }
  function apToast(msg, ok){ try { toast(msg, ok===false?'error':'success'); } catch(e){ /* no toast helper */ } }
  function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g, function(c){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function freqLabel(v){ for (var i=0;i<AP_FREQS.length;i++){ if (AP_FREQS[i][0]===v) return AP_FREQS[i][1]; } return v||'—'; }
  function cardLabel(cid){ for (var i=0;i<AP_CARDS.length;i++){ if (AP_CARDS[i].gateway_card_id===cid) return AP_CARDS[i].label; } return ''; }
  function money(v){ if (v==null||v==='') return '—'; var n=parseFloat(v); return isNaN(n)?esc(v):('$'+n.toFixed(2)); }
  function fmtDate(iso){
    if (!iso) return '—';
    var p = iso.split('-'); if (p.length!==3) return esc(iso);
    var d = new Date(+p[0], +p[1]-1, +p[2]);
    return d.toLocaleDateString(undefined, {weekday:'short', year:'numeric', month:'short', day:'numeric'});
  }

  async function apLoad(){
    var box = document.getElementById('cdAutopayContent');
    try {
      var r = await fetch('/api/v1/billing/admin/customers/' + AP_CID + '/autopay/', {
        credentials: 'same-origin',
        headers: {'X-CSRFToken': apCsrf(), 'Content-Type': 'application/json'}
      });
      if (!r.ok) { box.innerHTML = '<div class="cd-ap-empty">Could not load auto-pay settings.</div>'; return; }
      var data = await r.json();
      AP_STATE = {};
      AP_CARDS = data.available_cards || [];
      (data.schedules || []).forEach(function(s){ AP_STATE[s.id] = s; });
      apRender(data.schedules || []);
    } catch(e) {
      box.innerHTML = '<div class="cd-ap-empty">Could not load auto-pay settings.</div>';
    }
  }

  function apRender(scheds){
    var box = document.getElementById('cdAutopayContent');
    if (!scheds.length) {
      box.innerHTML = '<div class="cd-ap-empty">This customer is not enrolled in auto-pay '
        + '(no recurring invoice schedule).</div>';
      return;
    }
    box.innerHTML = scheds.map(apRowView).join('');
  }

  function apRowView(s){
    var status = s.is_active
      ? '<span class="cd-ap-active">Active</span>'
      : '<span class="cd-ap-paused">Paused</span>';
    var freqTxt = freqLabel(s.frequency);
    if (s.frequency === 'custom') freqTxt += ' (every ' + esc(s.billing_interval) + ' ' + esc(s.billing_unit) + ')';
    var loc = s.service_location_label ? '<div class="cd-ap-note">Billed to: ' + esc(s.service_location_label)
      + (s.has_card ? ' · card on file' : ' · <span style="color:#c62828">no card on file</span>') + '</div>' : '';
    // Which card autopay bills. Warn if the pinned card is no longer on file.
    var cardTxt;
    if (!s.square_card_id) cardTxt = '<span style="color:#c62828">No card selected</span>';
    else { var cl = cardLabel(s.square_card_id);
      cardTxt = cl ? esc(cl) : '<span style="color:#c62828">⚠️ card no longer on file</span>'; }
    var editBtn = AP_CAN_EDIT
      ? '<div class="cd-ap-actions"><button onclick="cdApEdit(\'' + s.id + '\')">Edit auto-pay</button></div>' : '';
    return ''
      + '<div class="cd-ap-grid" id="apView_' + s.id + '">'
      +   '<div class="lbl">Next payment</div><div class="val">' + fmtDate(s.next_invoice_date) + '</div>'
      +   '<div class="lbl">Frequency</div><div class="val">' + esc(freqTxt) + '</div>'
      +   '<div class="lbl">Amount</div><div class="val">' + money(s.amount) + '</div>'
      +   '<div class="lbl">Card billed</div><div class="val">' + cardTxt + '</div>'
      +   '<div class="lbl">Status</div><div class="val">' + status + '</div>'
      + '</div>' + loc + editBtn;
  }

  window.cdApEdit = function(id){
    if (!AP_CAN_EDIT) return;
    var s = AP_STATE[id]; if (!s) return;
    var view = document.getElementById('apView_' + id);
    var freqOpts = AP_FREQS.map(function(f){
      return '<option value="' + f[0] + '"' + (f[0]===s.frequency?' selected':'') + '>' + f[1] + '</option>';
    }).join('');
    var customRow = ''
      + '<div class="lbl">Custom period</div>'
      + '<div class="val cd-ap-custom" id="apCustom_' + id + '" ' + (s.frequency==='custom'?'':'style="display:none"') + '>'
      +   'every <input type="number" min="1" id="apInt_' + id + '" value="' + esc(s.billing_interval||1) + '">'
      +   '<select id="apUnit_' + id + '">'
      +     ['days','weeks','months'].map(function(u){ return '<option value="'+u+'"'+(u===(s.billing_unit||'months')?' selected':'')+'>'+u+'</option>'; }).join('')
      +   '</select>'
      + '</div>';
    // Card-to-bill dropdown, populated from the customer's active cards on file.
    var cardOpts = AP_CARDS.map(function(c){
      return '<option value="' + esc(c.gateway_card_id) + '"' + (c.gateway_card_id===s.square_card_id?' selected':'') + '>' + esc(c.label) + '</option>';
    }).join('');
    // If the currently-pinned card is no longer on file, surface it as a
    // selectable-but-flagged option so the operator sees what to replace.
    if (s.square_card_id && !cardLabel(s.square_card_id)) {
      cardOpts = '<option value="' + esc(s.square_card_id) + '" selected>⚠️ current card (no longer on file)</option>' + cardOpts;
    }
    if (!AP_CARDS.length && !s.square_card_id) {
      cardOpts = '<option value="">No cards on file — add one first</option>';
    }
    var cardRow = '<div class="lbl">Card to bill</div><div class="val"><select id="apCard_' + id + '">' + cardOpts + '</select></div>';
    view.outerHTML = ''
      + '<div class="cd-ap-grid cd-ap-form" id="apView_' + id + '">'
      +   '<div class="lbl">Next payment</div><div class="val"><input type="date" id="apDate_' + id + '" value="' + esc(s.next_invoice_date||'') + '"></div>'
      +   '<div class="lbl">Frequency</div><div class="val"><select id="apFreq_' + id + '" onchange="cdApFreqChange(\'' + id + '\')">' + freqOpts + '</select></div>'
      +   customRow
      +   '<div class="lbl">Amount ($)</div><div class="val"><input type="number" min="0" step="0.01" id="apAmt_' + id + '" value="' + esc(s.amount!=null?s.amount:'') + '"></div>'
      +   cardRow
      +   '<div class="lbl">Status</div><div class="val"><select id="apActive_' + id + '"><option value="1"' + (s.is_active?' selected':'') + '>Active</option><option value="0"' + (!s.is_active?' selected':'') + '>Paused</option></select></div>'
      + '</div>'
      + '<div class="cd-ap-actions">'
      +   '<button class="primary" id="apSave_' + id + '" onclick="cdApSave(\'' + id + '\')">Save</button>'
      +   '<button onclick="cdApCancel()">Cancel</button>'
      + '</div>';
  };

  window.cdApFreqChange = function(id){
    var freq = document.getElementById('apFreq_' + id).value;
    var row = document.getElementById('apCustom_' + id);
    if (row) row.style.display = (freq === 'custom') ? '' : 'none';
  };

  window.cdApCancel = function(){ apRender(Object.keys(AP_STATE).map(function(k){ return AP_STATE[k]; })); };

  window.cdApSave = async function(id){
    var btn = document.getElementById('apSave_' + id); if (btn) btn.disabled = true;
    var body = {
      next_invoice_date: document.getElementById('apDate_' + id).value,
      frequency: document.getElementById('apFreq_' + id).value,
      amount: document.getElementById('apAmt_' + id).value,
      is_active: document.getElementById('apActive_' + id).value === '1'
    };
    var cardEl = document.getElementById('apCard_' + id);
    if (cardEl && cardEl.value) body.square_card_id = cardEl.value;
    if (body.frequency === 'custom') {
      body.billing_interval = document.getElementById('apInt_' + id).value;
      body.billing_unit = document.getElementById('apUnit_' + id).value;
    }
    try {
      var r = await fetch('/api/v1/billing/admin/customers/' + AP_CID + '/autopay/' + id + '/', {
        method: 'PATCH', credentials: 'same-origin',
        headers: {'X-CSRFToken': apCsrf(), 'Content-Type': 'application/json'},
        body: JSON.stringify(body)
      });
      var d = await r.json().catch(function(){ return {}; });
      if (!r.ok) { apToast((d && d.error) || 'Save failed', false); if (btn) btn.disabled = false; return; }
      AP_STATE[id] = d.schedule;
      apRender(Object.keys(AP_STATE).map(function(k){ return AP_STATE[k]; }));
      apToast('Auto-pay updated');
    } catch(e) {
      apToast('Save failed', false); if (btn) btn.disabled = false;
    }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', apLoad);
  else apLoad();
})();