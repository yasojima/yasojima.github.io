const API='/api/v1';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(m)=>{const h={'X-CSRFToken':csrf()};if(m!=='GET')h['Content-Type']='application/json';return h;};
async function api(u,m='GET',b=null){const o={method:m,credentials:'same-origin',headers:hdr(m)};if(b)o.body=JSON.stringify(b);const r=await fetch(API+u,o);if(r.status===204)return null;return r.json();}
function fmtDate(s){if(!s)return'—';return new Date(s).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
function showModal(id){document.getElementById(id).classList.add('show');}
function hideModal(id){document.getElementById(id).classList.remove('show');}

const TYPE_BADGE={work:'green',drive:'blue',break:'gray',overtime:'orange'};
async function loadData(){
  let url='/timetracking/entries/?ordering=-clock_in';
  const t=document.getElementById('filterType').value;
  if(t)url+='&entry_type='+t;
  const d=await api(url);
  let items=d.results||d;
  const anomalyFilter=document.getElementById('filterAnomaly').value;
  if(anomalyFilter==='stale') items=items.filter(e=>e.is_stale);
  else if(anomalyFilter==='zero') items=items.filter(e=>e.is_zero_duration);
  else if(anomalyFilter==='needs_review') items=items.filter(e=>e.is_stale||e.is_zero_duration);
  const q=(document.getElementById('search').value||'').toLowerCase();
  if(q) items=items.filter(e=>(e.tech_name||'').toLowerCase().includes(q));
  const tb=document.getElementById('tableBody');
  if(!items.length){tb.innerHTML='<tr><td colspan="8" style="text-align:center;padding:40px;color:var(--text-light)">No time entries found.</td></tr>';return;}
  tb.innerHTML=items.map(e=>{
    const dur=e.clock_out?(Math.floor(e.duration_minutes/60)+'h '+e.duration_minutes%60+'m'):'Running...';
    const staleWarning=e.is_stale?'<span class="badge badge-red" title="Open for more than 16 hours — admin review needed">Stale</span> ':'';
    const zeroDurWarning=e.is_zero_duration?'<span class="badge badge-orange" title="Zero-duration entry — possible clock-out error">Zero</span> ':'';
    const clockOutCell=e.clock_out?fmtDate(e.clock_out):'<span class="badge badge-orange">Active</span>';
    const approvedCell=e.clock_out?(e.is_approved?'<span class="badge badge-green">Yes</span>':'<span class="badge badge-gray">No</span>'):'<span class="badge badge-gray" title="Cannot approve while entry is still open">N/A</span>';
    const closeBtn=e.is_stale?`<button onclick="closeOut('${e.id}')" style="font-size:11px;padding:3px 8px;border:1px solid #c62828;background:#fbe9e7;color:#c62828;border-radius:5px;cursor:pointer">Close out</button>`:'—';
    return `<tr><td><strong>${e.tech_name||'—'}</strong></td><td><span class="badge badge-${TYPE_BADGE[e.entry_type]||'gray'}">${e.entry_type}</span></td><td>${fmtDate(e.clock_in)}</td><td>${clockOutCell}</td><td>${staleWarning}${zeroDurWarning}${dur}</td><td>${e.appointment?'Yes':'—'}</td><td>${approvedCell}</td><td>${closeBtn}</td></tr>`;
  }).join('');}

async function closeOut(id){
  if(!confirm('Force-close this entry? Clock-out will be capped at clock-in + 16h.'))return;
  const r=await api('/timetracking/entries/'+id+'/close_out/','POST',{});
  if(r&&r.id){alert('Entry closed out.');loadData();}else{alert('Error: '+(r&&r.error?r.error:'unknown'));}}

document.addEventListener('DOMContentLoaded',loadData);