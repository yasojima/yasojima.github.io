const API='/api/v1';
const TO_CAN_MANAGE = (false || 'company_admin' === 'company_admin');
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(m)=>{const h={'X-CSRFToken':csrf()};if(m!=='GET')h['Content-Type']='application/json';return h;};
async function apiFetch(u,m='GET',b=null){const o={method:m,credentials:'same-origin',headers:hdr(m)};if(b)o.body=JSON.stringify(b);const r=await fetch(API+u,o);return r;}
async function api(u,m='GET',b=null){const r=await apiFetch(u,m,b);return r.json();}
function fmtDate(s){if(!s)return'Never';return new Date(s).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}

const RB={company_admin:'green',csr:'blue',billing_rep:'purple',technician:'orange',senior_tech:'orange',tech_manager:'green',hr:'blue',accountant:'gray',sales_rep:'blue',property_manager:'purple',customer_residential:'gray',customer_commercial:'gray',prospect:'gray'};
let editingId=null;
let pwResetId=null;

function toast(msg, type='success'){
  const t=document.getElementById('toast');
  t.textContent=msg; t.className='toast '+type;
  setTimeout(()=>{t.className='toast';},3000);
}


// Show manager field for tech roles
function onRoleChange(){
  const role=document.getElementById('fRole').value;
  const isTech=['technician','senior_tech','tech_manager'].includes(role);
  const hasPhone=['csr','sales_rep','billing_rep','company_admin'].includes(role);
  document.getElementById('managerRow').style.display=['technician','senior_tech'].includes(role)?'':'none';
  document.getElementById('travelRow').style.display=isTech?'':'none';document.getElementById('servTypesRow').style.display=document.getElementById('travelRow').style.display;
  document.getElementById('hourlyRow').style.display=isTech?'':'none';
  const extRow=document.getElementById('extensionRow');if(extRow)extRow.style.display=hasPhone?'':'none';
  const deskRow=document.getElementById('deskExtensionRow');if(deskRow)deskRow.style.display=hasPhone?'':'none';
}
document.getElementById('fRole').addEventListener('change', onRoleChange);

async function loadOffices(){
  const d=await api('/offices/');
  const sel=document.getElementById('fOffice');
  sel.innerHTML='<option value="">— No Office —</option>';
  for(const o of (d.results||d)){sel.innerHTML+='<option value="'+o.id+'">'+o.name+' — '+o.address.split(',')[0]+'</option>'}
}
loadOffices();
async function loadDepartments(){
  const sel=document.getElementById('fDept');if(!sel)return;
  try{
    const d=await api('/tickets/sla/departments/');const items=(d&&d.results)||d||[];
    sel.innerHTML='<option value="">No Department (sees none — only tickets assigned to them)</option>'+items.filter(x=>x.is_active!==false).map(x=>'<option value="'+x.id+'">'+String(x.name||x.slug||'').replace(/</g,'&lt;')+'</option>').join('');
  }catch(e){}
}
loadDepartments();

async function loadManagers(){
  const d=await api('/users/?role=tech_manager&is_active=true&page_size=50');
  const sel=document.getElementById('fManager');
  sel.innerHTML='<option value="">— None —</option>'+(d.results||[]).map(m=>'<option value="'+m.id+'">'+m.first_name+' '+m.last_name+'</option>').join('');
}
loadManagers();

async function loadData(){
  let url='/users/?ordering=-date_joined';
  const s=document.getElementById('search').value;
  const r=document.getElementById('filterRole').value;
  const a=document.getElementById('filterActive').value;
  if(s) url+='&search='+encodeURIComponent(s);
  if(r) url+='&role='+r;
  if(a) url+='&is_active='+a;
  const d=await api(url);
  const items=d.results||d;
  const tb=document.getElementById('tableBody');
  if(!items.length){tb.innerHTML='<tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-light)">No users found</td></tr>';return;}
  tb.innerHTML=items.map(u=>{
    const ini=((u.first_name||'')[0]||'')+((u.last_name||'')[0]||'');
    return `<tr>
      <td><span class="user-avatar">${ini.toUpperCase()||'?'}</span><strong>${u.first_name||''} ${u.last_name||''}</strong>${u.username?`<div style="font-size:11px;color:var(--text-light)">@${u.username}</div>`:''}</td>
      <td>${u.email||'—'}</td>
      <td>${u.phone||'—'}</td>
      <td><span class="badge badge-${RB[u.role]||'gray'}">${(u.role_display||u.role||'').replace(/_/g,' ')}</span>${u.is_superuser?' <span class="badge badge-red" style="font-size:9px">Super</span>':''}${u.manager_name?' <span style="font-size:10px;color:var(--text-light)">→ '+u.manager_name+'</span>':''}</td>
      <td>${u.is_active?'<span class="badge badge-green">Active</span>':'<span class="badge badge-gray">Inactive</span>'}</td>
      <td>${fmtDate(u.last_login)}</td>
      <td>
        <button type="button" class="btn-sm" onclick="openEdit('${u.id}')" title="Edit"><i class="fas fa-edit"></i></button>
        <button type="button" class="btn-sm" onclick="toggleActive('${u.id}',${u.is_active})" title="${u.is_active?'Deactivate':'Activate'}"><i class="fas fa-${u.is_active?'ban':'check'}"></i></button>
        <button type="button" class="btn-sm" onclick="openPwReset('${u.id}')" title="Reset Password"><i class="fas fa-key"></i></button>
        <button type="button" class="btn-sm" data-sched-uid="${u.id}" data-sched-name="${u.first_name} ${u.last_name}" title="Work Schedule" style="color:var(--primary)"><i class="fas fa-calendar-alt"></i></button>
        <button type="button" class="btn-sm" data-equip-uid="${u.id}" data-equip-name="${u.first_name} ${u.last_name}" title="Equipment" style="color:#e65100"><i class="fas fa-toolbox"></i></button>
        ${['technician','senior_tech','tech_manager'].includes(u.role)?'<button type="button" class="btn-sm" data-abil-uid="'+u.id+'" data-abil-name="'+u.first_name+' '+u.last_name+'" title="Job Abilities" style="color:#2e7d32"><i class="fas fa-star-half-alt"></i></button>':''}
        ${TO_CAN_MANAGE && !['property_manager','customer'].includes(u.role)?'<button type="button" class="btn-sm" data-to-uid="'+u.id+'" data-to-name="'+u.first_name+' '+u.last_name+'" title="Time Off / Vacation" style="color:#6a1b9a"><i class="fas fa-umbrella-beach"></i></button>':''}
        ${u.role==='property_manager'?'<a class="btn-sm" href="/users/'+u.id+'/" title="Managed accounts" style="color:var(--accent);display:inline-flex;align-items:center"><i class="fas fa-building"></i></a>':''}
      </td>
    </tr>`;
  }).join('');
}

function openNew(){
  editingId=null;
  document.getElementById('modalTitle').textContent='Add User';
  document.getElementById('passwordLabel').textContent='Password *';
  document.getElementById('passwordHelp').textContent='Required for new users.';
  ['fFirst','fLast','fUsername','fEmail','fPhone','fHomeAddress','fPassword','fExtension','fDeskExtension'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
  document.getElementById('fRole').value='csr';
  onRoleChange();
  document.getElementById('fManager').value='';
  document.getElementById('fOffice').value='';
  document.getElementById('fDept').value='';
  document.getElementById('fMaxTravel').value=45;
  document.getElementById('fMaxTravelVal').textContent='45min';
  renderServiceableTypes([]);
  document.getElementById('fHourlyCost').value='';
  document.getElementById('fActive').checked=true;
  document.getElementById('fUsername').readOnly=false;
  document.getElementById('userModal').classList.add('open');
}

async function openEdit(id){
  editingId=id;
  const u=await api('/users/'+id+'/');
  document.getElementById('modalTitle').textContent='Edit User';
  document.getElementById('passwordLabel').textContent='New Password';
  document.getElementById('passwordHelp').textContent='Leave blank to keep current password.';
  document.getElementById('fFirst').value=u.first_name||'';
  document.getElementById('fLast').value=u.last_name||'';
  document.getElementById('fUsername').value=u.username||'';
  document.getElementById('fUsername').readOnly=false;
  document.getElementById('fEmail').value=u.email||'';
  document.getElementById('fPhone').value=u.phone||'';
  document.getElementById('fHomeAddress').value=u.home_address||'';
  const extEl=document.getElementById('fExtension');if(extEl)extEl.value=u.phone_extension||'';
  const deskEl=document.getElementById('fDeskExtension');if(deskEl)deskEl.value=u.desk_extension||'';
  document.getElementById('fRole').value=u.role||'csr';
  onRoleChange();
  document.getElementById('fManager').value=u.manager||'';
  document.getElementById('fOffice').value=u.office||'';
  document.getElementById('fDept').value=u.department||'';
  document.getElementById('fActive').checked=u.is_active;
  document.getElementById('fPassword').value='';
  // Load tech settings if tech role
  const isTech=['technician','senior_tech','tech_manager'].includes(u.role);
  if(isTech){
    try{
      const ts=await api('/tech-settings/?user='+id);
      document.getElementById('fMaxTravel').value=ts.max_travel_minutes||45;
      document.getElementById('fMaxTravelVal').textContent=(ts.max_travel_minutes||45)+'min';
      renderServiceableTypes(ts.serviceable_property_types||[]);
      document.getElementById('fHourlyCost').value=(ts.hourly_cost!=null?ts.hourly_cost:'');
    }catch(e){
      document.getElementById('fOffice').value='';
  document.getElementById('fMaxTravel').value=45;
      document.getElementById('fMaxTravelVal').textContent='45min';
    }
  }
  document.getElementById('userModal').classList.add('open');
}

const PROPERTY_TYPE_OPTS=[['house','House'],['apartment','Apartment'],['multifamily','Multifamily'],['retail','Retail'],['office','Office'],['industrial','Industrial'],['restaurant','Restaurant'],['hospitality','Hospitality'],['land','Land']];
function renderServiceableTypes(selected){
  const el=document.getElementById('fServiceableTypes');
  if(!el)return;
  const sel=new Set(selected||[]);
  el.innerHTML=PROPERTY_TYPE_OPTS.map(([v,l])=>`<label style="display:flex;align-items:center;gap:6px;font-size:12px;font-weight:500;cursor:pointer;padding:4px;min-width:0"><input type="checkbox" class="svc-pt" value="${v}" ${sel.has(v)?'checked':''} style="width:14px;height:14px;margin:0;flex:0 0 14px;accent-color:var(--primary)"><span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${l}</span></label>`).join('');
}
function getServiceableTypes(){
  return Array.from(document.querySelectorAll('#fServiceableTypes .svc-pt:checked')).map(c=>c.value);
}
function closeModal(){document.getElementById('userModal').classList.remove('open');}

async function saveUser(){
  const body={
    first_name: document.getElementById('fFirst').value.trim(),
    last_name: document.getElementById('fLast').value.trim(),
    username: document.getElementById('fUsername').value.trim(),
    email: document.getElementById('fEmail').value.trim(),
    phone: document.getElementById('fPhone').value.trim(),
    home_address: document.getElementById('fHomeAddress').value.trim(),
    phone_extension: (document.getElementById('fExtension')?document.getElementById('fExtension').value.trim():''),
    desk_extension: (document.getElementById('fDeskExtension')?document.getElementById('fDeskExtension').value.trim():''),
    role: document.getElementById('fRole').value,
    manager: document.getElementById('fManager').value || null,
    office: document.getElementById('fOffice').value || null,
    department: document.getElementById('fDept').value || null,
    is_active: document.getElementById('fActive').checked,
  };
  const pw=document.getElementById('fPassword').value;
  if(pw) body.password=pw;

  if(!body.first_name||!body.last_name||!body.username){
    toast('First name, last name, and username are required.','error');return;
  }
  if(!editingId && !pw){
    toast('Password is required for new users.','error');return;
  }

  try{
    let r;
    if(editingId){
      r=await apiFetch('/users/'+editingId+'/', 'PATCH', body);
    } else {
      r=await apiFetch('/users/', 'POST', body);
    }
    const d=await r.json();
    if(r.ok){
      // Save tech settings (max travel) if tech role
      const savedRole=document.getElementById('fRole').value;
      if(['technician','senior_tech','tech_manager'].includes(savedRole)){
        const uid=editingId||d.id;
        try{
          await apiFetch('/tech-settings/?user='+uid,'PUT',{max_travel_minutes:parseInt(document.getElementById('fMaxTravel').value),serviceable_property_types:getServiceableTypes(),hourly_cost:(document.getElementById('fHourlyCost').value||'')});
        }catch(e){console.warn('Tech settings save:',e)}
      }
      toast(editingId?'User updated!':'User created!');
      closeModal();
      loadData();
    } else {
      const errs=Object.values(d).flat().join(', ');
      toast('Error: '+errs,'error');
    }
  }catch(e){toast('Error saving user','error');}
}

async function toggleActive(id, currentlyActive){
  if(!confirm(`${currentlyActive?'Deactivate':'Activate'} this user?`)) return;
  try{
    const r=await api('/users/'+id+'/toggle_active/','POST');
    toast(r.message||'Status updated');
    loadData();
  }catch(e){toast('Error toggling status','error');}
}

function openPwReset(id){
  pwResetId=id;
  document.getElementById('fNewPw').value='';
  document.getElementById('fConfirmPw').value='';
  document.getElementById('pwModal').classList.add('open');
}
function closePwModal(){document.getElementById('pwModal').classList.remove('open');}

async function doResetPw(){
  const pw=document.getElementById('fNewPw').value;
  const pw2=document.getElementById('fConfirmPw').value;
  if(pw.length<6){toast('Password must be at least 6 characters','error');return;}
  if(pw!==pw2){toast('Passwords do not match','error');return;}
  try{
    const r=await api('/users/'+pwResetId+'/reset_password/','POST',{password:pw});
    toast(r.message||'Password reset!');
    closePwModal();
  }catch(e){toast('Error resetting password','error');}
}

document.addEventListener('DOMContentLoaded',()=>{
  loadData();
  document.addEventListener('click',e=>{
    const btn=e.target.closest('[data-sched-uid]');
    if(btn) openSchedule(btn.dataset.schedUid, btn.dataset.schedName);
    const abBtn=e.target.closest('[data-abil-uid]');
    if(abBtn) openAbilities(abBtn.dataset.abilUid, abBtn.dataset.abilName);
    const toBtn=e.target.closest('[data-to-uid]');
    if(toBtn) openTimeOff(toBtn.dataset.toUid, toBtn.dataset.toName);
  });
});

// ─── Work Schedule Editor ───
const DAYS=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
const DAY_SHORT=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
let schedUserId=null,schedId=null,schedWeeks={},activeWeek=0;

// Per-tech Time Off (PTO / blocks) — company_admin only
let toUserId=null;
function toEsc(s){return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
function toToggleTimes(){
  const allDay=document.getElementById('toAllDay').checked;
  document.getElementById('toEndWrap').style.display=allDay?'flex':'none';
  document.getElementById('toTimesWrap').style.display=allDay?'none':'flex';
}
function toShowMsg(text,ok){
  const m=document.getElementById('toMsg');
  m.textContent=text; m.style.display='block';
  m.style.background=ok?'#e8f5e9':'#ffebee'; m.style.color=ok?'#2e7d32':'#c62828';
}
function openTimeOff(uid,name){
  toUserId=uid;
  document.getElementById('toTitle').textContent='Time Off - '+(name||'').trim();
  document.getElementById('toAllDay').checked=true;
  document.getElementById('toStart').value='';
  document.getElementById('toEnd').value='';
  document.getElementById('toStartTime').value='';
  document.getElementById('toEndTime').value='';
  document.getElementById('toReason').value='';
  document.getElementById('toMsg').style.display='none';
  toToggleTimes();
  document.getElementById('toModal').classList.add('open');
  loadTimeOff();
}
function closeToModal(){document.getElementById('toModal').classList.remove('open');}
async function loadTimeOff(){
  const box=document.getElementById('toList');
  box.innerHTML='Loading...';
  try{
    const r=await fetch('/users/'+toUserId+'/timeoff/list/',{credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest'}});
    const d=await r.json();
    if(d.supported===false){box.innerHTML='<div style="padding:10px;color:var(--text-light)">Time off cannot be set for this user.</div>';return;}
    if(!d.rows.length){box.innerHTML='<div style="padding:10px;color:var(--text-light)">No time off scheduled.</div>';return;}
    box.innerHTML='<table style="width:100%;border-collapse:collapse;font-size:13px"><thead><tr style="text-align:left;color:var(--text-light);font-size:11px;text-transform:uppercase"><th style="padding:6px 4px">When</th><th style="padding:6px 4px">Reason</th><th style="width:74px"></th></tr></thead><tbody>'+d.rows.map(function(o){return '<tr style="border-top:1px solid var(--border)'+(o.past?';opacity:.55':'')+'"><td style="padding:7px 4px">'+toEsc(o.label)+(o.past?' <span style="font-size:10px;background:#eee;color:#777;border-radius:4px;padding:1px 5px">past</span>':'')+'</td><td style="padding:7px 4px">'+toEsc(o.reason||'-')+'</td><td style="padding:7px 4px"><button type="button" onclick="delTimeOff(\''+o.id+'\')" style="padding:4px 9px;border:1px solid var(--border);border-radius:6px;background:#fff;color:#c62828;font-size:12px;cursor:pointer">Remove</button></td></tr>';}).join('')+'</tbody></table>';
  }catch(e){box.innerHTML='<div style="padding:10px;color:#c62828">Could not load time off.</div>';}
}
async function addTimeOff(){
  const allDay=document.getElementById('toAllDay').checked;
  const sd=document.getElementById('toStart').value;
  if(!sd){toShowMsg('Pick a start date.',false);return;}
  const body=new URLSearchParams();
  body.set('is_all_day',allDay?'1':'0');
  body.set('start_date',sd);
  body.set('end_date',document.getElementById('toEnd').value||sd);
  body.set('reason',document.getElementById('toReason').value||'');
  body.set('start_time',document.getElementById('toStartTime').value||'');
  body.set('end_time',document.getElementById('toEndTime').value||'');
  try{
    const r=await fetch('/users/'+toUserId+'/timeoff/add/',{method:'POST',credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest','X-CSRFToken':csrf(),'Content-Type':'application/x-www-form-urlencoded'},body:body.toString()});
    const d=await r.json().catch(function(){return {};});
    if(r.ok&&d.ok){toShowMsg('Time off added.',true);document.getElementById('toReason').value='';document.getElementById('toStart').value='';document.getElementById('toEnd').value='';loadTimeOff();}
    else{toShowMsg(d.error||'Could not save - check the dates.',false);}
  }catch(e){toShowMsg('Could not save time off.',false);}
}
async function delTimeOff(id){
  if(!confirm('Remove this time off?'))return;
  try{
    const r=await fetch('/users/'+toUserId+'/timeoff/'+id+'/delete/',{method:'POST',credentials:'same-origin',headers:{'X-Requested-With':'XMLHttpRequest','X-CSRFToken':csrf()}});
    const d=await r.json().catch(function(){return {};});
    if(r.ok&&d.ok){loadTimeOff();}else{toShowMsg('Could not remove.',false);}
  }catch(e){toShowMsg('Could not remove.',false);}
}


let abilUserId=null;
let allJobTypes=[];

async function loadJobTypes(){
  if(allJobTypes.length) return;
  const d=await api('/job-types/?page_size=100');
  allJobTypes=(d.results||d).sort((a,b)=>a.name.localeCompare(b.name));
}

function closeAbilModal(){document.getElementById('abilModal').classList.remove('open')}

async function openAbilities(uid,name){
  abilUserId=uid;
  document.getElementById('abilTitle').textContent='Job Abilities — '+name;
  document.getElementById('abilModal').classList.add('open');
  await loadJobTypes();
  await renderAbilities();
}

async function renderAbilities(){
  const d=await api('/tech-abilities/?user='+abilUserId);
  const list=document.getElementById('abilList');
  const empty=document.getElementById('abilEmpty');
  const abilities=d.abilities||[];
  
  // Update job type dropdown — exclude already assigned
  const assignedIds=new Set(abilities.map(a=>a.job_type_id));
  const sel=document.getElementById('abilJtSelect');
  sel.innerHTML='<option value="">Select job type...</option>'+allJobTypes.filter(jt=>!assignedIds.has(jt.id)).map(jt=>'<option value="'+jt.id+'">'+jt.name+'</option>').join('');
  
  if(!abilities.length){
    list.innerHTML='';empty.style.display='block';return;
  }
  empty.style.display='none';
  
  const profClasses={5:'expert',4:'proficient',3:'competent',2:'basic',1:'trainee'};
  list.innerHTML=abilities.map(a=>{
    const pc=profClasses[a.proficiency]||'competent';
    return '<div class="abil-card" data-aid="'+a.id+'">'+
      '<div class="abil-dot" style="background:'+a.job_type_color+'"></div>'+
      '<div class="abil-name">'+a.job_type_name+'</div>'+
      '<div class="abil-meta">'+
        '<select class="abil-sel" onchange="updateAbil(this,\'proficiency\')" data-aid="'+a.id+'">'+
          [1,2,3,4,5].map(v=>'<option value="'+v+'"'+(v===a.proficiency?' selected':'')+'>'+v+' - '+{1:'Trainee',2:'Basic',3:'Competent',4:'Proficient',5:'Expert'}[v]+'</option>').join('')+
        '</select>'+
        '<label class="abil-cert"><input type="checkbox" '+(a.is_certified?'checked':'')+' onchange="updateAbil(this,\'is_certified\')" data-aid="'+a.id+'"> Cert</label>'+
        '<div class="abil-stats">'+
          '<span class="abil-stat">'+a.jobs_completed+' jobs</span>'+
          '<span class="abil-stat">'+a.avg_rating+'★</span>'+
          '<span class="abil-stat" title="Score: higher = better ranked">'+a.score+' pts</span>'+
        '</div>'+
        '<button type="button" class="abil-del" onclick="delAbil(\''+a.id+'\')" title="Remove"><i class="fas fa-trash-alt"></i></button>'+
      '</div>'+
    '</div>';
  }).join('');
}

async function addAbility(){
  const jtId=document.getElementById('abilJtSelect').value;
  const prof=document.getElementById('abilProfSelect').value;
  if(!jtId){toast('Select a job type first','error');return;}
  try{
    const r=await apiFetch('/tech-abilities/','POST',{user_id:abilUserId,job_type_id:jtId,proficiency:parseInt(prof)});
    const d=await r.json();
    if(!r.ok){toast(d.error||'Error adding','error');return;}
    toast('Job type added');
    await renderAbilities();
  }catch(e){toast('Error: '+e.message,'error');}
}

async function updateAbil(el,field){
  const aid=el.dataset.aid||el.closest('[data-aid]').dataset.aid;
  const val=field==='is_certified'?el.checked:el.value;
  try{
    await apiFetch('/tech-abilities/'+aid+'/','PUT',{[field]:val});
    await renderAbilities();
  }catch(e){toast('Error updating','error');}
}

async function delAbil(aid){
  if(!confirm('Remove this job ability?'))return;
  await apiFetch('/tech-abilities/'+aid+'/','DELETE');
  toast('Ability removed');
  await renderAbilities();
}

function closeSchedModal(){document.getElementById('schedModal').classList.remove('open')}
function openLunchOverrides(){if(schedUserId){window.open('/schedule/lunch-overrides/'+schedUserId+'/','_blank');}else{toast('Open a technician schedule first','error');}}

async function openSchedule(uid,name){
  schedUserId=uid;schedId=null;schedWeeks={};activeWeek=0;
  document.getElementById('schedTitle').textContent='Work Schedule — '+name;
  const d=await api('/work-schedules/?user='+uid);
  const items=d.results||d;
  const sched=items[0]||null;
  if(sched){
    schedId=sched.id;
    document.getElementById('sType').value=sched.schedule_type;
    document.getElementById('sLoc').value=sched.default_location;
    document.getElementById('sCycleOn').value=sched.cycle_days_on||5;
    document.getElementById('sCycleOff').value=sched.cycle_days_off||2;
    document.getElementById('sCycleStart').value=sched.cycle_start_date||'';
    document.getElementById('sBiweeklyStart').value=sched.biweekly_start_date||'';
    (sched.days||[]).forEach(day=>{
      const w=day.week_number||0;
      if(!schedWeeks[w])schedWeeks[w]=[];
      schedWeeks[w].push(day);
    });
  } else {
    document.getElementById('sType').value='weekly';
    document.getElementById('sLoc').value='wfo';
    document.getElementById('sCycleStart').value='';
    document.getElementById('sBiweeklyStart').value='';
  }
  if(!Object.keys(schedWeeks).length){
    schedWeeks[0]=[];
    for(let i=0;i<7;i++) schedWeeks[0].push({day_of_week:i,week_number:0,is_working_day:i<5,start_time:'09:00',end_time:'17:00',location:'wfo',breaks:[]});
  }
  onSchedTypeChange();
  document.getElementById('schedModal').classList.add('open');
}

function onSchedTypeChange(){
  const t=document.getElementById('sType').value;
  document.getElementById('cycleOpts').className='sched-subconfig'+(t==='custom_cycle'?' show':'');
  document.getElementById('biweeklyOpts').className='sched-subconfig'+(t==='biweekly'?' show':'');
  if(t==='biweekly'){
    if(!schedWeeks[1]){
      const src=schedWeeks[0]||Object.values(schedWeeks)[0]||[];
      schedWeeks[1]=JSON.parse(JSON.stringify(src)).map(d=>({...d,week_number:1}));
    }
    if(!schedWeeks[2]){
      schedWeeks[2]=JSON.parse(JSON.stringify(schedWeeks[1])).map(d=>({...d,week_number:2}));
    }
    delete schedWeeks[0];
    activeWeek=activeWeek||1;
    if(!schedWeeks[activeWeek]) activeWeek=parseInt(Object.keys(schedWeeks).sort()[0]);
  } else if(t==='weekly'){
    if(!schedWeeks[0]){
      const first=Object.values(schedWeeks)[0]||[];
      schedWeeks={0:first.map(d=>({...d,week_number:0}))};
    } else {
      const keep=schedWeeks[0];
      schedWeeks={0:keep};
    }
    activeWeek=0;
  }
  renderWeekTabs();renderDayGrid();
}

function renderWeekTabs(){
  const t=document.getElementById('sType').value;
  const el=document.getElementById('weekTabs');
  if(t==='weekly'){el.innerHTML='';el.style.display='none';return}
  el.style.display='flex';
  const weeks=Object.keys(schedWeeks).map(Number).sort((a,b)=>a-b);
  let html='';
  weeks.forEach(w=>{
    const isActive=w===activeWeek;
    const canRemove=weeks.length>2;
    html+=`<div class="wk-tab${isActive?' active':''}" onclick="switchWeek(${w})">Week ${w}${canRemove?` <span class="wk-rm" onclick="event.stopPropagation();removeWeek(${w})" title="Remove week">&times;</span>`:''}</div>`;
  });
  html+=`<div class="wk-add" onclick="addWeek()">+ Add Week</div>`;
  el.innerHTML=html;
}

function switchWeek(w){activeWeek=w;renderWeekTabs();renderDayGrid()}

function addWeek(){
  const mx=Math.max(...Object.keys(schedWeeks).map(Number))+1;
  const src=Object.values(schedWeeks)[0]||[];
  schedWeeks[mx]=JSON.parse(JSON.stringify(src)).map(d=>({...d,week_number:mx}));
  activeWeek=mx;renderWeekTabs();renderDayGrid();
}

function removeWeek(w){
  if(Object.keys(schedWeeks).length<=2){toast('Need at least 2 weeks for biweekly','error');return}
  if(!confirm('Remove Week '+w+'?'))return;
  delete schedWeeks[w];
  const remaining=Object.keys(schedWeeks).map(Number).sort((a,b)=>a-b);
  if(!schedWeeks[activeWeek]) activeWeek=remaining[0];
  renderWeekTabs();renderDayGrid();
}

function renderDayGrid(){
  const wk=schedWeeks[activeWeek]||[];
  const grid=document.getElementById('dayGrid');
  for(let i=0;i<7;i++){if(!wk.find(d=>d.day_of_week===i))wk.push({day_of_week:i,week_number:activeWeek,is_working_day:i<5,start_time:'09:00',end_time:'17:00',location:'wfo',breaks:[]})}
  wk.sort((a,b)=>a.day_of_week-b.day_of_week);
  schedWeeks[activeWeek]=wk;
  let html='<div class="day-hdr"><span></span><span>Day</span><span>Start</span><span>End</span><span>Location</span><span>Breaks</span></div>';
  html+=wk.map((d,i)=>{
    const brks=(d.breaks||[]).map((b,bi)=>`<span class="brk-chip">${b.name} ${(b.start_time||'').slice(0,5)}-${(b.end_time||'').slice(0,5)} <span class="brk-x" onclick="rmBreak(${i},${bi})">&times;</span></span>`).join('');
    const locOpts=[['wfo','🏢 Office'],['wfh','🏠 Home'],['field','🚗 Field']].map(([v,l])=>`<option value="${v}"${d.location===v?' selected':''}>${l}</option>`).join('');
    return `<div class="day-row${d.is_working_day?'':' off'}">
      <input type="checkbox" ${d.is_working_day?'checked':''} onchange="toggleDay(${i},this.checked)">
      <span class="day-name">${DAYS[d.day_of_week]}</span>
      <input type="time" value="${(d.start_time||'09:00').slice(0,5)}" onchange="updDay(${i},'start_time',this.value)" ${d.is_working_day?'':'disabled'}>
      <input type="time" value="${(d.end_time||'17:00').slice(0,5)}" onchange="updDay(${i},'end_time',this.value)" ${d.is_working_day?'':'disabled'}>
      <select onchange="updDay(${i},'location',this.value)" ${d.is_working_day?'':'disabled'}>${locOpts}</select>
      <div class="brk-area">${brks}${d.is_working_day?`<button type="button" class="brk-add" onclick="showBrkForm(${i})">+ Break</button>`:''}
        <div class="brk-inline" id="bf${i}"><input type="text" id="bfn${i}" value="Lunch" placeholder="Name"><input type="time" id="bfs${i}" value="12:00"><input type="time" id="bfe${i}" value="12:30"><button type="button" class="brk-ok" onclick="addBreak(${i})">Add</button><button type="button" class="brk-cancel" onclick="hideBrkForm(${i})">✕</button></div>
      </div>
    </div>`}).join('');
  grid.innerHTML=html;
}

function toggleDay(i,v){schedWeeks[activeWeek][i].is_working_day=v;renderDayGrid()}
function updDay(i,k,v){schedWeeks[activeWeek][i][k]=v}
function showBrkForm(i){document.getElementById('bf'+i).classList.add('show')}
function hideBrkForm(i){document.getElementById('bf'+i).classList.remove('show')}
function addBreak(i){
  const n=document.getElementById('bfn'+i).value||'Break';
  const s=document.getElementById('bfs'+i).value;const e=document.getElementById('bfe'+i).value;
  if(!s||!e)return;
  if(!schedWeeks[activeWeek][i].breaks)schedWeeks[activeWeek][i].breaks=[];
  schedWeeks[activeWeek][i].breaks.push({name:n,start_time:s+':00',end_time:e+':00',is_paid:false});
  renderDayGrid();
}
function rmBreak(di,bi){schedWeeks[activeWeek][di].breaks.splice(bi,1);renderDayGrid()}

async function saveSchedule(){
  const body={
    user:schedUserId,schedule_type:document.getElementById('sType').value,
    default_location:document.getElementById('sLoc').value,
    cycle_days_on:parseInt(document.getElementById('sCycleOn').value)||5,
    cycle_days_off:parseInt(document.getElementById('sCycleOff').value)||2,
    cycle_start_date:document.getElementById('sCycleStart').value||null,
    biweekly_start_date:document.getElementById('sBiweeklyStart').value||null
  };
  try{
    let sid=schedId;
    if(!sid){
      const r=await apiFetch('/work-schedules/','POST',body);
      if(!r.ok){toast('Error creating schedule','error');return}
      const d=await r.json();sid=d.id;schedId=sid;
    } else {
      const r=await apiFetch('/work-schedules/'+sid+'/','PATCH',body);
      if(!r.ok){toast('Error updating schedule','error');return}
    }
    // Save days
    const allDays=[];
    Object.values(schedWeeks).forEach(wk=>{
      wk.forEach(d=>{
        allDays.push({day_of_week:d.day_of_week,week_number:d.week_number,is_working_day:d.is_working_day,start_time:d.start_time.length===5?d.start_time+':00':d.start_time,end_time:d.end_time.length===5?d.end_time+':00':d.end_time,location:d.location,breaks:(d.breaks||[]).map(b=>({name:b.name,start_time:b.start_time.length===5?b.start_time+':00':b.start_time,end_time:b.end_time.length===5?b.end_time+':00':b.end_time,is_paid:b.is_paid||false}))});
      });
    });
    const r2=await apiFetch('/work-schedules/'+sid+'/save-days/','POST',{days:allDays});
    if(r2.ok){toast('Schedule saved!');closeSchedModal()}
    else toast('Error saving days','error');
  }catch(e){toast('Error: '+e.message,'error')}
}


// ─── Equipment Tracking ───
let equipUserId=null;

document.addEventListener('click',e=>{
  const btn=e.target.closest('[data-equip-uid]');
  if(btn) openEquipment(btn.dataset.equipUid, btn.dataset.equipName);
});

async function openEquipment(uid, name){
  equipUserId=uid;
  document.getElementById('equipTitle').textContent='Equipment — '+name;
  document.getElementById('equipModal').classList.add('open');
  loadUserEquipment(uid);
  loadAvailableAssets();
  loadEquipHistory(uid);
}

async function loadUserEquipment(uid){
  const d=await api('/equipment/company-assets/?assigned_to='+uid);
  const items=d.results||d;
  if(!items.length){document.getElementById('equipList').innerHTML='<div style="color:var(--text-light);text-align:center;padding:20px">No equipment assigned</div>';return}
  const catColors={Vehicle:'#1565c0','Sprayer/Applicator':'#2e7d32','Safety/PPE':'#e65100','Electronic Device':'#6a1b9a','Hand Tool':'#37474f',Uniform:'#00838f'};
  document.getElementById('equipList').innerHTML=items.map(a=>{
    const bg=catColors[a.category_name]||'#666';
    return `<div class="eq-card">
      <div class="eq-icon" style="background:${bg}20;color:${bg}"><i class="${getCatIcon(a.category_name)}"></i></div>
      <div class="eq-info"><div class="eq-name">${a.name}</div><div class="eq-meta">${a.asset_tag} · ${a.manufacturer} ${a.model}${a.category_name?' · '+a.category_name:''}</div></div>
      <span class="eq-badge ${a.condition}">${a.condition_label}</span>
      <button type="button" class="eq-unassign" onclick="unassignEquip('${a.id}')"><i class="fas fa-times"></i> Return</button>
    </div>`}).join('');
}

function getCatIcon(cat){
  const m={'Vehicle':'fas fa-truck','Sprayer/Applicator':'fas fa-spray-can','Safety/PPE':'fas fa-hard-hat','Electronic Device':'fas fa-tablet-alt','Hand Tool':'fas fa-wrench','Uniform':'fas fa-tshirt'};
  return m[cat]||'fas fa-box';
}

async function loadAvailableAssets(){
  const d=await api('/equipment/company-assets/?status=available');
  const items=d.results||d;
  const sel=document.getElementById('equipAssetSelect');
  sel.innerHTML='<option value="">Select equipment to assign...</option>'+items.map(a=>`<option value="${a.id}">${a.name} (${a.asset_tag}) — ${a.category_name}</option>`).join('');
}

async function assignEquip(){
  const assetId=document.getElementById('equipAssetSelect').value;
  if(!assetId){toast('Select an asset first','error');return}
  const r=await apiFetch('/equipment/company-assets/'+assetId+'/assign/','POST',{user:equipUserId,condition:'good'});
  if(r.ok){toast('Equipment assigned!');loadUserEquipment(equipUserId);loadAvailableAssets();loadEquipHistory(equipUserId)}
  else toast('Error assigning','error');
}

async function unassignEquip(assetId){
  if(!confirm('Return this equipment?'))return;
  const r=await apiFetch('/equipment/company-assets/'+assetId+'/unassign/','POST',{condition:'good'});
  if(r.ok){toast('Equipment returned');loadUserEquipment(equipUserId);loadAvailableAssets();loadEquipHistory(equipUserId)}
  else toast('Error returning','error');
}

async function loadEquipHistory(uid){
  const d=await api('/equipment/asset-assignments/?user='+uid);
  const items=(d.results||d).slice(0,10);
  if(!items.length){document.getElementById('equipHistory').innerHTML='No history';return}
  document.getElementById('equipHistory').innerHTML=items.map(h=>`<div class="eq-hist"><span>${h.action_label}: <strong>${h.asset_name}</strong></span><span style="color:var(--text-light)">${new Date(h.created_at).toLocaleDateString()}</span></div>`).join('');
}