(() => {
  const {api,$,escape,choices,setChoices,textInput,notesInput,cell,button,sorted,status,open,form,filters}=OfficeUI;
  const filter=$("#document-filters");
  const latest=r=>r.history.at(-1);
  const state=v=>!v.due?"none":v.due<api.state.today?"expired":"valid";
  const defaultDepartments=["経理部","総務部","営業部","全社共通"];
  function departmentNames(){
    const saved=api.state.records.flatMap(r=>r.history.map(v=>v.department)).filter(Boolean);
    return [...new Set([...defaultDepartments,...sorted(saved)])];
  }
  function departmentField(value=""){
    return textInput("部署","department",value,'maxlength="110" list="document-departments" placeholder="選択または入力（空欄は全社共通）"')+
      '<datalist id="document-departments">'+choices(departmentNames())+'</datalist>';
  }
  function deadline(v){
    if(!v.due)return "期限なし";
    return state(v)==="expired"?'<span class="overdue">'+escape(v.due)+' · 期限超過</span>':escape(v.due);
  }
  function fileButtons(v){
    const pdf=button("PDFを開く","data-pdf",v.fileId);
    const photo=v.photoId?button("元の写真を開く","data-pdf",v.photoId):"";
    return '<span class="document-files">'+pdf+photo+'</span>';
  }
  function render(){
    const records=api.state.records;
    const options=departmentNames().map(name=>["dept:"+name,name]);
    if(records.some(r=>!latest(r).department)||filter.elements.department.value==="unassigned")options.push(["unassigned","部署未設定"]);
    setChoices(filter.elements.department,options,"すべての部署");
    const f=Object.fromEntries(new FormData(filter)), q=f.q.trim().normalize("NFKC").toLowerCase();
    const rows=records.filter(record=>{
      const v=latest(record), group=v.department?"dept:"+v.department:"unassigned";
      if((f.department && f.department!==group)||(f.status && f.status!==state(v)))return false;
      const fields=[v.department,v.title,v.number,v.filename,v.pdfName,...record.history.map(entry=>entry.office)];
      return !q||fields.some(value=>value?.normalize("NFKC").toLowerCase().includes(q));
    }).sort((a,b)=>latest(b).savedAt.localeCompare(latest(a).savedAt));
    $("#document-rows").innerHTML=rows.map(r=>{
      const v=latest(r);
      return "<tr>"+cell("部署",escape(v.department||"部署未設定"))+cell("書類名",button(v.title,"data-document",r.id))+cell("登録・許可番号など",escape(v.number||"—"))+
        cell("提出・登録日",escape(v.date))+cell("更新期限",deadline(v))+cell("最新版",r.history.length+"版")+
        cell("控え",fileButtons(v))+"</tr>";
    }).join("");
    $("#document-empty").hidden=rows.length>0;$("#document-count").textContent=rows.length+"件 · このブラウザに保存";
    $("#document-new").disabled=!!api.state.error;if(api.state.error)status(api.state.error);
  }
  function edit(record){
    const v=record?latest(record):{};
    const selected=filter.elements.department;
    const initialDepartment=record?v.department:(selected.value.startsWith("dept:")?selected.selectedOptions[0].text:"");
    const fields=departmentField(initialDepartment)+
      textInput("書類名","title",v.title,'required maxlength="150" placeholder="例：事業登録の控え"')+
      textInput("登録・許可番号など（任意）","number",v.number,'maxlength="100" placeholder="例：届出の受付番号、社内管理番号"')+
      textInput("提出・登録日","date",api.state.today,'type="date" required')+
      textInput("更新期限（期限がある場合）","due","",'type="date"')+
      '<div class="document-upload"><label for="document-file">書類の控え（PDF・JPEG・PNG）</label>'+
      '<input type="file" id="document-file" name="file" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" aria-describedby="document-photo-hint" required>'+
      '<button type="button" id="document-take-photo">カメラで撮る</button><input type="file" id="document-camera" accept="image/jpeg" capture="environment" hidden>'+
      '<small id="document-photo-hint">写真は元の画像と提出用のPDFで保管します。</small></div>'+notesInput("");
    form(record?"新版を追加":"書類を登録",fields,"保存",async draft=>{
      const file=draft.file;
      return api.save({...draft,file:await file.arrayBuffer(),filename:file.name,id:record?.id,revision:record?.revision});
    });
    const camera=$("#document-camera"), fileInput=$("#document-file");
    $("#document-take-photo").addEventListener("click",()=>camera.click());
    camera.addEventListener("change",()=>{
      if(camera.files.length){
        const chosen=new DataTransfer();
        chosen.items.add(camera.files[0]);
        fileInput.files=chosen.files;
        camera.value="";
      }
    });
  }
  function details(id){
    const record=api.state.records.find(x=>x.id===id);
    if(!record)return;
    open("書類の詳細・更新履歴",'<h3>'+escape(latest(record).title)+'</h3>'+
      record.history.slice().reverse().map((v,i)=>'<section class="history"><h3>第'+(record.history.length-i)+'版'+(i===0?' · 最新版':'')+'</h3>'+
        '<p>部署　'+escape(v.department||"部署未設定")+'</p>'+(v.office?'<p>登録時の事業所名　'+escape(v.office)+'</p>':'')+
        '<p>'+escape(v.title)+'</p><p>登録・許可番号など　'+escape(v.number||"—")+'</p><p>提出・登録日　'+escape(v.date)+
        '　更新期限　'+deadline(v)+'</p>'+(v.notes?'<p>'+escape(v.notes)+'</p>':'')+'<p class="muted">'+escape(v.filename)+'</p>'+
        fileButtons(v)+'</section>').join("")+
      '<p class="error" role="alert"></p><div class="office-actions">'+
      (!latest(record).department?'<button type="button" id="document-assign">部署を設定</button>':'')+
      '<button type="button" class="primary" id="document-revise">新版を追加</button></div>');
    $("#document-assign")?.addEventListener("click",()=>{
      form("部署を設定",departmentField(),"保存",draft=>api.save({...draft,update:"department",id,revision:record.revision}));
    });
    $("#document-revise").addEventListener("click",()=>edit(record));
  }
  $("#document-new").addEventListener("click",()=>edit(null));
  $("#office").addEventListener("click",async e=>{
    const detail=e.target.closest("[data-document]"),pdf=e.target.closest("[data-pdf]");
    if(detail)details(detail.dataset.document);
    if(pdf){try{await api.pdf(pdf.dataset.pdf);}catch(err){const error=OfficeUI.body.querySelector(".error");if(error && OfficeUI.dialog.open)error.textContent=err.message;else status(err.message);}}
  });
  filters(filter,render);document.addEventListener("office-updated",render);render();
})();