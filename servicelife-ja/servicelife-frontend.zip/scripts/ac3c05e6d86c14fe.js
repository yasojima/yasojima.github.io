function deddaSubmit(e) {
  e.preventDefault();
  const form = e.target;
  const data = new FormData(form);
  const params = new URLSearchParams();
  for (const [k, v] of data.entries()) {
    if (v.trim()) params.append(k, v.trim());
  }
  const url = '/api/v1/compliance/reports/de-dda/csv/?' + params.toString();
  window.location.href = url;
  const status = document.getElementById('dedda-status');
  status.className = 'dedda-status is-info';
  status.textContent = 'Generating CSV... Your download should start shortly.';
  return false;
}