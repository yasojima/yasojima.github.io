(function () {
  const LIST_EL = document.getElementById('rmList');
  const UPDATED_EL = document.getElementById('rmUpdated');
  const COUNT_ELS = {
    pending: document.getElementById('rmCountPending'),
    sent: document.getElementById('rmCountSent'),
    skipped: document.getElementById('rmCountSkipped'),
    failed: document.getElementById('rmCountFailed'),
    all: document.getElementById('rmCountAll'),
  };
  const TABS = Array.from(document.querySelectorAll('.rm-tab'));

  let currentStatus = 'pending';

  function csrfCookie() {
    const m = document.cookie.match(/(?:^|;)\s*csrftoken=([^;]+)/);
    return m ? m[1] : '';
  }

  function fmtDateTime(iso) {
    if (!iso) return '—';
    try {
      const d = new Date(iso);
      return d.toLocaleString(undefined, {
        weekday: 'short', month: 'short', day: 'numeric',
        hour: 'numeric', minute: '2-digit',
      });
    } catch (e) { return iso; }
  }

  function fmtRelative(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    const diffMs = d.getTime() - Date.now();
    const abs = Math.abs(diffMs);
    const mins = Math.round(abs / 60000);
    const hours = Math.round(abs / 3600000);
    const days = Math.round(abs / 86400000);
    const future = diffMs > 0;
    if (abs < 60000) return future ? 'in a moment' : 'just now';
    if (mins < 60) return future ? `in ${mins}m` : `${mins}m ago`;
    if (hours < 24) return future ? `in ${hours}h` : `${hours}h ago`;
    return future ? `in ${days}d` : `${days}d ago`;
  }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    })[c]);
  }

  function renderEmpty(status) {
    const map = {
      pending: { icon: 'fa-bell-slash', text: 'No reminders are queued. They\u2019re created automatically when appointments are scheduled.' },
      sent: { icon: 'fa-paper-plane', text: 'No reminders have been sent yet.' },
      skipped: { icon: 'fa-forward', text: 'No skipped reminders.' },
      failed: { icon: 'fa-exclamation-triangle', text: 'No failed reminders \u2014 things are healthy.' },
      '': { icon: 'fa-bell', text: 'No reminders yet.' },
    };
    const m = map[status] || map[''];
    return `<div class="rm-empty"><i class="fas ${m.icon}"></i><p>${escapeHtml(m.text)}</p></div>`;
  }

  function channelBadge(channel) {
    if (!channel) return '';
    const map = {
      sms: '<i class="fas fa-comment-sms"></i> SMS',
      email: '<i class="fas fa-envelope"></i> Email',
      both: '<i class="fas fa-broadcast-tower"></i> SMS+Email',
    };
    return `<span class="rm-chan-badge">${map[channel] || escapeHtml(channel)}</span>`;
  }

  function renderCard(r) {
    const scheduledAt = r.scheduled_for ? new Date(r.scheduled_for) : null;
    const now = Date.now();
    const isPending = r.status === 'pending';
    const isImminent = isPending && scheduledAt && (scheduledAt.getTime() - now) < 60 * 60 * 1000; // <1h
    const isPast = isPending && scheduledAt && scheduledAt.getTime() < now;
    const firesInClass = isPast ? 'past' : (isImminent ? 'urgent' : '');

    const apptHref = r.appointment_id
      ? `/appointments/?id=${encodeURIComponent(r.appointment_id)}`
      : null;
    const custHref = r.customer_id
      ? `/customers/${encodeURIComponent(r.customer_id)}/`
      : null;

    const skipBtn = isPending ? `
      <div class="rm-actions">
        <button class="rm-btn rm-skip" data-action="skip" data-id="${escapeHtml(r.id)}">
          <i class="fas fa-forward"></i> Skip
        </button>
      </div>
    ` : '';

    return `
      <div class="rm-card ${escapeHtml(r.status)}${isImminent ? ' imminent' : ''}" data-id="${escapeHtml(r.id)}">
        <div class="rm-main">
          <div class="rm-top">
            <span class="rm-when">${escapeHtml(fmtDateTime(r.scheduled_for))}</span>
            ${scheduledAt && isPending
              ? `<span class="rm-fires-in ${firesInClass}">${isPast ? 'overdue' : 'fires'} ${escapeHtml(fmtRelative(r.scheduled_for))}</span>`
              : ''}
            <span class="rm-status-badge rm-status-${escapeHtml(r.status)}">${escapeHtml(r.status)}</span>
            ${channelBadge(r.reminder_rule_channel)}
          </div>
          <div class="rm-row">
            <span><i class="fas fa-user" style="color:var(--text-light);font-size:10px"></i>
              ${custHref
                ? `<a href="${escapeHtml(custHref)}"><strong>${escapeHtml(r.customer_name || '(unknown customer)')}</strong></a>`
                : `<strong>${escapeHtml(r.customer_name || '(unknown customer)')}</strong>`}
            </span>
            ${r.customer_phone ? `<span class="sep">&middot;</span><span>${escapeHtml(r.customer_phone)}</span>` : ''}
          </div>
          <div class="rm-row">
            <span><i class="fas fa-calendar" style="color:var(--text-light);font-size:10px"></i>
              Appt ${escapeHtml(fmtDateTime(r.appointment_start_at))}
              ${r.appointment_technician_name ? `with <strong>${escapeHtml(r.appointment_technician_name)}</strong>` : ''}
            </span>
          </div>
          <div class="rm-rule">${escapeHtml(r.reminder_rule_name || '(no rule)')}</div>
        </div>
        ${skipBtn}
      </div>
    `;
  }

  function setCounts(counts) {
    const total = (counts.pending || 0) + (counts.sent || 0)
                + (counts.skipped || 0) + (counts.failed || 0);
    COUNT_ELS.pending.textContent = counts.pending || 0;
    COUNT_ELS.sent.textContent = counts.sent || 0;
    COUNT_ELS.skipped.textContent = counts.skipped || 0;
    COUNT_ELS.failed.textContent = counts.failed || 0;
    COUNT_ELS.all.textContent = total;
    if (counts.pending > 0) COUNT_ELS.pending.classList.add('has-rows');
    else COUNT_ELS.pending.classList.remove('has-rows');
  }

  async function loadList() {
    LIST_EL.innerHTML = '<div class="rm-loading"><i class="fas fa-spinner fa-spin"></i>Loading…</div>';
    const params = new URLSearchParams();
    if (currentStatus) params.set('status', currentStatus);
    try {
      const res = await fetch('/api/v1/communications/scheduled-reminders/?' + params.toString(), {
        credentials: 'same-origin',
        headers: { 'Accept': 'application/json' },
      });
      if (!res.ok) {
        LIST_EL.innerHTML = `<div class="rm-empty"><i class="fas fa-exclamation-triangle"></i><p>Failed to load (${res.status})</p></div>`;
        return;
      }
      const data = await res.json();
      setCounts(data.counts || {});
      const rows = data.results || [];
      if (rows.length === 0) {
        LIST_EL.innerHTML = renderEmpty(currentStatus);
      } else {
        LIST_EL.innerHTML = rows.map(renderCard).join('');
      }
      UPDATED_EL.textContent = 'Updated ' + new Date().toLocaleTimeString();
    } catch (e) {
      LIST_EL.innerHTML = `<div class="rm-empty"><i class="fas fa-exclamation-triangle"></i><p>Network error: ${escapeHtml(String(e))}</p></div>`;
    }
  }

  async function skip(id, btn) {
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Skipping…'; }
    try {
      const res = await fetch(`/api/v1/communications/scheduled-reminders/${encodeURIComponent(id)}/skip/`, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': csrfCookie(),
          'Accept': 'application/json',
        },
        body: JSON.stringify({}),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const msg = data.error === 'not_pending'
          ? `That reminder isn't pending anymore (current status: ${data.current_status}). It may have just fired or been skipped already.`
          : (data.error || ('Skip failed (' + res.status + ')'));
        alert(msg);
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-forward"></i> Skip'; }
        return;
      }
      loadList();
    } catch (e) {
      alert('Network error: ' + e);
      if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-forward"></i> Skip'; }
    }
  }

  TABS.forEach(tab => {
    tab.addEventListener('click', () => {
      TABS.forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');
      currentStatus = tab.dataset.status || '';
      loadList();
    });
  });

  LIST_EL.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-action]');
    if (!btn) return;
    const id = btn.dataset.id;
    if (!id) return;
    if (btn.dataset.action === 'skip') return skip(id, btn);
  });

  loadList();
})();