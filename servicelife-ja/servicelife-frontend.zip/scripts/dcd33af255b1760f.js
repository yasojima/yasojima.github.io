const API='/api/v1';
let _initializing=false; // BUG-007: suppress onchange during dropdown population
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(method)=>{
  const h={'X-CSRFToken':csrf()};
  if(method!=='GET') h['Content-Type']='application/json';
  return h;
};
async function api(url,method='GET',body=null){
  const opts={method,credentials:'same-origin',headers:hdr(method)};
  if(body) opts.body=JSON.stringify(body);
  const r=await fetch(API+url,opts);
  if(r.status===204) return null;
  let data=null;
  try{data=await r.json();}catch(e){data={detail:'Server returned '+r.status};}
  if(!r.ok){
    const err=new Error('API '+r.status);
    err.status=r.status;
    err.data=data;
    throw err;
  }
  return data;
}
// Surface API errors as a toast + inline messages on the form.
// Pass formId to clear+attach inline messages to inputs named after each error key.
function showApiError(err, formId){
  // Pick a single human-readable line for the toast
  const msg = (err && err.data) ? cbpFormatApiError(err.data, 'Please check the form and try again.') : 'Something went wrong. Please check the form and try again.';
  toast(msg, 'error');
  // Inline highlight: if formId given, attach .field-error spans next to inputs
  if(formId && err && err.data && typeof err.data==='object'){
    document.querySelectorAll('#'+formId+' .field-error').forEach(el=>el.remove());
    document.querySelectorAll('#'+formId+' .field-invalid').forEach(el=>el.classList.remove('field-invalid'));
    Object.entries(err.data).forEach(([k,v])=>{
      // try common field id patterns: f<Capital>, name=k
      const keyCap=k.charAt(0).toUpperCase()+k.slice(1).replace(/_(.)/g,(_,c)=>c.toUpperCase());
      const candidates=['f'+keyCap, k, 'f_'+k];
      for(const id of candidates){
        const inp=document.getElementById(id) || document.querySelector('#'+formId+' [name="'+k+'"]');
        if(inp){
          inp.classList.add('field-invalid');
          const span=document.createElement('div');
          span.className='field-error';
          span.style.cssText='color:#c0392b;font-size:12px;margin-top:2px;';
          span.textContent=Array.isArray(v)?v[0]:String(v);
          inp.parentNode.appendChild(span);
          break;
        }
      }
    });
  }
}
// Minimal toast — uses existing .toast styles if present, otherwise inline
function toast(msg, kind){
  let t=document.getElementById('_apiToast');
  if(!t){
    t=document.createElement('div');
    t.id='_apiToast';
    t.style.cssText='position:fixed;top:20px;right:20px;padding:12px 18px;border-radius:6px;color:#fff;font-size:14px;z-index:99999;box-shadow:0 4px 12px rgba(0,0,0,0.2);max-width:400px;display:none;';
    document.body.appendChild(t);
  }
  t.style.background=kind==='error'?'#c0392b':'#27ae60';
  t.textContent=msg;
  t.style.display='block';
  clearTimeout(t._timer);
  t._timer=setTimeout(()=>{t.style.display='none';},5000);
}
function fmtDate(s){if(!s)return'—';const d=new Date(s);return d.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
function fmtDateTime(s){if(!s)return'—';const d=new Date(s);return d.toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});}
function fmtTime(s){if(!s)return'—';const d=new Date(s);return d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'});}
function scopeBadge(a){
  var bs='display:inline-block;margin-left:5px;font-size:11px;padding:1px 6px;border-radius:4px;white-space:nowrap;';
  var o='';
  if(a.service_scope==='exterior_interior')
    o+=' <span style="'+bs+'background:#eef2ff;color:#4338ca">Ext+Int</span>';
  else if(a.service_scope==='exterior')
    o+=' <span style="'+bs+'background:#eef2ff;color:#4338ca">Ext only</span>';
  if(a.requires_home_presence===true)
    o+=' <span style="'+bs+'background:#fef3c7;color:#92400e">Must be home</span>';
  return o;
}
function statusBadge(s){const m={scheduled:'blue',confirmed:'blue',in_progress:'orange',completed:'green',cancelled:'red',no_show:'gray'};const l={scheduled:'Scheduled',confirmed:'Confirmed',in_progress:'In Progress',completed:'Completed',cancelled:'Cancelled',no_show:'No Show'};return `<span class="badge badge-${m[s]||'gray'}">${l[s]||(s||'').replace(/_/g,' ')}</span>`;}
// Pre-charge status badge (handoff 16.8). Returns empty string for 'not_due'
// so the column stays clean when prepay is not in play. Inline-styled to keep
// dependency footprint tiny (no new CSS class needed).
function prechargeBadge(s){
  if (!s || s === 'not_due') return '';
  const cfg = {
    skipped:        {bg:'#eceff1', fg:'#546e7a', icon:'fa-minus-circle',  label:'Pre-charge skipped'},
    succeeded:      {bg:'#e8f5e9', fg:'#2e7d32', icon:'fa-check-circle',  label:'Pre-charged'},
    failed:         {bg:'#ffebee', fg:'#c62828', icon:'fa-exclamation-triangle', label:'Pre-charge failed'},
    auto_cancelled: {bg:'#fce4ec', fg:'#ad1457', icon:'fa-ban',           label:'Auto-cancelled (pre-charge failed)'},
  }[s];
  if (!cfg) return '';
  return `<span title="${cfg.label}" style="display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:10px;background:${cfg.bg};color:${cfg.fg};font-size:10.5px;font-weight:600;margin-left:4px"><i class="fas ${cfg.icon}"></i>${cfg.label.replace('Pre-charge ','').replace('Pre-charged','Charged')}</span>`;
}
function showModal(id){document.getElementById(id).classList.add('show');}
function hideModal(id){document.getElementById(id).classList.remove('show');}

// ── State ──
let editId=null, currentPage=1, totalCount=0, nextUrl=null, prevUrl=null;
let PAGE_SIZE=25;

// ── Pagination helpers ──
function buildUrl(page){
  let url='/scheduling/appointments/?ordering=-start_datetime&page_size='+PAGE_SIZE+'&page='+page;
  const s=document.getElementById('search').value.trim();
  const st=document.getElementById('filterStatus').value;
  const t=document.getElementById('filterTech').value;
  const dt=document.getElementById('filterDate').value;
  if(st) url+='&status='+st;
  if(t) url+='&technician='+t;
  const jtf=document.getElementById('filterJobType').value;
  if(jtf) url+='&job_type_any='+jtf;
  if(s) url+='&search='+encodeURIComponent(s);
  if(dt) url+='&date='+dt;
  return url;
}
function clearDateFilter(){
  const el=document.getElementById('filterDate');
  if(el.value){ el.value=''; resetAndLoad(); }
}
function goToPage(n){
  // BUG-pagination-spa: inline onclicks in HTML attributes can NOT see
  // IIFE-scoped `let currentPage`. The SPA shim wraps page scripts in IIFEs
  // on every nav after the first, so currentPage is invisible to inline
  // handlers — they receive `undefined` for it, NaN for math on it, and
  // the click silently no-ops. The user has to hard-refresh to bypass
  // the IIFE wrap.
  //
  // Fix: accept string sentinels 'next' / 'prev' (and any numeric value
  // for jump-input). The function resolves currentPage from its own
  // module scope, where it IS visible.
  if (n === 'next') n = currentPage + 1;
  else if (n === 'prev') n = currentPage - 1;
  n=parseInt(n,10);
  if(!Number.isFinite(n)||n<1) return;
  // Defensive bounds check: don't advance past the last page on a force-click
  // or stale-DOM race. nextUrl/prevUrl were cached by the last loadData call.
  if (n > currentPage && !nextUrl) return;
  currentPage=n;
  loadData();
}
function setPageSize(n){
  n=parseInt(n,10);
  if(!Number.isFinite(n)||n<1) return;
  PAGE_SIZE=n;
  currentPage=1;
  loadData();
}
function renderPagination(){
  const el=document.getElementById('pagination');
  if(!el) return;
  if(!totalCount){el.style.display='none';return;}
  const totalPages=Math.max(1,Math.ceil(totalCount/PAGE_SIZE));
  if(currentPage>totalPages) currentPage=totalPages;
  const from=(currentPage-1)*PAGE_SIZE+1;
  const to=Math.min(currentPage*PAGE_SIZE,totalCount);
  const prevDis=!prevUrl?'disabled':'';
  const nextDis=!nextUrl?'disabled':'';
  el.style.display='flex';
  el.innerHTML=
    '<button type="button" '+prevDis+' onclick="goToPage(\'prev\')" title="Previous page"><i class="fas fa-chevron-left"></i> Prev</button>'
    +'<span class="pg-label">Page</span>'
    +'<input class="pg-jump" type="number" min="1" max="'+totalPages+'" value="'+currentPage+'" '
    +  'data-cur="'+currentPage+'" '
    +  'onkeydown="if(event.key===\'Enter\'){event.preventDefault();goToPage(this.value);}" '
    +  'onblur="if(parseInt(this.value,10)!==parseInt(this.dataset.cur,10))goToPage(this.value);">'
    +'<span class="pg-label">of '+totalPages+'</span>'
    +'<button type="button" '+nextDis+' onclick="goToPage(\'next\')" title="Next page">Next <i class="fas fa-chevron-right"></i></button>'
    +'<span class="pg-label" style="margin-left:12px">Per page</span>'
    +'<select onchange="setPageSize(this.value)">'
    +  [10,25,50,100].map(function(n){return '<option value="'+n+'"'+(n===PAGE_SIZE?' selected':'')+'>'+n+'</option>';}).join('')
    +'</select>'
    +'<span class="summary">Showing '+from+'\u2013'+to+' of '+totalCount+'</span>';
}

// ── Data loading ──
async function loadPage(page){
  currentPage=page;
  await loadData();
}
async function loadData(){
  if(_initializing) return; // BUG-007: skip re-entrant calls during init
  let d;
  try { d=await api(buildUrl(currentPage)); }
  catch(e) { if(currentPage>1){currentPage=1;return loadData();} throw e; }
  totalCount=d.count||0;
  nextUrl=d.next||null;
  prevUrl=d.previous||null;
  const items=d.results||d;
  const tb=document.getElementById('tableBody');
  if(!items.length){tb.innerHTML='<tr><td colspan="7"><div class="empty-state"><i class="fas fa-calendar-times"></i><p>No appointments found</p></div></td></tr>';renderPagination();return;}
  tb.innerHTML=items.map(a=>{
    const cust=a.customer_name||(a.customer_detail?a.customer_detail.first_name+' '+a.customer_detail.last_name:a.customer||'—');
    const tech=a.technician_name||(a.technician_detail?a.technician_detail.name:'Unassigned');
    const jt=a.job_type_name||a.title||'—';
    const winCell=a.arrival_window_label?`<br><span style="font-size:11px;color:#2E7D32" title="Customer-facing arrival window">🕑 ${a.arrival_window_label}</span>`:'';
    return `<tr class="clickable" tabindex="0" role="link" onkeydown="if(event.key==='Enter'||event.key===' '){this.click();event.preventDefault()}" onclick="openEdit('${a.id}')"><td>${fmtDateTime(a.start_datetime)}${winCell}</td><td><strong>${cust}</strong></td><td>${jt}${scopeBadge(a)}</td><td>${tech}</td><td>${a.location_text||a.location||'—'}</td><td>${a.duration_minutes||60}m</td><td>${statusBadge(a.status)}${prechargeBadge(a.precharge_status)}</td></tr>`;
  }).join('');
  renderPagination();
}
function resetAndLoad(){currentPage=1;loadData();}

// ── Dropdowns ──
async function loadDropdowns(){
  // Customer dropdown removed — replaced by search-autofill (initAC below).
  // Loading the full /customers/ list here is wasteful at 1000+ rows.
  const [techs,jts]=await Promise.all([api('/technicians/'),api('/job-types/')]);
  const ts=techs.results||techs,js=jts.results||jts;
  document.getElementById('fTech').innerHTML='<option value="">Unassigned</option>'+ts.map(t=>`<option value="${t.id}">${t.name||t.id}</option>`).join('');
  document.getElementById('filterTech').innerHTML='<option value="">All technicians</option>'+ts.map(t=>`<option value="${t.id}">${t.name||t.id}</option>`).join('');
  document.getElementById('fJobType').innerHTML='<option value="">Select...</option>'+js.map(j=>`<option value="${j.id}">${j.name}</option>`).join('');
  const _jf=document.getElementById('filterJobType'), _jfv=_jf.value;
  _jf.innerHTML='<option value="">All job types</option>'+js.slice().sort((a,b)=>(a.name||'').localeCompare(b.name||'')).map(j=>`<option value="${j.id}">${j.name}</option>`).join('');
  _jf.value=_jfv;
}

// ── Modal ──
function openNew(){
  editId=null;
  window._pickedPlace=null;
  document.getElementById('modalTitle').textContent='New Appointment';
  clearPickedCust(); // clears hidden #fCustomer + tag + visible search input
  ['fTech','fJobType','fLocation','fUnitSuite','fNotes'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('fDuration').value='60';
  document.getElementById('fDate').value=localDateStr();
  document.getElementById('fDate').min=localDateStr();
  document.getElementById('fTime').value='09:00';
  document.getElementById('cancelApptBtn').style.display='none';
  {var _pb=document.getElementById('pinBtn'); if(_pb) _pb.style.display='none';}
  // Slice E1 — reset and hide the "in the area" panel until a customer is picked.
  if(window.cbpInTheArea) window.cbpInTheArea.hide();
  showModal('modal');
}

// Slice E1 — fetch the picked customer's geocode, then show the panel.
// Falls back silently if the customer has no geocode or the API rejects.
async function cbpRefreshInTheArea(){
  if(!window.cbpInTheArea) return;
  const custId = document.getElementById('fCustomer').value;
  if(!custId){ window.cbpInTheArea.hide(); return; }
  try {
    const c = await api('/customers/' + custId + '/');
    if(c && c.latitude != null && c.longitude != null){
      window.cbpInTheArea.show({lat: c.latitude, lng: c.longitude, dateWindowDays: 7});
    } else {
      window.cbpInTheArea.hide();
    }
  } catch(e){
    // Non-fatal: just hide the panel on failure.
    window.cbpInTheArea.hide();
  }
}
async function openEdit(id){
  editId=id;
  window._pickedPlace=null;
  const a=await api('/scheduling/appointments/'+id+'/');
  document.getElementById('modalTitle').textContent='Edit Appointment';
  // Customer: render as a chip; fetch full record for nice display, fall back to list-serializer name
  clearPickedCust();
  if(a.customer){
    document.getElementById('fCustomer').value=a.customer;
    try {
      const c = await api('/customers/'+a.customer+'/');
      showTag('fCustTag','fCustWrap', c, "clearPickedCust()");
    } catch(e) {
      showTag('fCustTag','fCustWrap', {full_name: a.customer_name || 'Selected customer', phone: ''}, "clearPickedCust()");
    }
  }
  document.getElementById('fTech').value=a.technician||'';
  document.getElementById('fJobType').value=a.job_type||'';
  document.getElementById('fDuration').value=a.duration_minutes||60;
  document.getElementById('fLocation').value=a.location||'';
  document.getElementById('fUnitSuite').value=a.unit_suite||'';
  document.getElementById('fNotes').value=a.notes||'';
  if(a.start_datetime){const d=new Date(a.start_datetime);document.getElementById('fDate').value=localDateStr(d);document.getElementById('fTime').value=d.toTimeString().slice(0,5);}
  // Show cancel button only if not already cancelled
  const cb=document.getElementById('cancelApptBtn');
  cb.style.display=(a.status&&a.status!=='cancelled')?'inline-flex':'none';
  // Company-admin "Pin time · no notify" — only on a live (non-cancelled) appt.
  const pb=document.getElementById('pinBtn');
  if(pb) pb.style.display=(a.status&&a.status!=='cancelled')?'inline-flex':'none';
  // Net-Invoice only: show the Create Invoice action.
  window._apptPrice=a.price||'';
  const isNet=['net_15','net_30'].includes(a.effective_payment_mode);
  const ib=document.getElementById('createInvBtn');
  ib.style.display=isNet?'inline-flex':'none';
  const ir=document.getElementById('invoiceResult');ir.style.display='none';ir.innerHTML='';
  showModal('modal');
  // Slice E1 — refresh "in the area" panel for the editing customer.
  cbpRefreshInTheArea();
}
async function cancelAppointment(){
  if(!editId) return;
  // Required structured cancellation reason (picklist) — replaces the old
  // silent {cancelled_by:'admin'} default so cancels are learnable.
  const _reason = await cbpCancelReason({title:'Cancel this appointment?'});
  if(!_reason) return;
  try{
    await api('/scheduling/appointments/'+editId+'/cancel/','POST',{reason:_reason,notify_customer:{channel:'none'}});
    hideModal('modal');
    toast('Appointment cancelled','ok');
    loadData();
  }catch(err){
    showApiError(err);
  }
}
// Company-admin: pin this appointment to the Date/Time shown above, lock it
// against the optimizers, and do NOT notify the customer. Uses the dedicated
// /pin/ endpoint (sets _suppress_notifications server-side) rather than the
// normal Save (PATCH), which WOULD fire a reschedule email/SMS.
async function pinDateTime(){
  if(!editId) return;
  const dStr=document.getElementById('fDate').value, tStr=document.getElementById('fTime').value;
  if(!dStr||!tStr){toast('Please select a date and time','error');return;}
  const dur=parseInt(document.getElementById('fDuration').value)||60;
  const body={date:dStr, time:tStr, duration_min:dur};
  const confirmFn = window.cbpConfirm || (m=>Promise.resolve(window.confirm(m)));
  const pretty=(()=>{try{return new Date(dStr+'T'+tStr).toLocaleString([],{weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});}catch(e){return dStr+' '+tStr;}})();
  if(!await confirmFn('Pin this appointment to '+pretty+' and lock it so optimizers won’t move it?\n\nThe customer will NOT be notified.')) return;
  const btn=document.getElementById('pinBtn');
  for(let attempt=0; attempt<2; attempt++){
    try{
      if(btn){btn.disabled=true;btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> Pinning…';}
      await api('/scheduling/appointments/'+editId+'/pin/','POST',body);
      hideModal('modal');
      toast('Pinned to '+pretty+' · locked · customer not notified','ok');
      loadData();
      return;
    }catch(err){
      const d=err&&err.data;
      if(err&&err.status===409&&d&&d.override_available){
        if(!await confirmFn('The assigned technician already has an overlapping appointment in that window.\n\nPin it anyway (double-book)?')){ return; }
        body.override=true; continue;
      }
      showApiError(err,'modal');
      return;
    }finally{
      if(btn){btn.disabled=false;btn.innerHTML='<i class="fas fa-thumbtack"></i> Pin time · no notify';}
    }
  }
}
async function createSquareInvoice(){
  if(!editId) return;
  const def=window._apptPrice||'';
  const raw=prompt('Treatment price (before tax)?', def);
  if(raw===null) return;
  const price=parseFloat(raw);
  if(!(price>0)){toast('Enter a valid price','error');return;}
  const btn=document.getElementById('createInvBtn');
  const ir=document.getElementById('invoiceResult');
  btn.disabled=true;btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> Creating…';
  try{
    const r=await api('/scheduling/appointments/'+editId+'/create-invoice/','POST',{price:price});
    ir.style.display='block';
    ir.innerHTML=`<div style="font-weight:600;color:#2e7d32;margin-bottom:6px"><i class="fas fa-check-circle"></i> Invoice ${r.invoice_number||''} created & emailed — $${r.total} (incl. $${r.tax_amount} tax @ ${r.tax_rate}%), due ${r.due_date}</div>`+
      `<a href="${r.pdf_url}" class="btn btn-sm btn-primary" download style="margin-right:6px"><i class="fas fa-file-pdf"></i> Download PDF</a>`+
      (r.public_url?`<a href="${r.public_url}" target="_blank" rel="noopener" class="btn btn-sm btn-outline"><i class="fas fa-external-link-alt"></i> View on Square</a>`:'');
    toast('Invoice created','ok');
    btn.style.display='none';
  }catch(err){
    // 409 already-invoiced: surface the existing invoice links.
    const d=err&&err.data?err.data:{};
    if(d.error==='already_invoiced'){
      ir.style.display='block';
      ir.innerHTML=`<div style="color:#e65100;margin-bottom:6px"><i class="fas fa-info-circle"></i> This appointment is already invoiced.</div>`+
        `<a href="${d.pdf_url}" class="btn btn-sm btn-primary" download style="margin-right:6px"><i class="fas fa-file-pdf"></i> Download PDF</a>`+
        (d.public_url?`<a href="${d.public_url}" target="_blank" rel="noopener" class="btn btn-sm btn-outline"><i class="fas fa-external-link-alt"></i> View on Square</a>`:'');
    }else{
      showApiError(err);
    }
  }finally{
    btn.disabled=false;btn.innerHTML='<i class="fas fa-file-invoice-dollar"></i> Create Invoice';
  }
}
async function save(){
  const dStr=document.getElementById('fDate').value, tStr=document.getElementById('fTime').value;
  if(!dStr||!tStr){toast('Please select a date and time','error');return;}
  const dur=parseInt(document.getElementById('fDuration').value)||60;
  const dt=dStr+'T'+tStr+':00';
  // §16.1: route the naive local string through localToUTC so the office's
  // IANA tz is the authoritative interpretation, not the browser's. Without
  // this, a CSR viewing on a laptop in a different tz than the office stamps
  // appointments at the wrong wall-clock hour. Both start and end are derived
  // from a single UTC moment so duration stays consistent across DST.
  const startIso=window.localToUTC(dt, window._tenantTz);
  const endIso=new Date(new Date(startIso).getTime()+dur*60000).toISOString();
  const cust=document.getElementById('fCustomer').value;
  if(!cust){toast('Please select a customer','error');return;}
  const body={
    customer: cust,
    technician: document.getElementById('fTech').value || null,
    job_type: document.getElementById('fJobType').value || null,
    start_datetime: startIso,
    end_datetime: endIso,
    duration_minutes: dur,
    location: document.getElementById('fLocation').value,
    unit_suite: document.getElementById('fUnitSuite').value,
    notes: document.getElementById('fNotes').value
  };
  // If the user picked an address through Google Places, capture the Place ID
  // and lat/lng. We don't overwrite existing lat/lng when nothing was picked,
  // so unchanged-location edits don't clobber a previously geocoded record.
  if(window._pickedPlace){
    body.place_id = window._pickedPlace.place_id || '';
    if(window._pickedPlace.lat != null) body.latitude = window._pickedPlace.lat;
    if(window._pickedPlace.lng != null) body.longitude = window._pickedPlace.lng;
  }
  function _submitAppt(){
    if(editId) return api('/scheduling/appointments/'+editId+'/','PATCH',body);
    return api('/scheduling/appointments/','POST',body);
  }
  const confirmFn = window.cbpConfirm || (m=>Promise.resolve(window.confirm(m)));
  // Submit, and resolve operator-overridable blocks by confirming once and
  // re-submitting with the matching override flag. Bounded loop so a create
  // that trips more than one guard (e.g. exact-time window THEN a conflict)
  // is handled in sequence. Each override requires csr.appointments.override
  // on the server, signalled back via override_available.
  let forced=false;
  for(let attempt=0; attempt<4; attempt++){
    try{
      await _submitAppt();
      hideModal('modal');
      toast((editId?'Appointment updated':'Appointment created')+(forced?' (forced)':''),'ok');
      loadData();
      return;
    }catch(err){
      const d = err && err.data;
      // Conflict: tech double-booked (hard) or off/after-hours (soft).
      if(err && err.status===409 && d && d.override_available){
        const why = d.conflict_type==='hard'
          ? 'This technician already has an overlapping appointment during this window.'
          : 'This technician is off or outside their working hours during this window.';
        if(!await confirmFn(why+'\n\nForce-create the appointment anyway?')) return;
        body.override_conflicts=true; forced=true; continue;
      }
      // 2-hour arrival-window policy: this job type is normally booked with a
      // window, not an exact time. Admins may override to book the exact time.
      if(err && err.status===400 && d && d.code==='arrival_window_required' && d.override_available){
        if(!await confirmFn('This job type is normally booked with a 2-hour arrival window.\n\nBook it at the exact time you selected anyway?')) return;
        body.override_arrival_window=true; forced=true; continue;
      }
      showApiError(err, 'modal');
      return;
    }
  }
}
// ── Customer autocomplete (search-autofill) — ports the /calendar/ initAC
// pattern. Picked customer's UUID goes to the hidden #fCustomer input so
// the existing save() and cbpRefreshInTheArea() reads still work.
function initAC(iid,did,onPick){
  const inp=document.getElementById(iid),dd=document.getElementById(did);let t;
  if(!inp||!dd) return;
  inp.addEventListener('input',()=>{
    clearTimeout(t);
    const q=inp.value.trim();
    if(q.length<2){dd.classList.remove('show');return}
    t=setTimeout(async()=>{
      try {
        const d=await api(`/customer-search/?q=${encodeURIComponent(q)}`);
        if(!d.length){dd.innerHTML='<div class="it" style="color:#999">No results</div>';dd.classList.add('show');return}
        dd.innerHTML=d.map(c=>`<div class="it" data-j='${JSON.stringify(c).replace(/'/g,"&#39;")}'><div class="n">${escHTML(c.full_name)} <span style="color:#aaa;font-weight:400">${escHTML(c.phone||'')}</span>${c.customer_type==='commercial'?' <span style="font-size:10px;background:#e3f2fd;color:#1565c0;padding:0 5px;border-radius:3px">Commercial</span>':''}</div><div class="m">${escHTML(c.service_address||'')}${c.service_address_2?' #'+escHTML(c.service_address_2):''}${c.service_city?', '+escHTML(c.service_city):''}</div></div>`).join('');
        dd.classList.add('show');
        dd.querySelectorAll('.it[data-j]').forEach(el=>{el.onclick=()=>{onPick(JSON.parse(el.dataset.j));dd.classList.remove('show');inp.value=''}});
      } catch(e){
        dd.innerHTML='<div class="it" style="color:#c62828">Search failed</div>';dd.classList.add('show');
      }
    },200);
  });
  inp.addEventListener('blur',()=>setTimeout(()=>dd.classList.remove('show'),200));
}
function showTag(tid,wid,c,clr){
  const pref = c && c.preferred_technician ? ' <span style="font-size:10px;color:var(--accent);font-weight:700">★ '+escHTML(c.preferred_technician.name)+'</span>' : '';
  const ph = c && c.phone ? ' — '+escHTML(c.phone) : '';
  document.getElementById(tid).innerHTML='<span class="ct">'+escHTML(c.full_name||'')+ph+pref+' <span class="x" onclick="'+clr+'">&times;</span></span>';
  document.getElementById(tid).style.display='block';
  document.getElementById(wid).style.display='none';
}
function clearPickedCust(){
  document.getElementById('fCustomer').value='';
  const tag=document.getElementById('fCustTag'); if(tag){tag.style.display='none';tag.innerHTML='';}
  const wrap=document.getElementById('fCustWrap'); if(wrap){wrap.style.display='block';}
  const inp=document.getElementById('fCust'); if(inp) inp.value='';
  if(window.cbpInTheArea) window.cbpInTheArea.hide();
}
// ── Google Places autocomplete on the Location input. Mirrors
// scheduling/calendar.html's gmAC() but additionally captures place_id
// and geometry (lat/lng) so we can persist them on the Appointment.
function apptLocAC(id){
  const el=document.getElementById(id);
  if(!el) return;
  if(typeof google==='undefined'||!google.maps||!google.maps.importLibrary){
    // Maps JS still loading — retry once on window load
    window.addEventListener('load',()=>setTimeout(()=>apptLocAC(id),500),{once:true});
    return;
  }
  google.maps.importLibrary('places').then(({Autocomplete})=>{
    const ac=new Autocomplete(el,{componentRestrictions:{country:'us'},fields:['formatted_address','place_id','geometry'],types:['address']});
    ac.addListener('place_changed',()=>{
      const p=ac.getPlace();
      if(p.formatted_address) el.value=p.formatted_address;
      window._pickedPlace = {
        place_id: p.place_id || '',
        lat: (p.geometry && p.geometry.location) ? p.geometry.location.lat() : null,
        lng: (p.geometry && p.geometry.location) ? p.geometry.location.lng() : null,
      };
    });
  });
}

// BUG-cb81031d: On SPA navigation the DCL shim fires async handlers via
// setTimeout(fn,0)/try-catch — sync-only, so async rejections after the
// first await (e.g. AbortError from fetch interception) escape unhandled.
// _initializing stays true, loadData() is never called, table stays empty.
// Fix: named initPage() with try/finally (guarantees _initializing resets)
// called directly so SPA nav bypasses the shim path entirely (BUG-042 pattern).
let _pageLoaded=false;
async function initPage(){
  if(_pageLoaded) return;
  _pageLoaded=true;
  _initializing=true;
  try{
    await loadDropdowns(); // populate selects before first data fetch
  }finally{
    _initializing=false;
  }
  loadData(); // single fetch — onchange during dropdown population is now suppressed
  // Wire the customer search-autofill (replaces the old <select> with /customer-search/ debounced lookups).
  // On pick we (1) write the UUID to hidden #fCustomer, (2) show the chip, (3) autofill location/unit
  // from the customer record if those modal fields are empty, (4) refresh the Slice-E1 nearby panel.
  initAC('fCust','fCustDD', c => {
    document.getElementById('fCustomer').value = c.id;
    showTag('fCustTag','fCustWrap', c, "clearPickedCust()");
    const locEl  = document.getElementById('fLocation');
    const usEl   = document.getElementById('fUnitSuite');
    if(locEl && !locEl.value) locEl.value = c.full_address || c.service_address || '';
    if(usEl  && !usEl.value  && c.service_address_2) usEl.value = c.service_address_2;
    cbpRefreshInTheArea();
  });
  // Wire Google Places autocomplete on the Location input.
  apptLocAC('fLocation');
  if(window.cbpInTheArea){
    window.cbpInTheArea.onAddStop = function(item){
      // Drop the address into the location field as a hint; the CSR
      // can then pick the matching customer to actually link the row.
      // The host page intentionally doesn't auto-create a sibling
      // appointment — that requires a separate flow (out of scope for E1).
      if(item && item.address){
        const noteEl = document.getElementById('fNotes');
        if(noteEl){
          const tag = item._kind === 'recurring'
            ? 'Recurring stop nearby: '
            : 'Overdue customer nearby: ';
          const line = tag + (item.customer_name || '') + ' — ' + item.address;
          noteEl.value = (noteEl.value ? noteEl.value + '\n' : '') + line;
        }
        toast('Added "' + (item.customer_name || 'stop') + '" to notes', 'ok');
      }
    };
  }
}
document.addEventListener('DOMContentLoaded', initPage);
initPage(); // BUG-042 pattern: direct call for SPA nav (DOM already ready after swap)

// ── Discard-confirm guard for create/edit modals ─────────────────────
// Tracks 'dirty' by listening for any input/change inside the modal.
// Exposes el._cbpIsDirty()/el._cbpResetDirty() so base.html's
// closeModalEl() can prompt before closing on backdrop click or ESC.
// X/Cancel buttons close immediately (call hideModal directly) — by design,
// since those are intentional clicks. Reset dirty whenever the modal
// transitions from hidden to visible (new openNew/openEdit invocation).
(function(){
  const MODAL_IDS = ['modal'];
  MODAL_IDS.forEach(function(id){
    const el = document.getElementById(id);
    if (!el) return;
    let dirty = false;
    const mark = function(){ dirty = true; };
    el.addEventListener('input',  mark);
    el.addEventListener('change', mark);
    // Reset dirty when the modal becomes visible (class .show or .open added)
    new MutationObserver(function(muts){
      muts.forEach(function(m){
        if (m.attributeName !== 'class') return;
        const oldCls = (m.oldValue || '').split(/\s+/);
        const wasHidden = !oldCls.includes('show') && !oldCls.includes('open');
        const isShown  = el.classList.contains('show') || el.classList.contains('open');
        if (wasHidden && isShown) dirty = false;
      });
    }).observe(el, { attributes: true, attributeFilter: ['class'], attributeOldValue: true });
    el.dataset.discardConfirm = '1';
    el._cbpIsDirty    = function(){ return dirty; };
    el._cbpResetDirty = function(){ dirty = false; };
  });
})();