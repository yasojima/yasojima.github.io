(() => {
  const {api,$,escape,choices,setChoices,textInput,selectInput,notesInput,cell,button,sorted,status,form,filters}=OfficeUI;
  const formFilter=$("#expense-filters"), money=cents=>"A$"+(cents/100).toLocaleString("ja-JP",{minimumFractionDigits:2,maximumFractionDigits:2});
  const carName=v=>v.id+" · "+v.model+" · "+v.plate;
  const cars=()=>new Map((api.state.cars||[]).map(v=>[v.key,v]));
  const carChoices=()=>[...cars()].map(([key,car])=>[String(key),carName(car)]);
  function totals(selector, rows, key, label) {
    const groups=new Map();
    for(const row of rows){const k=row[key];groups.set(k,(groups.get(k)||0)+row.cents);}
    $(selector).innerHTML=groups.size?[...groups].sort((a,b)=>b[1]-a[1]||label(a[0]).localeCompare(label(b[0]),"ja")).map(([k,sum])=>
      '<div><dt>'+escape(label(k))+'</dt><dd>'+money(sum)+'</dd></div>').join(""):'<div class="muted"><dt>明細なし</dt><dd>—</dd></div>';
  }
  let first=true;
  function render(){
    const {records,categories,statuses,error}=api.state, fleet=cars(), fields=formFilter.elements;
    setChoices(fields.team,sorted(records.map(r=>r.team)),"すべての班");
    setChoices(fields.vehicle,carChoices(),"すべての車両");
    setChoices(fields.category,categories,"すべての費目");setChoices(fields.status,statuses,"すべての状況");
    if(first && api.state.vehicle)fields.vehicle.value=String(api.state.vehicle);
    first=false;$("#expense-new").disabled=!!error;
    if(error)status(error);
    const f=Object.fromEntries(new FormData(formFilter));
    const rows=records.filter(r=>(!f.team||r.team===f.team)&&(!f.vehicle||r.vehicle===Number(f.vehicle))&&
      (!f.category||r.category===f.category)&&(!f.status||r.status===f.status)&&(!f.from||r.date>=f.from)&&(!f.to||r.date<=f.to))
      .sort((a,b)=>b.date.localeCompare(a.date)||a.team.localeCompare(b.team,"ja"));
    $("#expense-total").textContent=money(rows.reduce((sum,r)=>sum+r.cents,0));
    $("#expense-count").textContent=rows.length+"件";
    totals("#expense-teams",rows,"team",key=>key);
    const vehicleLabel=k=>fleet.has(k)?carName(fleet.get(k)):"車両ID "+k;
    totals("#expense-cars",rows,"vehicle",vehicleLabel);
    $("#expense-rows").innerHTML=rows.map(r=>{
      const vehicle=escape(vehicleLabel(r.vehicle));
      const car=api.canOpenFleet?'<a href="/maintenance/?vehicle='+r.vehicle+'">'+vehicle+'</a>':vehicle;
      return "<tr>"+cell("支払日",escape(r.date))+cell("班",escape(r.team))+cell("車両",car)+
        cell("費目・内容",escape(r.category)+'<small>'+escape(r.description||r.vendor)+'</small>')+cell("記録者",escape(r.person))+
        cell("金額",money(r.cents))+cell("対応状況",escape(r.status))+cell("明細",button("詳細","data-expense",r.id))+"</tr>";
    }).join("");
    $("#expense-empty").hidden=rows.length>0;
  }
  function edit(row) {
    const s=api.state, f=formFilter.elements;
    const fields=textInput("支払日","date",row?.date||s.today,'type="date" required')+
      selectInput("費目","category",choices(s.categories,row?.category||"ガソリン代"))+
      textInput("金額（AUD）","amount",row?(row.cents/100).toFixed(2):"",'type="number" inputmode="decimal" min="0.01" max="9999999999.99" step="0.01" required')+
      textInput("班","team",row?.team||f.team.value,'maxlength="70" list="existing-teams" placeholder="例：A班" required')+
      '<datalist id="existing-teams">'+choices(sorted(s.records.map(r=>r.team)))+'</datalist>'+
      selectInput("車両","vehicle",choices(carChoices(),row?.vehicle||f.vehicle.value,"車両を選択"))+
      textInput("支払先","vendor",row?.vendor,'maxlength="120"')+
      textInput("内容","description",row?.description,'maxlength="180"')+
      (s.admin?selectInput("対応状況","status",choices(s.statuses,row?.status||s.statuses[0])):"")+notesInput(row?.notes);
    form(row?"経費明細を編集":"経費を記録",fields,"保存",draft=>api.save({...draft,id:row?.id,revision:row?.revision}));
  }
  function details(id) {
    const row=api.state.records.find(r=>r.id===id);
    if(!row)return;
    const car=cars().get(row.vehicle);
    const data=[["支払日",row.date],["費目",row.category],["金額",money(row.cents)],["班",row.team],["車両",car?carName(car):row.vehicle],
      ["支払先",row.vendor],["内容",row.description],["記録者",row.person],["対応状況",row.status],["メモ",row.notes]];
    const editButton=api.state.admin||row.status==="確認待ち"?'<div class="office-actions"><button type="button" class="primary" id="expense-edit">編集</button></div>':"";
    OfficeUI.open("経費の詳細",'<dl class="office-fields">'+data.map(([k,v])=>'<div><dt class="muted">'+escape(k)+'</dt><dd>'+escape(v||"—")+'</dd></div>').join("")+'</dl>'+editButton);
    $("#expense-edit")?.addEventListener("click",()=>edit(row));
  }
  $("#expense-new").addEventListener("click",()=>edit(null));
  $("#expense-rows").addEventListener("click",e=>{const b=e.target.closest("[data-expense]");if(b)details(b.dataset.expense);});
  filters(formFilter,render);document.addEventListener("office-updated",render);render();
})();