const API='/api/v1';const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(m)=>{const h={'X-CSRFToken':csrf()};if(m!=='GET')h['Content-Type']='application/json';return h;};
async function api(u,m='GET',b=null){const o={method:m,credentials:'same-origin',headers:hdr(m)};if(b)o.body=JSON.stringify(b);const r=await fetch(API+u,o);if(r.status===204)return null;return r.json();}
function toast(msg,kind){
  let e=document.getElementById('_apiToast');
  if(!e){e=document.createElement('div');e.id='_apiToast';e.style.cssText='position:fixed;top:20px;right:20px;padding:10px 16px;border-radius:6px;color:#fff;z-index:99999;font-size:13px;font-weight:500;box-shadow:0 4px 12px rgba(0,0,0,.15);max-width:380px;display:none';document.body.appendChild(e);}
  e.style.background=kind==='error'?'#e53935':'#43a047';
  e.textContent=msg;e.style.display='block';
  clearTimeout(e._t);e._t=setTimeout(()=>{e.style.display='none'},3000);
}
function _parseErr(d){ return cbpFormatApiError(d, 'Save failed'); }

function fmtDate(s){if(!s)return'—';return new Date(s+'T00:00:00').toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
function showModal(id){document.getElementById(id).classList.add('show');}
function hideModal(id){document.getElementById(id).classList.remove('show');}
const TYPE_CFG={maintenance:{color:'#4CAF50',icon:'fa-sync-alt'},one_time:{color:'#2196F3',icon:'fa-clipboard-check'},cc_auth:{color:'#FF9800',icon:'fa-credit-card'}};
const STAT_BADGE={draft:'gray',sent:'blue',signed:'purple',active:'green',expiring:'orange',expired:'red',renewed:'green',cancelled:'gray'};
let editId=null;

function toggleCustomPeriod(pfx){
  const val=document.getElementById(pfx+'Freq').value;
  const row=document.getElementById(pfx+'CustomPeriodRow');
  if(row) row.style.display=val==='custom'?'block':'none';
}
function getFreqValue(pfx){
  const freq=document.getElementById(pfx+'Freq').value;
  if(freq!=='custom') return {billing_frequency:freq,billing_interval:1,billing_unit:'months'};
  return {
    billing_frequency:'custom',
    billing_interval:parseInt(document.getElementById(pfx+'Interval').value)||1,
    billing_unit:document.getElementById(pfx+'Unit').value||'months',
  };
}
function setFreqValue(pfx,freq,interval,unit){
  const sel=document.getElementById(pfx+'Freq');
  if(sel) sel.value=freq||'one_time';
  const row=document.getElementById(pfx+'CustomPeriodRow');
  if(row) row.style.display=freq==='custom'?'block':'none';
  const intEl=document.getElementById(pfx+'Interval');
  if(intEl) intEl.value=interval||1;
  const unitEl=document.getElementById(pfx+'Unit');
  if(unitEl) unitEl.value=unit||'months';
}
async function loadKPIs(){
  try{const d=await api('/contracts/stats/');
  document.getElementById('kpiStrip').innerHTML=`
    <div class="kpi"><div class="lbl">Total</div><div class="val">${d.total}</div></div>
    <div class="kpi" title="Active + signed contracts (in force, generating revenue)"><div class="lbl">Active &amp; Signed</div><div class="val" style="color:#2e7d32">${d.active}</div></div>
    <div class="kpi" title="Annualized recurring value of the active maintenance book (per-site fee x visits/year)"><div class="lbl">Active TCV</div><div class="val">$${(d.active_value||d.total_value||0).toLocaleString()}</div></div>
    <div class="kpi" title="Commercial slice of the active maintenance book (annualized recurring revenue)"><div class="lbl">Commercial Active TCV</div><div class="val">$${Math.round(d.commercial_value||0).toLocaleString()}</div></div>
    <div class="kpi" title="Residential recurring maintenance sites (annualized value)"><div class="lbl">Residential Total</div><div class="val">${d.residential_count||0} <span style="font-size:11px;color:var(--text-light);font-weight:500">($${Math.round(d.residential_value||0).toLocaleString()})</span></div></div>
    <div class="kpi" title="Commercial recurring maintenance sites (annualized value)"><div class="lbl">Commercial Total</div><div class="val">${d.commercial_count||0} <span style="font-size:11px;color:var(--text-light);font-weight:500">($${Math.round(d.commercial_value||0).toLocaleString()})</span></div></div>
    <div class="kpi" title="Drafts + sent contracts (not yet signed) and their potential value"><div class="lbl">Pipeline</div><div class="val">${d.pipeline||0} <span style="font-size:11px;color:var(--text-light);font-weight:500">($${(d.pipeline_value||0).toLocaleString()})</span></div></div>
    <div class="kpi" title="Active maintenance contracts for customers in /maintenance/, one per site"><div class="lbl">Maintenance</div><div class="val">${d.maintenance!=null?d.maintenance:(d.by_type.maintenance||0)}</div></div>
    <div class="kpi"><div class="lbl">One-Time</div><div class="val">${d.by_type.one_time||0}</div></div>
    <div class="kpi"><div class="lbl">CC Auth</div><div class="val">${d.by_type.cc_auth||0}</div></div>`;
  }catch(e){}
}

async function loadData(){
  const tb=document.getElementById('tableBody');
  try{
  let url='/contracts/contracts/?ordering=-created_at';
  const s=document.getElementById('search').value,t=document.getElementById('filterType').value,st=document.getElementById('filterStatus').value;
  if(s) url+='&search='+encodeURIComponent(s);
  if(t) url+='&contract_type='+t;
  if(st) url+='&status='+st;
  const d=await api(url);const items=d.results||d;
  if(!items.length){tb.innerHTML='<tr><td colspan="11"><div class="empty-state"><i class="fas fa-file-contract"></i><p>No contracts found</p></div></td></tr>';loadKPIs();return;}
  tb.innerHTML=items.map(c=>{
    const tc=TYPE_CFG[c.contract_type]||{color:'#607D8B',icon:'fa-file'};
    const typeLabel=TYPE_CFG[c.contract_type]?(c.type_display||(c.contract_type||'').replace(/_/g,' ')||'—'):'—';
    // F1.E — Auto-pay badge for operator visibility. Show only when
    // the contract is flagged auto_pay; ✅ when a card is on file
    // (payment_method linked), ⚠️ when it's not.
    const autoPayBadge = c.auto_pay
      ? (c.payment_method
          ? '<span title="Auto-pay: card on file" style="margin-left:6px;color:#2E7D32;font-size:11px;white-space:nowrap">⚡ Card</span>'
          : '<span title="Auto-pay enabled but no card on file" style="margin-left:6px;color:#C62828;font-size:11px;white-space:nowrap">⚡ No card</span>')
      : '';
    return `<tr class="clickable" tabindex="0" role="link" onkeydown="if(event.key==='Enter'||event.key===' '){this.click();event.preventDefault()}" onclick="openContract('${c.id}','${c.status}')"><td><strong>${escHTML(c.contract_number)||'Draft'}</strong></td><td><span class="type-icon" style="background:${tc.color}"><i class="fas ${tc.icon}"></i></span>${typeLabel}</td><td>${escHTML(c.customer_name)||'—'}</td><td title="${escHTML(c.title)}">${escHTML(c.title)}</td><td>${c.initial_treatment_fee&&parseFloat(c.initial_treatment_fee)>0?'$'+parseFloat(c.initial_treatment_fee).toFixed(2):'—'}</td><td>$${parseFloat(c.recurring_fee||c.amount||0).toFixed(2)}</td><td>${c.tax_rate&&parseFloat(c.tax_rate)>0?c.tax_rate+'%':'—'}</td><td>${c.billing_frequency==='custom'?((c.billing_interval||1)+' '+(c.billing_unit||'months')):(c.billing_frequency_display||(c.billing_frequency||'').replace(/_/g,' ').replace(/\b\w/g,l=>l.toUpperCase())||'')}</td><td>${fmtDate(c.start_date)}</td><td>${fmtDate(c.end_date)}</td><td><span class="badge badge-${STAT_BADGE[c.status]||'gray'}">${(c.status_display||c.status)}</span>${autoPayBadge}</td></tr>`;
  }).join('');
  loadKPIs();
  }catch(e){if(e&&e.name==='AbortError')return;tb.innerHTML='<tr><td colspan="11"><div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Could not load contracts.</p></div></td></tr>';}
}

let _ctSearchTimer=null;
function loadCustomers(){}
function searchContractCust(){clearTimeout(_ctSearchTimer);_ctSearchTimer=setTimeout(_doSearchContractCust,250);}
async function _doSearchContractCust(){
  const q=document.getElementById('fCustomerSearch').value.trim();
  const wrap=document.getElementById('custResults');
  document.getElementById('fCustomer').value='';
  if(q.length<2){wrap.innerHTML='';return;}
  let items=[];
  try{const d=await api('/customers/?search='+encodeURIComponent(q)+'&page_size=8');items=d.results||d||[];}catch(e){items=[];}
  wrap.innerHTML='';
  if(!items.length){wrap.innerHTML='<div style="padding:8px;color:var(--text-light)">No matching customer.</div>';return;}
  items.forEach(function(c){
    const full=((c.first_name||'')+' '+(c.last_name||'')).trim();
    const el=document.createElement('div');
    el.style.cssText='padding:6px 8px;cursor:pointer;border-bottom:1px solid var(--border)';
    const co=c.company_name?' <span style="color:var(--text-light)">('+escHTML(c.company_name)+')</span>':'';
    el.innerHTML=escHTML(full)+co+'<div style="color:var(--text-light)">'+escHTML(c.phone||c.email||'')+'</div>';
    el.addEventListener('mousedown',function(ev){ev.preventDefault();pickContractCust(c.id,full,c.company_name||'');});
    wrap.appendChild(el);
  });
}
function pickContractCust(id,name,company){
  document.getElementById('fCustomer').value=id;
  document.getElementById('fCustomerSearch').value=name+(company?' ('+company+')':'');
  document.getElementById('custResults').innerHTML='';
  loadContractLocations(id);
}
async function loadContractLocations(customerId, selectedId){
  const row=document.getElementById('fLocRow');
  const sel=document.getElementById('fServiceLoc');
  if(!row||!sel)return;
  sel.innerHTML='<option value="">All locations (customer-level contract)</option>';
  if(!customerId){row.style.display='none';return;}
  try{
    const r=await fetch('/api/v1/service-locations/?customer='+customerId+'&is_active=true&page_size=200',{credentials:'same-origin'});
    const d=await r.json();
    const items=d.results||d;
    if(!items.length){row.style.display='none';return;}
    items.forEach(l=>{
      const o=document.createElement('option');
      o.value=l.id;
      o.textContent=l.location_name+(l.address?' — '+l.address:'');
      if(selectedId&&l.id===selectedId)o.selected=true;
      sel.appendChild(o);
    });
    row.style.display='grid';
  }catch(e){console.warn('Loc load failed',e);row.style.display='none';}
}
function openNew(){editId=null;document.getElementById('modalTitle').textContent='New Contract';['fTitle','fDesc','fNotes'].forEach(id=>document.getElementById(id).value='');document.getElementById('fType').value='maintenance';document.getElementById('fCustomer').value='';document.getElementById('fCustomerSearch').value='';document.getElementById('custResults').innerHTML='';if(document.getElementById('fLocRow')){document.getElementById('fLocRow').style.display='none';document.getElementById('fServiceLoc').value='';}setFreqValue('f','monthly',1,'months');document.getElementById('fAmount').value='0';document.getElementById('fRecurring').value='0';document.getElementById('fInitialFee').value='0';document.getElementById('fTaxRate').value='0';try{document.getElementById('taxSummary').style.display='none'}catch(e){};document.getElementById('fVisits').value='0';document.getElementById('fAutoRenew').value='true';document.getElementById('fAutoPay').checked=false;document.getElementById('fStart').value=localDateStr();document.getElementById('fEnd').value='';document.getElementById('fTemplate').value='';loadTemplateOptions();const sb=document.getElementById('sendContractBtn');if(sb)sb.style.display='none';const cb=document.getElementById('cancelContractBtn');if(cb)cb.style.display='none';cbpAttachClearOnInput(document.getElementById('modal'));showModal('modal');}
function openContract(id, status){
  if(status==='signed'||status==='active') openView(id);
  else openEdit(id);
}
async function openView(id){
  viewId=id;
  document.getElementById('viewModalTitle').textContent='Loading...';
  document.getElementById('viewModalBody').innerHTML='<div style="text-align:center;padding:30px;color:var(--text-light)"><i class="fas fa-spinner fa-spin"></i></div>';
  showModal('viewModal');
  const c=await api('/contracts/contracts/'+id+'/');
  document.getElementById('viewModalTitle').textContent=c.contract_number+' — '+c.title;
  document.getElementById('dlPdfBtn').dataset.id=id;
  const ff=c.form_field_values||{};
  const ffHtml=Object.keys(ff).filter(k=>k!=='cvv_provided'&&ff[k]).length>0
    ?'<div class="vc-section"><div class="vc-label">Filled Information</div><table style="width:100%;font-size:13px;border-collapse:collapse">'
      +Object.entries(ff).filter(([k,v])=>k!=='cvv_provided'&&v).map(([k,v])=>
        `<tr><td style="padding:3px 8px;font-weight:600;color:#555;white-space:nowrap">${escHTML(k.replace(/_/g,' ').replace(/\b\w/g,l=>l.toUpperCase()))}</td><td style="padding:3px 8px">${escHTML(String(v))}</td></tr>`
      ).join('')+'</table></div>' :'';
  const sigHtml=c.customer_signature
    ?`<div class="vc-section"><div class="vc-label">Signature</div><div class="vc-sig"><img src="${c.customer_signature}" onerror="this.replaceWith(Object.assign(document.createElement('em'),{textContent:'(signature image unavailable)',style:'color:#999'}))" style="max-width:300px;display:block"><br><small>${c.customer_signed_at?new Date(c.customer_signed_at).toLocaleString():''}</small></div></div>`:'' ;
  // Signing certificate
  let certHtml='';
  try{
    const esignResp=await fetch(API+'/contracts/contracts/'+id+'/esign_info/',{credentials:'same-origin'});
    if(esignResp.ok){
      const ei=await esignResp.json();
      if(ei&&ei.signing_certificate){
        const sc=ei.signing_certificate;
        const geo=sc.geolocation||{};
        const loc=[geo.city,geo.region].filter(Boolean).join(', ')||'Unknown';
        certHtml=`<div class="vc-section"><div class="vc-label">Signing Certificate</div>`
          +`<div class="cert-badge">`
          +`<strong>Signer:</strong> ${sc.signer_name||''} &lt;${sc.signer_email||''}&gt;<br>`
          +`<strong>Signed:</strong> ${(sc.timestamp_utc||'').slice(0,19).replace('T',' ')} UTC<br>`
          +`<strong>IP Address:</strong> ${sc.ip_address||''}<br>`
          +`<strong>Location:</strong> ${loc}<br>`
          +`<strong>Document ID:</strong> ${sc.contract_number||sc.contract_id||''}`
          +`</div></div>`;
      }
    }
  }catch(e){}
  // F1.E — Auto-pay status surfaced in the view-modal header.
  const apBadgeView = c.auto_pay
    ? (c.payment_method
        ? ' &nbsp;·&nbsp; <strong style="color:#2E7D32">Auto-pay: ✅ Card on file</strong>'
        : ' &nbsp;·&nbsp; <strong style="color:#C62828">Auto-pay: ⚠️ No card on file</strong>')
    : '';
  document.getElementById('viewModalBody').innerHTML=
    `<div style="font-size:13px;margin-bottom:16px"><strong>Customer:</strong> ${escHTML(c.customer_name)||'—'} &nbsp;·&nbsp; <strong>Status:</strong> ${c.status} &nbsp;·&nbsp; <strong>Signed:</strong> ${c.customer_signed_at?new Date(c.customer_signed_at).toLocaleDateString():'Not yet'}${apBadgeView}</div>`
    +ffHtml
    +`<div class="vc-section"><div class="vc-label">Contract Terms</div><div class="vc-body">${c.description?c.description.replace(/</g,'&lt;'):'<em style="color:#999">No additional terms.</em>'}</div></div>`
    +sigHtml
    +certHtml;
}
async function downloadPdf(){
  const id=document.getElementById('dlPdfBtn').dataset.id||viewId;
  if(!id)return;
  const a=document.createElement('a');a.href=API+'/contracts/contracts/'+id+'/pdf/';a.target='_blank';document.body.appendChild(a);a.click();document.body.removeChild(a);
}
let sendId=null,viewId=null;
function openSend(){sendId=editId;hideModal('modal');document.getElementById('sendResult').style.display='none';document.getElementById('copyBox').style.display='none';showModal('sendModal');}
async function loadSignLink(){
  if(!sendId)return;
  const r=await api('/contracts/contracts/'+sendId+'/send_for_signing/','POST',{channel:'link'});
  if(r&&r.sign_url){
    document.getElementById('copyLinkInput').value=r.sign_url;
    document.getElementById('copyBox').style.display='flex';
  }
}
function copyLink(){
  const inp=document.getElementById('copyLinkInput');
  inp.select();navigator.clipboard.writeText(inp.value).catch(()=>inp.select());
  const btn=document.querySelector('.copy-btn');const orig=btn.innerHTML;
  btn.innerHTML='<i class="fas fa-check"></i> Copied!';btn.style.background='#4CAF50';btn.style.color='#fff';
  setTimeout(()=>{btn.innerHTML=orig;btn.style.background='';btn.style.color='';},2000);
}
// One-click flow for the "Copy Link" option in the send modal: fetch a
// fresh signing URL if we don't already have one cached on this open,
// then copy it to the clipboard. The footer "Get Link" button + the
// inner #copyBox Copy button still work for the see-first-then-copy flow.
async function copyLinkFromOpt(){
  if(!sendId)return;
  const inp=document.getElementById('copyLinkInput');
  if(!inp.value){
    await loadSignLink();
  }
  if(inp.value){
    // copyLink() leaves the input selected on clipboard-API failure (e.g. Safari
    // losing user-activation across an await), so the user can still Ctrl+C.
    copyLink();
  }else{
    const res=document.getElementById('sendResult');
    res.innerHTML='<i class="fas fa-exclamation-circle"></i> Could not generate signing link — please try again or check the contract status.';
    res.style.background='#FFEBEE';res.style.color='#C62828';res.style.display='block';
  }
}
async function cancelContract(){
  if(!editId) return;
  if(!await cbpConfirm('Cancel this contract? This cannot be undone.')) return;
  const btn=document.getElementById('cancelContractBtn');
  await cbpSubmit(btn, async () => {
    const r=await fetch(`${API}/contracts/contracts/${editId}/`,{method:'PATCH',credentials:'same-origin',headers:hdr('PATCH'),body:JSON.stringify({status:'cancelled'})});
    let d=null;try{d=await r.json();}catch(_){}
    if(!r.ok){toast(_parseErr(d),'error');return;}
    hideModal('modal');toast('Contract cancelled');loadData();
  });
}
async function doSend(channel){
  if(!sendId)return;
  const opts=document.querySelectorAll('.send-opt');opts.forEach(o=>o.style.opacity='0.5');
  const r=await api('/contracts/contracts/'+sendId+'/send_for_signing/','POST',{channel});
  opts.forEach(o=>o.style.opacity='1');
  const res=document.getElementById('sendResult');
  if(r&&(r.sent_email||r.sent_sms||r.sign_url)){
    const msgs=[];
    if(r.sent_email)msgs.push('Email sent');
    if(r.sent_sms)msgs.push('SMS sent');
    if(!r.sent_email&&!r.sent_sms)msgs.push('Link generated');
    // Warn about any channel that was attempted but did NOT reach the customer
    // (e.g. SMS 'skipped' for no consent) so staff aren't misled by a blanket "sent".
    const warn=[];
    if(r.email_status&&r.email_status!=='sent')warn.push('Email not delivered'+(r.email_reason?' ('+r.email_reason+')':''));
    if(r.sms_status&&r.sms_status!=='sent')warn.push('SMS not delivered'+(r.sms_reason?' ('+r.sms_reason+')':''));
    let html='<i class="fas fa-check-circle"></i> '+msgs.join(' · ');
    if(warn.length)html+='<br><small style="color:#C62828">⚠ '+warn.join('; ')+'</small>';
    html+='<br><small style="opacity:.8">Signing link expires '+new Date(r.expires_at).toLocaleDateString()+'</small>';
    res.innerHTML=html;
    res.style.display='block';
    loadData();
  }else{
    res.innerHTML='<i class="fas fa-exclamation-circle"></i> '+(r&&r.error?r.error:'Send failed — check communications settings');
    res.style.background='#FFEBEE';res.style.color='#C62828';res.style.display='block';
  }
}
async function openEdit(id){editId=id;const c=await api('/contracts/contracts/'+id+'/');document.getElementById('modalTitle').textContent='Edit — '+c.contract_number;document.getElementById('fType').value=c.contract_type;document.getElementById('fCustomer').value=c.customer||'';document.getElementById('fCustomerSearch').value=c.customer_name||'';if(c.customer)loadContractLocations(c.customer, c.service_location);document.getElementById('fTitle').value=c.title||'';document.getElementById('fStart').value=c.start_date||'';document.getElementById('fEnd').value=c.end_date||'';setFreqValue('f',c.billing_frequency,c.billing_interval,c.billing_unit);document.getElementById('fAmount').value=c.amount||0;document.getElementById('fRecurring').value=c.recurring_fee||c.amount||0;document.getElementById('fInitialFee').value=c.initial_treatment_fee||0;document.getElementById('fTaxRate').value=c.tax_rate||0;try{calcTax()}catch(e){};document.getElementById('fVisits').value=c.visits_included||0;document.getElementById('fAutoRenew').value=c.auto_renew?'true':'false';document.getElementById('fAutoPay').checked=!!c.auto_pay;
// F1.E — show current card-on-file state next to the auto-pay checkbox.
const _apStatus=document.getElementById('fAutoPayStatus');
if(_apStatus){
  if(!c.auto_pay){_apStatus.textContent='';_apStatus.style.display='none';}
  else if(c.payment_method){_apStatus.innerHTML='<span style="color:#2E7D32">✅ Card on file</span>';_apStatus.style.display='inline';}
  else{_apStatus.innerHTML='<span style="color:#C62828">⚠️ No card on file yet</span>';_apStatus.style.display='inline';}
}
document.getElementById('fDesc').value=c.description||'';document.getElementById('fNotes').value=c.notes||'';const _sb=document.getElementById('sendContractBtn');if(_sb){const _ns=['signed','active','cancelled'];_sb.style.display=_ns.includes(c.status)?'none':'inline-flex';}const _cb=document.getElementById('cancelContractBtn');if(_cb){_cb.style.display=c.status&&c.status!=='cancelled'?'inline-flex':'none';}cbpAttachClearOnInput(document.getElementById('modal'));document.querySelectorAll('#modal .field-error').forEach(el=>el.remove());document.querySelectorAll('#modal .field-invalid').forEach(el=>el.classList.remove('field-invalid'));showModal('modal');}
function showContractErrors(errData){
  document.querySelectorAll('#modal .field-error').forEach(el=>el.remove());
  document.querySelectorAll('#modal .field-invalid').forEach(el=>el.classList.remove('field-invalid'));
  toast(cbpFormatApiError(errData,'Please fill in the required fields.'),'error');
  if(!errData||typeof errData!=='object')return;
  const fieldMap={customer:'fCustomer',title:'fTitle',contract_type:'fType',start_date:'fStart',end_date:'fEnd',recurring_fee:'fRecurring',initial_treatment_fee:'fInitialFee',tax_rate:'fTaxRate',description:'fDesc',notes:'fNotes'};
  Object.entries(errData).forEach(([k,v])=>{
    const elId=fieldMap[k]||('f'+k.charAt(0).toUpperCase()+k.slice(1).replace(/_(.)/g,(_,c)=>c.toUpperCase()));
    const el=document.getElementById(elId);
    if(!el)return;
    el.classList.add('field-invalid');
    const span=document.createElement('div');
    span.className='field-error';
    span.textContent=Array.isArray(v)?v[0]:String(v);
    el.parentNode.appendChild(span);
  });
}
async function save(){
  const btn=document.getElementById('contractSaveBtn');
  await cbpSubmit(btn, async () => {
    const errs={};
    if(!document.getElementById('fCustomer').value)errs.customer=['Please select a customer.'];
    if(!document.getElementById('fTitle').value.trim())errs.title=['Please enter a title.'];
    if(Object.keys(errs).length){showContractErrors(errs);return;}
    const tplVal=document.getElementById('fTemplate')?document.getElementById('fTemplate').value:'';
    const body={contract_type:document.getElementById('fType').value,customer:document.getElementById('fCustomer').value,service_location:(document.getElementById('fServiceLoc')?document.getElementById('fServiceLoc').value:'')||null,title:document.getElementById('fTitle').value,start_date:document.getElementById('fStart').value||null,end_date:document.getElementById('fEnd').value||null,billing_frequency:getFreqValue('f').billing_frequency,billing_interval:getFreqValue('f').billing_interval,billing_unit:getFreqValue('f').billing_unit,amount:parseFloat(document.getElementById('fRecurring').value)||0,initial_treatment_fee:parseFloat(document.getElementById('fInitialFee').value)||0,recurring_fee:parseFloat(document.getElementById('fRecurring').value)||0,tax_rate:parseFloat(document.getElementById('fTaxRate').value)||0,tax_amount:Math.round((parseFloat(document.getElementById('fInitialFee').value)||0)*(parseFloat(document.getElementById('fTaxRate').value)||0)*100)/10000,recurring_tax_amount:Math.round((parseFloat(document.getElementById('fRecurring').value)||0)*(parseFloat(document.getElementById('fTaxRate').value)||0)*100)/10000,visits_included:parseInt(document.getElementById('fVisits').value),auto_renew:document.getElementById('fAutoRenew').value==='true',auto_pay:document.getElementById('fAutoPay').checked,description:document.getElementById('fDesc').value,notes:document.getElementById('fNotes').value};
    if(tplVal)body.template=tplVal;
    const url=editId?`/contracts/contracts/${editId}/`:'/contracts/contracts/';
    const method=editId?'PATCH':'POST';
    const r=await fetch(API+url,{method,credentials:'same-origin',headers:hdr(method),body:JSON.stringify(body)});
    let d=null;try{d=await r.json();}catch(_){}
    if(!r.ok){showContractErrors(d);return;}
    hideModal('modal');toast(editId?'Contract updated':'Contract created');loadData();
  });
}
document.addEventListener('DOMContentLoaded',()=>{loadCustomers();loadData();});

// ========== TEMPLATE SELECTOR IN NEW CONTRACT ==========
let contractTemplates=[];
async function loadTemplateOptions(){
  if(!contractTemplates.length){
    const d=await api('/contracts/templates/');
    contractTemplates=d.results||d;
  }
  const sel=document.getElementById('fTemplate');
  sel.innerHTML='<option value="">— No template (manual entry) —</option>'+contractTemplates.map(t=>{
    const tc=TYPE_CFG[t.contract_type]||{icon:'fa-file'};
    return '<option value="'+t.id+'">'+t.name+' ('+((t.contract_type||'').replace(/_/g,' '))+')</option>';
  }).join('');
}
async function applyTemplate(){
  const tplId=document.getElementById('fTemplate').value;
  if(!tplId)return;
  // Find template in cache or fetch
  let tpl=contractTemplates.find(t=>t.id===tplId);
  if(!tpl){const d=await api('/contracts/templates/'+tplId+'/');tpl=d;}
  if(!tpl)return;
  // Auto-fill form fields
  document.getElementById('fType').value=tpl.contract_type||'maintenance';
  document.getElementById('fTitle').value=tpl.name||'';
  setFreqValue('f',tpl.default_billing_frequency,tpl.default_billing_interval,tpl.default_billing_unit);
  document.getElementById('fAmount').value=tpl.default_amount||0;document.getElementById('fRecurring').value=tpl.default_recurring_fee||tpl.default_amount||0;document.getElementById('fInitialFee').value=tpl.default_initial_fee||0;try{calcTax()}catch(e){};
  document.getElementById('fAutoRenew').value=tpl.auto_renew_default?'true':'false';
  // Set end date based on duration
  if(tpl.default_duration_months){
    const start=new Date(document.getElementById('fStart').value||localDateStr());
    start.setMonth(start.getMonth()+tpl.default_duration_months);
    document.getElementById('fEnd').value=localDateStr(start);
  }
  // Description is left as user free-text scope notes. Template clauses are
  // assembled at sign time in views.py:esign_page (header_text + clauses), so
  // duplicating them into a plain textarea here just dumped raw HTML on screen.
  // Leave fDesc untouched (or clear if blank).
  if(!document.getElementById('fDesc').value)document.getElementById('fDesc').value='';
}

// ========== TAX CALC ==========
function calcTax(){var i=parseFloat(document.getElementById('fInitialFee').value)||0,r=parseFloat(document.getElementById('fRecurring').value)||0,t=parseFloat(document.getElementById('fTaxRate').value)||0,it=Math.round(i*t*100)/10000,rt=Math.round(r*t*100)/10000,el=document.getElementById('taxSummary');if(i||r){var h='';if(i)h+='<div><b>Initial:</b> $'+i.toFixed(2)+' + $'+it.toFixed(2)+' tax = <b>$'+(i+it).toFixed(2)+'</b></div>';if(r)h+='<div><b>Recurring:</b> $'+r.toFixed(2)+' + $'+rt.toFixed(2)+' tax = <b>$'+(r+rt).toFixed(2)+'</b>/period</div>';if(t)h+='<div style="color:var(--text-light)">Tax: '+t+'%</div>';el.innerHTML=h;el.style.display='block'}else{el.style.display='none'}document.getElementById('fAmount').value=r}
async function lookupTax(){var cid=document.getElementById('fCustomer').value;if(!cid){alert('Select a customer first');return}try{var st='',ci='';var locSel=document.getElementById('fServiceLoc');var locId=locSel?locSel.value:'';if(locId){try{var l=await api('/service-locations/'+locId+'/');st=l.state||'';ci=l.city||''}catch(_e){}}if(!st||!ci){var c=await api('/customers/'+cid+'/');if(!st)st=c.service_state||c.billing_state||'';if(!ci)ci=c.service_city||c.billing_city||'';if(!ci||!st){var addr=(c.service_address||c.billing_address||'').trim();var m=/,\s*([^,]+?)\s*,\s*([A-Z]{2})(?:\s+(\d{5}))?(?:\s*,\s*USA)?\s*$/i.exec(addr);if(m){if(!ci)ci=m[1].trim();if(!st)st=m[2].toUpperCase()}}}if(!st){alert('Could not determine state for this address (set service_state on the customer or service location)');return}var t=await api('/billing/tax-lookup/?state='+encodeURIComponent(st)+'&city='+encodeURIComponent(ci));if(t.combined_rate){document.getElementById('fTaxRate').value=t.combined_rate;calcTax()}else{alert('No tax rate found for '+(ci||'(no city)')+', '+st)}}catch(e){alert('Tax lookup failed')}}

// ========== TAB SWITCHING ==========
function switchTab(tab){
  ['contracts','templates','clauses','renewals'].forEach(t=>{
    document.getElementById('panel'+t.charAt(0).toUpperCase()+t.slice(1)).style.display=t===tab?'':'none';
    document.getElementById('tab'+t.charAt(0).toUpperCase()+t.slice(1)).classList.toggle('active',t===tab);
  });
  const acts=document.getElementById('topActions');
  if(tab==='contracts')acts.innerHTML='<button type="button" class="btn btn-primary" onclick="openNew()"><i class="fas fa-plus"></i> New Contract</button>';
  else if(tab==='templates'){acts.innerHTML='';loadTemplates();}
  else if(tab==='clauses'){acts.innerHTML='';loadClauses();}
  else if(tab==='renewals'){acts.innerHTML='';loadRenewals();}
}

// ========== RENEWALS ==========
async function loadRenewals(){
  const tbody=document.getElementById('renewalTableBody');
  tbody.innerHTML='<tr><td colspan="7"><div class="empty-state"><i class="fas fa-spinner fa-spin"></i><p>Loading...</p></div></td></tr>';
  const search=(document.getElementById('renewalSearch').value||'').toLowerCase();
  let items=[];
  try{const d=await api('/contracts/renewals/');items=d.results||d;}catch(e){tbody.innerHTML='<tr><td colspan="7"><div class="empty-state"><p>Failed to load renewals.</p></div></td></tr>';return;}
  if(search){items=items.filter(r=>{const cn=(r.contract_number||r.contract||'').toString().toLowerCase();return cn.includes(search)||(r.customer_name||'').toLowerCase().includes(search);});}
  if(!items.length){tbody.innerHTML='<tr><td colspan="7"><div class="empty-state"><i class="fas fa-sync-alt"></i><p>No renewal records found.</p></div></td></tr>';return;}
  tbody.innerHTML=items.map(r=>`<tr>
    <td>${r.contract_number||r.contract||'—'}</td>
    <td>${escHTML(r.customer_name)||'—'}</td>
    <td>${fmtDate(r.renewed_from)}</td>
    <td>${fmtDate(r.renewed_to)}</td>
    <td>$${parseFloat(r.new_amount||0).toFixed(2)}</td>
    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${r.notes||'—'}</td>
    <td>${r.created_at?new Date(r.created_at).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}):'—'}</td>
  </tr>`).join('');
}

// ========== TEMPLATES ==========
let allClauses=[], tplEditId=null;
const CAT_COLORS={payment:'#E3F2FD',service:'#E8F5E9',liability:'#FFF3E0',cancellation:'#FCE4EC',compliance:'#F3E5F5',pest_control:'#E8F5E9',credit_card:'#FFF8E1',signature:'#ECEFF1',other:'#F5F5F5'};
const CAT_TEXT={payment:'#1565C0',service:'#2E7D32',liability:'#E65100',cancellation:'#C62828',compliance:'#6A1B9A',pest_control:'#2E7D32',credit_card:'#F57F17',signature:'#37474F',other:'#616161'};

async function loadTemplates(){
  const grid=document.getElementById('tplGrid');
  grid.innerHTML='<div style="padding:30px;text-align:center;color:var(--text-light)"><i class="fas fa-spinner fa-spin"></i></div>';
  let url='/contracts/templates/';
  const search=document.getElementById('tplSearch').value;
  const type=document.getElementById('tplFilterType').value;
  const d=await api(url);const items=(d.results||d).filter(t=>{
    if(search&&!t.name.toLowerCase().includes(search.toLowerCase()))return false;
    if(type&&t.contract_type!==type)return false;
    return true;
  });
  if(!items.length){grid.innerHTML='<div style="padding:40px;text-align:center;color:var(--text-light);grid-column:1/-1">No templates yet. Create one to get started!</div>';return;}
  grid.innerHTML=items.map(t=>{
    const tc=TYPE_CFG[t.contract_type]||{color:'#607D8B',icon:'fa-file'};
    const clauseNames=(t.template_clauses||[]).map(tc=>tc.clause?.name||'').filter(Boolean);
    return `<div class="tpl-card" onclick="openTplEdit('${t.id}')">
      <div style="display:flex;justify-content:space-between;align-items:flex-start">
        <h3><span class="type-icon" style="background:${tc.color}"><i class="fas ${tc.icon}"></i></span>${t.name}</h3>
        <div style="display:flex;align-items:center;gap:6px" onclick="event.stopPropagation()">
          <span style="font-size:11px;color:var(--text-light);margin-right:4px">${t.contract_count||0} contracts</span>
          <button type="button" title="Duplicate" data-id="${t.id}" onclick="event.stopPropagation();duplicateTpl(this.dataset.id)" style="padding:4px 8px;border:1.5px solid var(--border);border-radius:5px;background:#fff;cursor:pointer;font-size:11px;color:#555"><i class="fas fa-copy"></i></button>
          <button type="button" title="Delete" data-id="${t.id}" onclick="event.stopPropagation();deleteTpl(this.dataset.id)" style="padding:4px 8px;border:1.5px solid #FFCDD2;border-radius:5px;background:#fff;cursor:pointer;font-size:11px;color:#C62828"><i class="fas fa-trash"></i></button>
        </div>
      </div>
      <div class="meta">
        <span>${parseFloat(t.default_amount||0)>0?'$'+parseFloat(t.default_amount).toLocaleString():'—'}</span>
        <span>${t.default_billing_frequency==='custom'?(t.default_billing_interval||1)+' '+(t.default_billing_unit||'months'):(t.default_billing_frequency_display||t.default_billing_frequency||'')}</span>
        <span>${t.default_duration_months||0} months</span>
        ${t.auto_renew_default?'<span style="color:#4CAF50">⟳ Auto-renew</span>':''}
      </div>
      <div class="clauses-preview"><strong>${clauseNames.length} clauses:</strong> ${clauseNames.slice(0,5).join(', ')}${clauseNames.length>5?' + '+(clauseNames.length-5)+' more':''}</div>
    </div>`;
  }).join('');
}

async function loadAllClauses(){
  const d=await api('/contracts/clauses/');
  allClauses=(d.results||d).sort((a,b)=>a.sort_order-b.sort_order);
  return allClauses;
}

function renderClausePicker(selectedIds=[]){
  const el=document.getElementById('clausePicker');
  if(!allClauses.length){el.innerHTML='<div style="color:var(--text-light);font-size:12px">Loading clauses...</div>';return;}
  // Group by category
  const groups={};
  allClauses.forEach(c=>{if(!groups[c.category])groups[c.category]=[];groups[c.category].push(c);});
  let html='';
  for(const[cat,clauses] of Object.entries(groups)){
    const catLabel=clauses[0]?.category_display||cat;
    html+=`<div style="font-size:11px;font-weight:700;color:var(--text-light);text-transform:uppercase;margin-top:8px;margin-bottom:4px">${catLabel}</div>`;
    clauses.forEach(c=>{
      const checked=selectedIds.includes(c.id)?'checked':'';
      const sel=checked?'selected':'';
      html+=`<label class="clause-pick ${sel}" onclick="this.classList.toggle('selected')">
        <input type="checkbox" name="tplClause" value="${c.id}" ${checked}>
        <div><div class="cp-name">${c.name}${c.requires_initial?' <span style="color:#FF9800;font-size:10px">✍ Initial required</span>':''}</div>
        <div class="cp-cat">${(stripHTML(c.body)||"").substring(0,100)}${(stripHTML(c.body)||"").length>100?'...':''}</div></div>
      </label>`;
    });
  }
  el.innerHTML=html;
}

async function openTplNew(){
  tplEditId=null;
  document.getElementById('tplModalTitle').textContent='New Template';
  ensureQuill();document.getElementById('tName').value='';tplQuill.setContents([]);
  document.getElementById('tType').value='maintenance';
  document.getElementById('tAmount').value='0';
  setFreqValue('t','monthly',1,'months');
  document.getElementById('tDuration').value='12';
  document.getElementById('tAutoRenew').value='false';
  if(!allClauses.length) await loadAllClauses();
  renderClausePicker([]);
  showModal('tplModal');
}

async function openTplEdit(id){
  tplEditId=id;
  const t=await api('/contracts/templates/'+id+'/');
  document.getElementById('tplModalTitle').textContent='Edit — '+t.name;
  document.getElementById('tName').value=t.name||'';
  document.getElementById('tType').value=t.contract_type||'maintenance';
  ensureQuill();tplQuill.root.innerHTML=t.header_text||'';
  document.getElementById('tAmount').value=t.default_amount||0;
  setFreqValue('t',t.default_billing_frequency,t.default_billing_interval,t.default_billing_unit);
  document.getElementById('tDuration').value=t.default_duration_months||12;
  document.getElementById('tAutoRenew').value=t.auto_renew_default?'true':'false';
  if(!allClauses.length) await loadAllClauses();
  const selectedIds=(t.template_clauses||[]).map(tc=>tc.clause?.id).filter(Boolean);
  renderClausePicker(selectedIds);
  showModal('tplModal');
}

async function saveTpl(){
  const btn=document.getElementById('tplSaveBtn');
  await cbpSubmit(btn, async () => {
    const clauseIds=[...document.querySelectorAll('input[name=tplClause]:checked')].map(el=>el.value);
    const body={name:document.getElementById('tName').value,contract_type:document.getElementById('tType').value,header_text:tplQuill.root.innerHTML,default_amount:parseFloat(document.getElementById('tAmount').value)||0,default_initial_fee:parseFloat(document.getElementById('tInitialFee').value)||0,default_recurring_fee:parseFloat(document.getElementById('tRecurringFee').value)||0,...getFreqValue('t'),default_billing_frequency:getFreqValue('t').billing_frequency,default_billing_interval:getFreqValue('t').billing_interval,default_billing_unit:getFreqValue('t').billing_unit,default_duration_months:parseInt(document.getElementById('tDuration').value)||12,auto_renew_default:document.getElementById('tAutoRenew').value==='true',clause_ids:clauseIds,is_active:true};
    const url=tplEditId?`/contracts/templates/${tplEditId}/`:'/contracts/templates/';
    const method=tplEditId?'PATCH':'POST';
    try{
      const r=await fetch(API+url,{method,credentials:'same-origin',headers:hdr(method),body:JSON.stringify(body)});
      let d=null;try{d=await r.json();}catch(_){}
      if(!r.ok || !(d&&d.id)){toast('Error saving template: '+_parseErr(d),'error');return;}
      hideModal('tplModal');toast(tplEditId?'Template updated':'Template created');loadTemplates();
    }catch(e){
      if(e&&e.name==='AbortError') throw e;
      console.error('Save error:',e);
      toast('Error: '+e.message,'error');
    }
  });
}
async function deleteTpl(id){
  const t=await api('/contracts/templates/'+id+'/');
  const name=t&&t.name?t.name:'this template';
  if(!confirm('Delete template "'+name+'"? This cannot be undone.'))return;
  await api('/contracts/templates/'+id+'/','DELETE');
  loadTemplates();
}
async function duplicateTpl(id,name){
  const t=await api('/contracts/templates/'+id+'/');
  if(!t)return;
  const clauseIds=(t.template_clauses||[]).map(tc=>tc.clause?.id).filter(Boolean);
  const body={
    name:'Copy of '+t.name,
    contract_type:t.contract_type,
    header_text:t.header_text||'',
    description:t.description||'',
    default_amount:t.default_amount||0,
    default_initial_fee:t.default_initial_fee||0,
    default_recurring_fee:t.default_recurring_fee||0,
    default_billing_frequency:t.default_billing_frequency||'one_time',
    default_billing_interval:t.default_billing_interval||1,
    default_billing_unit:t.default_billing_unit||'months',
    default_duration_months:t.default_duration_months||12,
    auto_renew_default:t.auto_renew_default||false,
    is_active:true,
    auto_send:t.auto_send||false,
    clause_ids:clauseIds,
  };
  const r=await api('/contracts/templates/','POST',body);
  if(r&&r.id){loadTemplates();}
  else{alert('Duplicate failed: '+(r?.detail||JSON.stringify(r)));}
}

// ========== CLAUSES ==========
let clauseEditId=null;

async function loadClauses(){
  const grid=document.getElementById('clauseGrid');
  grid.innerHTML='<div style="padding:30px;text-align:center;color:var(--text-light)"><i class="fas fa-spinner fa-spin"></i></div>';
  const d=await api('/contracts/clauses/');
  let items=(d.results||d);
  const search=(document.getElementById('clauseSearch').value||'').toLowerCase();
  const cat=document.getElementById('clauseFilterCat').value;
  if(search)items=items.filter(c=>c.name.toLowerCase().includes(search)||c.body.toLowerCase().includes(search));
  if(cat)items=items.filter(c=>c.category===cat);
  if(!items.length){grid.innerHTML='<div style="padding:40px;text-align:center;color:var(--text-light);grid-column:1/-1">No clauses found</div>';return;}
  grid.innerHTML=items.map(c=>{
    const bg=CAT_COLORS[c.category]||'#F5F5F5';
    const fg=CAT_TEXT[c.category]||'#616161';
    return `<div class="clause-card" onclick="openClauseEdit('${c.id}')">
      <span class="cat-badge" style="background:${bg};color:${fg}">${c.category_display||c.category}</span>
      ${c.requires_initial?'<span style="font-size:10px;color:#FF9800;margin-left:6px">✍ Initial required</span>':''}
      ${!c.tenant?'<span style="font-size:10px;color:#9E9E9E;margin-left:6px">System default</span>':''}
      <h4>${escHTML(c.name)}</h4>
      <div class="body-preview">${(stripHTML(c.body)||"(no preview)").substring(0,200)}</div>
    </div>`;
  }).join('');
}

function openClauseNew(){
  clauseEditId=null;
  document.getElementById('clauseModalTitle').textContent='New Clause';
  ensureQuill();document.getElementById('cName').value='';clauseQuill.setContents([]);
  document.getElementById('cCat').value='other';
  document.getElementById('cInitial').value='false';
  document.getElementById('cSort').value='50';
  // Restore editable state (in case modal was last opened on a system default)
  document.getElementById('clauseRoBanner').classList.remove('show');
  ['cName','cCat','cInitial','cSort'].forEach(id=>document.getElementById(id).disabled=false);
  clauseQuill.enable(true);
  document.getElementById('clauseSaveBtn').style.display='';
  document.getElementById('clauseDuplicateBtn').style.display='none';
  document.getElementById('clauseDeleteBtn').style.display='none';
  showModal('clauseModal');
}

async function openClauseEdit(id){
  clauseEditId=id;
  const c=await api('/contracts/clauses/'+id+'/');
  const isSystem=!c.tenant;
  document.getElementById('clauseModalTitle').textContent=(isSystem?'View (system default) — ':'Edit — ')+c.name;
  document.getElementById('cName').value=c.name||'';
  document.getElementById('cCat').value=c.category||'other';
  ensureQuill();clauseQuill.root.innerHTML=c.body||'';
  document.getElementById('cInitial').value=c.requires_initial?'true':'false';
  document.getElementById('cSort').value=c.sort_order||50;
  // Toggle read-only mode for system defaults
  const ro=isSystem;
  document.getElementById('clauseRoBanner').classList.toggle('show',ro);
  document.getElementById('cName').disabled=ro;
  document.getElementById('cCat').disabled=ro;
  document.getElementById('cInitial').disabled=ro;
  document.getElementById('cSort').disabled=ro;
  clauseQuill.enable(!ro);
  document.getElementById('clauseSaveBtn').style.display=ro?'none':'';
  document.getElementById('clauseDuplicateBtn').style.display=ro?'':'none';
  document.getElementById('clauseDeleteBtn').style.display=ro?'none':'';
  showModal('clauseModal');
}

async function saveClause(){
  const btn=document.getElementById('clauseSaveBtn');
  await cbpSubmit(btn, async () => {
    const body={name:document.getElementById('cName').value,category:document.getElementById('cCat').value,body:clauseQuill.root.innerHTML,requires_initial:document.getElementById('cInitial').value==='true',sort_order:parseInt(document.getElementById('cSort').value)};
    const url=clauseEditId?`/contracts/clauses/${clauseEditId}/`:'/contracts/clauses/';
    const method=clauseEditId?'PATCH':'POST';
    const r=await fetch(API+url,{method,credentials:'same-origin',headers:hdr(method),body:JSON.stringify(body)});
    let d=null;try{d=await r.json();}catch(_){}
    if(!r.ok){toast(_parseErr(d),'error');return;}
    hideModal('clauseModal');toast(clauseEditId?'Clause updated':'Clause created');loadClauses();allClauses=[]; // reset cache
  });
}

// ── HTML helpers + clause read-only / delete / duplicate + picker search ──
function stripHTML(html){if(!html)return '';const d=document.createElement('div');d.innerHTML=html;const t=(d.textContent||d.innerText||'').replace(/\s+/g,' ').trim();return t;}
function renderClausePickerFiltered(){
  const q=(document.getElementById('clausePickerSearch')?.value||'').toLowerCase().trim();
  const checked=Array.from(document.querySelectorAll('input[name=tplClause]:checked')).map(i=>i.value);
  const _orig=allClauses;
  if(q){allClauses=_orig.filter(c=>c.name.toLowerCase().includes(q)||(c.body||'').toLowerCase().includes(q));}
  renderClausePicker(checked);
  allClauses=_orig;
}
async function deleteClause(){
  if(!clauseEditId)return;
  if(!confirm('Delete this clause? This cannot be undone.'))return;
  const btn=document.getElementById('clauseDeleteBtn');
  await cbpSubmit(btn, async () => {
    const r=await fetch(API+'/contracts/clauses/'+clauseEditId+'/',{method:'DELETE',credentials:'same-origin',headers:hdr('DELETE')});
    if(!r.ok && r.status !== 204){let d=null;try{d=await r.json()}catch(_){};toast(_parseErr(d)||'Delete failed','error');return;}
    hideModal('clauseModal');toast('Clause deleted');loadClauses();allClauses=[];
  });
}
async function duplicateSystemClause(){
  if(!clauseEditId)return;
  const btn=document.getElementById('clauseDuplicateBtn');
  await cbpSubmit(btn, async () => {
    const r=await fetch(API+'/contracts/clauses/'+clauseEditId+'/duplicate/',{method:'POST',credentials:'same-origin',headers:hdr('POST')});
    let d=null;try{d=await r.json()}catch(_){};
    if(!r.ok){toast(_parseErr(d)||'Duplicate failed','error');return;}
    hideModal('clauseModal');toast('Cloned to your clauses — opening for edit');
    allClauses=[];await loadClauses();
    if(d&&d.id)openClauseEdit(d.id);
  });
}

// ── Quill WYSIWYG init ──
const QUILL_TOOLBAR=[[{header:[1,2,3,false]}],['bold','italic','underline'],[{list:'ordered'},{list:'bullet'}],['clean']];
let tplQuill,clauseQuill;
// Lazy init — Quill must init after modal is visible (hidden elements = zero height)
function ensureQuill(){
  if(!tplQuill){
    tplQuill=new Quill('#tHeaderEditor',{modules:{toolbar:QUILL_TOOLBAR},theme:'snow'});
    tplQuill.on('text-change',()=>highlightTokens(tplQuill));
  }
  if(!clauseQuill){
    clauseQuill=new Quill('#cBodyEditor',{modules:{toolbar:QUILL_TOOLBAR},theme:'snow'});
    clauseQuill.on('text-change',()=>highlightTokens(clauseQuill));
  }
}
const AUTO_FIELDS=new Set(['customer_name','customer_first_name','customer_address','customer_phone','customer_email','business_name','business_phone','business_address','date','appointment_date','appointment_time','contract_amount','technician_name']);
function insertMergeField(quill,fieldName){
  if(!fieldName||!fieldName.trim())return;
  const name=fieldName.trim().replace(/\s+/g,'_');
  const token='\x7B\x7B'+name+'\x7D\x7D';
  const isAuto=AUTO_FIELDS.has(name);
  const fg=isAuto?'#1B5E20':'#0D47A1';
  const bg=isAuto?'#E8F5E9':'#E3F2FD';
  const range=quill.getSelection(true)||(quill.focus(),quill.getSelection(true));
  const idx=range?range.index:(quill.getLength()||0);
  quill.insertText(idx,token,{'color':fg,'background':bg,'bold':true});
  quill.setSelection(idx+token.length);
  quill.formatText(idx,token.length,{'color':fg,'background':bg,'bold':true});
}
function highlightTokens(quill){
  // Re-apply green styling to any  that lost it
  const text=quill.getText();
  const re=/\{\{\w+\}\}/g;let m;
  while((m=re.exec(text))!==null){
    const existing=quill.getFormat(m.index,m[0].length);
    if(!existing.color||existing.color!=='#2E7D32'){
      quill.formatText(m.index,m[0].length,{'color':'#2E7D32','background':'#E8F5E9','bold':true},{'api':true});
    }
  }
}

// ── Discard-confirm guard for create/edit modals ─────────────────────
// Tracks 'dirty' by listening for any input/change inside the modal.
// Exposes el._cbpIsDirty()/el._cbpResetDirty() so base.html's
// closeModalEl() can prompt before closing on backdrop click or ESC.
// X/Cancel buttons close immediately (call hideModal directly) — by design,
// since those are intentional clicks. Reset dirty whenever the modal
// transitions from hidden to visible (new openNew/openEdit invocation).
(function(){
  const MODAL_IDS = ['modal'];
  MODAL_IDS.forEach(function(id){
    const el = document.getElementById(id);
    if (!el) return;
    let dirty = false;
    const mark = function(){ dirty = true; };
    el.addEventListener('input',  mark);
    el.addEventListener('change', mark);
    new MutationObserver(function(muts){
      muts.forEach(function(m){
        if (m.attributeName !== 'class') return;
        const oldCls = (m.oldValue || '').split(/\s+/);
        const wasHidden = !oldCls.includes('show') && !oldCls.includes('open');
        const isShown  = el.classList.contains('show') || el.classList.contains('open');
        if (wasHidden && isShown) dirty = false;
      });
    }).observe(el, { attributes: true, attributeFilter: ['class'], attributeOldValue: true });
    el.dataset.discardConfirm = '1';
    el._cbpIsDirty    = function(){ return dirty; };
    el._cbpResetDirty = function(){ dirty = false; };
  });
})();