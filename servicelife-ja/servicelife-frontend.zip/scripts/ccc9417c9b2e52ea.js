(function(){
  if (window.cbpInTheArea) return;  // idempotent include guard
  const API = '/api/v1/routing/nearby/';
  const csrf = () => document.cookie.match(/csrftoken=([^;]+)/)?.[1] || '';

  function esc(s){
    return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function fmtDate(iso){
    if(!iso) return '—';
    try { return new Date(iso).toLocaleString('en-US', {month:'short', day:'numeric', hour:'numeric', minute:'2-digit'}); }
    catch(e){ return iso; }
  }

  function panel(){ return document.getElementById('cbp-in-the-area-panel'); }
  function el(sel){ return panel().querySelector(sel); }

  async function fetchNearby(lat, lng, dateWindowDays){
    const url = `${API}?lat=${encodeURIComponent(lat)}&lng=${encodeURIComponent(lng)}&date_window_days=${encodeURIComponent(dateWindowDays || 7)}`;
    const r = await fetch(url, {credentials: 'same-origin', headers: {'X-CSRFToken': csrf(), 'Accept': 'application/json'}});
    if(!r.ok){
      const err = new Error('nearby fetch failed: ' + r.status);
      err.status = r.status;
      throw err;
    }
    return await r.json();
  }

  function renderRow(opts){
    const miles = opts.miles != null ? `${Number(opts.miles).toFixed(2)} mi` : '';
    const pill = opts.pill ? `<span class="cbp-area-pill">${esc(opts.pill)}</span>` : '';
    const sub = opts.sub ? `<div class="where">${esc(opts.sub)}</div>` : '';
    return `<div class="cbp-area-row" data-area-item-id="${esc(opts.id)}">
      <div>
        <div class="who">${esc(opts.title)}${pill}</div>
        ${sub}
      </div>
      <div class="actions">
        <span class="miles">${miles}</span>
        <button type="button" class="cbp-area-add" data-area-add>+ Add stop</button>
      </div>
    </div>`;
  }

  function render(data){
    const meta = el('[data-area-meta]');
    const total = (data.recurring?.length || 0) + (data.overdue?.length || 0);
    meta.textContent = total
      ? `${total} opportunities within ${data.radius_miles} mi`
      : `0 within ${data.radius_miles} mi`;

    const recurringList = el('[data-area-recurring-list]');
    if(data.recurring?.length){
      recurringList.innerHTML = data.recurring.map(r => renderRow({
        id: r.appointment_id,
        title: r.customer_name,
        sub: `${r.address} · ${fmtDate(r.start_datetime)}` + (r.technician_name ? ` · ${r.technician_name}` : ''),
        miles: r.miles_away,
        pill: r.recurrence,
      })).join('');
    } else {
      recurringList.innerHTML = '<div class="cbp-area-empty">No recurring stops booked nearby this week.</div>';
    }

    const overdueList = el('[data-area-overdue-list]');
    if(data.overdue?.length){
      overdueList.innerHTML = data.overdue.map(o => renderRow({
        id: o.customer_id,
        title: o.customer_name,
        sub: `${o.address}${o.days_since_last_service ? ' · ' + o.days_since_last_service + ' days since last service' : ''}`,
        miles: o.miles_away,
      })).join('');
    } else {
      overdueList.innerHTML = '<div class="cbp-area-empty">No overdue customers nearby.</div>';
    }

    // Wire add-stop buttons. Host page (booking flow) attaches onAddStop.
    panel().querySelectorAll('[data-area-add]').forEach(btn => {
      btn.addEventListener('click', () => {
        const row = btn.closest('[data-area-item-id]');
        const id = row?.getAttribute('data-area-item-id');
        // Find the source record by id from the rendered data
        const recurring = (data.recurring || []).find(x => x.appointment_id === id);
        const overdue = (data.overdue || []).find(x => x.customer_id === id);
        const item = recurring
          ? Object.assign({_kind: 'recurring'}, recurring)
          : (overdue ? Object.assign({_kind: 'overdue'}, overdue) : null);
        if (typeof window.cbpInTheArea.onAddStop === 'function' && item){
          window.cbpInTheArea.onAddStop(item);
        }
      });
    });
  }

  async function show(opts){
    const lat = opts && opts.lat;
    const lng = opts && opts.lng;
    const dateWindowDays = (opts && opts.dateWindowDays) || 7;
    if(lat == null || lng == null){
      hide();
      return;
    }
    const p = panel();
    p.classList.remove('is-hidden');
    el('[data-area-meta]').textContent = 'Loading…';
    el('[data-area-recurring-list]').innerHTML = '<div class="cbp-area-loading"><i class="fas fa-spinner fa-spin"></i> Looking up nearby jobs…</div>';
    el('[data-area-overdue-list]').innerHTML = '<div class="cbp-area-loading"><i class="fas fa-spinner fa-spin"></i> Looking up overdue customers…</div>';
    try {
      const data = await fetchNearby(lat, lng, dateWindowDays);
      render(data);
    } catch(e){
      el('[data-area-meta]').textContent = 'Lookup failed';
      const msg = e && e.status === 403
        ? 'You do not have permission to view nearby jobs.'
        : esc(e && e.message ? e.message : 'error');
      el('[data-area-recurring-list]').innerHTML = `<div class="cbp-area-empty">${msg}</div>`;
      el('[data-area-overdue-list]').innerHTML = '';
    }
  }

  function hide(){
    const p = panel();
    if(p) p.classList.add('is-hidden');
  }

  window.cbpInTheArea = { show, hide, onAddStop: null };
})();