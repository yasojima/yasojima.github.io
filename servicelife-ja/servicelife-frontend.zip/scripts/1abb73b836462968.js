const API='/api/v1';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(m)=>{const h={'X-CSRFToken':csrf()};if(m!=='GET')h['Content-Type']='application/json';return h;};
async function api(u,m='GET',b=null){const o={method:m,credentials:'same-origin',headers:hdr(m)};if(b)o.body=JSON.stringify(b);const r=await fetch(API+u,o);if(r.status===204)return null;return r.json();}
const _esc=document.createElement('textarea');
function escHTML(s){_esc.textContent=String(s||'');return _esc.innerHTML;}
function fmtDate(s){if(!s)return'—';return new Date(s).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
function showModal(id){document.getElementById(id).classList.add('show');}

let _sortField='created_at',_sortDir='desc';
function sortBy(field){
  if(_sortField===field){_sortDir=(_sortDir==='asc')?'desc':'asc';}
  else{_sortField=field;_sortDir='asc';}
  document.querySelectorAll('.data-table th.sortable').forEach(th=>{
    th.classList.remove('sort-asc','sort-desc');
    if(th.dataset.sort===_sortField)th.classList.add('sort-'+_sortDir);
  });
  loadData();
}

function hideModal(id){
  document.getElementById(id).classList.remove('show');
}

const STAT_BADGE={draft:'gray',sent:'blue',viewed:'purple',paid:'green',overdue:'red',cancelled:'gray',partially_paid:'orange'};
let editId=null,lineIdx=0;

async function loadKPIs(){
  try{const d=await api('/billing/stats/');
  document.getElementById('kpiStrip').innerHTML=`
    <div class="kpi"><div class="lbl">Invoiced (Month)</div><div class="val">$${(d.month?.total_invoiced||0).toLocaleString()}</div></div>
    <div class="kpi"><div class="lbl">Collected</div><div class="val" style="color:#2e7d32">$${(d.month?.total_collected||0).toLocaleString()}</div></div>
    <div class="kpi"><div class="lbl">Outstanding</div><div class="val" style="color:#e65100">$${(d.month?.outstanding||0).toLocaleString()}</div></div>
    <div class="kpi"><div class="lbl">Overdue</div><div class="val" style="color:#c62828">${d.overdue||0}</div></div>
    <div class="kpi"><div class="lbl">Cards on File</div><div class="val">${d.cards_on_file||0}</div></div>
    ${prechargeFailedCard(d.precharge)}`;
  }catch(e){}
}

// Pre-charge failed counter (handoff 16.8 chunk 4). Renders only when the
// tenant has prepay activity — no stat tile when the count is zero AND
// there's been no month activity, so the dashboard stays clean for tenants
// who haven't enabled prepay. When there's a failure to act on, the card
// goes red so it draws the eye.
function prechargeFailedCard(pp){
  if (!pp) return '';
  const open = pp.week_failed_open || 0;
  const monthAny = (pp.month_succeeded||0) + (pp.month_failed||0) + (pp.month_auto_cancelled||0);
  if (open === 0 && monthAny === 0) return '';  // no prepay activity yet
  const fg = open > 0 ? '#c62828' : '#546e7a';
  const sub = open > 0
    ? `${open} pending recovery`
    : `${pp.month_succeeded||0} charged this month`;
  return `<div class="kpi" title="Failed pre-charges in the last 7 days that are still awaiting customer recovery"><div class="lbl">Pre-Charge Failed (7d)</div><div class="val" style="color:${fg}">${open}</div><div style="font-size:11px;color:var(--text-light);margin-top:2px">${sub}</div></div>`;
}

async function loadData(){
  const tb=document.getElementById('tableBody');
  try{
    const ordering=(_sortDir==='desc'?'-':'')+_sortField;
    let url='/billing/invoices/?ordering='+ordering;
    const s=document.getElementById('search').value,st=document.getElementById('filterStatus').value;
    if(st)url+='&status='+st;
    if(s)url+='&search='+encodeURIComponent(s);
    const d=await api(url);const items=d.results||d;
    if(!items.length){tb.innerHTML='<tr><td colspan="10"><div class="empty-state"><i class="fas fa-file-invoice-dollar"></i><p>No invoices yet</p></div></td></tr>';loadKPIs();return;}
    tb.innerHTML=items.map(i=>`<tr class="clickable" tabindex="0" role="link" onkeydown="if(event.key==='Enter'||event.key===' '){this.click();event.preventDefault()}" onclick="openEdit('${i.id}')"><td><strong>${i.invoice_number||'Draft'}</strong></td><td>${escHTML(i.customer_name||'—')}</td><td>${fmtDate(i.created_at)}</td><td>${fmtDate(i.due_date)}</td><td>$${p(i.subtotal)}</td><td>$${p(i.tax_amount)}</td><td><strong>$${p(i.total)}</strong></td><td>$${p(i.amount_paid)}</td><td style="color:${parseFloat(i.balance_due)>0?'#c62828':'#2e7d32'}">$${p(i.balance_due)}</td><td><span class="badge badge-${STAT_BADGE[i.status]||'gray'}">${i.status_display||i.status}</span></td></tr>`).join('');
    loadKPIs();
  }catch(e){if(e&&e.name==='AbortError')return;tb.innerHTML='<tr><td colspan="10"><div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Could not load invoices.</p></div></td></tr>';}
}
function p(v){return parseFloat(v||0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});}

async function loadCustomers(){
  const d=await api('/customers/?page_size=200');const items=d.results||d;
  document.getElementById('fCustomer').innerHTML='<option value="">Select...</option>'+items.map(c=>`<option value="${c.id}">${escHTML(c.first_name)} ${escHTML(c.last_name)}${c.company_name?' ('+escHTML(c.company_name)+')':''}</option>`).join('');
  document.getElementById('fCustomer').addEventListener('change',function(){loadInvoiceLocations(this.value);});
}

function addLine(desc='',qty=1,price=0){
  const idx=lineIdx++;
  const div=document.createElement('div');
  div.id='line_'+idx;div.style.cssText='display:grid;grid-template-columns:2fr 60px 80px 30px;gap:8px;margin-bottom:6px;align-items:center';
  div.innerHTML=`<input placeholder="Description" id="ld_${idx}" value="${desc}"><input type="number" value="${qty}" id="lq_${idx}" min="1" style="text-align:center"><input type="number" step="0.01" value="${price}" id="lp_${idx}"><button type="button" onclick="document.getElementById('line_${idx}').remove()" style="background:none;border:none;color:#c62828;cursor:pointer;font-size:14px"><i class="fas fa-times"></i></button>`;
  document.getElementById('lineItems').appendChild(div);
}

async function loadInvoiceLocations(customerId, selectedId){
  const row=document.getElementById('fInvLocRow');
  const sel=document.getElementById('fInvServiceLoc');
  if(!row||!sel)return;
  sel.innerHTML='<option value="">Customer-level invoice</option>';
  if(!customerId){row.style.display='none';return;}
  try{
    const r=await fetch('/api/v1/service-locations/?customer='+customerId+'&is_active=true&page_size=200',{credentials:'same-origin'});
    const d=await r.json();
    const items=d.results||d;
    if(!items.length){row.style.display='none';return;}
    items.forEach(l=>{
      const o=document.createElement('option');
      o.value=l.id;
      o.textContent=l.location_name+(l.address?' — '+l.address:'');
      if(selectedId&&l.id===selectedId)o.selected=true;
      sel.appendChild(o);
    });
    row.style.display='grid';
  }catch(e){console.warn('Loc load failed',e);row.style.display='none';}
}
function openNew(){editId=null;lineIdx=0;document.getElementById('modalTitle').textContent='New Invoice';document.getElementById('fCustomer').value='';if(document.getElementById('fInvLocRow')){document.getElementById('fInvLocRow').style.display='none';document.getElementById('fInvServiceLoc').value='';}document.getElementById('fDueDate').value='';document.getElementById('fTaxRate').value='0';document.getElementById('fDiscount').value='0';document.getElementById('fNotes').value='';document.getElementById('fIntentionallyZero').checked=false;document.getElementById('lineItems').innerHTML='';addLine();showModal('modal');}

async function invLookupTax(){var cid=document.getElementById('fCustomer').value;if(!cid){alert('Select a customer first');return}try{var st='',ci='';var locSel=document.getElementById('fInvServiceLoc');var locId=locSel?locSel.value:'';if(locId){try{var l=await api('/service-locations/'+locId+'/');st=l.state||'';ci=l.city||''}catch(_e){}}if(!st||!ci){var c=await api('/customers/'+cid+'/');if(!st)st=c.service_state||c.billing_state||'';if(!ci)ci=c.service_city||c.billing_city||'';if(!ci||!st){var addr=(c.service_address||c.billing_address||'').trim();var m=/,\s*([^,]+?)\s*,\s*([A-Z]{2})(?:\s+(\d{5}))?(?:\s*,\s*USA)?\s*$/i.exec(addr);if(m){if(!ci)ci=m[1].trim();if(!st)st=m[2].toUpperCase()}}}if(!st){alert('Could not determine state for this address (set service_state on the customer or service location)');return}var t=await api('/billing/tax-lookup/?state='+encodeURIComponent(st)+'&city='+encodeURIComponent(ci));if(t.combined_rate){document.getElementById('fTaxRate').value=t.combined_rate}else{alert('No tax rate found for '+(ci||'(no city)')+', '+st)}}catch(e){alert('Tax lookup failed')}}
async function openEdit(id){editId=id;lineIdx=0;const inv=await api('/billing/invoices/'+id+'/');document.getElementById('modalTitle').textContent='Invoice '+inv.invoice_number;const _sel=document.getElementById('fCustomer');_sel.value=inv.customer||'';if(inv.customer&&_sel.value!==inv.customer){const _o=document.createElement('option');_o.value=inv.customer;_o.textContent=inv.customer_name||inv.customer;_sel.appendChild(_o);_sel.value=inv.customer;}if(inv.customer)loadInvoiceLocations(inv.customer, inv.service_location);document.getElementById('fDueDate').value=inv.due_date||'';document.getElementById('fTaxRate').value=inv.tax_rate||0;document.getElementById('fDiscount').value=inv.discount||0;document.getElementById('fNotes').value=inv.notes||'';document.getElementById('fIntentionallyZero').checked=!!inv.intentionally_zero;document.getElementById('lineItems').innerHTML='';(inv.line_items||[]).forEach(li=>addLine(li.description,li.quantity,li.unit_price));if(!inv.line_items?.length)addLine();showModal('modal');
}

function toast(msg,kind){let e=document.getElementById('_apiToast');if(!e){e=document.createElement('div');e.id='_apiToast';e.style.cssText='position:fixed;top:20px;right:20px;padding:10px 16px;border-radius:6px;color:#fff;z-index:99999;font-size:13px;font-weight:500;box-shadow:0 4px 12px rgba(0,0,0,.15);max-width:380px;display:none';document.body.appendChild(e);}e.style.background=kind==='error'?'#e53935':'#43a047';e.textContent=msg;e.style.display='block';clearTimeout(e._t);e._t=setTimeout(()=>{e.style.display='none'},3000);}
function _parseErr(d){return cbpFormatApiError(d,'Save failed');}
async function save(){
  const custEl=document.getElementById('fCustomer');
  custEl.classList.remove('field-invalid');
  const prevErr=custEl.parentNode.querySelector(':scope > .field-error');
  if(prevErr)prevErr.remove();
  if(!custEl.value){custEl.classList.add('field-invalid');const err=document.createElement('div');err.className='field-error';err.style.cssText='color:#c62828;font-size:12px;margin-top:3px';err.textContent='Please select a customer';custEl.parentNode.appendChild(err);custEl.focus();return;}
  const btn=document.getElementById('invSaveBtn');
  await cbpSubmit(btn,async()=>{
    const body={customer:custEl.value,service_location:(document.getElementById('fInvServiceLoc')?document.getElementById('fInvServiceLoc').value:'')||null,due_date:document.getElementById('fDueDate').value||null,tax_rate:document.getElementById('fTaxRate').value,discount:document.getElementById('fDiscount').value,notes:document.getElementById('fNotes').value,intentionally_zero:document.getElementById('fIntentionallyZero').checked};
    // collect line items and send them to the server for persistence
    const lineItems=[];const lines=document.getElementById('lineItems').children;
    for(let el of lines){const idx=el.id.split('_')[1];const desc=(document.getElementById('ld_'+idx)?.value||'').trim();const q=parseFloat(document.getElementById('lq_'+idx)?.value||1);const p=parseFloat(document.getElementById('lp_'+idx)?.value||0);if(desc||p>0){lineItems.push({description:desc,quantity:q,unit_price:p});}}
    body.line_items=lineItems;
    const url=editId?'/billing/invoices/'+editId+'/':'/billing/invoices/';
    const method=editId?'PATCH':'POST';
    const r=await fetch(API+url,{method,credentials:'same-origin',headers:hdr(method),body:JSON.stringify(body)});
    let d=null;try{d=await r.json();}catch(_){}
    if(!r.ok){toast(_parseErr(d),'error');return;}
    hideModal('modal');toast(editId?'Invoice updated':'Invoice saved');loadData();
  });
}

document.addEventListener('DOMContentLoaded',()=>{
  const params=new URLSearchParams(window.location.search);
  const st=params.get('status');
  if(st){const sel=document.getElementById('filterStatus');if(sel&&[...sel.options].some(o=>o.value===st))sel.value=st;}
  loadCustomers();loadData().then(()=>{
  const deepId=params.get('id');
  if(deepId)openEdit(deepId);
});cbpAttachClearOnInput(document.getElementById('modal'));
});