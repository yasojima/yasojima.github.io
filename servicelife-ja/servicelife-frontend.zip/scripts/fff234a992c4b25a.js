const API = '/api/v1/communications';
const state = {
  status: 'open', channel: 'all', mine: false, q: '',
  intent: 'all', // Slice D3: last_intent filter
  selectedId: null,
  refreshTimer: null,
  offset: 0,
};

const csrftoken = (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';

// OAUTH_REQUIRED_HANDLED marker
class OAuthRequiredError extends Error {
  constructor(redirectUrl, detail) {
    super(detail || 'OAuth required');
    this.name = 'OAuthRequiredError';
    this.redirectUrl = redirectUrl;
  }
}

async function api(path, opts={}) {
  const r = await fetch(API + path, {
    credentials: 'same-origin',
    headers: {'Content-Type': 'application/json', 'X-CSRFToken': csrftoken, ...(opts.headers||{})},
    ...opts,
  });
  if (!r.ok) {
    let msg = '';
    let body = null;
    try {
      body = await r.json();
      msg = body.message || body.detail || body.error || '';
    } catch(_) {}
    // Backend signals "user must (re)authorize Microsoft" by returning
    // 401 with {oauth_required: true, redirect_url: ...}. Surface as
    // a structured error so callers can redirect rather than alert.
    if (body && body.oauth_required && body.redirect_url) {
      throw new OAuthRequiredError(body.redirect_url, msg);
    }
    throw new Error(`${r.status} ${r.statusText}${msg ? ': ' + msg : ''}`);
  }
  return r.json();
}

function fmtRelative(iso) {
  if (!iso) return '';
  const d = new Date(iso); const ms = Date.now() - d.getTime();
  const s = Math.round(ms/1000), m = Math.round(s/60), h = Math.round(m/60), days = Math.round(h/24);
  if (s < 60) return 'just now';
  if (m < 60) return m + 'm';
  if (h < 24) return h + 'h';
  if (days < 7) return days + 'd';
  return d.toLocaleDateString('en-US', { timeZone: window._tenantTz || 'America/New_York', month: 'short', day: 'numeric' });
}

// escHTML is now a global helper (base.html). Local definition removed by XSS sweep.

// SMS6: shared intent-chip renderer. Used by the conversation list and the
// per-message thread rendering on customer_detail.html (see _intent_chip.html).
// Returns '' when no intent (callers can decide to render a placeholder).
const INTENT_CHIP_CLASSES = {
  confirm: 'intent-chip-confirm',
  reschedule: 'intent-chip-reschedule',
  cancel: 'intent-chip-cancel',
  complaint: 'intent-chip-complaint',
  payment: 'intent-chip-payment',
  question: 'intent-chip-question',
  // 'stop' / 'other' / null → gray "other" chip per PRD.
  stop: 'intent-chip-other',
  other: 'intent-chip-other',
};
function renderIntentChip(intent, confidence, opts) {
  const o = opts || {};
  if (!intent && !o.renderEmpty) return '';
  const label = intent || 'other';
  const cls = INTENT_CHIP_CLASSES[label] || 'intent-chip-other';
  let title = 'Most recent inbound intent: ' + label;
  if (typeof confidence === 'number') {
    title += ' (confidence ' + Math.round(confidence * 100) + '%)';
  }
  const margin = o.inlineMargin === false ? '' : ' style="margin-left:6px"';
  return `<span class="intent-chip ${cls}"${margin} title="${escHTML(title)}">${escHTML(label)}</span>`;
}
// SMS5 override badge: shows the override intent with the original struck
// through. Carries who/when/why in a tooltip. Safely no-ops when the SMS5
// fields are absent (server returns empty strings).
function renderIntentOverrideChip(m) {
  if (!m || !m.intent_override_to) return '';
  const overrideCls = INTENT_CHIP_CLASSES[m.intent_override_to] || 'intent-chip-other';
  const origCls = INTENT_CHIP_CLASSES[m.intent || 'other'] || 'intent-chip-other';
  let tip = 'Overridden';
  if (m.intent_overridden_by_name) tip += ' by ' + m.intent_overridden_by_name;
  if (m.intent_overridden_at) tip += ' on ' + (new Date(m.intent_overridden_at)).toLocaleString();
  if (m.intent_override_reason) tip += ': ' + m.intent_override_reason;
  return (
    `<span class="intent-chip-override" title="${escHTML(tip)}">` +
      `<span class="intent-chip ${overrideCls}">${escHTML(m.intent_override_to)}</span>` +
      (m.intent ? `<span class="intent-chip ${origCls} intent-chip-original">${escHTML(m.intent)}</span>` : '') +
    `</span>`
  );
}

// ===== LIST =====
function _convItemHTML(it) {
  const chCls = 'ch-' + it.channel;
  const chIcon = {phone:'phone-alt', sms:'comment', email:'envelope', webchat:'comments', team:'hard-hat'}[it.channel] || 'circle';
  const unreadDot = it.unread_count > 0 ? '<span class="unread-dot" title="Unread"></span>' : '';
  const activeCls = it.id === state.selectedId ? ' active' : '';
  const nameOrUnknown = it.customer_name || it.contact_phone || 'Unknown';
  // Slice SMS6: intent chip CSS class per PRD §10 color map. Falls back to
  // 'other' for null / unknown labels (e.g. 'stop' renders as gray).
  const intentChip = renderIntentChip(it.last_intent, it.last_intent_confidence);
  return `<div class="conv-item${activeCls}" data-id="${it.id}">
    <div class="conv-row1">
      <div class="conv-name">${escHTML(nameOrUnknown)}${(it.is_unidentified && nameOrUnknown === 'Unknown')?' <span style="font-weight:400;color:#c87f00;font-size:10px">[unidentified]</span>':''}</div>
      <div class="conv-time">${fmtRelative(it.last_message_at)}${unreadDot}</div>
    </div>
    <div class="conv-preview">${escHTML(it.preview)}</div>
    <div class="conv-row3">
      <span class="conv-channel ${chCls}"><i class="fas fa-${chIcon}"></i> ${escHTML(it.channel_display)}</span>${intentChip}
      ${it.assigned_to_name ? '<span style="margin-left:auto"><i class="fas fa-user" style="font-size:9px"></i> '+escHTML(it.assigned_to_name)+'</span>' : ''}
    </div>
  </div>`;
}

async function loadList(append) {
  if (!append) state.offset = 0;
  const params = new URLSearchParams();
  params.set('status', state.status);
  if (state.channel !== 'all' && state.channel !== 'mine') params.set('channel', state.channel);
  if (state.channel === 'mine' || state.mine) params.set('mine', '1');
  if (state.q) params.set('q', state.q);
  if (state.intent && state.intent !== 'all') params.set('intent', state.intent);
  params.set('limit', '100');
  params.set('offset', String(state.offset));

  let data;
  try { data = await api('/inbox/?' + params); }
  catch(e) {
    document.getElementById('convList').innerHTML =
      `<div style="padding:20px;color:#c62828;font-size:12px">Error: ${escHTML(e.message)}</div>`;
    return;
  }

  if (!append) {
    // counts in tabs
    const c = data.counts || {};
    document.getElementById('cnt-open').textContent = c.open || 0;
    document.getElementById('cnt-waiting').textContent = c.waiting || 0;
    document.getElementById('cnt-closed').textContent = c.closed || 0;
  }

  const items = (data.items || []).filter(item => item.channel !== 'team');
  const list = document.getElementById('convList');

  if (!append) {
    if (!items.length) { list.innerHTML = '<div style="padding:30px;text-align:center;color:var(--text-light);font-size:12px">No conversations.</div>'; return; }
    list.innerHTML = items.map(_convItemHTML).join('');
  } else {
    // Remove existing "Load more" button before appending next page
    const prev = list.querySelector('.inbox-load-more');
    if (prev) prev.remove();
    if (items.length) {
      const frag = document.createRange().createContextualFragment(items.map(_convItemHTML).join(''));
      list.appendChild(frag);
    }
  }

  if (data.has_more) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'inbox-load-more';
    btn.textContent = 'Load more conversations';
    btn.addEventListener('click', () => { state.offset += 100; loadList(true); });
    list.appendChild(btn);
  }
}

// Delegated click handling for conv-items — avoids re-wiring after each list refresh.
document.getElementById('convList').addEventListener('click', e => {
  const item = e.target.closest('.conv-item');
  if (item && item.dataset.id) selectConversation(item.dataset.id);
});

// ===== THREAD =====

// Render a single message for the thread pane. Branches on channel + direction.
function renderMessage(m, channel) {
  const author = m.author_name ? ' · ' + escHTML(m.author_name) : '';
  const time = fmtRelative(m.created_at);

  // ----- System events (CSR Inbox Phase 1: appointment.*, etc.) -----
  // Audit rows (assignment/status changes) are stored as direction='internal'
  // with a "[system] …" body — catch them here so they render as a system pill,
  // NOT as a phone call (on phone conversations they'd otherwise fall through to
  // the phone-call branch below and be drawn as bogus "→ Outbound call" rows).
  if (m.direction === 'system' || (m.direction === 'internal' && String(m.body || '').indexOf('[system]') === 0)) {
    const summary = String(m.body || (m.event_type || 'system event')).replace(/^\[system\]\s*/, '');
    const ev = m.event_type || '';
    const icon = ev.indexOf('appointment.') === 0 ? 'calendar-check' : 'info-circle';
    return `<div class="msg msg-system" data-event="${escHTML(ev)}"><i class="fas fa-${icon}" style="opacity:.75;margin-right:6px"></i>${escHTML(summary)}<div class="msg-meta" style="text-align:center;margin-top:2px">${time}</div></div>`;
  }

  // ----- Phone calls: just a centered pill, no body bubble -----
  // Only real calls (inbound/outbound) render here; internal notes / system
  // audit rows on a phone conversation must NOT be drawn as call pills.
  if (channel === 'phone' && (m.direction === 'inbound' || m.direction === 'outbound')) {
    const icon = m.direction === 'inbound' ? 'phone-volume' : 'phone';
    const arrow = m.direction === 'inbound' ? '←' : '→';
    const recAttr = m.recording_url ? ` data-recording-url="${escHTML(m.recording_url)}"` : '';
    // AI summary card (rendered if present). The recording player is appended
    // afterwards by enhanceRecordings(). Transcript goes in a collapsed
    // <details> so it doesn't dominate the thread.
    let summaryCard = '';
    if (m.summary) {
      const sj = m.summary_json || {};
      const tags = [];
      if (sj.intent && sj.intent !== 'other') tags.push(sj.intent.replace(/_/g, ' '));
      if (sj.pest_type && sj.pest_type !== 'unknown' && sj.pest_type !== 'none') tags.push(sj.pest_type.replace(/_/g, ' '));
      if (sj.urgency === 'high') tags.push('🔥 high urgency');
      if (sj.callback_needed) tags.push('📞 callback needed');
      if (sj.sentiment === 'frustrated' || sj.sentiment === 'negative') tags.push('⚠️ ' + sj.sentiment);
      const tagHtml = tags.length
        ? `<div style="margin-top:4px;display:flex;flex-wrap:wrap;gap:4px">${tags.map(t => `<span style="background:#eef2ff;color:#4338ca;font-size:10px;padding:2px 6px;border-radius:10px;font-weight:500">${escHTML(t)}</span>`).join('')}</div>`
        : '';
      // BUG-012: partial audio warning — if transcribed audio is <90% of call duration, warn the CSR
      const _am = (sj._audio_meta || {});
      const _isPartial = m.transcription_status === 'partial' || (_am.duration_seconds && m.duration_seconds && _am.duration_seconds < m.duration_seconds * 0.9);
      const _partialChip = _isPartial ? '<div style="margin-top:4px;font-size:10px;color:#b45309;background:#fef3c7;padding:3px 8px;border-radius:4px;display:inline-block"><i class="fas fa-exclamation-triangle" style="margin-right:3px"></i>Partial audio — listen to recording for full details</div>' : '';
      // PCI compliance: recording withheld when CC info was detected
      const _ccChip = m.has_credit_card_info ? '<div style="margin-top:4px;font-size:10px;color:#7c3aed;background:#f5f3ff;padding:3px 8px;border-radius:4px;display:inline-block"><i class="fas fa-lock" style="margin-right:3px"></i>Recording withheld — contains payment card data. Transcript digits redacted.</div>' : '';
      summaryCard = `<div style="margin-top:6px;padding:8px 10px;background:linear-gradient(135deg,#eef2ff 0%,#fdf4ff 100%);border-left:3px solid #6366f1;border-radius:6px;font-size:12px;line-height:1.45;color:#1e293b">
          <div style="font-size:10px;font-weight:700;color:#6366f1;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">AI Summary</div>
          <div>${escHTML(m.summary)}</div>
          ${tagHtml}
          ${_partialChip}
          ${_ccChip}
        </div>`;
    } else if (m.has_credit_card_info) {
      // No AI summary yet but CC was detected — show the security notice
      summaryCard = `<div style="margin-top:6px;padding:6px 10px;background:#f5f3ff;border-left:3px solid #7c3aed;border-radius:6px;font-size:11px;color:#5b21b6">
        <i class="fas fa-lock" style="margin-right:4px"></i>Recording unavailable — contains payment card data. Transcript digits have been redacted.
      </div>`;
    } else if (m.recording_url) {
      // BUG-011 upgrade: use transcription_status from BE state machine.
      // States: pending, in_progress, ok, partial, failed, skipped.
      // Age fallback kept as safety net for stale pending messages.
      const _ts = m.transcription_status || '';
      if (_ts === 'failed') {
        summaryCard = `<div style="margin-top:6px;padding:6px 10px;background:#fef3c7;border-radius:6px;font-size:11px;color:#92400e">
          <i class="fas fa-exclamation-triangle" style="margin-right:4px"></i>Transcription failed${m.transcription_attempts ? ' (after ' + m.transcription_attempts + ' attempts)' : ''} — listen to recording.
        </div>`;
      } else if (_ts === 'skipped') {
        summaryCard = `<div style="margin-top:6px;padding:6px 10px;background:#f6f7f9;border-radius:6px;font-size:11px;color:#94a3b8">
          <i class="fas fa-info-circle" style="margin-right:4px"></i>Transcript not available for this call.
        </div>`;
      } else if (_ts === 'pending' || _ts === 'in_progress' || !_ts) {
        // Still processing — show spinner, but cap at 10min age to avoid infinite wait
        const _callAgeMin = (Date.now() - new Date(m.created_at).getTime()) / 60000;
        if (_callAgeMin > 10) {
          summaryCard = `<div style="margin-top:6px;padding:6px 10px;background:#fef3c7;border-radius:6px;font-size:11px;color:#92400e">
            <i class="fas fa-exclamation-triangle" style="margin-right:4px"></i>Transcript unavailable — transcription did not complete for this call.
          </div>`;
        } else {
          summaryCard = `<div style="margin-top:6px;padding:6px 10px;background:#f6f7f9;border-radius:6px;font-size:11px;color:#94a3b8;font-style:italic">
            <i class="fas fa-spinner fa-spin" style="margin-right:4px;opacity:.6"></i>Transcribing call…
          </div>`;
        }
      }
    }
    let transcriptBlock = '';
    if (m.transcript) {
      transcriptBlock = `<details style="margin-top:6px;font-size:11px;color:#475569">
        <summary style="cursor:pointer;color:#64748b;user-select:none">View transcript</summary>
        <div style="margin-top:4px;padding:6px 8px;background:#fafbfc;border-radius:4px;white-space:pre-wrap;line-height:1.5;max-height:240px;overflow-y:auto">${escHTML(m.transcript)}</div>
      </details>`;
    }
    return `<div class="msg-phone" data-msg-id="${m.id}"${recAttr}><i class="fas fa-${icon}"></i> ${arrow} ${escHTML(m.body)}<span style="opacity:.6;margin-left:6px">· ${time}${author}</span>${summaryCard}${transcriptBlock}</div>`;
  }

  // ----- Emails: white card with subject head -----
  if (channel === 'email') {
    const dir = m.direction === 'inbound' ? 'From customer' : (m.direction === 'outbound' ? 'Sent to customer' : 'Note');
    const subj = m.subject ? `<span class="msg-email-subject">${escHTML(m.subject)}</span>` : '<span class="msg-email-subject" style="color:var(--text-light)">(no subject)</span>';
    const status = m.status === 'failed' ? ' <span style="color:#c62828;font-weight:600">· FAILED</span>' : '';
    // If body_html is present, trust it (our own templated outbound emails).
    // Inbound emails will be sanitized at ingest when IMAP is wired up.
    const html = m.body_html
      ? `<div class="msg-email-body">${m.body_html}</div>`
      : `<div class="msg-email-body" style="white-space:pre-wrap">${escHTML(m.body || m.body_text || '')}</div>`;
    // Attachment chips: only non-inline attachments shown as download links;
    // inline images are already wired up via cid: rewriting on the server.
    const fmtSize = b => b<1024 ? b+'B' : b<1048576 ? Math.round(b/1024)+'KB' : (Math.round(b/104857.6)/10)+'MB';
    const _chipList = (m.attachments||[]).filter(a => !a.is_inline).map(a => {
      if (a.file_missing) {
        return `<span class="msg-att-chip msg-att-chip--missing" title="${escHTML(a.filename)} (file no longer available)">` +
          `<i class="fas fa-exclamation-circle"></i><span class="msg-att-name">${escHTML(a.filename)}</span><span class="msg-att-size">unavailable</span></span>`;
      }
      return `<a class="msg-att-chip" href="${escHTML(a.download_url)}" target="_blank" rel="noopener" download="${escHTML(a.filename)}" title="${escHTML(a.filename)} (${fmtSize(a.size_bytes)})">` +
        `<i class="fas fa-paperclip"></i><span class="msg-att-name">${escHTML(a.filename)}</span><span class="msg-att-size">${fmtSize(a.size_bytes)}</span></a>`;
    }).join('');
    const chipsHtml = _chipList ? `<div class="msg-email-attachments">${_chipList}</div>` : '';
    return `<div class="msg msg-email">
      <div class="msg-email-head">
        ${subj}
        <span style="white-space:nowrap">${dir} · ${time}${author}${status}</span>
      </div>
      ${html}${chipsHtml}
    </div>`;
  }

  // ----- SMS link autolinker (Quick-Win #5) -----
  // Wraps bare http(s)/www URLs in <a target="_blank"> tags so SMS chat
  // bubbles render clickable links. Input is already HTML-escaped via
  // escHTML(), so we only see safe text — no XSS surface. We avoid the
  // anchor regex matching inside already-rendered anchors by checking
  // for a preceding `=" ` (attribute boundary) negative.
  function _smsLinkify(safeHtml) {
    // Match http://, https://, or www. URLs, stopping at whitespace
    // or the inserted <br>. Trailing punctuation handled by stripping
    // common terminal chars before closing the anchor.
    return safeHtml.replace(
      /(^|[\s>])((?:https?:\/\/|www\.)[^\s<]+[^\s<.,;:!?)])/g,
      (m, pre, url) => {
        const href = url.startsWith('http') ? url : 'https://' + url;
        return pre + '<a href="' + href + '" target="_blank" rel="noopener noreferrer" style="color:inherit;text-decoration:underline">' + url + '</a>';
      }
    );
  }

  // ----- SMS + internal notes (default chat-bubble layout) -----
  let cls = 'msg ';
  if (m.direction === 'inbound') cls += 'msg-inbound';
  else if (m.direction === 'outbound') cls += 'msg-outbound';
  else cls += 'msg-internal';
  if (m.status === 'failed') cls += ' msg-failed';
  let metaExtras = '';
  if (m.status === 'failed') metaExtras += ' · FAILED';
  // SMS6: per-message intent chip (inbound only — outbound + internal don't
  // run the classifier). Override badge replaces the bare chip when the
  // message has been overridden by a CSR (SMS5 fields).
  let intentBlock = '';
  if (m.direction === 'inbound' && (m.intent || m.intent_override_to)) {
    intentBlock = m.intent_override_to
      ? ' ' + renderIntentOverrideChip(m)
      : ' ' + renderIntentChip(m.intent, m.intent_confidence);
  }
  const _smsInner = _smsLinkify(escHTML(m.body).replace(/\n/g,'<br>'));
  const _bodyDiv = _smsInner ? `<div>${_smsInner}</div>` : '';
  const _teamAtts = (channel === 'team' && m.provider === 'team_chat' && m.team_attachments && m.team_attachments.length)
    ? `<div>${m.team_attachments.map(a => a.is_image
        ? `<a class="team-att" href="${escHTML(a.url)}" target="_blank" rel="noopener"><img src="${escHTML(a.url)}" alt="${escHTML(a.filename)}"></a>`
        : `<a class="team-att" href="${escHTML(a.url)}" target="_blank" rel="noopener">📎 ${escHTML(a.filename)}</a>`).join('')}</div>`
    : '';
  // Inbound MMS media (SimpleTexting): view-links, since their API won't serve
  // the bytes. Shows as chips so the photo/video the customer sent is reachable.
  const _mms = (m.sms_media && m.sms_media.length)
    ? `<div class="msg-mms">${m.sms_media.map((x,i)=>`<a class="mms-chip" href="${escHTML(x.view_url)}" target="_blank" rel="noopener">📷 ${m.sms_media.length>1?('Photo/video '+(i+1)):'Photo/video'} · view ↗</a>`).join('')}</div>`
    : '';
  return `<div class="${cls}">${(channel === 'team' && m.direction === 'inbound' && m.author_name) ? `<div style="font-size:11px;font-weight:700;color:#0b5da8;margin-bottom:2px">${escHTML(m.author_name)} <span style="background:#e3f0fb;border-radius:4px;font-size:9px;padding:0 4px">TECH</span></div>` : ''}${_bodyDiv}${_teamAtts}${_mms}<div class="msg-meta">${time}${author}${metaExtras}${intentBlock}</div></div>`;
}

function closeThreadMobile() {
  const g = document.getElementById('inboxGrid');
  if (g) g.classList.remove('thread-open');
}
async function selectConversation(convId) {
  state.selectedId = convId;
  // Mobile: switch from the list to the full-screen thread pane.
  const _g = document.getElementById('inboxGrid');
  if (_g) _g.classList.add('thread-open');
  if (typeof apptResetForConversation === 'function') apptResetForConversation();
  document.querySelectorAll('.conv-item').forEach(el => el.classList.toggle('active', el.dataset.id === convId));

  document.getElementById('threadBody').textContent = 'Loading…';
  document.getElementById('threadBody').className = 'thread-empty';

  let data;
  try { data = await api('/inbox/' + convId + '/'); }
  catch(e) {
    document.getElementById('threadBody').textContent = 'Error: ' + e.message;
    return;
  }

  const conv = data.conversation, cust = data.customer, msgs = data.messages || [];
  window.__replyAllCc = data.reply_all_cc || [];  // suggested Cc for Reply-All (email)
  state.selectedConv = conv;  // accessible to callCustomer / patchConversation
  state.selectedCustomerId = (cust && cust.id) ? cust.id : null;  // #2: synchronous customer id for the schedule drawer (independent of the async appts fetch)

  // Head
  const head = document.getElementById('threadHead'); head.style.display = 'flex';
  document.getElementById('threadWho').textContent = conv.customer_name || conv.contact_phone || 'Unknown';
  document.getElementById('threadMeta').innerHTML =
    `${escHTML(conv.channel_display)} • ${escHTML(conv.contact_phone || conv.contact_email || '')} • status: ${escHTML(conv.status)}` +
    (conv.assigned_to_name ? ` • assigned: ${escHTML(conv.assigned_to_name)}` : '');

  // Show Reopen vs Take/Close based on status
  const isClosed = (conv.status === 'closed');
  // Call button: show whenever the conversation has a phone number,
  // regardless of channel (lets you call from email/sms threads too).
  document.getElementById('btnCall').style.display = (conv.contact_phone ? '' : 'none');
  document.getElementById('btnAssignMe').style.display = isClosed ? 'none' : '';
  document.getElementById('btnClose').style.display    = isClosed ? 'none' : '';
  document.getElementById('btnReopen').style.display   = isClosed ? '' : 'none';
  // Ignore wrapper hidden on closed convs (you can't ignore-and-close what's already closed).
  document.getElementById('ignoreWrap').style.display  = isClosed ? 'none' : '';
  closeIgnoreMenu();

  // Messages
  const body = document.getElementById('threadBody');
  body.className = 'thread-msgs';
  body.innerHTML = msgs.map(m => renderMessage(m, conv.channel)).join('') || '<div style="text-align:center;color:var(--text-light);padding:30px">No messages yet.</div>';
  body.scrollTop = body.scrollHeight;

  // CSR Inbox Phase 1 — refresh appt card if appointment.* system event arrived.
  if (typeof apptDetectSystemEvents === 'function') apptDetectSystemEvents(msgs);

  // BUG-013: render recording players for phone messages with recording_url
  if (typeof enhanceRecordings === 'function') enhanceRecordings();

  // Reply box — channel-aware
  const replyBox = document.getElementById('replyBox');
  const hint = document.getElementById('replyHint');
  // Reset subject + reply-all rows (only shown for email)
  var _subjRow = document.getElementById('emailSubjectRow');
  if (_subjRow) _subjRow.style.display = 'none';
  var _raRow = document.getElementById('replyAllRow');
  if (_raRow) _raRow.style.display = 'none';
  var _raChk = document.getElementById('chkReplyAll');
  if (_raChk) _raChk.checked = false;
  if (conv.channel === 'sms') {
    replyBox.style.display = 'block';
    hint.textContent = 'SMS reply via SimpleTexting';
  } else if (conv.channel === 'phone') {
    replyBox.style.display = 'block';
    hint.textContent = 'Phone replies save as internal notes (no auto-dial yet)';
  } else if (conv.channel === 'webchat') {
    replyBox.style.display = 'block';
    hint.textContent = 'Webchat reply (delivered to visitor via legacy chat bridge)';
    document.getElementById('chkInternal').checked = false;
  } else if (conv.channel === 'email') {
    replyBox.style.display = 'block';
    hint.textContent = 'Email reply via ' + (window._emailProviderLabel || 'configured provider');
    document.getElementById('chkInternal').checked = false;
    // Show subject row + prefill from latest message
    document.getElementById('emailSubjectRow').style.display = 'block';
    var lastSubj = '';
    for (var i = msgs.length - 1; i >= 0; i--) {
      if (msgs[i] && msgs[i].subject) { lastSubj = msgs[i].subject; break; }
    }
    var subjEl = document.getElementById('replySubject');
    if (lastSubj) {
      subjEl.value = /^re:/i.test(lastSubj.trim()) ? lastSubj.trim() : 'Re: ' + lastSubj.trim();
    } else {
      subjEl.value = '';
      subjEl.placeholder = 'Subject (e.g. Re: Your appointment)';
    }
    // Reply-All toggle: only offered when other people are on the thread.
    var raRow = document.getElementById('replyAllRow');
    var raChk = document.getElementById('chkReplyAll');
    var raCc = document.getElementById('replyAllCc');
    var ccList = window.__replyAllCc || [];
    if (raRow && raChk && raCc) {
      raChk.checked = false;
      raCc.textContent = '';
      if (ccList.length) {
        raRow.style.display = 'block';
        raChk.onchange = function () {
          raCc.textContent = this.checked ? ('Cc: ' + ccList.join(', ')) : '';
        };
      } else {
        raRow.style.display = 'none';
      }
    }
  } else {
    replyBox.style.display = 'none';
  }

  // Customer card
  renderCustomerCard(conv, cust);


  // Refresh list (so unread dot updates after mark-read)
  loadList();
}

function renderCustomerCard(conv, cust) {
  const card = document.getElementById('custCard');
  if (!cust) {
    const _chanLabel = conv.channel === 'phone' ? 'caller' : 'contact';
    const _contactLine = conv.contact_phone
      ? `Phone: ${escHTML(conv.contact_phone)}`
      : conv.contact_email
        ? `Email: ${escHTML(conv.contact_email)}`
        : '—';
    card.innerHTML = `
      <div class="unidentified">
        <strong><i class="fas fa-user-question"></i> Unidentified ${_chanLabel}</strong>
        <p style="margin:6px 0 8px">${_contactLine}</p>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <button type="button" class="btn-icon" id="apptUnknownScheduleBtn" data-conv-phone="${escHTML(conv.contact_phone || '')}" data-conv-id="${escHTML(conv.id || '')}">+ Schedule</button>
          <button type="button" class="btn-icon" id="linkCustomerBtn" data-conv-id="${escHTML(conv.id || '')}"><i class="fas fa-link"></i> Link to Customer</button>
        </div>
      </div>
    `;
    return;
  }
  const stalePill = cust.ai_summary_is_stale ? '<span class="stale-pill">stale</span>' : '';
  card.innerHTML = `
    <div class="cust-name">${escHTML(cust.full_name)}</div>
    <div class="cust-phone">${escHTML(cust.phone || '')}${cust.phone_alt?' / '+escHTML(cust.phone_alt):''}${cust.email?'<span style="margin:0 8px;color:var(--text-light)">·</span>'+escHTML(cust.email):''}</div>
    ${(cust.address || cust.city) ? `<div class="cust-line"><i class="fas fa-map-marker-alt" style="color:var(--text-light);margin-right:4px"></i>${escHTML(cust.address || '')}${cust.city?', '+escHTML(cust.city):''}${cust.state?' '+escHTML(cust.state):''}${cust.zip_code?' '+escHTML(cust.zip_code):''}</div>` : ''}
    <a class="cust-link" href="/customers/${cust.id}/locations/"><i class="fas fa-arrow-right"></i> Open customer record</a>
    <div class="ticket-card-actions">
      <button type="button" class="btn-secondary" id="ticketCreateBtn" data-customer-id="${escHTML(cust.id || '')}" data-customer-name="${escHTML(cust.full_name || '')}"><i class="fas fa-ticket-alt"></i> + New ticket</button>
      <button type="button" class="appt-btn-schedule" id="custScheduleBtn" data-customer-id="${escHTML(cust.id || '')}" title="Schedule an appointment for this customer"><i class="fas fa-calendar-plus"></i> + Schedule</button>
    </div>
    <div id="apptCardHost"></div>
    ${cust.ai_summary ? `
      <div class="cust-section">
        <h4>AI Summary ${stalePill}</h4>
        <div class="cust-summary">${escHTML(cust.ai_summary)}</div>
      </div>
    ` : '<div class="cust-section"><h4>AI Summary</h4><div style="color:var(--text-light);font-size:12px">No summary yet — generated automatically after recent activity.</div></div>'}
  `;
  // CSR Inbox Phase 1 — load appointments card after customer card paints.
  if (typeof loadAppointments === 'function' && cust && cust.id) loadAppointments(cust.id, 'upcoming');
}

// ===== TAKE / CLOSE / REOPEN =====
async function patchConversation(body) {
  if (!state.selectedId) return;
  try {
    await api('/inbox/' + state.selectedId + '/', {
      method: 'PATCH', body: JSON.stringify(body),
    });
    selectConversation(state.selectedId);   // reload thread + customer card
    loadList();                             // counts + assignment update in left pane
  } catch (e) {
    alert('Update failed: ' + e.message);
  }
}

// Click-to-call — POST to the click-to-call endpoint with the conversation's
// contact phone. Backend creates an outbound Message that appears in this
// thread within ~15s (next poll).
async function callCustomer() {
  if (!state.selectedConv || !state.selectedConv.contact_phone) return;
  const btn = document.getElementById('btnCall');
  btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Calling...';
  try {
    // Path is relative to API const = '/api/v1/communications'
    await api('/phone/click-to-call/', {
      method: 'POST',
      body: JSON.stringify({
        to_number: state.selectedConv.contact_phone,
        customer_id: state.selectedConv.customer_id || null,
      }),
    });
    btn.innerHTML = '<i class="fas fa-check"></i> Ringing';
    setTimeout(() => loadList(), 2000);
    setTimeout(() => selectConversation(state.selectedConv.id), 2500);
  } catch (e) {
    alert('Call failed: ' + e.message);
  } finally {
    setTimeout(() => {
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-phone-alt"></i> Call';
    }, 3000);
  }
}
// ===== Inbox toast (success / error) with optional Undo =====
let _inboxToastTimer = null;
function showInboxToast(msg, opts) {
  opts = opts || {};
  const wrap = document.getElementById('inboxToast');
  const span = document.getElementById('inboxToastMsg');
  const undo = document.getElementById('inboxToastUndo');
  if (!wrap || !span) return;
  span.textContent = msg || '';
  wrap.classList.toggle('error', !!opts.error);
  if (typeof opts.undo === 'function') {
    undo.style.display = '';
    undo.onclick = () => {
      hideInboxToast();
      try { opts.undo(); } catch (_) {}
    };
  } else {
    undo.style.display = 'none';
    undo.onclick = null;
  }
  wrap.classList.add('show');
  if (_inboxToastTimer) clearTimeout(_inboxToastTimer);
  _inboxToastTimer = setTimeout(hideInboxToast, opts.duration || 6000);
}
function hideInboxToast() {
  const wrap = document.getElementById('inboxToast');
  if (wrap) wrap.classList.remove('show');
  if (_inboxToastTimer) { clearTimeout(_inboxToastTimer); _inboxToastTimer = null; }
}

// ===== Ignore menu =====
function closeIgnoreMenu() {
  const m = document.getElementById('ignoreMenu');
  if (m) { m.style.display = 'none'; m.setAttribute('aria-hidden', 'true'); }
}
function openIgnoreMenu() {
  const conv = state.selectedConv;
  const menu = document.getElementById('ignoreMenu');
  if (!conv || !menu) return;
  // Build menu items based on what the conversation has
  const email = (conv.contact_email || '').trim();
  const phone = (conv.contact_phone || '').trim();
  const items = [];
  if (email) {
    items.push(`<button type="button" class="ignore-menu-item" data-scope="email" role="menuitem">Ignore <span class="ig-target">${escHTML(email)}</span></button>`);
    const at = email.lastIndexOf('@');
    if (at > 0 && at < email.length - 1) {
      const domain = email.substring(at + 1);
      items.push(`<button type="button" class="ignore-menu-item" data-scope="domain" role="menuitem">Ignore entire domain <span class="ig-target">@${escHTML(domain)}</span></button>`);
    }
  }
  if (phone && (conv.channel === 'phone' || conv.channel === 'sms')) {
    items.push(`<button type="button" class="ignore-menu-item" data-scope="phone" role="menuitem">Ignore <span class="ig-target">${escHTML(phone)}</span></button>`);
  }
  if (!items.length) {
    menu.innerHTML = '<div class="ignore-menu-empty">No sender info to ignore on this conversation.</div>';
  } else {
    menu.innerHTML = items.join('');
    menu.querySelectorAll('.ignore-menu-item').forEach(btn => {
      btn.addEventListener('click', () => ignoreSender(btn.dataset.scope, false));
    });
  }
  menu.style.display = 'block';
  menu.setAttribute('aria-hidden', 'false');
}

// Close the menu on outside click / Escape
document.addEventListener('click', (e) => {
  const wrap = document.getElementById('ignoreWrap');
  if (wrap && !wrap.contains(e.target)) closeIgnoreMenu();
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeIgnoreMenu(); });

// ===== Ignore action — POST /inbox/<id>/ignore/ =====
// Uses raw fetch (not api()) so we can read the 409 customer-collision body.
async function ignoreSender(scope, force) {
  const conv = state.selectedConv;
  if (!conv) return;
  closeIgnoreMenu();
  const target = (scope === 'phone') ? conv.contact_phone
               : (scope === 'domain') ? '@' + (conv.contact_email || '').split('@').pop()
               : conv.contact_email;
  if (!target) return;
  const verb = (scope === 'domain') ? 'every email from' : 'all messages from';
  const ok = window.confirm(
    `Ignore ${verb} ${target}?\n\n` +
    `Future messages will be hidden from your inbox and this conversation will be closed. ` +
    `You can unignore from Settings → Inbox Filters.`
  );
  if (!ok) return;
  const btn = document.getElementById('btnIgnore');
  if (btn) btn.disabled = true;
  try {
    const r = await fetch(API + '/inbox/' + conv.id + '/ignore/', {
      method: 'POST',
      credentials: 'same-origin',
      headers: {'Content-Type': 'application/json', 'X-CSRFToken': csrftoken},
      body: JSON.stringify({scope: scope, force: !!force}),
    });
    let body = null;
    try { body = await r.json(); } catch (_) {}
    if (r.status === 409 && body && body.detail === 'value_matches_customer') {
      const name = body.customer_name || 'a customer';
      if (window.confirm(`WARNING: ${target} belongs to customer ${name}.\n\nIgnore anyway?`)) {
        return ignoreSender(scope, true);
      }
      return;
    }
    if (!r.ok) {
      const msg = window.cbpFormatApiError ? window.cbpFormatApiError(body, 'Failed to ignore.') : (body && (body.detail || body.message)) || ('HTTP ' + r.status);
      showInboxToast(msg, {error: true});
      return;
    }
    // Success — body has the IgnoredSender id. Wire Undo to soft-delete it.
    const ignoredId = body && body.id;
    // Clear the open thread (it's now closed and will be filtered out on reload).
    state.selectedId = null;
    state.selectedConv = null;
    document.getElementById('threadHead').style.display = 'none';
    document.getElementById('replyBox').style.display = 'none';
    document.getElementById('threadBody').className = 'thread-empty';
    document.getElementById('threadBody').innerHTML = 'Conversation ignored.';
    loadList();
    showInboxToast(`Ignored ${target}.`, {
      duration: 8000,
      undo: ignoredId ? (async () => {
        try {
          const dr = await fetch(API + '/ignored-senders/' + ignoredId + '/', {
            method: 'DELETE',
            credentials: 'same-origin',
            headers: {'X-CSRFToken': csrftoken},
          });
          if (!dr.ok) throw new Error('HTTP ' + dr.status);
          showInboxToast(`Restored ${target}.`, {duration: 3000});
          loadList();
        } catch (e) {
          showInboxToast('Undo failed: ' + (e.message || 'unknown'), {error: true});
        }
      }) : null,
    });
  } catch (e) {
    showInboxToast('Network error: ' + (e.message || 'failed'), {error: true});
  } finally {
    if (btn) btn.disabled = false;
  }
}

document.getElementById('btnIgnore').addEventListener('click', (e) => {
  e.stopPropagation();
  const m = document.getElementById('ignoreMenu');
  if (m && m.style.display === 'block') closeIgnoreMenu();
  else openIgnoreMenu();
});

document.getElementById('btnCall').addEventListener('click', callCustomer);

  // ===== New conversation composer (Item 6): SMS / Email / Call + lookup =====
  (function _wireNewMessage(){
    const overlay = document.getElementById('nmOverlay');
    if (!overlay) return;
    const titleEl  = document.getElementById('nmTitle');
    const searchEl = document.getElementById('nmSearch');
    const resultsEl= document.getElementById('nmResults');
    const pickedEl = document.getElementById('nmPickedChip');
    const phoneEl  = document.getElementById('nmPhone');
    const emailEl  = document.getElementById('nmEmail');
    const subjEl   = document.getElementById('nmSubject');
    const bodyEl   = document.getElementById('nmBody');
    const rowPhone = document.getElementById('nmRowPhone');
    const rowEmail = document.getElementById('nmRowEmail');
    const rowBody  = document.getElementById('nmRowBody');
    const sendBtn  = document.getElementById('nmSend');
    let mode = 'sms';
    let pickedCustomerId = '';
    let searchTimer = null;
    const TITLES = { sms:'&#128172; New text message', email:'&#9993;&#65039; New email', call:'&#128222; New outbound call' };
    const SEND_LABELS = { sms:'<i class="fas fa-paper-plane"></i> Send', email:'<i class="fas fa-paper-plane"></i> Send', call:'<i class="fas fa-phone-alt"></i> Call' };
    function clearPicked(){ pickedCustomerId=''; if(pickedEl){ pickedEl.style.display='none'; pickedEl.innerHTML=''; } }
    function applyMode(m){
      mode=m;
      if(titleEl) titleEl.innerHTML = TITLES[m] || TITLES.sms;
      if(sendBtn) sendBtn.innerHTML = SEND_LABELS[m] || SEND_LABELS.sms;
      if(rowPhone) rowPhone.style.display = (m==='email') ? 'none' : '';
      if(rowEmail) rowEmail.style.display = (m==='email') ? '' : 'none';
      if(rowBody)  rowBody.style.display  = (m==='call')  ? 'none' : '';
    }
    function open(m){
      applyMode(m);
      if(searchEl) searchEl.value='';
      if(resultsEl){ resultsEl.style.display='none'; resultsEl.innerHTML=''; }
      if(phoneEl) phoneEl.value=''; if(emailEl) emailEl.value=''; if(subjEl) subjEl.value=''; if(bodyEl) bodyEl.value='';
      clearPicked();
      overlay.classList.add('show'); overlay.setAttribute('aria-hidden','false');
      setTimeout(function(){ (searchEl||phoneEl||{focus:function(){}}).focus(); },30);
    }
    function close(){ overlay.classList.remove('show'); overlay.setAttribute('aria-hidden','true'); }
    function renderResults(rows){
      if(!resultsEl) return;
      if(!rows || !rows.length){ resultsEl.style.display='none'; resultsEl.innerHTML=''; return; }
      resultsEl.innerHTML='';
      rows.slice(0,8).forEach(function(c){
        const div=document.createElement('div'); div.className='nm-result';
        const nm = c.name || c.full_name || ((c.first_name||'')+' '+(c.last_name||'')).trim() || c.company_name || '(no name)';
        const sub = [c.phone, c.email].filter(Boolean).join('  -  ');
        div.innerHTML = '<div class="nm-result-name">'+escHTML(nm)+'</div>'+(sub?'<div class="nm-result-sub">'+escHTML(sub)+'</div>':'');
        div.addEventListener('click', function(){ pickCustomer(c, nm); });
        resultsEl.appendChild(div);
      });
      resultsEl.style.display='';
    }
    function pickCustomer(c, nm){
      pickedCustomerId = c.id || c.customer_id || '';
      if(phoneEl && c.phone) phoneEl.value=c.phone;
      if(emailEl && c.email) emailEl.value=c.email;
      if(resultsEl){ resultsEl.style.display='none'; resultsEl.innerHTML=''; }
      if(searchEl) searchEl.value='';
      if(pickedEl){
        pickedEl.style.display='flex';
        pickedEl.innerHTML='<span>Linked: '+escHTML(nm)+'</span><button type="button" class="nm-picked-x" title="Unlink">&times;</button>';
        const x=pickedEl.querySelector('.nm-picked-x'); if(x) x.addEventListener('click', clearPicked);
      }
    }
    function doSearch(q){
      fetch('/api/v1/customer-search/?q='+encodeURIComponent(q), {credentials:'same-origin'})
        .then(function(r){ return r.ok ? r.json() : null; })
        .then(function(d){ if(!d){ renderResults([]); return; } const rows = Array.isArray(d) ? d : (d.results || d.customers || []); renderResults(rows); })
        .catch(function(){ renderResults([]); });
    }
    if(searchEl){
      searchEl.addEventListener('input', function(){
        const q=(searchEl.value||'').trim();
        if(searchTimer) clearTimeout(searchTimer);
        if(q.length<2){ renderResults([]); return; }
        searchTimer=setTimeout(function(){ doSearch(q); },250);
      });
    }
    async function send(){
      const body=(bodyEl && bodyEl.value || '').trim();
      if(mode==='call'){
        const phone=(phoneEl.value||'').trim();
        if(!phone){ showInboxToast('Enter or pick a phone number',{error:true}); phoneEl.focus(); return; }
        sendBtn.disabled=true; const o=sendBtn.innerHTML; sendBtn.innerHTML='<i class="fas fa-spinner fa-spin"></i> Calling...';
        try{
          const payload={to_number:phone}; if(pickedCustomerId) payload.customer_id=pickedCustomerId;
          await api('/phone/click-to-call/', {method:'POST', body: JSON.stringify(payload)});
          close(); showInboxToast('Calling '+phone+'...');
        }catch(e){ showInboxToast('Could not place call: '+((e&&e.message)?e.message:'error'),{error:true,duration:9000}); }
        finally{ sendBtn.disabled=false; sendBtn.innerHTML=o; }
        return;
      }
      if(mode==='email'){
        const email=(emailEl.value||'').trim(); const subject=(subjEl.value||'').trim();
        if(!email){ showInboxToast('Enter or pick an email address',{error:true}); emailEl.focus(); return; }
        if(!body){ showInboxToast('Enter a message',{error:true}); bodyEl.focus(); return; }
        sendBtn.disabled=true; const o=sendBtn.innerHTML; sendBtn.innerHTML='<i class="fas fa-spinner fa-spin"></i> Sending...';
        try{
          const payload={channel:'email', email:email, subject:subject, body:body}; if(pickedCustomerId) payload.customer_id=pickedCustomerId;
          const resp = await api('/inbox/start/', {method:'POST', body: JSON.stringify(payload)});
          close(); showInboxToast((resp && resp.created) ? 'New email conversation started' : 'Email sent');
          try{ if(typeof state==='object' && state){ state.status='open'; } }catch(_){}
          await loadList(); if(resp && resp.conversation_id){ selectConversation(resp.conversation_id); }
        }catch(e){ showInboxToast('Could not send: '+((e&&e.message)?e.message:'error'),{error:true,duration:9000}); }
        finally{ sendBtn.disabled=false; sendBtn.innerHTML=o; }
        return;
      }
      const phone=(phoneEl.value||'').trim();
      if(!phone){ showInboxToast('Enter or pick a phone number',{error:true}); phoneEl.focus(); return; }
      if(!body){ showInboxToast('Enter a message',{error:true}); bodyEl.focus(); return; }
      sendBtn.disabled=true; const o=sendBtn.innerHTML; sendBtn.innerHTML='<i class="fas fa-spinner fa-spin"></i> Sending...';
      try{
        const payload={phone:phone, body:body}; if(pickedCustomerId) payload.customer_id=pickedCustomerId;
        const resp = await api('/inbox/start/', {method:'POST', body: JSON.stringify(payload)});
        close(); showInboxToast((resp && resp.created) ? 'New conversation started' : 'Message sent');
        try{ if(typeof state==='object' && state){ state.status='open'; } }catch(_){}
        await loadList(); if(resp && resp.conversation_id){ selectConversation(resp.conversation_id); }
      }catch(e){ showInboxToast('Could not send: '+((e&&e.message)?e.message:'error'),{error:true,duration:9000}); }
      finally{ sendBtn.disabled=false; sendBtn.innerHTML=o; }
    }
    const bSms=document.getElementById('btnNewSms'), bEmail=document.getElementById('btnNewEmail'), bCall=document.getElementById('btnNewCall');
    if(bSms)   bSms.addEventListener('click', function(){ open('sms'); });
    if(bEmail) bEmail.addEventListener('click', function(){ open('email'); });
    if(bCall)  bCall.addEventListener('click', function(){ open('call'); });
    document.getElementById('nmClose').addEventListener('click', close);
    document.getElementById('nmCancel').addEventListener('click', close);
    sendBtn.addEventListener('click', send);
    overlay.addEventListener('click', function(e){ if(e.target===overlay) close(); });
    document.addEventListener('keydown', function(e){ if(e.key==='Escape' && overlay.classList.contains('show')) close(); });
    if(bodyEl) bodyEl.addEventListener('keydown', function(e){ if((e.metaKey||e.ctrlKey) && e.key==='Enter'){ e.preventDefault(); send(); } });
  })();
document.getElementById('btnAssignMe').addEventListener('click', () => patchConversation({assigned_to: 'me'}));
document.getElementById('btnClose').addEventListener('click', () => patchConversation({status: 'closed'}));
document.getElementById('btnReopen').addEventListener('click', () => patchConversation({status: 'open'}));

// ===== REPLY =====
// ATTACHMENTS_UI_WIRED — file picker state + handlers
const MAX_ATTACH_BYTES = 3 * 1024 * 1024;  // 3 MB total raw payload
// Graph's sendMail caps at ~4 MB request body; base64 inflates ~33% so 3 MB
// raw leaves headroom for headers, MIME boundaries, body text/html.
let _selectedFiles = [];

function _humanSize(bytes) {
  if (bytes < 1024) return bytes + 'B';
  if (bytes < 1024*1024) return (bytes/1024).toFixed(0) + 'KB';
  return (bytes/(1024*1024)).toFixed(1) + 'MB';
}

function _refreshAttachChips() {
  const wrap = document.getElementById('attachChips');
  wrap.innerHTML = '';
  _selectedFiles.forEach((f, idx) => {
    const chip = document.createElement('span');
    chip.className = 'attach-chip';
    chip.innerHTML = `<span class="attach-chip-name">${escHTML(f.name)}</span><span class="attach-chip-size">${_humanSize(f.size)}</span><button class="attach-chip-x" type="button" title="Remove">×</button>`;
    chip.querySelector('.attach-chip-x').addEventListener('click', () => {
      _selectedFiles.splice(idx, 1);
      _refreshAttachChips();
    });
    wrap.appendChild(chip);
  });
}

function _showAttachError(msg) {
  const el = document.getElementById('attachError');
  if (msg) { el.textContent = msg; el.style.display = 'block'; }
  else { el.textContent = ''; el.style.display = 'none'; }
}

document.getElementById('btnAttach').addEventListener('click', () => {
  // Block attachments on internal notes — they're CRM-only, can't send via Graph.
  if (document.getElementById('chkInternal').checked) {
    _showAttachError('Internal notes cannot have attachments.');
    return;
  }
  document.getElementById('fileInput').click();
});

document.getElementById('fileInput').addEventListener('change', (e) => {
  _showAttachError('');
  const newFiles = Array.from(e.target.files || []);
  // Compute total size including already-selected files
  const totalNew = newFiles.reduce((s, f) => s + f.size, 0);
  const totalExisting = _selectedFiles.reduce((s, f) => s + f.size, 0);
  if (totalNew + totalExisting > MAX_ATTACH_BYTES) {
    _showAttachError(`Total attachment size would exceed 3 MB (${_humanSize(totalNew + totalExisting)}). Pick smaller or fewer files.`);
    e.target.value = '';
    return;
  }
  _selectedFiles = _selectedFiles.concat(newFiles);
  _refreshAttachChips();
  // Reset input so picking the same file again triggers change
  e.target.value = '';
});

// ----- Paste-image handler (Quick-Win #2) ---------------------------------
// Catch image blobs pasted into the reply composer (Cmd/Ctrl+V or right-click
// "Paste") and route them through the same _selectedFiles pipeline as the
// paperclip picker. Honors the same internal-note block and MAX_ATTACH_BYTES
// cap. Non-image clipboard content (plain text) falls through untouched so
// normal pasting into the textarea still works.
document.getElementById('replyText').addEventListener('paste', (e) => {
  const cd = e.clipboardData || window.clipboardData;
  if (!cd || !cd.items) return;
  const imageItems = Array.from(cd.items).filter(it => it.kind === 'file' && it.type && it.type.startsWith('image/'));
  if (imageItems.length === 0) return;  // No image -> let default paste happen.

  // Block paste-image on internal notes, same as paperclip.
  if (document.getElementById('chkInternal').checked) {
    e.preventDefault();
    _showAttachError('Internal notes cannot have attachments.');
    return;
  }

  e.preventDefault();
  _showAttachError('');
  const newFiles = [];
  const now = new Date();
  // ISO-ish stamp safe for filenames: YYYY-MM-DD_HHmmss
  const stamp = now.toISOString().replace(/[:T]/g, '-').slice(0, 19);
  imageItems.forEach((it, idx) => {
    const blob = it.getAsFile();
    if (!blob) return;
    // Browsers paste blobs as "image.png" with no useful name. Stamp it.
    const ext = (blob.type.split('/')[1] || 'png').toLowerCase().replace(/[^a-z0-9]/g, '') || 'png';
    const named = new File(
      [blob],
      `pasted-${stamp}${imageItems.length > 1 ? '-' + (idx + 1) : ''}.${ext}`,
      { type: blob.type, lastModified: now.getTime() }
    );
    newFiles.push(named);
  });
  if (newFiles.length === 0) return;
  const totalNew = newFiles.reduce((s, f) => s + f.size, 0);
  const totalExisting = _selectedFiles.reduce((s, f) => s + f.size, 0);
  if (totalNew + totalExisting > MAX_ATTACH_BYTES) {
    _showAttachError(`Pasted image too large. Total would exceed 3 MB (${_humanSize(totalNew + totalExisting)}).`);
    return;
  }
  _selectedFiles = _selectedFiles.concat(newFiles);
  _refreshAttachChips();
});

async function sendReply() {
  // Suppress the polling tick for the duration of the send + a grace
  // window. The send already calls loadList() / selectConversation()
  // explicitly when it succeeds; we don't want a stale poll to land on
  // top of those and re-render with pre-send data.
  if (typeof window.suppressPollFor === 'function') window.suppressPollFor(8000);
  const ta = document.getElementById('replyText');
  const text = ta.value.trim();
  if (!text || !state.selectedId) return;
  const internal = document.getElementById('chkInternal').checked;

  // Email-channel: subject required (unless internal note)
  const subjEl = document.getElementById('replySubject');
  const subjRow = document.getElementById('emailSubjectRow');
  const isEmail = subjRow && subjRow.style.display !== 'none';
  const raChk = document.getElementById('chkReplyAll');
  const replyAll = isEmail && !internal && raChk && raChk.checked;
  let subject = '';
  if (isEmail && !internal) {
    subject = (subjEl && subjEl.value || '').trim();
    if (!subject) {
      alert('Subject is required for email replies.');
      subjEl && subjEl.focus();
      return;
    }
  }

  // Internal notes can't have attachments — block at submit too in case
  // user toggled the checkbox after picking files.
  if (internal && _selectedFiles.length) {
    alert('Internal notes cannot have attachments. Uncheck "Internal note" or remove the files.');
    return;
  }

  const hasFiles = _selectedFiles.length > 0;
  const btn = document.getElementById('btnSend'); btn.disabled = true;
  try {
    let resp;
    if (hasFiles) {
      // Multipart path. api() doesn't support FormData, so call fetch directly
      // and replicate the oauth_required handling from api().
      const fd = new FormData();
      fd.append('body', text);
      fd.append('internal', internal ? '1' : '0');
      if (subject) fd.append('subject', subject);
      if (replyAll) fd.append('reply_all', '1');
      _selectedFiles.forEach(f => fd.append('attachments', f, f.name));
      const r = await fetch(API + '/inbox/' + state.selectedId + '/reply/', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {'X-CSRFToken': csrftoken},  // NO Content-Type — browser sets multipart boundary
        body: fd,
      });
      if (!r.ok) {
        let body = null, msg = '';
        try { body = await r.json(); msg = body.message || body.detail || body.error || ''; } catch(_) {}
        if (body && body.oauth_required && body.redirect_url) {
          throw new OAuthRequiredError(body.redirect_url, msg);
        }
        throw new Error(`${r.status} ${r.statusText}${msg ? ': ' + msg : ''}`);
      }
      resp = await r.json();
    } else {
      const payload = {body: text, internal};
      if (subject) payload.subject = subject;
      if (replyAll) payload.reply_all = true;
      resp = await api('/inbox/' + state.selectedId + '/reply/', {
        method: 'POST', body: JSON.stringify(payload)
      });
    }
    // If backend returned 201 with a body.error string, surface it (failed but recorded)
    if (resp && resp.error) {
      alert('Email send recorded as failed: ' + resp.error);
    }
    ta.value = '';
    document.getElementById('chkInternal').checked = false;
    if (raChk) { raChk.checked = false; var _raCcEl = document.getElementById('replyAllCc'); if (_raCcEl) _raCcEl.textContent = ''; }
    _selectedFiles = [];
    _refreshAttachChips();
    _showAttachError('');
    autoSize(ta);
    selectConversation(state.selectedId);   // refresh thread
  } catch(e) {
    if (e && e.name === 'OAuthRequiredError') {
      // First reply attempt or refresh-token revoked: redirect to
      // /oauth/microsoft/start/?next=... and complete OAuth round trip.
      // After return the user clicks Send again (their text is still in
      // the textarea because we didn't clear it on error).
      const msg = document.createElement('div');
      msg.style.cssText = 'position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#2563eb;color:#fff;padding:10px 16px;border-radius:8px;z-index:9999;font-size:13px;box-shadow:0 4px 12px rgba(0,0,0,.15)';
      msg.textContent = 'Connecting your Microsoft account...';
      document.body.appendChild(msg);
      setTimeout(() => { window.location.href = e.redirectUrl; }, 400);
      return;
    }
    alert('Send failed: ' + (e && e.message ? e.message : e));
  } finally {
    // F-032 R13: after a successful send the textarea is cleared, so the
    // button should stay disabled until the user types again. On error we
    // leave the text in place, so the button should be re-enabled.
    btn.disabled = !ta.value.trim();
  }
}

// ===== EVENTS =====
function autoSize(ta) {
  ta.style.height = 'auto';
  ta.style.height = Math.min(140, ta.scrollHeight) + 'px';
}

document.getElementById('btnSend').addEventListener('click', sendReply);
// ===== Quick replies (canned responses) in the composer =====
(function(){
  async function loadQuickReplies(){
    var bar=document.getElementById('qrBar'); if(!bar) return;
    try{
      var r=await fetch('/api/v1/communications/canned-responses/',{headers:{'Accept':'application/json'},credentials:'same-origin'});
      if(!r.ok) return;
      var d=await r.json();
      var items=Array.isArray(d)?d:(d.results||[]);
      items=items.filter(function(it){return it && it.is_active!==false && it.body;});
      bar.innerHTML='';
      items.forEach(function(it){
        var c=document.createElement('button');
        c.type='button'; c.className='qr-chip'; c.textContent=it.title||'Quick reply';
        c.title=it.body;
        c.addEventListener('click',function(){ insertQuickReply(it.body); });
        bar.appendChild(c);
      });
    }catch(e){}
  }
  function insertQuickReply(body){
    var ta=document.getElementById('replyText'); if(!ta) return;
    var cur=ta.value||'';
    ta.value = cur ? (cur.replace(/\s+$/,'') + '\n' + body) : body;
    ta.focus();
    ta.dispatchEvent(new Event('input',{bubbles:true}));
  }
  loadQuickReplies();
})();
// F-032 R13: keep Send disabled until the reply textarea has a non-whitespace
// value. Reset on send is handled by sendReply() clearing the textarea, then
// dispatching 'input' would normally re-disable; we re-disable explicitly
// after clearing to avoid relying on event bubbling.
document.getElementById('replyText').addEventListener('input', e => {
  autoSize(e.target);
  const btn = document.getElementById('btnSend');
  if (btn) btn.disabled = !e.target.value.trim();
});
document.getElementById('replyText').addEventListener('keydown', e => {
  if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); sendReply(); }
});
document.getElementById('searchInp').addEventListener('input', debounce(e => { state.q = e.target.value.trim(); loadList(); }, 300));

document.querySelectorAll('#statusTabs .tab').forEach(el => {
  el.addEventListener('click', () => {
    if (!el.dataset.status) return;  // skip non-status tabs in this row (e.g. #tabMine)
    document.querySelectorAll('#statusTabs .tab[data-status]').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
    state.status = el.dataset.status;
    loadList();
  });
});
document.querySelectorAll('#channelTabs .tab').forEach(el => {
  el.addEventListener('click', () => {
    document.querySelectorAll('#channelTabs .tab').forEach(t => t.classList.remove('active'));
    el.classList.add('active');
    state.channel = el.dataset.channel;
    loadList();
  });
});
// "Mine" lives in the status row but is an independent toggle:
// it composes with the active channel filter (backend supports mine=1 + channel=*).
(() => {
  const mineEl = document.getElementById('tabMine');
  if (!mineEl) return;
  mineEl.addEventListener('click', () => {
    state.mine = !state.mine;
    mineEl.classList.toggle('active', state.mine);
    loadList();
  });
})();

// Slice D3: intent filter dropdown — narrows by Conversation.last_intent.
(() => {
  const sel = document.getElementById('intentFilter');
  if (!sel) return;
  sel.addEventListener('change', () => {
    state.intent = sel.value || 'all';
    loadList();
  });
})();

function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

// ===== POLLING (guarded against user-interaction) =====
//
// The inbox SPA-loads, so this script may run multiple times in one page-
// session. Cancel any previous interval before registering a new one;
// otherwise timers stack and the effective rate compounds (we observed
// ~5s under the literal 15000ms because three intervals were live).
if (state.refreshTimer) {
  clearInterval(state.refreshTimer);
  state.refreshTimer = null;
}

// Action handlers (sendReply, future Take/Close) call suppressPollFor()
// on entry to keep stale poll responses from clobbering optimistic UI.
state.pollSuppressUntil = 0;
window.suppressPollFor = function(ms) {
  state.pollSuppressUntil = Date.now() + (ms || 5000);
};

// True when polling would yank UI out from under the CSR. We skip poll
// ticks (not just the thread re-render) — list re-renders also reset
// scroll, selection highlight, and any open hover/menu state.
function _userIsInteracting() {
  if (document.hidden) return true;
  if (Date.now() < state.pollSuppressUntil) return true;
  // Recent mouse/keyboard/scroll/touch activity → CSR is reading or
  // navigating. Don't yank the DOM out from under them.
  if (state.lastUserActivity && (Date.now() - state.lastUserActivity) < 5000) return true;
  const a = document.activeElement;
  if (a) {
    const tag = a.tagName;
    if (tag === 'TEXTAREA' || tag === 'INPUT' || tag === 'SELECT') return true;
    if (a.isContentEditable) return true;
  }
  // Any visible modal-overlay (matches the convention used across templates).
  const modals = document.querySelectorAll('.modal-overlay');
  for (let i = 0; i < modals.length; i++) {
    const s = modals[i].style.display;
    if (s && s !== 'none') return true;
  }
  return false;
}

// CSR Inbox Issue #1 fix — track user activity so polling can defer to
// "user is reading" without exhaustive event-by-event handling. 5s debounce
// in _userIsInteracting() above covers the typical reading cadence.
state.lastUserActivity = state.lastUserActivity || 0;
(function _trackInboxActivity() {
  function bump() { state.lastUserActivity = Date.now(); }
  ['mousemove', 'mousedown', 'keydown', 'wheel', 'touchstart'].forEach(function(ev) {
    window.addEventListener(ev, bump, { passive: true });
  });
  // Scroll uses capture:true so we catch scroll inside .pane-list, .pane-thread, etc.
  document.addEventListener('scroll', bump, { passive: true, capture: true });
})();

// True when the thread contains a playing <audio> element. We use this
// to decide whether to re-render the thread on poll — replacing the
// thread DOM kills audio playback (the <audio> node is recreated).
function _threadAudioPlaying() {
  const audios = document.querySelectorAll('#threadBody audio');
  for (let i = 0; i < audios.length; i++) {
    const a = audios[i];
    if (!a.paused && !a.ended) return true;
  }
  return false;
}

loadList();
state.refreshTimer = setInterval(() => {
  // Skip the entire tick if the user is mid-interaction. Polling resumes
  // automatically next tick — at most 25s of staleness, which is fine.
  if (_userIsInteracting()) return;

  loadList();
  if (state.selectedId) {
    const body = document.getElementById('threadBody');
    const nearBottom = body && (body.scrollHeight - body.scrollTop - body.clientHeight < 100);
    // Re-fetch the thread only when (a) user is reading the latest, and
    // (b) no audio is playing — reloading would wipe the player to 0:00.
    if (nearBottom && !_threadAudioPlaying()) {
      selectConversation(state.selectedId);
    }
  }
  document.getElementById('inboxStatus').textContent = 'Updated ' + new Date().toLocaleTimeString();
}, 25000);

document.getElementById('inboxStatus').textContent = 'Updated ' + new Date().toLocaleTimeString();

// ---- call recording inline player ----
// Phone messages with a recording_url get an <audio controls> appended.
// Streamed lazily from /api/v1/communications/messages/<id>/recording/ which
// SFTPs from the PBX. Range-supported so scrubbing works.
function enhanceRecordings() {
  document.querySelectorAll('[data-msg-id][data-recording-url]:not([data-rec-rendered])')
    .forEach(function(el) {
      var msgId = el.getAttribute('data-msg-id');
      var url = el.getAttribute('data-recording-url');
      if (!msgId || !url) return;
      var wrap = document.createElement('div');
      wrap.style.cssText = 'margin-top:6px;padding:6px 8px;background:#f6f7f9;border-radius:6px';
      wrap.innerHTML = '<div style="font-size:11px;color:#666;margin-bottom:4px">' +
                       '<span style="color:#999">Recording</span></div>' +
                       '<audio controls preload="none" style="width:100%;height:32px" ' +
                       'src="/api/v1/communications/messages/' + msgId + '/recording/"></audio>';
      el.appendChild(wrap);
      el.setAttribute('data-rec-rendered', '1');
    });
}
// BUG-013: monkey-patch removed — lexical scope prevented it from intercepting
// selectConversation calls. Direct call added inside selectConversation instead.

// ===== OAuth connection status pill (#10) =====
const oauthPill = document.getElementById("oauthPill");

async function fetchOAuthStatus(){
  try{
    const r = await fetch("/oauth/microsoft/status/", {credentials:"same-origin"});
    if(!r.ok) return null;
    return await r.json();
  }catch(e){ console.warn("oauth status fetch failed", e); return null; }
}

function renderOAuthPill(s){
  if(!oauthPill) return;
  oauthPill.style.display = "none"; return;  /* hide the "M365 not connected" pill in the read-only demo */
  if(!s){ oauthPill.style.display = "none"; return; }
  oauthPill.style.display = "inline-flex";
  oauthPill.classList.remove("connected", "needs-reconnect", "disconnected");
  if(s.connected){
    oauthPill.classList.add("connected");
    oauthPill.innerHTML = `<i class="fas fa-check-circle"></i><span>Connected: ${escHTML(s.mailbox_email||"")}</span>` +
      `<button class="oauth-disco" type="button" id="oauthDiscoBtn">Disconnect</button>`;
    oauthPill.onclick = null;
    document.getElementById("oauthDiscoBtn")?.addEventListener("click", handleDisconnect);
  } else if(s.needs_reconnect){
    oauthPill.classList.add("needs-reconnect");
    const _nextR = encodeURIComponent(window.location.pathname + window.location.search);
    oauthPill.innerHTML = `<a href="/oauth/microsoft/start/?next=${_nextR}" data-no-spa style="display:inline-flex;align-items:center;gap:6px;color:inherit;text-decoration:none;cursor:pointer"><i class="fas fa-exclamation-triangle"></i><span>Reconnect required</span></a>`;
    oauthPill.onclick = null;
  } else {
    oauthPill.classList.add("disconnected");
    const _nextD = encodeURIComponent(window.location.pathname + window.location.search);
    oauthPill.innerHTML = `<a href="/oauth/microsoft/start/?next=${_nextD}" data-no-spa style="display:inline-flex;align-items:center;gap:6px;color:inherit;text-decoration:none;cursor:pointer"><i class="fas fa-plug"></i><span>M365 not connected — click to connect</span></a>`;
    oauthPill.onclick = null;
  }
}

async function handleDisconnect(ev){
  ev.stopPropagation();
  if(!confirm("Disconnect Microsoft 365? You'll need to reconnect before sending email replies.")) return;
  const csrf = (document.cookie.match(/csrftoken=([^;]+)/)||[])[1] ||
               document.querySelector("[name=csrfmiddlewaretoken]")?.value || "";
  try{
    const r = await fetch("/oauth/microsoft/disconnect/", {
      method: "POST",
      headers: {"X-CSRFToken": csrf, "Accept":"application/json"},
      credentials: "same-origin",
    });
    if(!r.ok){ alert("Disconnect failed: HTTP "+r.status); return; }
  }catch(e){ alert("Disconnect failed: "+e.message); return; }
  const s = await fetchOAuthStatus();
  renderOAuthPill(s);
}

fetchOAuthStatus().then(renderOAuthPill);
if(new URLSearchParams(window.location.search).get("oauth_connected") === "microsoft"){
  setTimeout(()=>fetchOAuthStatus().then(renderOAuthPill), 300);
}


// ===== CSR Inbox — Appointments card (Phase 1: read-only) =====
// Read-only list of a customer's appointments in the right rail.
// Endpoints (all gated server-side by HasAppointmentPerm + HasFeatureFlag):
//   GET /api/v1/customers/{id}/appointments/?scope=upcoming|past|all
// Forward-compat: appointment.* system events in the thread refresh the card.

const apptState = {
  customerId: null,
  scope: 'upcoming',
  // Last seen system-event message id per conversation, used to detect new
  // appointment.* events and trigger a refresh without polling the appt API
  // every 15s. Cleared on conversation switch.
  lastSysMsgId: null,
  // In-flight request token — discards stale responses if the user
  // switches conversations or tabs faster than the network.
  reqToken: 0,
  expanded: false,            // "Show more" expander state for upcoming
  pastCursor: null,           // cursor returned by past pagination
  pastAccumulated: [],        // accumulated past rows when paginating
  // Disabled forwards-compat: false until phase 2 ships the schedule drawer.
  // Wrapped in apptCanManage() so we can wire the perm check later.
  canManage: true,
};

// Small wrapper around fetch that prepends /api/v1, sends CSRF, and surfaces
// 403/404 quietly (returns null) so we can hide the card when the user lacks
// view perm or the feature flag is off for the tenant.
async function apptApi(path, opts) {
  opts = opts || {};
  const r = await fetch('/api/v1' + path, {
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': csrftoken,
      'Accept': 'application/json',
      ...(opts.headers || {}),
    },
    ...opts,
  });
  if (r.status === 403 || r.status === 404) {
    // 403: missing csr.appointments.view. 404: feature flag off OR customer
    // not in tenant. Either way, treat as "card unavailable" — caller hides.
    return { _hidden: true, _status: r.status };
  }
  if (!r.ok) {
    let detail = '';
    try { const b = await r.json(); detail = b.detail || b.error || ''; } catch (_) {}
    throw new Error(`${r.status} ${r.statusText}${detail ? ': ' + detail : ''}`);
  }
  return r.json();
}

// Status pill HTML. Brief uses American "canceled"; model uses British
// "cancelled". CSS handles both class spellings; we use the canonical
// model value for the class so future status filters match server-side.
function apptStatusPill(status) {
  const cls = (status || 'scheduled').toLowerCase().replace(/-/g, '_');
  const labels = {
    scheduled: 'Scheduled', confirmed: 'Confirmed',
    in_progress: 'In progress', completed: 'Completed',
    cancelled: 'Canceled', canceled: 'Canceled',
    no_show: 'No-show', rescheduled: 'Rescheduled',
  };
  const label = labels[cls] || cls;
  return `<span class="pill ${cls}">${escHTML(label)}</span>`;
}

// "Tomorrow · 9:00 AM" / "May 6, 1:30 PM" — relative when within 6 days,
// absolute otherwise. Uses the customer's stored TZ if available later;
// for now uses the browser TZ which equals the tenant TZ for City Best.
function apptFmtWhen(iso) {
  if (!iso) return { rel: '—', abs: '' };
  const tz = window._tenantTz || 'America/New_York';
  const d = new Date(iso);
  // Compare calendar dates in the tenant timezone to determine relative labels.
  const todayStr = new Date().toLocaleDateString('en-CA', { timeZone: tz });
  const dayStr   = d.toLocaleDateString('en-CA', { timeZone: tz });
  const dayDelta = Math.round((new Date(dayStr) - new Date(todayStr)) / 86400000);
  const time = d.toLocaleTimeString('en-US', { timeZone: tz, hour: 'numeric', minute: '2-digit' });
  let rel;
  if (dayDelta === 0)      rel = `Today · ${time}`;
  else if (dayDelta === 1) rel = `Tomorrow · ${time}`;
  else if (dayDelta === -1) rel = `Yesterday · ${time}`;
  else if (dayDelta > 1 && dayDelta < 7) rel = `${d.toLocaleDateString('en-US', { timeZone: tz, weekday: 'long' })} · ${time}`;
  else if (dayDelta < 0 && dayDelta > -7) rel = `Last ${d.toLocaleDateString('en-US', { timeZone: tz, weekday: 'long' })} · ${time}`;
  else rel = `${d.toLocaleDateString('en-US', { timeZone: tz, month: 'short', day: 'numeric' })} · ${time}`;
  const abs = d.toLocaleDateString('en-US', { timeZone: tz, year: 'numeric', month: 'short', day: 'numeric' });
  return { rel, abs };
}

// Single appointment row.
function apptRowHtml(a) {
  const when = apptFmtWhen(a.start_at);
  const svc = a.service ? a.service.name : 'Service';
  const dur = a.duration_min ? `${a.duration_min}m` : '';
  const tech = a.technician;
  const techHtml = tech
    ? `<span class="tech-avatar" title="${escHTML(tech.name || '')}">${escHTML(tech.initials || '?')}</span><span class="tech-name">${escHTML(tech.name || '')}</span>`
    : `<span class="tech-name" style="color:var(--text-light);font-style:italic">Unassigned</span>`;
  const addr = (a.location && a.location.address) ? a.location.address : '';
  const conflicts = a.has_conflicts ? `<span class="conflicts-flag" title="Overlaps another appointment">⚠ conflict</span>` : '';
  // Pre-charge flag — only show when meaningful (failed/auto_cancelled), not
  // for the default not_due/skipped/succeeded states which clutter the row.
  let prechargeFlag = '';
  if (a.precharge_status === 'failed') {
    prechargeFlag = `<span class="precharge-flag failed" title="Pre-charge failed — awaiting customer">⚡ pay failed</span>`;
  } else if (a.precharge_status === 'auto_cancelled') {
    prechargeFlag = `<span class="precharge-flag auto_cancelled" title="Auto-cancelled for non-payment">⚡ auto-cancelled</span>`;
  }
  // Instruction/notes indicators — one compact line per non-empty field so
  // CSRs see site + visit instructions at a glance (full text in Edit notes).
  const site = a.site || {};
  const noteItems = [
    ['🔑', 'Site access', (site.access && site.access.text) || ''],
    ['⚠️', 'Site special', (site.special && site.special.text) || ''],
    ['🔑', 'Visit access', a.visit_access_instructions || ''],
    ['📝', 'Visit notes', a.appointment_notes || a.customer_notes || ''],
    ['🔒', 'Internal', a.internal_notes || ''],
  ];
  const noteFlag = noteItems
    .filter(it => (it[2] || '').trim())
    .map(it => {
      const t = it[2].trim();
      const short = t.length > 40 ? t.slice(0, 40) + '…' : t;
      return `<div class="note-flag"><span class="note-icon">${it[0]}</span><span><strong>${escHTML(it[1])}:</strong> ${escHTML(short)}</span></div>`;
    })
    .join('');

  // Phase 1: kebab is rendered but disabled (manage actions ship in phase 2-3).
  // The hover-revealed kebab still indicates affordance is coming.
  // Phase 2: kebab is enabled and opens an action menu (event-delegated).
  // Items: Edit notes (always), Reschedule (placeholder, ships in Phase 3),
  // Cancel (upcoming/scheduled), Open in Appointments page.
  const kebab = apptState.canManage
    ? `<button class="row-kebab" data-appt-id="${escHTML(a.id)}" type="button" aria-label="Appointment actions" aria-haspopup="menu" aria-expanded="false" title="Actions">⋯</button>`
    : '';

  // Slice 4B: pending-reminders badge. Renders only when at least one
  // pending reminder exists for this appt. Click toggles an inline
  // timeline; the list is lazy-fetched on first open so we don't
  // inflate the inbox payload with reminders for every visible appt.
  const reminderCount = a.pending_reminder_count || 0;
  const reminderBadge = reminderCount > 0
    ? `<button class="reminder-toggle" type="button" data-appt-id="${escHTML(a.id)}" aria-expanded="false" aria-controls="rt-${escHTML(a.id)}" title="${reminderCount} pending reminder${reminderCount === 1 ? '' : 's'}"><span class="rt-icon">🔔</span>${reminderCount}</button>`
    : '';

  return `<div class="appt-row" data-appt-id="${escHTML(a.id)}">
    <div>${apptStatusPill(a.status)}${conflicts}${prechargeFlag}${reminderBadge}</div>
    <div><span class="when">${escHTML(when.rel)}</span><span class="when-abs">${escHTML(when.abs)}</span>${a.arrival_window_label ? `<span class="when-abs" style="color:#2E7D32" title="Customer-facing arrival window">🕑 ${escHTML(a.arrival_window_label)}</span>` : ''}</div>
    <div class="svc-line">${escHTML(svc)}${dur ? ' · ' + escHTML(dur) : ''}</div>
    <div class="tech-line">${techHtml}${addr ? `<span class="addr" title="${escHTML(addr)}">· ${escHTML(addr)}</span>` : ''}</div>
    ${noteFlag}
    <div class="reminder-timeline" id="rt-${escHTML(a.id)}" data-appt-id="${escHTML(a.id)}" data-loaded="0"></div>
    ${kebab}
  </div>`;
}

// Past-tab summary line: "12 completed · 1 no-show · 2 canceled · last service Apr 28."
function apptPastSummary(rows) {
  if (!rows || !rows.length) return '';
  const counts = { completed: 0, no_show: 0, cancelled: 0 };
  let lastCompleted = null;
  rows.forEach(r => {
    const s = (r.status || '').toLowerCase().replace(/-/g, '_');
    if (counts[s] !== undefined) counts[s]++;
    if (s === 'completed' && r.start_at && (!lastCompleted || r.start_at > lastCompleted)) {
      lastCompleted = r.start_at;
    }
  });
  const parts = [];
  if (counts.completed) parts.push(`${counts.completed} completed`);
  if (counts.no_show)   parts.push(`${counts.no_show} no-show`);
  if (counts.cancelled) parts.push(`${counts.cancelled} canceled`);
  if (lastCompleted) {
    const d = new Date(lastCompleted);
    parts.push(`last service ${d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`);
  }
  return parts.length ? `<div class="appt-past-summary">${escHTML(parts.join(' · '))}</div>` : '';
}

// Render the card given a server payload.
function renderApptCard(host, payload, scope) {
  if (!host) return;
  const rows = (payload && payload.results) || [];
  const tabHtml = ['upcoming', 'past', 'all'].map(s =>
    `<button class="appt-tab${s === scope ? ' active' : ''}" data-scope="${s}">${s.charAt(0).toUpperCase() + s.slice(1)}</button>`
  ).join('');

  // Cap visible rows: brief says 3 default for upcoming, 10 for past.
  const visibleCap = (scope === 'upcoming' && !apptState.expanded) ? 3 : rows.length;
  const visible = rows.slice(0, visibleCap);
  const hiddenCount = rows.length - visible.length;

  let body;
  if (!rows.length) {
    body = scope === 'upcoming'
      ? `<div class="appt-empty">No upcoming appointments.<br><button class="appt-empty-action" id="apptEmptyScheduleBtn" title="Schedule an appointment for this customer">+ Schedule</button></div>`
      : (scope === 'past'
          ? `<div class="appt-empty">No past appointments.</div>`
          : `<div class="appt-empty">No appointments yet.</div>`);
  } else {
    const summary = scope === 'past' ? apptPastSummary(rows) : '';
    body = summary +
      `<div class="appt-list">${visible.map(apptRowHtml).join('')}</div>` +
      (hiddenCount > 0
        ? `<button class="appt-show-more" data-action="expand">Show ${hiddenCount} more</button>`
        : (payload.next_cursor && scope !== 'upcoming'
            ? `<button class="appt-show-more" data-action="loadmore">Load more</button>`
            : ''));
  }

  // Brief: header has count chip from upcoming.total. We have rows.length on
  // the current page; if there's a next_cursor, show "N+" to hint there's
  // more. For the upcoming tab specifically (which is what the chip
  // represents), this is the visible count + any collapsed.
  const countLabel = (rows.length + (payload.next_cursor ? '+' : ''));
  host.innerHTML = `
    <div class="appt-card" id="apptCard">
      <div class="appt-head">
        <h4>Appointments</h4>
        <span class="appt-count" title="${rows.length} ${scope}">${countLabel}</span>
        <div class="appt-head-spacer"></div>
        <button class="appt-btn-schedule" id="apptScheduleBtn" title="Schedule an appointment for this customer">
          + Schedule
        </button>
        <button class="appt-btn-kebab" id="apptHeadKebab" title="Open in Appointments page">⋮</button>
      </div>
      <div class="appt-tabs" role="tablist">${tabHtml}</div>
      ${body}
    </div>
  `;

  // Tab switching
  host.querySelectorAll('.appt-tab').forEach(t => {
    t.addEventListener('click', () => {
      apptState.scope = t.dataset.scope;
      apptState.expanded = false;
      apptState.pastCursor = null;
      apptState.pastAccumulated = [];
      loadAppointments(apptState.customerId, apptState.scope);
    });
  });

  // Show more (upcoming expander) / Load more (past pagination)
  const sm = host.querySelector('.appt-show-more');
  if (sm) {
    sm.addEventListener('click', () => {
      if (sm.dataset.action === 'expand') {
        apptState.expanded = true;
        loadAppointments(apptState.customerId, apptState.scope);
      } else if (sm.dataset.action === 'loadmore' && payload.next_cursor) {
        apptState.pastCursor = payload.next_cursor;
        loadAppointments(apptState.customerId, apptState.scope, { append: true });
      }
    });
  }

  // Header kebab — deep link to /appointments/ filtered by customer.
  // Brief calls for a menu; phase 1 just links out (matches existing
  // "Open customer record" pattern).
  const headKebab = host.querySelector('#apptHeadKebab');
  if (headKebab) {
    headKebab.addEventListener('click', () => {
      window.location.href = `/appointments/?customer=${encodeURIComponent(apptState.customerId)}`;
    });
  }
}

// Skeleton state while fetching.
function renderApptSkeleton(host) {
  if (!host) return;
  host.innerHTML = `
    <div class="appt-card">
      <div class="appt-head">
        <h4>Appointments</h4>
        <span class="appt-count">…</span>
      </div>
      <div class="appt-skeleton">
        <div class="appt-skel-row"></div>
        <div class="appt-skel-row"></div>
        <div class="appt-skel-row"></div>
      </div>
    </div>
  `;
}

// Error state with retry.
function renderApptError(host, msg) {
  if (!host) return;
  host.innerHTML = `
    <div class="appt-card">
      <div class="appt-head"><h4>Appointments</h4></div>
      <div class="appt-error">
        Couldn't load: ${escHTML(msg || 'unknown error')}
        <button class="appt-retry" id="apptRetryBtn">Retry</button>
      </div>
    </div>
  `;
  const btn = host.querySelector('#apptRetryBtn');
  if (btn) btn.addEventListener('click', () => loadAppointments(apptState.customerId, apptState.scope));
}

// Fetch + render. Honors `apptState.reqToken` to discard stale responses.
async function loadAppointments(customerId, scope, opts) {
  opts = opts || {};
  const host = document.getElementById('apptCardHost');
  if (!host) return;
  if (!customerId) {
    host.innerHTML = '';
    return;
  }
  apptState.customerId = customerId;
  apptState.scope = scope || 'upcoming';

  // Issue a new token; if token mismatches by the time we get a response,
  // we drop the result on the floor (user already moved on).
  const myToken = ++apptState.reqToken;

  // Skeleton only on first paint per (customer, scope) pair.
  if (!opts.append && !host.querySelector('.appt-card')) {
    renderApptSkeleton(host);
  }

  // Limit: 3 visible by default for upcoming, 10 for past per brief.
  // We over-fetch by a few so "Show N more" can do its job without a refetch.
  const limit = apptState.scope === 'upcoming' ? 10 : 10;
  const params = new URLSearchParams({ scope: apptState.scope, limit: String(limit) });
  if (opts.append && apptState.pastCursor) params.set('cursor', apptState.pastCursor);

  let data;
  try {
    data = await apptApi(`/customers/${encodeURIComponent(customerId)}/appointments/?${params}`);
  } catch (e) {
    if (myToken !== apptState.reqToken) return;
    renderApptError(host, e.message);
    return;
  }
  if (myToken !== apptState.reqToken) return;
  if (data && data._hidden) {
    // Feature flag off or no perm — hide silently.
    host.innerHTML = '';
    return;
  }

  // Append mode: merge new rows into accumulated and render as one.
  if (opts.append) {
    apptState.pastAccumulated = apptState.pastAccumulated.concat(data.results || []);
    renderApptCard(host, {
      results: apptState.pastAccumulated,
      next_cursor: data.next_cursor,
    }, apptState.scope);
  } else {
    apptState.pastAccumulated = data.results || [];
    renderApptCard(host, data, apptState.scope);
  }
}

// Detect appointment.* system events in the message list and refresh the
// card. Called from selectConversation after messages are loaded. Compares
// against the last-seen system message id to avoid refresh storms when the
// thread re-renders without any new events.
function apptDetectSystemEvents(msgs) {
  if (!msgs || !msgs.length) return false;
  let newest = null;
  for (let i = msgs.length - 1; i >= 0; i--) {
    const m = msgs[i];
    if (m && m.direction === 'system' && m.event_type
        && m.event_type.indexOf('appointment.') === 0) {
      newest = m.id; break;
    }
  }
  if (newest && newest !== apptState.lastSysMsgId) {
    apptState.lastSysMsgId = newest;
    if (apptState.customerId) loadAppointments(apptState.customerId, apptState.scope);
    return true;
  }
  return false;
}

// Reset state when the user switches conversations (or deselects). Prevents
// stale cursor / expander / sysmsg state from leaking across customers.
function apptResetForConversation() {
  apptState.lastSysMsgId = null;
  apptState.expanded = false;
  apptState.pastCursor = null;
  apptState.pastAccumulated = [];
  apptState.scope = 'upcoming';
  apptState.reqToken++;
}

// =============================================================================
// CSR Inbox — Appointment row actions (Phase 2)
//
// Wires the per-row kebab menu (placeholder added in Phase 1) to three live
// actions: Edit notes, Cancel, Open in Appointments page. Reschedule is shown
// but disabled — the slot picker ships in Phase 3.
//
// Endpoints (all gated server-side by HasAppointmentPerm + csr_inbox_appointments
// flag; fields sourced from scheduling/views_csr_inbox.py):
//   PATCH /api/v1/appointments/{id}/notes/   body: {internal_notes?, customer_notes?, conversation_id?}
//   PATCH /api/v1/appointments/{id}/cancel/  body: {reason: {code, comment}, notify_customer: {channel}, conversation_id?, refund_prepay?}
//
// Permission gating: there's no /api/v1/auth/me/ endpoint and adding one is
// out of scope for this task (Python change). For now we render all kebab
// items and rely on server-side 403s to enforce — a friendly toast surfaces
// the denial. Phase 4 (or a follow-up) can add a perms endpoint and gate
// items client-side.
// =============================================================================

// ---------------- Helpers: PATCH wrapper with structured errors ----------------
// The legacy api() helper prepends API='/api/v1/communications' AND throws
// plain Error objects without status/data. Neither fits us. apptApi() exists
// for GETs at /api/v1/* — we add the PATCH/POST sibling here.
async function apptApiPatch(path, body, opts) {
  opts = opts || {};
  const url = '/api/v1' + path;
  const csrf = (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';
  const r = await fetch(url, {
    method: opts.method || 'PATCH',
    credentials: 'same-origin',
    headers: {'Content-Type': 'application/json', 'X-CSRFToken': csrf},
    body: JSON.stringify(body || {}),
    signal: opts.signal,
  });
  let data = null;
  try { data = await r.json(); } catch (_) { /* empty body or non-json */ }
  if (r.ok) return data;
  const msg = (data && (data.error || data.detail)) || (r.status + ' ' + r.statusText);
  const err = new Error(msg);
  err.status = r.status;
  err.data = data || {};
  throw err;
}

// ---------------- Toast helper ----------------
function apptToast(msg, kind) {
  let host = document.getElementById('apptToastHost');
  if (!host) {
    host = document.createElement('div');
    host.id = 'apptToastHost';
    host.className = 'appt-toast-host';
    document.body.appendChild(host);
  }
  const k = kind || 'info';
  const ICONS = { success: '✓', error: '!', info: 'i' };
  const t = document.createElement('div');
  t.className = 'appt-toast kind-' + k;
  t.setAttribute('role', k === 'error' ? 'alert' : 'status');
  t.setAttribute('aria-live', k === 'error' ? 'assertive' : 'polite');
  t.innerHTML = `<span class="toast-icon">${escHTML(ICONS[k] || 'i')}</span><span class="toast-msg"></span><button class="toast-close" aria-label="Dismiss">&times;</button>`;
  t.querySelector('.toast-msg').textContent = msg || '';
  t.querySelector('.toast-close').addEventListener('click', () => t.remove());
  host.appendChild(t);
  // Auto-dismiss after 4.5s for success, 7s for error/info (give CSR time to read).
  const ttl = k === 'success' ? 4500 : 7000;
  setTimeout(() => { if (t.parentNode) t.remove(); }, ttl);
}

// ---------------- Map BE error codes to friendly messages ----------------
function apptFriendlyErr(err) {
  const d = (err && err.data) || {};
  const map = {
    feature_disabled:           'Appointment management is disabled for this workspace.',
    appointment_not_found:      'Appointment not found.',
    invalid_state_transition:   'That action isn\'t allowed in the current status.',
    reason_required:            'A reason is required.',
    override_reason_required:   'An override reason is required.',
    override_not_permitted:     'You don\'t have permission to override conflicts.',
    backdate_not_permitted:     'Cannot reschedule into the past.',
    invalid_status:             'Invalid status for this action.',
  };
  if (d.error && map[d.error]) return map[d.error];
  if (err && err.status === 403) return "You don't have permission to do that.";
  if (err && err.status === 404) return 'That appointment is no longer available.';
  if (d.error)  return 'Error: ' + d.error;
  if (d.detail) return d.detail;
  return (err && err.message) || 'Something went wrong.';
}

// ---------------- Modal scaffolding (single-instance; only one modal at a time) ----------------
const apptModal = { rootEl: null, prevFocusEl: null, keyHandler: null };

function apptModalOpen(opts) {
  apptModalClose(); // close any existing modal first
  apptModal.prevFocusEl = document.activeElement;
  const overlay = document.createElement('div');
  overlay.className = 'appt-modal-overlay';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-labelledby', 'apptModalTitle');
  overlay.innerHTML = `
    <div class="appt-modal" role="document">
      <div class="appt-modal-head">
        <h3 id="apptModalTitle">${escHTML(opts.title || '')}</h3>
        <button class="modal-close" type="button" aria-label="Close">&times;</button>
      </div>
      <div class="appt-modal-body">${opts.bodyHtml || ''}</div>
      <div class="appt-modal-foot">${opts.footerHtml || ''}</div>
    </div>`;
  document.body.appendChild(overlay);
  apptModal.rootEl = overlay;
  // Click the overlay (but not the inner modal) to close.
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) apptModalClose();
  });
  overlay.querySelector('.modal-close').addEventListener('click', apptModalClose);
  // Esc to close + Tab focus trap.
  apptModal.keyHandler = function (e) {
    if (e.key === 'Escape') { apptModalClose(); return; }
    if (e.key === 'Tab') apptModalTrapFocus(e);
  };
  document.addEventListener('keydown', apptModal.keyHandler, true);
  // Focus the first focusable element. Defer so animation in doesn't race.
  setTimeout(() => {
    const first = overlay.querySelector('textarea, select, input:not([type="hidden"]), button:not(.modal-close)');
    if (first) first.focus();
  }, 30);
  if (typeof opts.onOpen === 'function') opts.onOpen(overlay);
}

function apptModalClose() {
  if (!apptModal.rootEl) return;
  if (apptModal.keyHandler) document.removeEventListener('keydown', apptModal.keyHandler, true);
  apptModal.keyHandler = null;
  apptModal.rootEl.remove();
  apptModal.rootEl = null;
  if (apptModal.prevFocusEl && apptModal.prevFocusEl.focus) {
    try { apptModal.prevFocusEl.focus(); } catch (e) { /* ignore */ }
  }
  apptModal.prevFocusEl = null;
}

function apptModalTrapFocus(e) {
  const root = apptModal.rootEl;
  if (!root) return;
  const focusable = Array.from(root.querySelectorAll(
    'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
  ));
  if (!focusable.length) return;
  const first = focusable[0], last = focusable[focusable.length - 1];
  if (e.shiftKey && document.activeElement === first) {
    e.preventDefault(); last.focus();
  } else if (!e.shiftKey && document.activeElement === last) {
    e.preventDefault(); first.focus();
  }
}

// ---------------- Per-row kebab popover ----------------
const apptRowMenu = { el: null, btn: null, dismiss: null };

function apptOpenRowMenu(apptId, kebabBtn) {
  apptCloseRowMenu();
  const appt = apptFindAppt(apptId);
  if (!appt) return;
  const status = (appt.status || '').toLowerCase().replace(/-/g, '_');
  const isUpcomingScheduled = (status === 'scheduled' || status === 'confirmed');
  const menu = document.createElement('div');
  menu.className = 'appt-row-menu';
  menu.setAttribute('role', 'menu');
  menu.innerHTML = [
    `<button type="button" role="menuitem" data-action="edit_notes"><span class="menu-icon">📝</span>Edit notes</button>`,
    isUpcomingScheduled
      ? `<button type="button" role="menuitem" data-action="edit_appointment"><span class="menu-icon">✏️</span>Edit</button>`
      : '',
    isUpcomingScheduled
      ? `<button type="button" role="menuitem" data-action="reschedule"><span class="menu-icon">📅</span>Reschedule</button>`
      : '',
    isUpcomingScheduled
      ? `<button type="button" role="menuitem" class="menu-danger" data-action="cancel"><span class="menu-icon">✕</span>Cancel</button>`
      : '',
    `<button type="button" role="menuitem" data-action="generate_contract"><span class="menu-icon">📄</span>Generate contract</button>`,
    `<div class="menu-divider"></div>`,
    `<button type="button" role="menuitem" data-action="open_page"><span class="menu-icon">↗</span>Open in Appointments</button>`,
  ].join('');
  document.body.appendChild(menu);

  // Position below the kebab, right-aligned. If it would overflow viewport, flip up.
  const rect = kebabBtn.getBoundingClientRect();
  menu.style.top = (rect.bottom + 4) + 'px';
  menu.style.left = Math.max(8, rect.right - menu.offsetWidth) + 'px';
  if (menu.getBoundingClientRect().bottom > window.innerHeight - 8) {
    menu.style.top = (rect.top - menu.offsetHeight - 4) + 'px';
  }

  apptRowMenu.el = menu;
  apptRowMenu.btn = kebabBtn;
  kebabBtn.setAttribute('aria-expanded', 'true');

  // Click on a menu item dispatches the action.
  // CRITICAL: stop propagation so the document-level click delegation
  // (which ALSO matches button[data-action="reschedule"] inside .appt-row-menu)
  // does not fire a second time and create a duplicate drawer.
  menu.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-action]');
    if (!b || b.disabled) return;
    e.preventDefault();
    e.stopPropagation();
    const action = b.dataset.action;
    apptCloseRowMenu();
    apptDispatchRowAction(action, apptId);
  });

  // Dismiss on outside click or Esc.
  apptRowMenu.dismiss = function (e) {
    if (e.type === 'keydown' && e.key !== 'Escape') return;
    if (e.type === 'click' && menu.contains(e.target)) return;
    apptCloseRowMenu();
  };
  setTimeout(() => {
    document.addEventListener('click', apptRowMenu.dismiss, true);
    document.addEventListener('keydown', apptRowMenu.dismiss, true);
    const firstItem = menu.querySelector('button:not([disabled])');
    if (firstItem) firstItem.focus();
  }, 0);
}

function apptCloseRowMenu() {
  if (apptRowMenu.dismiss) {
    document.removeEventListener('click', apptRowMenu.dismiss, true);
    document.removeEventListener('keydown', apptRowMenu.dismiss, true);
    apptRowMenu.dismiss = null;
  }
  if (apptRowMenu.btn) apptRowMenu.btn.setAttribute('aria-expanded', 'false');
  if (apptRowMenu.el) apptRowMenu.el.remove();
  apptRowMenu.el = null;
  apptRowMenu.btn = null;
}

function apptDispatchRowAction(action, apptId) {
  if (action === 'edit_notes') return apptOpenNotesModal(apptId);
  if (action === 'edit_appointment') return apptOpenEditModal(apptId);
  if (action === 'cancel')     return apptOpenCancelModal(apptId);
  if (action === 'reschedule') return openScheduleDrawer({ mode: 'reschedule', apptId: apptId });
  if (action === 'generate_contract') return apptOpenGenerateContractModal(apptId);
  if (action === 'open_page')  { window.location.href = '/appointments/?customer=' + encodeURIComponent(apptState.customerId || ''); return; }
}

// Find an appt object in current state. Phase 1 keeps results in
// apptState.pastAccumulated for past pagination; for upcoming/all, the
// renderer holds them transiently. Track them here so action handlers
// can prefill modals without re-fetching.
function apptFindAppt(apptId) {
  if (!apptId) return null;
  const all = (apptState._lastResults || []).concat(apptState.pastAccumulated || []);
  return all.find(x => x && x.id === apptId) || null;
}

// ---------------- Notes modal ----------------
// Short hint clarifying where site-level edits land: a named commercial
// service location, or the customer record (residential).
function apptSiteScopeHint(appt) {
  const site = appt && appt.site;
  if (!site) return '';
  if (site.source === 'location') return ' — ' + escHTML(site.location_name || 'this location');
  if (site.source === 'customer') return ' — customer record';
  return '';
}
function apptOpenNotesModal(apptId) {
  const appt = apptFindAppt(apptId);
  if (!appt) { apptToast('Could not find that appointment.', 'error'); return; }
  const summary = apptModalSummary(appt);
  apptModalOpen({
    title: 'Edit notes',
    bodyHtml: `
      <div class="summary-line">${summary}</div>
      <div class="notes-group-label">Site <span class="label-hint">(applies to all visits at this site${apptSiteScopeHint(appt)})</span></div>
      <div class="field">
        <label for="apptNotesSiteAccess">Access Instructions (Site level) <span class="label-hint">(gate codes, parking, key location)</span></label>
        <textarea id="apptNotesSiteAccess" maxlength="2000" placeholder="e.g. Gate code 1234; lockbox on side door"></textarea>
      </div>
      <div class="field">
        <label for="apptNotesSiteSpecial">Special Instructions (Site level)</label>
        <textarea id="apptNotesSiteSpecial" maxlength="2000" placeholder="e.g. Beware of dog; treat garage every visit"></textarea>
      </div>
      <div class="notes-group-label">This visit <span class="label-hint">(this appointment only)</span></div>
      <div class="field">
        <label for="apptNotesVisitAccess">Access Instructions (this visit)</label>
        <textarea id="apptNotesVisitAccess" maxlength="2000" placeholder="e.g. Gate code changed to 9876 for today"></textarea>
      </div>
      <div class="field">
        <label for="apptNotesAppt">Appointment Notes (this visit) <span class="label-hint">(office &amp; technician)</span></label>
        <textarea id="apptNotesAppt" maxlength="2000" placeholder="Notes for the office and the tech on this visit"></textarea>
      </div>
      <div class="field">
        <label for="apptNotesIntern">Internal note <span class="label-hint">(staff only &mdash; never shown to the customer)</span></label>
        <textarea id="apptNotesIntern" maxlength="2000" placeholder="Staff-only note (other CSRs, dispatchers and techs)"></textarea>
      </div>
      <div id="apptNotesErr" class="field-error" style="display:none"></div>`,
    footerHtml: `
      <div class="foot-spacer"></div>
      <button type="button" class="btn" id="apptNotesCancel">Cancel</button>
      <button type="button" class="btn btn-primary" id="apptNotesSave">Save</button>`,
    onOpen: function (root) {
      const site = appt.site || {};
      root.querySelector('#apptNotesSiteAccess').value = (site.access && site.access.text) || '';
      root.querySelector('#apptNotesSiteSpecial').value = (site.special && site.special.text) || '';
      root.querySelector('#apptNotesVisitAccess').value = appt.visit_access_instructions || '';
      root.querySelector('#apptNotesAppt').value = appt.appointment_notes || appt.customer_notes || '';
      root.querySelector('#apptNotesIntern').value = appt.internal_notes || '';
      // Optimistic-concurrency: remember the notes version we loaded; sent back
      // on save so a stale form can't silently overwrite a newer edit.
      apptNotesBaseVersion = appt.notes_version || '';
      apptNotesForce = false;
      root.querySelector('#apptNotesCancel').addEventListener('click', apptModalClose);
      root.querySelector('#apptNotesSave').addEventListener('click', () => apptSubmitNotes(apptId, root));
    },
  });
}

// Optimistic-concurrency state for the notes modal (set on open).
let apptNotesBaseVersion = '';
let apptNotesForce = false;

async function apptSubmitNotes(apptId, root) {
  const saveBtn = root.querySelector('#apptNotesSave');
  const cancelBtn = root.querySelector('#apptNotesCancel');
  const errEl = root.querySelector('#apptNotesErr');
  saveBtn.disabled = true; cancelBtn.disabled = true;
  errEl.style.display = 'none';
  const body = {
    site_access_instructions: root.querySelector('#apptNotesSiteAccess').value,
    site_special_instructions: root.querySelector('#apptNotesSiteSpecial').value,
    visit_access_instructions: root.querySelector('#apptNotesVisitAccess').value,
    appointment_notes: root.querySelector('#apptNotesAppt').value,
    internal_notes: root.querySelector('#apptNotesIntern').value,
    base_version: apptNotesBaseVersion,
    conversation_id: (window.state && state.selectedId) || '',
  };
  if (apptNotesForce) body.force_notes_overwrite = true;
  try {
    await apptApiPatch('/appointments/' + encodeURIComponent(apptId) + '/notes/', body);
  } catch (e) {
    saveBtn.disabled = false; cancelBtn.disabled = false;
    // Lost-update guard tripped: someone saved these notes since we opened.
    if (e && e.status === 409 && e.data && e.data.error === 'notes_conflict') {
      apptRenderNotesConflict(root, e.data);
      return;
    }
    errEl.textContent = apptFriendlyErr(e);
    errEl.style.display = '';
    return;
  }
  apptModalClose();
  apptToast('Notes saved.', 'success');
  // System-event bus will trigger loadAppointments() automatically. Nothing
  // to do here — but guard against the bus missing the message: re-load
  // after a short delay if no event has arrived.
  apptOptimisticReload();
}

// Render the lost-update warning inside the notes modal: who changed it, with
// a "Load their version" button (pulls the current server values into the form)
// and arming the Save button to overwrite on the next click.
function apptRenderNotesConflict(root, data) {
  const errEl = root.querySelector('#apptNotesErr');
  const saveBtn = root.querySelector('#apptNotesSave');
  const cur = (data && data.current) || {};
  const c = (data && data.conflict) || {};
  const who = c.by || 'Someone else';
  let when = '';
  try { if (c.at) when = ' at ' + new Date(c.at).toLocaleString(); } catch (_) {}
  errEl.innerHTML = '';
  const msg = document.createElement('div');
  msg.textContent = '⚠️ ' + who + ' changed these notes' + when +
    ' while you had this open. Load their version to see it, or click Save again to overwrite it with yours.';
  const reload = document.createElement('button');
  reload.type = 'button';
  reload.className = 'btn';
  reload.style.marginTop = '8px';
  reload.textContent = 'Load their version';
  reload.addEventListener('click', function () {
    root.querySelector('#apptNotesVisitAccess').value = cur.visit_access_instructions || '';
    root.querySelector('#apptNotesAppt').value = cur.appointment_notes || cur.customer_notes || '';
    root.querySelector('#apptNotesIntern').value = cur.internal_notes || '';
    const site = cur.site || {};
    root.querySelector('#apptNotesSiteAccess').value = (site.access && site.access.text) || '';
    root.querySelector('#apptNotesSiteSpecial').value = (site.special && site.special.text) || '';
    apptNotesBaseVersion = cur.notes_version || (c.current_version || '');
    apptNotesForce = false;
    errEl.style.display = 'none';
    saveBtn.textContent = 'Save';
  });
  errEl.appendChild(msg);
  errEl.appendChild(reload);
  errEl.style.display = '';
  // Next Save click overwrites (unless they reload first, which clears this).
  apptNotesForce = true;
  apptNotesBaseVersion = c.current_version || apptNotesBaseVersion;
  saveBtn.textContent = 'Save over theirs';
}

// ---------------- Cancel modal ----------------
// Cancel reason codes MUST match the BE allowlist in
// scheduling/services_csr_inbox.py CANCEL_REASON_CODES. Expanded 2026-09-16
// with actionable reasons so cancellations become learnable.
const APPT_CANCEL_REASONS = [
  ['customer_canceled',    'Customer changed their mind / cancelled'],
  ['schedule_conflict',    "Time didn't work / didn't agree to time"],
  ['price_concern',        'Price too high / no pricing given at booking'],
  ['questions_unanswered', 'Questions not answered before booking'],
  ['agreement_terms',      'Not OK with agreement / contract terms'],
  ['competitor',           'Went with another company'],
  ['dissatisfied',         'Unhappy with prior service'],
  ['no_longer_needed',     'No longer needs service'],
  ['duplicate',            'Duplicate booking'],
  ['tech_unavailable',     "We couldn't staff it"],
  ['weather',              'Weather'],
  ['other',                'Other (specify below)'],
];

function apptOpenCancelModal(apptId) {
  const appt = apptFindAppt(apptId);
  if (!appt) { apptToast('Could not find that appointment.', 'error'); return; }
  const summary = apptModalSummary(appt);
  const reasonOpts = APPT_CANCEL_REASONS
    .map(([v, l]) => `<option value="${escHTML(v)}">${escHTML(l)}</option>`)
    .join('');
  apptModalOpen({
    title: 'Cancel appointment',
    bodyHtml: `
      <div class="summary-line">${summary}</div>
      <div class="field">
        <label for="apptCancelReason">Reason <span class="label-hint">(required)</span></label>
        <select id="apptCancelReason">${reasonOpts}</select>
      </div>
      <div class="field">
        <label for="apptCancelComment">Comment <span class="label-hint">(optional, but required if "Other")</span></label>
        <textarea id="apptCancelComment" maxlength="500" placeholder="What happened?"></textarea>
      </div>
      <div class="field">
        <label class="checkbox-row">
          <input type="checkbox" id="apptCancelNotify" checked>
          <span>Notify the customer (uses default channel)</span>
        </label>
      </div>
      <div id="apptCancelErr" class="field-error" style="display:none"></div>`,
    footerHtml: `
      <div class="foot-spacer"></div>
      <button type="button" class="btn" id="apptCancelBack">Back</button>
      <button type="button" class="btn btn-danger" id="apptCancelConfirm">Cancel appointment</button>`,
    onOpen: function (root) {
      root.querySelector('#apptCancelBack').addEventListener('click', apptModalClose);
      root.querySelector('#apptCancelConfirm').addEventListener('click', () => apptSubmitCancel(apptId, root));
    },
  });
}

async function apptSubmitCancel(apptId, root) {
  const confirmBtn = root.querySelector('#apptCancelConfirm');
  const backBtn = root.querySelector('#apptCancelBack');
  const errEl = root.querySelector('#apptCancelErr');
  const code = root.querySelector('#apptCancelReason').value;
  const comment = root.querySelector('#apptCancelComment').value.trim();
  const notify = root.querySelector('#apptCancelNotify').checked;

  // Client-side validation for "Other" requires a comment.
  if (code === 'other' && !comment) {
    errEl.textContent = 'A comment is required when reason is "Other".';
    errEl.style.display = '';
    return;
  }
  errEl.style.display = 'none';
  confirmBtn.disabled = true; backBtn.disabled = true;

  // Optimistic UI: gray out the row and apply cancelled-pending styling.
  const rowEl = document.querySelector('.appt-row[data-appt-id="' + CSS.escape(apptId) + '"]');
  if (rowEl) rowEl.classList.add('is-busy');

  const body = {
    reason: { code: code, comment: comment },
    notify_customer: { channel: notify ? 'sms' : 'none' },
    conversation_id: (window.state && state.selectedId) || '',
  };
  try {
    await apptApiPatch('/appointments/' + encodeURIComponent(apptId) + '/cancel/', body);
  } catch (e) {
    if (rowEl) rowEl.classList.remove('is-busy');
    confirmBtn.disabled = false; backBtn.disabled = false;
    errEl.textContent = apptFriendlyErr(e);
    errEl.style.display = '';
    return;
  }
  // Success — flip optimistic styling so the row visibly transitions before
  // the bus re-renders the card from server data.
  if (rowEl) {
    rowEl.classList.remove('is-busy');
    rowEl.classList.add('is-cancelled-pending');
  }
  apptModalClose();
  apptToast('Appointment cancelled.', 'success');
  apptOptimisticReload();
}

// ---------------- Optimistic reload guard ----------------
// Per BE handoff §4.4: after a write, the system-event bus auto-refreshes
// the card. But there's a 200-500ms gap between HTTP response and bus
// event. To make the UX snappy, kick a manual reload after 1s only if no
// fresh data has arrived yet (lastSysMsgId hasn't advanced).
function apptOptimisticReload() {
  const before = apptState.lastSysMsgId;
  setTimeout(() => {
    if (apptState.customerId && apptState.lastSysMsgId === before) {
      loadAppointments(apptState.customerId, apptState.scope);
    }
  }, 1100);
}

// Build a one-liner summary used in modal headers.
function apptModalSummary(a) {
  const when = (typeof apptFmtWhen === 'function') ? apptFmtWhen(a.start_at) : { rel: a.start_at, abs: '' };
  const tech = a.technician ? a.technician.name : 'Unassigned';
  const svc = a.service ? a.service.name : 'Service';
  return escHTML(svc) + ' · ' + escHTML(when.rel) + ' ' + escHTML(when.abs) + ' · ' + escHTML(tech);
}

// ---------------- Per-appt reminder timeline (Slice 4B) ----------------
// Lazy-fetched inline list of ScheduledReminders for an appointment.
// Uses the same /api/v1/communications/scheduled-reminders/ endpoint
// the standalone Reminders queue uses, with ?appointment_id=<uuid>.
//
// Skip button on pending rows calls the same /skip/ action. After a
// successful skip the local cache is dropped and the timeline re-fetches
// so the badge count and row state stay in sync.

function apptRemFmtRelative(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const diffMs = d.getTime() - Date.now();
  const abs = Math.abs(diffMs);
  const mins = Math.round(abs / 60000);
  const hours = Math.round(abs / 3600000);
  const days = Math.round(abs / 86400000);
  const future = diffMs > 0;
  if (abs < 60000) return future ? 'in a moment' : 'just now';
  if (mins < 60) return future ? `in ${mins}m` : `${mins}m ago`;
  if (hours < 24) return future ? `in ${hours}h` : `${hours}h ago`;
  return future ? `in ${days}d` : `${days}d ago`;
}

function apptRemFmtAbs(iso) {
  if (!iso) return '';
  try {
    return new Date(iso).toLocaleString(undefined, {
      month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit',
    });
  } catch (e) { return iso; }
}

function apptRemRowHtml(r) {
  const isPending = r.status === 'pending';
  const chan = (r.reminder_rule_channel || '').toUpperCase() || '?';
  const skipBtn = isPending
    ? `<button class="rt-skip" type="button" data-action="rt-skip" data-id="${escHTML(r.id)}" title="Skip this reminder">Skip</button>`
    : '';
  return `<div class="rt-row ${escHTML(r.status)}" data-id="${escHTML(r.id)}">
    <span class="rt-status ${escHTML(r.status)}">${escHTML(r.status)}</span>
    <span class="rt-chan">${escHTML(chan)}</span>
    <span class="rt-when">${escHTML(apptRemFmtAbs(r.scheduled_for))} <span style="color:var(--text-light)">(${escHTML(apptRemFmtRelative(r.scheduled_for))})</span><span class="rt-rule">· ${escHTML(r.reminder_rule_name || '')}</span></span>
    ${skipBtn}
  </div>`;
}

async function apptRemLoadTimeline(host, apptId) {
  host.innerHTML = '<div class="rt-loading">Loading reminders…</div>';
  try {
    const res = await fetch(
      `/api/v1/communications/scheduled-reminders/?appointment_id=${encodeURIComponent(apptId)}&limit=20`,
      { credentials: 'same-origin', headers: { 'Accept': 'application/json' } }
    );
    if (!res.ok) {
      host.innerHTML = `<div class="rt-error">Failed to load (${res.status})</div>`;
      return;
    }
    const data = await res.json();
    const rows = data.results || [];
    if (rows.length === 0) {
      host.innerHTML = '<div class="rt-empty">No reminders for this appointment.</div>';
    } else {
      // Pending first (ASC by scheduled_for), then everything else.
      const pending = rows.filter(r => r.status === 'pending').sort((a, b) => (a.scheduled_for || '').localeCompare(b.scheduled_for || ''));
      const other = rows.filter(r => r.status !== 'pending').sort((a, b) => (b.scheduled_for || '').localeCompare(a.scheduled_for || ''));
      host.innerHTML = pending.concat(other).map(apptRemRowHtml).join('');
    }
    host.dataset.loaded = '1';
  } catch (e) {
    host.innerHTML = `<div class="rt-error">Network error: ${escHTML(String(e))}</div>`;
  }
}

function apptRemToggleTimeline(toggleBtn) {
  const apptId = toggleBtn.dataset.apptId;
  if (!apptId) return;
  const host = document.getElementById(`rt-${apptId}`);
  if (!host) return;
  const isOpen = host.classList.contains('open');
  if (isOpen) {
    host.classList.remove('open');
    toggleBtn.setAttribute('aria-expanded', 'false');
    return;
  }
  host.classList.add('open');
  toggleBtn.setAttribute('aria-expanded', 'true');
  // Lazy-load on first open. Subsequent opens just re-show the cached HTML.
  if (host.dataset.loaded !== '1') {
    apptRemLoadTimeline(host, apptId);
  }
}

function apptRemSkipReminder(skipBtn) {
  const reminderId = skipBtn.dataset.id;
  if (!reminderId) return;
  const host = skipBtn.closest('.reminder-timeline');
  if (!host) return;
  const apptId = host.dataset.apptId;
  skipBtn.disabled = true;
  skipBtn.textContent = '…';
  const csrf = (document.cookie.match(/(?:^|;)\s*csrftoken=([^;]+)/) || ['',''])[1];
  fetch(`/api/v1/communications/scheduled-reminders/${encodeURIComponent(reminderId)}/skip/`, {
    method: 'POST',
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': csrf,
      'Accept': 'application/json',
    },
    body: '{}',
  }).then(async (res) => {
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = data.error === 'not_pending'
        ? `That reminder isn't pending anymore (status: ${data.current_status}).`
        : (data.error || ('Skip failed (' + res.status + ')'));
      alert(msg);
      skipBtn.disabled = false;
      skipBtn.textContent = 'Skip';
      return;
    }
    // Refresh the timeline (status changes) and the badge count.
    host.dataset.loaded = '0';
    apptRemLoadTimeline(host, apptId);
    // Decrement the badge count optimistically. The inbox card will
    // re-fetch from the server on its next loadAppointments(), but the
    // user sees the count drop immediately.
    const toggle = document.querySelector(`.reminder-toggle[data-appt-id="${apptId}"]`);
    if (toggle) {
      const cur = parseInt(toggle.textContent.replace(/[^0-9]/g, ''), 10) || 0;
      const next = Math.max(0, cur - 1);
      if (next === 0) {
        // No more pending — leave the toggle in place until next inbox
        // load to avoid jank; just update the count.
        toggle.innerHTML = `<span class="rt-icon">🔔</span>0`;
      } else {
        toggle.innerHTML = `<span class="rt-icon">🔔</span>${next}`;
      }
    }
  }).catch((err) => {
    alert('Network error: ' + err);
    skipBtn.disabled = false;
    skipBtn.textContent = 'Skip';
  });
}

// ---------------- Wire kebab clicks via event delegation ----------------
// The kebab button is rendered by apptRowHtml() inside the right-rail card
// host. The card host re-renders on every loadAppointments() — so we use
// document-level delegation instead of binding per-row. No memory leaks.
//
// Slice 4B: the same delegation block also handles reminder badge clicks
// and per-row Skip buttons inside the inline timeline. Tied together so
// only one document-level click listener gets added.
document.addEventListener('click', function (e) {
  const t = e.target;
  if (!t) return;
  // Reminder badge → toggle inline timeline (lazy-fetch on first open).
  const remToggle = t.closest && t.closest('.reminder-toggle[data-appt-id]');
  if (remToggle) {
    e.preventDefault(); e.stopPropagation();
    apptRemToggleTimeline(remToggle);
    return;
  }
  // Skip button inside a reminder timeline row.
  const skipBtn = t.closest && t.closest('button[data-action="rt-skip"][data-id]');
  if (skipBtn) {
    e.preventDefault(); e.stopPropagation();
    apptRemSkipReminder(skipBtn);
    return;
  }
  // Kebab → open per-row action menu.
  const kebab = t.closest && t.closest('.row-kebab[data-appt-id]');
  if (!kebab || kebab.disabled) return;
  e.preventDefault(); e.stopPropagation();
  const apptId = kebab.dataset.apptId;
  apptOpenRowMenu(apptId, kebab);
});

// ---------------- Stash row payload for action handlers ----------------
// renderApptCard receives the server payload. We need an apptId → appt-row
// lookup for the modals. Wrap renderApptCard so we capture the latest
// results before the original runs. Keeps Phase 1 / Phase 2 decoupled.
(function () {
  const orig = (typeof renderApptCard === 'function') ? renderApptCard : null;
  if (!orig) return;
  window.renderApptCard = function (host, payload, scope) {
    if (payload && Array.isArray(payload.results)) {
      apptState._lastResults = payload.results;
    }
    orig(host, payload, scope);
  };
})();

// =============================================================================
// CSR Inbox — Schedule/Reschedule drawer (Phase 3)
//
// One drawer, two modes (mode='create' | mode='reschedule'). Opens from:
//   * card header  + Schedule button   (mode='create')
//   * empty-state  + Schedule button   (mode='create')
//   * row kebab    Reschedule          (mode='reschedule', apptId)
//
// Endpoints (BE phase 4a/4b):
//   POST  /api/v1/scheduling/suggest/                     — slot search
//   POST  /api/v1/appointments/                           — create (source=csr_inbox)
//   PATCH /api/v1/appointments/{id}/reschedule/           — reschedule
// =============================================================================

// ---------------- State ----------------
const apptDrawer = {
  open: false,
  rootEl: null,
  prevFocus: null,
  mode: 'create',                   // 'create' | 'reschedule'
  apptId: null,                     // reschedule only — id of current appt
  priorAppt: null,                  // reschedule only — full appt object
  modeKey: 'csr_inbox.last_scheduling_mode',  // localStorage key for last-used scheduling mode
  schedMode: 'asap',                // 'asap' | 'specific' — sticky per CSR
  state: null,                      // shared form state (preserved across mode flip)
  suggestToken: 0,                  // stale-response guard
  suggestAbort: null,               // AbortController for in-flight suggest
  suggestTimer: null,               // debounce timer id
  detectChip: null,                 // detected hint string or null
  detectDismissed: false,           // chip closed by user
  servicesCache: null,              // [{id, name}, ...]
  techsCache: null,                 // [{id, name, initials}, ...]
  busy: false,                      // submit in flight
};

// Conversation auto-detect (regex-only — LLM intent is explicitly out of scope).
const APPT_DETECT_RX = {
  asap: /\b(asap|as soon as possible|earliest|first available|any opening|whenever|right away|immediately|emergency|urgent)\b/i,
  specific_day: /\b(tomorrow|today|next (?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)|(?:mon|tues|wednes|thurs|fri|satur|sun)day|\d{1,2}\/\d{1,2}(?:\/\d{2,4})?|\d{1,2}-\d{1,2})\b/i,
  specific_time: /\b(\d{1,2}(?::\d{2})?\s*(?:am|pm)|morning|afternoon|evening|noon|midday)\b/i,
  this_week: /\b(this week|by (?:friday|the weekend))\b/i,
};

// ---------------- POST helper (sibling of apptApiPatch) ----------------
async function apptApiPost(path, body, opts) {
  opts = opts || {};
  const url = '/api/v1' + path;
  const csrf = (document.cookie.match(/csrftoken=([^;]+)/) || [])[1] || '';
  const r = await fetch(url, {
    method: 'POST',
    credentials: 'same-origin',
    headers: {'Content-Type': 'application/json', 'X-CSRFToken': csrf},
    body: JSON.stringify(body),
    signal: opts.signal,
  });
  let data = null;
  try { data = await r.json(); } catch (_) {}
  if (r.ok) return data;
  const err = new Error((data && (data.error || data.detail)) || `${r.status} ${r.statusText}`);
  err.status = r.status;
  err.data = data || {};
  throw err;
}

// ---------------- Tiny utils ----------------
function apptDrawerTodayIso() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}
function apptDrawerDatePlus(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}
function apptInitialsOf(name) {
  if (!name) return '';
  const parts = String(name).trim().split(/\s+/);
  if (parts.length === 1) return parts[0][0].toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

// ---------------- Conversation auto-detect ----------------
function apptDetectFromThread() {
  // Pull the last 10 messages of the currently-rendered thread DOM.
  const msgs = Array.from(document.querySelectorAll('#threadBody .msg, #threadBody .msg-email'))
    .slice(-10)
    .map(el => (el.textContent || '').trim())
    .filter(Boolean);
  if (!msgs.length) return null;
  const blob = msgs.join(' \n ');
  const out = { mode: null, hint: '', earliest: null, latest: null };
  if (APPT_DETECT_RX.asap.test(blob)) {
    out.mode = 'asap';
    out.hint = 'customer asked for ASAP';
    if (APPT_DETECT_RX.this_week.test(blob)) {
      out.hint += ' — this week';
      out.earliest = apptDrawerTodayIso();
      out.latest = apptDrawerDatePlus(7);
    }
    return out;
  }
  if (APPT_DETECT_RX.specific_day.test(blob) || APPT_DETECT_RX.specific_time.test(blob)) {
    out.mode = 'specific';
    const dayM = blob.match(APPT_DETECT_RX.specific_day);
    const timeM = blob.match(APPT_DETECT_RX.specific_time);
    out.hint = `Detected: ${[dayM && dayM[0], timeM && timeM[0]].filter(Boolean).join(' ')}`;
    return out;
  }
  return null;
}

// ---------------- Drawer open / close ----------------
async function openScheduleDrawer(opts) {
  opts = opts || {};
  apptDrawer.mode = opts.mode || 'create';
  apptDrawer.apptId = opts.apptId || null;
  apptDrawer.priorAppt = null;

  // Resolve customer + conversation from selected conv (Phase 1 state).
  const conv = (typeof state !== 'undefined' && state.selectedConv) ? state.selectedConv : null;
  const customerId = (typeof state !== 'undefined' && state.selectedCustomerId) || (apptState && apptState.customerId) || null;
  if (apptDrawer.mode === 'create' && !customerId) {
    if (typeof apptToast === 'function') apptToast('Open a conversation with a known customer first.', 'error');
    return;
  }
  if (apptDrawer.mode === 'reschedule' && apptDrawer.apptId) {
    apptDrawer.priorAppt = (typeof apptFindAppt === 'function') ? apptFindAppt(apptDrawer.apptId) : null;
  }

  // Sticky scheduling mode — but reschedule defaults to 'specific' per brief.
  let storedMode = null;
  try { storedMode = localStorage.getItem(apptDrawer.modeKey); } catch (e) {}
  apptDrawer.schedMode = (apptDrawer.mode === 'reschedule')
    ? 'specific'
    : (storedMode === 'specific' ? 'specific' : 'asap');

  // Auto-detect overrides default mode for create.
  apptDrawer.detectChip = null;
  apptDrawer.detectDismissed = false;
  if (apptDrawer.mode === 'create') {
    const det = apptDetectFromThread();
    if (det && det.mode) {
      apptDrawer.schedMode = det.mode;
      apptDrawer.detectChip = det.hint;
    }
  }

  // Initial form state — preserved across mode flips while drawer stays open.
  apptDrawer.state = {
    customerId: customerId,
    conversationId: conv ? conv.id : '',
    serviceId: apptDrawer.priorAppt && apptDrawer.priorAppt.service ? apptDrawer.priorAppt.service.id : '',
    durationMin: apptDrawer.priorAppt ? (apptDrawer.priorAppt.duration_min || 60) : 60,
    price: (apptDrawer.priorAppt && apptDrawer.priorAppt.price != null) ? apptDrawer.priorAppt.price : '',  // pre-tax subtotal
    address: '',                       // resolved line1 — set when an address is picked (sent to BE)
    addresses: [],                     // [{id, label, kind, line1, line2, city, state, zip}, ...]
    selectedAddressId: '',             // id from `addresses` or '' = none picked yet
    customerLoaded: false,             // true after apptLoadCustomerAddresses completes
    earliestDate: apptDrawerTodayIso(),
    latestDate: apptDrawerDatePlus(7),
    timeOfDay: 'any',
    avoidWeekends: false,
    preferredTechId: apptDrawer.priorAppt && apptDrawer.priorAppt.technician ? apptDrawer.priorAppt.technician.id : '',
    specificDate: apptDrawerTodayIso(),
    specificStartTime: '09:00',
    specificEndTime: '',
    sendChannel: (conv && conv.channel === 'email') ? 'email' : 'sms',
    rescheduleReasonCode: 'customer_request',
    rescheduleReasonComment: '',
    slots: [],
    selectedSlot: null,
    specResult: null,
  };

  // Apply detect prefills.
  if (apptDrawer.detectChip && apptDrawer.mode === 'create') {
    const det = apptDetectFromThread();
    if (det && det.earliest) apptDrawer.state.earliestDate = det.earliest;
    if (det && det.latest) apptDrawer.state.latestDate = det.latest;
  }

  // Build DOM and mount.
  apptDrawer.prevFocus = document.activeElement;
  const root = document.createElement('div');
  root.className = 'appt-drawer-overlay';
  root.setAttribute('role', 'dialog');
  root.setAttribute('aria-modal', 'true');
  root.setAttribute('aria-labelledby', 'apptDrwTitle');
  root.innerHTML = apptDrawerHtml();
  document.body.appendChild(root);
  apptDrawer.rootEl = root;
  apptDrawer.open = true;
  document.addEventListener('keydown', apptDrawerKeydown, true);

  // Wire chrome.
  root.addEventListener('click', (e) => {
    if (e.target === root) closeScheduleDrawer();
  });
  root.querySelector('.drw-close').addEventListener('click', closeScheduleDrawer);
  root.querySelectorAll('[data-mode-target]').forEach(b => {
    b.addEventListener('click', () => apptFlipSchedMode(b.dataset.modeTarget));
  });
  const dchip = root.querySelector('.appt-detect-chip');
  if (dchip) dchip.querySelector('.chip-dismiss').addEventListener('click', () => {
    apptDrawer.detectDismissed = true; dchip.remove();
  });

  apptRebindForm();
  // Initial focus: first interactive element in body.
  setTimeout(() => {
    const firstInput = root.querySelector('.appt-drawer-body select, .appt-drawer-body input, .appt-drawer-body button');
    if (firstInput) firstInput.focus();
  }, 50);

  // Lazy-load services + techs (cache for the session) AND fetch customer
  // addresses (per-open — primary + service_locations). Render once both
  // have resolved so the form has its full data on first paint.
  const _drwTasks = [
    apptLoadDrawerOptions(),
    apptLoadCustomerAddresses(apptDrawer.state.customerId),
  ];
  // + Schedule on an existing customer: pre-select their last recurring service.
  if (apptDrawer.mode === 'create') _drwTasks.push(apptPrefillRecurringDefault());
  Promise.all(_drwTasks).then(() => {
    apptRenderForm();
    apptScheduleSuggest(0);  // initial fetch (gated on address inside apptDoSuggest)
  });
}

// + Schedule (create) default: if the customer's most recent appointment was a
// recurring insect/rodent service, pre-check it (multi-job aware) so the CSR
// doesn't re-pick the usual service. No-op if the last visit wasn't recurring,
// or if a service is already prefilled (detect/reschedule paths).
async function apptPrefillRecurringDefault() {
  const cid = apptDrawer.state.customerId;
  if (!cid || apptDrawer.state.serviceId) return;
  let data;
  try {
    data = await apptApi(`/customers/${encodeURIComponent(cid)}/appointments/?scope=past&limit=1`);
  } catch (e) { return; }
  if (data && data._hidden) return;
  const last = data && (data.results || [])[0];
  if (!last) return;
  const jts = (last.job_types && last.job_types.length)
    ? last.job_types
    : (last.service ? [last.service] : []);
  const isRecurring = (n) => /^recurring\s+(insects|rodents)/i.test(String(n || ''));
  const recurring = jts.filter(j => isRecurring(j.name));
  if (!recurring.length) return;
  apptDrawer.state.serviceIds = recurring.map(j => String(j.id));
  apptDrawer.state.serviceId = apptDrawer.state.serviceIds[0];
}

function closeScheduleDrawer() {
  if (!apptDrawer.open) return;
  apptDrawer.open = false;
  document.removeEventListener('keydown', apptDrawerKeydown, true);
  if (apptDrawer.suggestAbort) { try { apptDrawer.suggestAbort.abort(); } catch (e) {} }
  if (apptDrawer.suggestTimer) clearTimeout(apptDrawer.suggestTimer);
  if (apptDrawer.rootEl && apptDrawer.rootEl.parentNode) {
    apptDrawer.rootEl.parentNode.removeChild(apptDrawer.rootEl);
  }
  apptDrawer.rootEl = null;
  if (apptDrawer.prevFocus && typeof apptDrawer.prevFocus.focus === 'function') {
    try { apptDrawer.prevFocus.focus(); } catch (e) {}
  }
}

// Esc to close + Tab focus trap.
function apptDrawerKeydown(e) {
  if (!apptDrawer.open) return;
  if (e.key === 'Escape') { e.stopPropagation(); closeScheduleDrawer(); return; }
  if (e.key !== 'Tab' || !apptDrawer.rootEl) return;
  const focusables = apptDrawer.rootEl.querySelectorAll(
    'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
  );
  if (!focusables.length) return;
  const first = focusables[0], last = focusables[focusables.length - 1];
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
}

// ---------------- Drawer chrome HTML ----------------
// ===== CSR Inbox — contract / recurring-form options on the schedule drawer =====
// Renders 3 checkboxes into the create-mode drawer. On booking success the
// checked ones auto-create the matching contracts (+ send for signing) and/or
// send the customer a preferences link. Reuses existing contracts +
// preference-link endpoints; best-effort (never blocks the booking itself).
function apptContractsSectionHtml() {
  return `
    <div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--border,#e5e7eb)">
      <div style="font-size:12px;font-weight:700;color:var(--text,#111);margin-bottom:8px">Contracts &amp; forms <span style="font-weight:400;color:var(--text-light,#777)">— created &amp; sent to the customer after scheduling</span></div>
      <label style="display:flex;align-items:center;gap:8px;font-size:13px;margin-bottom:7px;cursor:pointer"><input type="checkbox" id="apptCkCcAuth"><span>Create Credit Card Authorization form</span></label>
      <label style="display:flex;align-items:center;gap:8px;font-size:13px;margin-bottom:7px;cursor:pointer"><input type="checkbox" id="apptCkMaint"><span>Create Maintenance agreement</span></label>
      <div id="apptMaintBox" style="display:none;margin:0 0 8px 26px;padding:10px;background:#f8f9fa;border:1px solid var(--border,#e5e7eb);border-radius:8px">
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <div style="flex:1;min-width:118px"><label style="display:block;font-size:11px;color:var(--text-light,#777);margin-bottom:3px">Frequency</label><select id="apptMaintFreq" style="width:100%;padding:6px 8px;border:1px solid var(--border,#e5e7eb);border-radius:6px;font-size:13px;background:#fff"><option value="monthly">Monthly</option><option value="quarterly" selected>Quarterly</option><option value="bi_monthly">Bi-Monthly</option></select></div>
          <div style="flex:1;min-width:118px"><label style="display:block;font-size:11px;color:var(--text-light,#777);margin-bottom:3px">Maintenance fee (pre-tax)</label><input type="number" id="apptMaintFee" min="0" step="0.01" placeholder="0.00" style="width:100%;padding:6px 8px;border:1px solid var(--border,#e5e7eb);border-radius:6px;font-size:13px"></div>
          <div style="flex:1;min-width:118px"><label style="display:block;font-size:11px;color:var(--text-light,#777);margin-bottom:3px">Initial treatment fee</label><input type="number" id="apptMaintInit" min="0" step="0.01" placeholder="0.00" style="width:100%;padding:6px 8px;border:1px solid var(--border,#e5e7eb);border-radius:6px;font-size:13px"></div>
        </div>
      </div>
      <label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer"><input type="checkbox" id="apptCkPrefLink"><span>Send preferred recurring day/time form</span></label>
    </div>
  `;
}

document.addEventListener('change', function (e) {
  const t = e.target;
  if (t && t.id === 'apptCkMaint') {
    const box = document.getElementById('apptMaintBox');
    if (box) box.style.display = t.checked ? '' : 'none';
  }
});

function apptCfNameMatchesFreq(name, freq) {
  const nm = (name || '').toLowerCase();
  if (freq === 'bi_monthly') return nm.indexOf('bi-monthly') !== -1 || nm.indexOf('bi monthly') !== -1 || nm.indexOf('bimonthly') !== -1;
  if (freq === 'quarterly') return nm.indexOf('quarterly') !== -1;
  if (freq === 'monthly') return nm.indexOf('monthly') !== -1 && nm.indexOf('bi-monthly') === -1 && nm.indexOf('bi monthly') === -1;
  return false;
}

function apptCfPickTemplate(tpls, type, freq) {
  const list = (tpls || []).filter(function (t) { return t.contract_type === type; });
  if (type === 'cc_auth') return list[0] || null;
  const pool = list.filter(function (t) { return (t.name || '').toLowerCase().indexOf('qa test') === -1; });
  const fl = pool.length ? pool : list;
  let m = fl.find(function (t) { return (t.default_billing_frequency || '').toLowerCase() === freq; });
  if (!m) m = fl.find(function (t) { return apptCfNameMatchesFreq(t.name, freq); });
  if (!m) m = fl[0] || list[0] || null;
  return m;
}

async function apptRunPostBooking(apptId, customerId, channel, opts) {
  const done = [], failed = [];
  let tpls = null;
  if (opts.ccAuth || opts.maint) {
    try {
      const r = await apptApi('/contracts/templates/?limit=100');
      tpls = Array.isArray(r) ? r : (r && r.results ? r.results : []);
    } catch (e) { tpls = []; }
  }
  async function genAndSend(tpl, extra, label) {
    if (!tpl) { failed.push(label + ' (no template)'); return; }
    const body = Object.assign({ template_id: tpl.id, appointment_id: apptId }, extra || {});
    let c;
    try { c = await apptApiPost('/contracts/contracts/generate-for-appointment/', body); }
    catch (e) { failed.push(label + ' (create failed)'); return; }
    const cid = c && (c.id || c.contract_id);
    if (!cid) { failed.push(label + ' (no id)'); return; }
    try {
      await apptApiPost('/contracts/contracts/' + encodeURIComponent(cid) + '/send_for_signing/', { channel: channel });
      done.push(label + ' sent');
    } catch (e) { done.push(label + ' created (send pending)'); }
  }
  if (opts.ccAuth) await genAndSend(apptCfPickTemplate(tpls, 'cc_auth', null), {}, 'CC auth');
  if (opts.maint) await genAndSend(apptCfPickTemplate(tpls, 'maintenance', opts.maint.freq), { recurring_fee: opts.maint.fee || '0', initial_treatment_fee: opts.maint.initial || '0' }, 'Maintenance');
  if (opts.prefLink) {
    try {
      await apptApiPost('/customers/' + encodeURIComponent(customerId) + '/send-preference-link/', { channel: channel });
      done.push('Preferences link sent');
    } catch (e) { failed.push('Preferences link'); }
  }
  if (done.length || failed.length) {
    const parts = [];
    if (done.length) parts.push(done.join(', '));
    if (failed.length) parts.push('failed: ' + failed.join(', '));
    if (typeof apptToast === 'function') apptToast(parts.join(' - '), failed.length ? 'error' : 'success');
  }
}

function apptDrawerHtml() {
  const isResched = apptDrawer.mode === 'reschedule';
  const title = isResched ? 'Reschedule appointment' : 'Schedule appointment';
  const banner = isResched ? apptReschedBannerHtml() : '';
  const chip = (apptDrawer.detectChip && !apptDrawer.detectDismissed)
    ? `<div class="appt-detect-chip"><span class="chip-text">${escHTML(apptDrawer.detectChip)}</span><button type="button" class="chip-dismiss" aria-label="Dismiss">×</button></div>`
    : '';
  const asapPressed = apptDrawer.schedMode === 'asap' ? 'true' : 'false';
  const specPressed = apptDrawer.schedMode === 'specific' ? 'true' : 'false';
  return `
    <div class="appt-drawer">
      <div class="appt-drawer-head">
        <h3 id="apptDrwTitle">${escHTML(title)}</h3>
        <button type="button" class="drw-close" aria-label="Close">×</button>
      </div>
      <div class="appt-drawer-body">
        ${banner}
        ${chip}
        <div class="appt-mode-toggle" role="radiogroup" aria-label="Scheduling mode">
          <button type="button" role="radio" aria-checked="${asapPressed}" data-mode-target="asap">ASAP — Soonest</button>
          <button type="button" role="radio" aria-checked="${specPressed}" data-mode-target="specific">Specific date/time</button>
        </div>
        <div id="apptDrwForm"></div>
        <div id="apptDrwResults"></div>
        <div class="appt-slot-summary is-empty" id="apptDrwSummary" aria-live="polite">No slot selected yet.</div>
        ${isResched ? '' : apptContractsSectionHtml()}
      </div>
      <div class="appt-drawer-foot">
        <button type="button" class="btn" id="apptDrwCancel">Cancel</button>
        <span class="foot-spacer"></span>
        <button type="button" class="btn btn-primary" id="apptDrwSubmit" disabled>${isResched ? 'Reschedule' : 'Schedule'}</button>
      </div>
    </div>
  `;
}

function apptReschedBannerHtml() {
  const a = apptDrawer.priorAppt;
  if (!a) return '';
  const when = (typeof apptFmtWhen === 'function') ? apptFmtWhen(a.start_at) : (a.start_at || '');
  const tech = a.technician ? a.technician.name : 'unassigned';
  const svc = a.service ? a.service.name : 'service';
  return `
    <div class="appt-resched-banner">
      <strong>Currently scheduled:</strong> ${escHTML(svc)} — ${escHTML(when.abs || when)} with ${escHTML(tech)}.
    </div>
  `;
}

// ---------------- Customer addresses (primary + service_locations) ----------------
// Fetches the customer record and builds the address list shown in the
// drawer's 'Service address' picker. Always runs on drawer open (per-open
// freshness — addresses can change while the drawer is closed).
//
// Picker items:
//   {id: 'primary', kind: 'primary', label: 'Primary — 123 Main St', line1, line2, city, state, zip}
//   {id: '<uuid>',  kind: 'location', label: 'Warehouse — 456 Oak Ave', ...}
//
// On reschedule, pre-selects an existing address that matches the prior
// appointment's location.address (substring match); otherwise primary.
async function apptLoadCustomerAddresses(customerId) {
  apptDrawer.state.addresses = [];
  apptDrawer.state.selectedAddressId = '';
  apptDrawer.state.address = '';
  apptDrawer.state.customerLoaded = false;
  if (!customerId) return;
  let cust;
  try {
    cust = await apptApi(`/customers/${encodeURIComponent(customerId)}/`);
  } catch (e) {
    apptDrawer.state.customerLoaded = true;
    return;
  }
  apptDrawer.state.customerLoaded = true;
  const list = [];
  // Primary address (always first, always present even if some fields blank).
  if (cust && (cust.service_address || cust.full_service_address)) {
    list.push({
      id: 'primary',
      kind: 'primary',
      label: cust.full_service_address || cust.service_address,
      line1: cust.service_address || '',
      line2: cust.service_address_2 || '',
      city:  cust.service_city || '',
      state: cust.service_state || '',
      zip:   cust.service_zip || '',
      durOverrides: {},
    });
  }
  // Service locations (commercial multi-site customers).
  const locs = (cust && cust.service_locations) || [];
  for (const loc of locs) {
    if (loc.is_active === false) continue;
    const labelHead = loc.location_name || 'Site';
    const labelTail = loc.full_address || loc.address || '';
    list.push({
      id: loc.id,
      kind: 'location',
      label: labelTail ? `${labelHead} — ${labelTail}` : labelHead,
      line1: loc.address || loc.street_address || '',
      line2: loc.address_2 || loc.street_address_2 || '',
      city:  loc.city || '',
      state: loc.state || '',
      zip:   loc.zip_code || loc.zip || '',
      durOverrides: loc.job_duration_overrides || {},
    });
  }
  apptDrawer.state.addresses = list;

  // Default selection.
  let sel = '';
  if (apptDrawer.priorAppt && apptDrawer.priorAppt.location && apptDrawer.priorAppt.location.address) {
    const priorAddr = String(apptDrawer.priorAppt.location.address).toLowerCase();
    const match = list.find(a => priorAddr.includes((a.line1 || '').toLowerCase()) && (a.line1 || '').length > 3);
    if (match) sel = match.id;
  }
  if (!sel && list.length) sel = list[0].id;
  apptDrawer.state.selectedAddressId = sel;
  apptApplySelectedAddress();
}

// Pulls the chosen item out of state.addresses and sets state.address (line1
// for the BE payload). Called whenever the picker changes.
function apptApplySelectedAddress() {
  const s = apptDrawer.state;
  const item = s.addresses.find(a => a.id === s.selectedAddressId);
  if (!item) { s.address = ''; return; }
  // Prefer line1 for BE; fall back to label if line1 is somehow blank.
  s.address = item.line1 || item.label || '';
}

// Derive Duration from the chosen job type's default, preferring a per-address
// (site) override when the selected address carries one in job_duration_overrides.
// Called on service/address CHANGE only (not initial open), so manual edits and
// a reschedule's prior duration survive until the CSR changes service or address.
function apptAutofillDuration() {
  const s = apptDrawer.state;
  const jt = (apptDrawer.servicesCache || []).find(x => x.id === s.serviceId);
  if (!jt) return;
  let dur = Number(jt.dur) || 0;
  const addr = (s.addresses || []).find(a => a.id === s.selectedAddressId);
  if (addr && addr.durOverrides) {
    const ov = Number(addr.durOverrides[s.serviceId]);
    if (ov && ov > 0) dur = ov;
  }
  if (dur && dur > 0) {
    s.durationMin = dur;
    const root = apptDrawer.rootEl;
    const durEl = root && root.querySelector('#apptDrwDuration');
    if (durEl) durEl.value = dur;
  }
}

// ---------------- Lazy-load services + technicians ----------------
async function apptLoadDrawerOptions() {
  const tasks = [];
  if (!apptDrawer.servicesCache) {
    tasks.push(apptApi('/job-types/?limit=200').then(d => {
      const arr = (d && (d.results || d)) || [];
      apptDrawer.servicesCache = arr.map(j => ({id: j.id, name: j.name, dur: j.default_duration_minutes || j.default_duration || 0}));
    }).catch(() => { apptDrawer.servicesCache = []; }));
  }
  if (!apptDrawer.techsCache) {
    tasks.push(apptApi('/technicians/?limit=200').then(d => {
      const arr = (d && (d.results || d)) || [];
      apptDrawer.techsCache = arr.map(t => {
        // BUGFIX: API returns `name` (=user.get_full_name) and `user` as a UUID
        // FK pk (a plain string), not a nested object. The previous attempt at
        // (t.user && (t.user.first_name + ' ' + t.user.last_name)) produced the
        // literal string 'undefined undefined' for every row, because t.user is
        // a truthy string and t.user.first_name/.last_name are both undefined.
        // Prefer `name`; fall back gracefully if get_full_name returned ''.
        let nm = (t.name || '').trim();
        if (!nm) nm = t.full_name || t.username || t.email || 'Unnamed';
        return {id: t.id, name: nm, initials: apptInitialsOf(nm)};
      });
    }).catch(() => { apptDrawer.techsCache = []; }));
  }
  await Promise.all(tasks);
}

// ---------------- Form rendering ----------------
function apptRenderForm() {
  if (!apptDrawer.rootEl) return;
  const host = apptDrawer.rootEl.querySelector('#apptDrwForm');
  if (!host) return;
  host.innerHTML = (apptDrawer.schedMode === 'asap')
    ? apptAsapFormHtml()
    : apptSpecFormHtml();
  apptRebindForm();
}

function apptAsapFormHtml() {
  const s = apptDrawer.state;
  const _selIds = s.serviceIds || (s.serviceId ? [s.serviceId] : []);
  const services = (apptDrawer.servicesCache || []).map(x =>
    `<label class="appt-jt-check"><input type="checkbox" value="${escHTML(x.id)}"${_selIds.indexOf(x.id) !== -1 ? ' checked' : ''}> ${escHTML(x.name)}</label>`
  ).join('');
  const techs = (apptDrawer.techsCache || []).map(x =>
    `<option value="${escHTML(x.id)}"${x.id === s.preferredTechId ? ' selected' : ''}>${escHTML(x.name)}</option>`
  ).join('');
  const todChip = (val, label) =>
    `<button type="button" class="appt-tod-chip" data-tod="${escHTML(val)}" aria-pressed="${s.timeOfDay === val ? 'true' : 'false'}">${escHTML(label)}</button>`;
  return `
    <div class="appt-drw-field">
      <label>Service(s) ${s.serviceId ? '' : '<span class="hint">required</span>'}</label>
      <div id="apptDrwService" class="appt-jt-checks">${services}</div>
    </div>
    <div class="appt-drw-field-row">
      <div class="appt-drw-field">
        <label>Duration <span class="hint">minutes</span></label>
        <input type="number" id="apptDrwDuration" min="15" max="480" step="15" value="${s.durationMin}">
      </div>
      <div class="appt-drw-field">
        <label>Preferred tech</label>
        <select id="apptDrwTech"><option value="">Any</option>${techs}</select>
      </div>
    </div>
    <div class="appt-drw-field">
      <label>Price <span class="hint">pre-tax subtotal</span></label>
      <input type="number" id="apptDrwPrice" min="0" step="0.01" placeholder="0.00" value="${s.price !== '' && s.price != null ? escHTML(String(s.price)) : ''}">
    </div>
    ${apptAddressPickerHtml()}
    <div class="appt-drw-field-row">
      <div class="appt-drw-field">
        <label>Earliest</label>
        <input type="date" id="apptDrwEarliest" min="${apptDrawerTodayIso()}" value="${escHTML(s.earliestDate)}">
      </div>
      <div class="appt-drw-field">
        <label>Latest</label>
        <input type="date" id="apptDrwLatest" min="${apptDrawerTodayIso()}" value="${escHTML(s.latestDate)}">
      </div>
    </div>
    <div class="appt-drw-field">
      <label>Time of day</label>
      <div class="appt-tod-row" id="apptDrwTodRow">
        ${todChip('any','Any')} ${todChip('morning','Morning')} ${todChip('afternoon','Afternoon')} ${todChip('evening','Evening')}
      </div>
    </div>
    <label class="appt-toggle-row">
      <input type="checkbox" id="apptDrwAvoidWeekends" ${s.avoidWeekends ? 'checked' : ''}> Avoid weekends
    </label>
    <div class="appt-drw-field">
      <label>Send confirmation</label>
      <select id="apptDrwSendCh">
        <option value="sms"${s.sendChannel==='sms'?' selected':''}>SMS</option>
        <option value="email"${s.sendChannel==='email'?' selected':''}>Email</option>
        <option value="none"${s.sendChannel==='none'?' selected':''}>None</option>
      </select>
    </div>
    ${apptDrawer.mode === 'reschedule' ? apptReasonBlockHtml() : ''}
  `;
}

function apptSpecFormHtml() {
  const s = apptDrawer.state;
  const _selIds = s.serviceIds || (s.serviceId ? [s.serviceId] : []);
  const services = (apptDrawer.servicesCache || []).map(x =>
    `<label class="appt-jt-check"><input type="checkbox" value="${escHTML(x.id)}"${_selIds.indexOf(x.id) !== -1 ? ' checked' : ''}> ${escHTML(x.name)}</label>`
  ).join('');
  const techs = (apptDrawer.techsCache || []).map(x =>
    `<option value="${escHTML(x.id)}"${x.id === s.preferredTechId ? ' selected' : ''}>${escHTML(x.name)}</option>`
  ).join('');
  return `
    <div class="appt-drw-field">
      <label>Service(s) ${s.serviceId ? '' : '<span class="hint">required</span>'}</label>
      <div id="apptDrwService" class="appt-jt-checks">${services}</div>
    </div>
    <div class="appt-drw-field-row">
      <div class="appt-drw-field">
        <label>Duration <span class="hint">minutes</span></label>
        <input type="number" id="apptDrwDuration" min="15" max="480" step="15" value="${s.durationMin}">
      </div>
      <div class="appt-drw-field">
        <label>Preferred tech</label>
        <select id="apptDrwTech"><option value="">Any</option>${techs}</select>
      </div>
    </div>
    <div class="appt-drw-field">
      <label>Price <span class="hint">pre-tax subtotal</span></label>
      <input type="number" id="apptDrwPrice" min="0" step="0.01" placeholder="0.00" value="${s.price !== '' && s.price != null ? escHTML(String(s.price)) : ''}">
    </div>
    ${apptAddressPickerHtml()}
    <div class="appt-drw-field-row">
      <div class="appt-drw-field">
        <label>Date</label>
        <input type="date" id="apptDrwSpecDate" min="${apptDrawerTodayIso()}" value="${escHTML(s.specificDate)}">
      </div>
      <div class="appt-drw-field">
        <label>Start time</label>
        <input type="time" id="apptDrwSpecStart" step="900" value="${escHTML(s.specificStartTime)}">
      </div>
    </div>
    <div class="appt-drw-field">
      <label>Time window end <span class="hint">optional</span></label>
      <input type="time" id="apptDrwSpecEnd" step="900" value="${escHTML(s.specificEndTime || '')}">
    </div>
    <div class="appt-drw-field">
      <label>Send confirmation</label>
      <select id="apptDrwSendCh">
        <option value="sms"${s.sendChannel==='sms'?' selected':''}>SMS</option>
        <option value="email"${s.sendChannel==='email'?' selected':''}>Email</option>
        <option value="none"${s.sendChannel==='none'?' selected':''}>None</option>
      </select>
    </div>
    ${apptDrawer.mode === 'reschedule' ? apptReasonBlockHtml() : ''}
  `;
}

// ---------------- Address picker ----------------
// Renders the service-address <select> + 'Add new service address' button.
// Used by both apptAsapFormHtml and apptSpecFormHtml.
function apptAddressPickerHtml() {
  const s = apptDrawer.state;
  if (!s.customerLoaded) {
    return `<div class="appt-drw-field"><label>Service address</label><div class="appt-addr-loading">Loading addresses…</div></div>`;
  }
  const opts = (s.addresses || []).map(a =>
    `<option value="${escHTML(a.id)}"${a.id === s.selectedAddressId ? ' selected' : ''}>${escHTML(a.label)}</option>`
  ).join('');
  const noneOpt = s.selectedAddressId ? '' : `<option value="" disabled selected>— Select an address —</option>`;
  return `
    <div class="appt-drw-field">
      <label>Service address ${s.selectedAddressId ? '' : '<span class="hint">required</span>'}</label>
      <div class="appt-addr-row">
        <select id="apptDrwAddrPicker" class="appt-addr-picker">${noneOpt}${opts}</select>
        <button type="button" id="apptDrwAddrAdd" class="appt-addr-add-btn" title="Add new service address">+ New</button>
      </div>
    </div>
  `;
}

function apptBindAddressPicker() {
  const root = apptDrawer.rootEl;
  if (!root) return;
  const sel = root.querySelector('#apptDrwAddrPicker');
  if (sel) sel.addEventListener('change', () => {
    apptDrawer.state.selectedAddressId = sel.value;
    apptApplySelectedAddress();
    apptAutofillDuration();
    apptScheduleSuggest(0);
  });
  const addBtn = root.querySelector('#apptDrwAddrAdd');
  if (addBtn) addBtn.addEventListener('click', apptOpenNewAddressModal);
}

// New-address modal — matches Phase 2's apptModalOpen({bodyHtml, footerHtml,
// onOpen}) contract. The onOpen callback receives the overlay root and is
// responsible for wiring button click handlers (Cancel + Save).
function apptOpenNewAddressModal() {
  if (typeof apptModalOpen !== 'function') return;
  apptModalOpen({
    title: 'Add service address',
    bodyHtml: `
      <div class="field"><label>Location name <span class="label-hint">e.g. Warehouse, Vacation Home</span></label>
        <input type="text" id="apptNewAddrName" placeholder="Site"></div>
      <div class="field"><label>Address line 1 <span class="label-hint">required</span></label>
        <input type="text" id="apptNewAddrLine1" required></div>
      <div class="field"><label>Address line 2 <span class="label-hint">apt, suite, unit</span></label>
        <input type="text" id="apptNewAddrLine2"></div>
      <div class="field"><label>City</label>
        <input type="text" id="apptNewAddrCity"></div>
      <div class="field" style="display:flex;gap:8px">
        <div style="flex:1"><label>State</label>
          <input type="text" id="apptNewAddrState" maxlength="2" value="PA"></div>
        <div style="flex:2"><label>ZIP</label>
          <input type="text" id="apptNewAddrZip"></div>
      </div>
      <div class="field-error" id="apptNewAddrErr" style="display:none"></div>`,
    footerHtml: `
      <div class="foot-spacer"></div>
      <button type="button" class="btn" id="apptNewAddrCancel">Cancel</button>
      <button type="button" class="btn btn-primary" id="apptNewAddrSave">Save address</button>`,
    onOpen: function (root) {
      root.querySelector('#apptNewAddrCancel').addEventListener('click', apptModalClose);
      root.querySelector('#apptNewAddrSave').addEventListener('click', () => apptSubmitNewAddress(root));
      _apptWireAddressAutocomplete(root);
    },
  });
}


// ----- Google Places autocomplete for new service-address modal (Quick-Win #7) -----
// Loads Maps Places library on first need; wires Autocomplete onto the
// Address Line 1 input and splits the picked place into line2 (subpremise),
// city, state, and ZIP.
let _APPT_GMAPS_LOADER = null;
function _apptLoadGoogleMaps() {
  if (_APPT_GMAPS_LOADER) return _APPT_GMAPS_LOADER;
  if (typeof google !== 'undefined' && google.maps && google.maps.importLibrary) {
    _APPT_GMAPS_LOADER = Promise.resolve();
    return _APPT_GMAPS_LOADER;
  }
  _APPT_GMAPS_LOADER = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    const key = (window.GOOGLE_MAPS_KEY || '').trim();
    if (!key) { reject(new Error('Maps key missing')); return; }
    s.src = 'https://maps.googleapis.com/maps/api/js?key=' + encodeURIComponent(key)
          + '&libraries=places&loading=async&callback=Function.prototype';
    s.async = true; s.defer = true;
    s.onerror = () => reject(new Error('Maps script failed to load'));
    s.onload = () => resolve();
    document.head.appendChild(s);
  });
  return _APPT_GMAPS_LOADER;
}

// Generalized Places autocomplete — same behavior as _apptWireAddressAutocomplete
// but with caller-supplied field selectors, so it can drive the new-customer
// form's service-address fields (fills city / state / ZIP). Added for CSR-inbox
// create-customer parity with the appointment address modal.
function _apptWireAddrAutocompleteOn(root, sel) {
  const input = root.querySelector(sel.line1);
  if (!input) return;
  input.setAttribute('autocomplete', 'off');
  _apptLoadGoogleMaps().then(() => google.maps.importLibrary('places')).then(({ Autocomplete }) => {
    const ac = new Autocomplete(input, {
      componentRestrictions: { country: 'us' },
      fields: ['address_components', 'formatted_address'],
      types: ['address'],
    });
    ac.addListener('place_changed', () => {
      const pl = ac.getPlace();
      if (!pl || !pl.address_components) return;
      const comp = {};
      for (const c of pl.address_components) {
        for (const t of (c.types || [])) { comp[t] = { long: c.long_name, short: c.short_name }; }
      }
      const streetNum = (comp.street_number || {}).long || '';
      const route     = (comp.route        || {}).long || '';
      const subpremise = (comp.subpremise  || {}).long || '';
      const city  = (comp.locality || comp.sublocality || comp.postal_town || comp.administrative_area_level_3 || comp.administrative_area_level_2 || {}).long || '';
      const state = (comp.administrative_area_level_1 || {}).short || '';
      const zip   = (comp.postal_code || {}).long || '';
      const line1 = (streetNum + ' ' + route).trim();
      if (line1) input.value = line1;
      const setVal = (q, val) => { if (!q || !val) return; const el = root.querySelector(q); if (!el) return; el.value = val; try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {} };
      if (subpremise) setVal(sel.line2, subpremise);
      setVal(sel.city, city);
      setVal(sel.state, state);
      setVal(sel.zip, zip);
    });
  }).catch(err => { console.warn('addr autocomplete unavailable:', err); });
}

function _apptWireAddressAutocomplete(root) {
  const input = root.querySelector('#apptNewAddrLine1');
  if (!input) return;
  _apptLoadGoogleMaps().then(() => google.maps.importLibrary('places')).then(({ Autocomplete }) => {
    const ac = new Autocomplete(input, {
      componentRestrictions: { country: 'us' },
      fields: ['address_components', 'formatted_address'],
      types: ['address'],
    });
    ac.addListener('place_changed', () => {
      const p = ac.getPlace();
      if (!p || !p.address_components) return;
      const comp = {};
      for (const c of p.address_components) {
        for (const t of (c.types || [])) {
          comp[t] = { long: c.long_name, short: c.short_name };
        }
      }
      const streetNum = (comp.street_number || {}).long || '';
      const route     = (comp.route        || {}).long || '';
      const subpremise = (comp.subpremise   || {}).long || '';
      const city = (comp.locality || comp.sublocality || comp.postal_town || comp.administrative_area_level_3 || comp.administrative_area_level_2 || {}).long || '';
      const state = (comp.administrative_area_level_1 || {}).short || '';
      const zip   = (comp.postal_code || {}).long || '';

      const line1 = (streetNum + ' ' + route).trim();
      if (line1) input.value = line1;
      const line2El = root.querySelector('#apptNewAddrLine2');
      const cityEl  = root.querySelector('#apptNewAddrCity');
      const stateEl = root.querySelector('#apptNewAddrState');
      const zipEl   = root.querySelector('#apptNewAddrZip');
      if (line2El && subpremise) line2El.value = subpremise;
      if (cityEl  && city)       cityEl.value  = city;
      if (stateEl && state)      stateEl.value = state;
      if (zipEl   && zip)        zipEl.value   = zip;
    });
  }).catch(err => { console.warn('apptNewAddr autocomplete unavailable:', err); });
}

async function apptSubmitNewAddress(root) {
  const get = id => (root.querySelector('#' + id) || {}).value || '';
  const errEl = root.querySelector('#apptNewAddrErr');
  const saveBtn = root.querySelector('#apptNewAddrSave');
  const cancelBtn = root.querySelector('#apptNewAddrCancel');
  const showErr = (msg) => { if (errEl) { errEl.textContent = msg; errEl.style.display = 'block'; } };
  errEl.style.display = 'none';

  const line1 = get('apptNewAddrLine1').trim();
  if (!line1) { showErr('Address line 1 is required.'); return; }

  saveBtn.disabled = true; cancelBtn.disabled = true;

  const body = {
    customer: apptDrawer.state.customerId,
    location_name: get('apptNewAddrName').trim() || 'Site',
    address: line1,
    address_2: get('apptNewAddrLine2').trim(),
    city:    get('apptNewAddrCity').trim(),
    state:   (get('apptNewAddrState') || 'PA').trim().toUpperCase(),
    zip_code: get('apptNewAddrZip').trim(),
    is_active: true,
  };

  let created;
  try {
    created = await apptApiPost('/service-locations/', body);
  } catch (e) {
    saveBtn.disabled = false; cancelBtn.disabled = false;
    showErr((e && e.data && (e.data.error || e.data.detail)) || (e && e.message) || 'Could not save.');
    return;
  }

  // Append to picker list, select it, close modal, refresh form.
  const newItem = {
    id: created.id,
    kind: 'location',
    label: `${body.location_name} — ${body.address}${body.city ? ', ' + body.city : ''}`,
    line1: body.address,
    line2: body.address_2,
    city:  body.city,
    state: body.state,
    zip:   body.zip_code,
  };
  apptDrawer.state.addresses.push(newItem);
  apptDrawer.state.selectedAddressId = newItem.id;
  apptApplySelectedAddress();
  apptModalClose();
  if (typeof apptToast === 'function') apptToast('Address added', 'success');
  apptRenderForm();
  apptScheduleSuggest(0);
}

function apptReasonBlockHtml() {
  const s = apptDrawer.state;
  const opt = (v, label) =>
    `<option value="${escHTML(v)}"${s.rescheduleReasonCode === v ? ' selected' : ''}>${escHTML(label)}</option>`;
  return `
    <div class="appt-reason-block">
      <div class="field-label">Reason for reschedule</div>
      <div class="appt-drw-field">
        <select id="apptDrwReasonCode">
          ${opt('customer_request','Customer request')}
          ${opt('tech_unavailable','Tech unavailable')}
          ${opt('weather','Weather')}
          ${opt('other','Other')}
        </select>
      </div>
      <div class="appt-drw-field">
        <label>Comment <span class="hint">optional</span></label>
        <textarea id="apptDrwReasonComment" rows="2">${escHTML(s.rescheduleReasonComment || '')}</textarea>
      </div>
    </div>
  `;
}

// ---------------- Rebind form inputs after re-render ----------------
function apptRebindForm() {
  const root = apptDrawer.rootEl;
  if (!root) return;
  const s = apptDrawer.state;

  // Inputs that exist in both modes.
  const bind = (id, key, prop) => {
    const el = root.querySelector('#' + id);
    if (!el) return;
    el.addEventListener('change', () => {
      s[key] = (prop === 'value') ? el.value : el.checked;
      apptScheduleSuggest();
    });
  };
  // #13 + per-address override: bind serviceId AND auto-fill Duration via
  // apptAutofillDuration() (job-type default, or the selected address's per-site
  // override). Manual override still works; re-picking service/address re-fills.
  const _svcEl = root.querySelector('#apptDrwService');
  if (_svcEl) {
    _svcEl.addEventListener('change', () => {
      // Multi-job: track the full ordered selection; primary = first (drives
      // slotting + back-compat). Duration auto-fills only for a single service.
      s.serviceIds = Array.prototype.map.call(_svcEl.querySelectorAll('input[type=checkbox]:checked'), i => i.value);
      s.serviceId = s.serviceIds[0] || '';
      if (s.serviceIds.length === 1) apptAutofillDuration();
      apptScheduleSuggest();
    });
  }
  bind('apptDrwDuration', 'durationMin', 'value');
  bind('apptDrwPrice', 'price', 'value');
  bind('apptDrwTech', 'preferredTechId', 'value');
  bind('apptDrwSendCh', 'sendChannel', 'value');
  // Address picker — separate wiring (select change + 'Add new' button).
  apptBindAddressPicker();

  // Mode-specific.
  if (apptDrawer.schedMode === 'asap') {
    bind('apptDrwEarliest', 'earliestDate', 'value');
    bind('apptDrwLatest', 'latestDate', 'value');
    const aw = root.querySelector('#apptDrwAvoidWeekends');
    if (aw) aw.addEventListener('change', () => { s.avoidWeekends = aw.checked; apptScheduleSuggest(); });
    root.querySelectorAll('.appt-tod-chip').forEach(b => {
      b.addEventListener('click', () => {
        s.timeOfDay = b.dataset.tod;
        root.querySelectorAll('.appt-tod-chip').forEach(x =>
          x.setAttribute('aria-pressed', x === b ? 'true' : 'false'));
        apptScheduleSuggest();
      });
    });
  } else {
    bind('apptDrwSpecDate', 'specificDate', 'value');
    bind('apptDrwSpecStart', 'specificStartTime', 'value');
    bind('apptDrwSpecEnd', 'specificEndTime', 'value');
  }

  // Reason block (reschedule only).
  if (apptDrawer.mode === 'reschedule') {
    const rc = root.querySelector('#apptDrwReasonCode');
    if (rc) rc.addEventListener('change', () => { s.rescheduleReasonCode = rc.value; });
    const rcm = root.querySelector('#apptDrwReasonComment');
    if (rcm) rcm.addEventListener('input', () => { s.rescheduleReasonComment = rcm.value; });
  }

  // Footer.
  const cancelBtn = root.querySelector('#apptDrwCancel');
  if (cancelBtn) cancelBtn.onclick = closeScheduleDrawer;
  const submitBtn = root.querySelector('#apptDrwSubmit');
  if (submitBtn) submitBtn.onclick = apptDrawerSubmit;
}

// ---------------- Mode flip ----------------
function apptFlipSchedMode(target) {
  if (target !== 'asap' && target !== 'specific') return;
  if (apptDrawer.schedMode === target) return;
  apptDrawer.schedMode = target;
  try { localStorage.setItem(apptDrawer.modeKey, target); } catch (e) {}
  // Update toggle chips.
  apptDrawer.rootEl.querySelectorAll('[data-mode-target]').forEach(b =>
    b.setAttribute('aria-checked', b.dataset.modeTarget === target ? 'true' : 'false'));
  apptDrawer.state.selectedSlot = null;
  apptRenderForm();
  apptScheduleSuggest(0);
  apptUpdateSummary();
}

// ---------------- Suggest call (debounced) ----------------
function apptScheduleSuggest(delay) {
  delay = (typeof delay === 'number') ? delay : 300;
  if (apptDrawer.suggestTimer) clearTimeout(apptDrawer.suggestTimer);
  apptDrawer.suggestTimer = setTimeout(apptDoSuggest, delay);
}

async function apptDoSuggest() {
  const root = apptDrawer.rootEl;
  if (!root) return;
  const s = apptDrawer.state;
  // Gate: don't ask the BE for slots until we have a service address.
  // Slot ranking depends on travel distance from address; without one,
  // results are noise.
  if (!s.address) {
    const results = root.querySelector('#apptDrwResults');
    if (results) {
      results.innerHTML = `<div class="appt-slot-empty">Pick a service address to see available slots.</div>`;
    }
    s.slots = []; s.selectedSlot = null; s.specResult = null;
    const submitBtn = root.querySelector('#apptDrwSubmit');
    if (submitBtn) submitBtn.disabled = true;
    apptUpdateSummary();
    return;
  }
  // Same gate for service: slot ranking depends on service duration and
  // technician skill match, both of which require a service. Without it,
  // the BE either falls back to a default duration or returns over-broad
  // matches — neither surfaces the right answer.
  if (!s.serviceId) {
    const results = root.querySelector('#apptDrwResults');
    if (results) {
      results.innerHTML = `<div class="appt-slot-empty">Pick a service to see available slots.</div>`;
    }
    s.slots = []; s.selectedSlot = null; s.specResult = null;
    const submitBtn = root.querySelector('#apptDrwSubmit');
    if (submitBtn) submitBtn.disabled = true;
    apptUpdateSummary();
    return;
  }
  const body = {
    mode: apptDrawer.schedMode,
    customer_id: s.customerId,
    service_id: s.serviceId || null,
    duration_min: parseInt(s.durationMin, 10) || 60,
    service_address: { line1: s.address || '' },
    limit: 20,
    conversation_id: s.conversationId || '',
  };
  if (apptDrawer.schedMode === 'asap') {
    body.asap = {
      earliest_date: s.earliestDate || apptDrawerTodayIso(),
      latest_date: s.latestDate || apptDrawerDatePlus(7),
      time_of_day: s.timeOfDay === 'any' ? null : (s.timeOfDay || null),
      avoid_weekends: !!s.avoidWeekends,
      preferred_technician_id: s.preferredTechId || null,
    };
  } else {
    body.specific = {
      date: s.specificDate || apptDrawerTodayIso(),
      start_time: s.specificStartTime || '09:00',
      window_end_time: s.specificEndTime || null,
      preferred_technician_id: s.preferredTechId || null,
    };
  }

  // Stale-token guard.
  const myToken = ++apptDrawer.suggestToken;
  if (apptDrawer.suggestAbort) { try { apptDrawer.suggestAbort.abort(); } catch (e) {} }
  apptDrawer.suggestAbort = new AbortController();

  const results = root.querySelector('#apptDrwResults');
  results.innerHTML = `<div class="appt-search-status"><span class="spinner"></span>Searching for slots…</div>`;

  let data;
  try {
    data = await apptApiPost('/scheduling/suggest/', body, { signal: apptDrawer.suggestAbort.signal });
  } catch (e) {
    if (myToken !== apptDrawer.suggestToken) return;
    if (e && e.name === 'AbortError') return;
    results.innerHTML = `<div class="appt-slot-empty">Couldn't load suggestions: ${escHTML((e && e.message) || 'unknown')}</div>`;
    return;
  }
  if (myToken !== apptDrawer.suggestToken) return;

  const _normTech = (sl) => { if (sl && !sl.technician && (sl.technician_name || sl.technician_id)) { sl.technician = { id: sl.technician_id || null, name: sl.technician_name || '', color: sl.technician_color || '' }; } return sl; };
  if (data) {
    (data.slots || []).forEach(_normTech);
    (data.closest_alternates_same_day || []).forEach(_normTech);
    (data.closest_alternates_nearby_days || []).forEach(_normTech);
  }
  s.slots = (data && data.slots) || [];
  s.specResult = (apptDrawer.schedMode === 'specific') ? apptComputeSpecResult(data) : null;
  // Drop stale selection.
  if (s.selectedSlot && !s.slots.some(x => x.slot_id === s.selectedSlot.slot_id)) {
    s.selectedSlot = null;
  }
  apptRenderResults();
  apptUpdateSummary();
}

function apptComputeSpecResult(data) {
  if (data && data.exact_match && (data.slots || []).length) {
    return { state: 'green', sameDay: [], nearbyDays: [] };
  }
  const sameDay = (data && data.closest_alternates_same_day) || [];
  const nearby = (data && data.closest_alternates_nearby_days) || [];
  if (sameDay.length || nearby.length) {
    return { state: 'amber', sameDay, nearbyDays: nearby };
  }
  return { state: 'red', sameDay: [], nearbyDays: [] };
}

// ---------------- Result rendering ----------------
function apptRenderResults() {
  const root = apptDrawer.rootEl;
  if (!root) return;
  const host = root.querySelector('#apptDrwResults');
  if (!host) return;
  if (apptDrawer.schedMode === 'asap') {
    host.innerHTML = apptAsapResultsHtml();
  } else {
    host.innerHTML = apptSpecResultsHtml();
  }
  // Wire slot rows.
  host.querySelectorAll('.appt-slot-row').forEach((row, idx) => {
    row.addEventListener('click', () => {
      const slot = apptDrawer.state.slots[parseInt(row.dataset.slotIdx, 10)];
      if (!slot) return;
      apptDrawer.state.selectedSlot = slot;
      host.querySelectorAll('.appt-slot-row').forEach(r =>
        r.setAttribute('aria-selected', r === row ? 'true' : 'false'));
      apptUpdateSummary();
      const submit = apptDrawer.rootEl.querySelector('#apptDrwSubmit');
      if (submit) submit.disabled = false;
    });
  });
  // Wire "show more" expander.
  const more = host.querySelector('.appt-slot-show-more');
  if (more) more.addEventListener('click', () => {
    host.querySelectorAll('.appt-slot-row.is-hidden').forEach(r => r.classList.remove('is-hidden'));
    more.remove();
  });
  // Wire "try different criteria" link in empty state.
  const altLink = host.querySelector('.appt-slot-empty .alt-link');
  if (altLink) altLink.addEventListener('click', () => apptFlipSchedMode('specific'));
  // Wire alt-pills (specific amber state).
  host.querySelectorAll('.appt-spec-alts .alt-pill').forEach(p => {
    p.addEventListener('click', () => {
      const idx = parseInt(p.dataset.altIdx, 10);
      const which = p.dataset.altGroup;
      const arr = (apptDrawer.state.specResult || {})[which] || [];
      const slot = arr[idx];
      if (!slot) return;
      apptDrawer.state.slots = [slot];
      apptDrawer.state.selectedSlot = slot;
      apptDrawer.state.specResult = { state: 'green', sameDay: [], nearbyDays: [] };
      apptRenderResults();
      apptUpdateSummary();
      const submit = apptDrawer.rootEl.querySelector('#apptDrwSubmit');
      if (submit) submit.disabled = false;
    });
  });
}

function apptAsapResultsHtml() {
  const slots = apptDrawer.state.slots;
  if (!slots.length) {
    return `<div class="appt-slot-empty">No slots match these filters.<br><button type="button" class="alt-link">Try different criteria →</button></div>`;
  }
  const visible = 5;
  const rows = slots.map((sl, i) => apptSlotRowHtml(sl, i, i >= visible)).join('');
  const showMore = slots.length > visible
    ? `<button type="button" class="appt-slot-show-more">Show ${slots.length - visible} more</button>` : '';
  return `<div class="appt-slot-list">${rows}</div>${showMore}`;
}

function apptSpecResultsHtml() {
  const r = apptDrawer.state.specResult;
  if (!r) return '';
  if (r.state === 'green') {
    const slots = apptDrawer.state.slots;
    const rows = slots.map((sl, i) => apptSlotRowHtml(sl, i, false)).join('');
    return `
      <div class="appt-spec-result spec-green">
        <h5>✓ Exact match available</h5>
        <div>Pick a technician below.</div>
      </div>
      <div class="appt-slot-list">${rows}</div>
    `;
  }
  if (r.state === 'amber') {
    const altRow = (arr, group) => arr.length ? `
      <div class="alt-row">
        ${arr.slice(0, 3).map((sl, i) => `<button type="button" class="alt-pill" data-alt-idx="${i}" data-alt-group="${group}">${escHTML(apptFmtSlotWhen(sl))} · ${escHTML((sl.technician && sl.technician.name) || '')}</button>`).join('')}
      </div>` : '';
    return `
      <div class="appt-spec-result spec-amber">
        <h5>⚠ No technician available at that exact time</h5>
        <div class="appt-spec-alts">
          ${r.sameDay.length ? `<div class="alt-group-label">Closest times that day</div>${altRow(r.sameDay, 'sameDay')}` : ''}
          ${r.nearbyDays.length ? `<div class="alt-group-label">Same time, nearby days</div>${altRow(r.nearbyDays, 'nearbyDays')}` : ''}
        </div>
      </div>
    `;
  }
  // red
  return `
    <div class="appt-spec-result spec-red">
      <h5>✗ No availability for that slot</h5>
      <div>Try ASAP mode, a different date, or a different technician. Forcing an override is not enabled in this build.</div>
    </div>
  `;
}

function apptSlotRowHtml(sl, i, hidden) {
  const tech = sl.technician || {};
  const fitBand = sl.fit_band || 'fair';
  const fitLabel = ({great_fit:'Great Fit', good:'Good', fair:'Fair'})[fitBand] || 'Fair';
  const fitTooltip = (sl.fit_reasons || []).join(' · ') + (sl.fit_score != null ? ` (score ${sl.fit_score})` : '');
  const ribbon = sl.is_best_match ? `<span class="best-ribbon">Best</span>` : '';
  let travel = (sl.travel_min_from_prior != null) ? `${sl.travel_min_from_prior} min travel` : '';
  if ((sl.fit_reasons || []).includes('extended_travel')) travel += ' - longer drive (not ideal)';
  return `
    <button type="button" class="appt-slot-row${hidden ? ' is-hidden' : ''}" data-slot-idx="${i}" aria-selected="false" ${hidden ? 'style="display:none"' : ''} title="${escHTML(fitTooltip)}">
      <span class="slot-fit ${fitBand}">${escHTML(fitLabel)}</span>
      <div class="slot-when">${ribbon}${escHTML(apptFmtSlotWhen(sl))}</div>
      <div class="slot-tech">
        <span class="tech-avatar">${escHTML(apptInitialsOf(tech.name || ''))}</span>
        <span>${escHTML(tech.name || 'Any technician')}</span>
      </div>
      ${travel ? `<div class="slot-meta">${escHTML(travel)}</div>` : ''}
    </button>
  `;
}

function apptFmtSlotWhen(sl) {
  if (!sl.start_at) return '';
  const d = new Date(sl.start_at);
  const dateStr = d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
  // Phase 2 — show the 2-hour arrival window (the customer commitment) when the
  // slot falls in one; else the exact time.
  if (sl.win_label) return `${dateStr} · ${sl.win_label}`;
  const timeStr = d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  return `${dateStr} · ${timeStr}`;
}

// ---------------- Slot summary footer (aria-live) ----------------
function apptUpdateSummary() {
  const root = apptDrawer.rootEl;
  if (!root) return;
  const el = root.querySelector('#apptDrwSummary');
  const submit = root.querySelector('#apptDrwSubmit');
  const sl = apptDrawer.state.selectedSlot;
  if (!sl) {
    el.classList.add('is-empty');
    el.textContent = 'No slot selected yet.';
    if (submit) submit.disabled = true;
    return;
  }
  el.classList.remove('is-empty');
  const tech = (sl.technician && sl.technician.name) || 'Any technician';
  const when = apptFmtSlotWhen(sl);
  const dur = sl.duration_min ? `${sl.duration_min}m` : '';
  const fit = sl.fit_band ? ` · <strong>${escHTML(({great_fit:'Great Fit', good:'Good', fair:'Fair'})[sl.fit_band] || sl.fit_band)}</strong>${sl.fit_score != null ? ` (${sl.fit_score})` : ''}` : '';
  el.innerHTML = `<strong>${escHTML(when)}</strong> with ${escHTML(tech)} · ${escHTML(dur)}${fit}`;
  if (submit) submit.disabled = false;
}

// ---------------- Submit ----------------
async function apptDrawerSubmit() {
  if (apptDrawer.busy) return;
  const root = apptDrawer.rootEl;
  if (!root) return;
  const s = apptDrawer.state;
  // Defense in depth: never POST a create/reschedule without an address. The
  // suggest-call gate normally prevents getting here, but this catches edge
  // cases (address row deleted while drawer was open, stale state restored
  // from a previous open, etc).
  if (!s.address || !s.selectedAddressId) {
    if (typeof apptToast === 'function') apptToast('Pick a service address first.', 'error');
    // Bounce focus back to the picker if it exists.
    const sel = root.querySelector('#apptDrwAddrSel');
    if (sel) try { sel.focus(); } catch (e) {}
    return;
  }
  if (!s.serviceId) {
    if (typeof apptToast === 'function') apptToast('Pick a service first.', 'error');
    const sel = root.querySelector('#apptDrwService');
    if (sel) try { sel.focus(); } catch (e) {}
    return;
  }
  if (!s.selectedSlot) {
    if (typeof apptToast === 'function') apptToast('Pick a slot first.', 'error');
    return;
  }
  const submitBtn = root.querySelector('#apptDrwSubmit');
  apptDrawer.busy = true;
  if (submitBtn) submitBtn.disabled = true;

  let resp;
  try {
    if (apptDrawer.mode === 'create') {
      // Carry the picked service site so the per-site FK is set (not just the
      // free-text address) — this is what dispatches the tech to the right
      // property for multi-location customers. 'primary' = the customer's
      // single primary address (no ServiceLocation FK).
      const _siteId = (s.selectedAddressId && s.selectedAddressId !== 'primary') ? s.selectedAddressId : null;
      const body = {
        source: 'csr_inbox',
        customer_id: s.customerId,
        price: (s.price !== '' && s.price != null) ? s.price : null,
        slot_id: s.selectedSlot.slot_id,
        win_key: s.selectedSlot.win_key || null,
        service_id: s.serviceId || null,
        service_ids: s.serviceIds || (s.serviceId ? [s.serviceId] : []),
        service_location_id: _siteId,
        location: s.address ? { line1: s.address } : null,
        send_confirmation: { channel: s.sendChannel || 'sms' },
        conversation_id: s.conversationId || '',
        fit_score: s.selectedSlot.fit_score,
        fit_band: s.selectedSlot.fit_band,
        slot_rank_chosen: s.slots.indexOf(s.selectedSlot),
      };
      try {
        resp = await apptApiPost('/appointments/', body);
      } catch (ce) {
        // Multi-site address confirmation: the server refuses to book a
        // multi-location customer until the operator confirms the exact address
        // the technician will be dispatched to. Show it; on OK re-submit, on
        // Cancel leave the drawer open to pick a different site.
        if (ce && ce.status === 409 && ce.data && ce.data.error === 'address_confirmation_required') {
          const _addr = (ce.data.resolved_address || s.address || '');
          const ok = window.confirm('This customer has multiple service locations.\n\nThe technician will be dispatched to:\n' + _addr + '\n\nProceed with this address? (Cancel to go back and pick a different site.)');
          if (!ok) {
            apptDrawer.busy = false;
            if (submitBtn) submitBtn.disabled = false;
            return;
          }
          body.address_confirmed = true;
          resp = await apptApiPost('/appointments/', body);
        } else {
          throw ce;
        }
      }
    } else {
      // reschedule
      const body = {
        slot_id: s.selectedSlot.slot_id,
        reason: { code: s.rescheduleReasonCode || 'customer_request', comment: s.rescheduleReasonComment || '' },
        send_confirmation: { channel: s.sendChannel || 'sms' },
        conversation_id: s.conversationId || '',
      };
      resp = await apptApiPatch(`/appointments/${encodeURIComponent(apptDrawer.apptId)}/reschedule/`, body);
    }
  } catch (e) {
    apptDrawer.busy = false;
    if (submitBtn) submitBtn.disabled = false;
    // 409 TOCTOU — re-fetch slots.
    if (e && e.status === 409 && e.data && e.data.error === 'conflict_detected') {
      if (typeof apptToast === 'function') apptToast('That slot was just taken — refreshed options below.', 'error');
      apptDrawer.state.selectedSlot = null;
      apptDoSuggest();
      apptUpdateSummary();
      return;
    }
    const msg = (e && e.data && e.data.error) ? (typeof apptFriendlyErr === 'function' ? apptFriendlyErr(e) : e.message) : (e.message || 'Could not save.');
    if (typeof apptToast === 'function') apptToast(msg, 'error');
    return;
  }

  // Success.
  apptDrawer.busy = false;
  const verb = apptDrawer.mode === 'reschedule' ? 'Rescheduled' : 'Scheduled';
  if (typeof apptToast === 'function') apptToast(verb + ' ✓', 'success');

  // CSR-inbox: read contract/form checkboxes BEFORE the drawer DOM is torn down.
  let _pbOpts = null, _pbApptId = null, _pbCust = null, _pbChan = null;
  if (apptDrawer.mode === 'create') {
    const _ck = (id) => { const el = root.querySelector('#' + id); return !!(el && el.checked); };
    const _v  = (id) => { const el = root.querySelector('#' + id); return el ? (el.value || '').trim() : ''; };
    const wantCc = _ck('apptCkCcAuth'), wantMaint = _ck('apptCkMaint'), wantPref = _ck('apptCkPrefLink');
    if (wantCc || wantMaint || wantPref) {
      _pbApptId = resp && (resp.id || resp.appointment_id || (resp.appointment && resp.appointment.id));
      _pbCust = s.customerId;
      _pbChan = s.sendChannel || 'sms';
      _pbOpts = { ccAuth: wantCc, maint: wantMaint ? { freq: _v('apptMaintFreq') || 'quarterly', fee: _v('apptMaintFee') || '0', initial: _v('apptMaintInit') || '0' } : null, prefLink: wantPref };
    }
  }

  closeScheduleDrawer();
  if (_pbOpts && _pbApptId && typeof apptRunPostBooking === 'function') {
    apptRunPostBooking(_pbApptId, _pbCust, _pbChan, _pbOpts);
  } else if (_pbOpts && !_pbApptId) {
    if (typeof apptToast === 'function') apptToast('Booked, but could not attach contracts/forms (no appointment id).', 'error');
  }
  // The system_event arriving in the conversation thread will refresh the
  // appointments card via apptDetectSystemEvents() — no manual reload needed.
  // Belt-and-suspenders: nudge the conversation to refetch its messages.
  if (s.conversationId && typeof selectConversation === 'function') {
    setTimeout(() => selectConversation(s.conversationId), 250);
  }
}

// ---------------- Wiring: enable + Schedule, empty-state + Schedule, Reschedule ----------------
// Phase 1/2 left these buttons disabled. Phase 3 enables them via runtime
// fixup (so we don't have to surgery the template strings) and an event
// delegation handler.
document.addEventListener('click', function (e) {
  const t = e.target;
  if (!t || !t.closest) return;
  // Header + Schedule button.
  const headBtn = t.closest('#apptScheduleBtn');
  if (headBtn) {
    e.preventDefault(); e.stopPropagation();
    openScheduleDrawer({ mode: 'create' });
    return;
  }
  // Empty-state + Schedule button (rendered when there are no upcoming appts).
  const emptyBtn = t.closest('#apptEmptyScheduleBtn');
  if (emptyBtn) {
    e.preventDefault(); e.stopPropagation();
    openScheduleDrawer({ mode: 'create' });
    return;
  }
  // Customer-card + Schedule button (always visible on the customer card).
  const custSchedBtn = t.closest('#custScheduleBtn');
  if (custSchedBtn && !custSchedBtn.disabled) {
    e.preventDefault(); e.stopPropagation();
    openScheduleDrawer({ mode: 'create' });
    return;
  }
  // Row-kebab Reschedule menu item.
  const rsBtn = t.closest('button[data-action="reschedule"]');
  if (rsBtn && rsBtn.closest('.appt-row-menu')) {
    e.preventDefault(); e.stopPropagation();
    const apptId = rsBtn.closest('.appt-row-menu').dataset.apptId
                || rsBtn.dataset.apptId
                || (rsBtn.closest('.appt-kebab-host') && rsBtn.closest('.appt-kebab-host').dataset.apptId);
    if (typeof apptCloseRowMenu === 'function') apptCloseRowMenu();
    openScheduleDrawer({ mode: 'reschedule', apptId: apptId });
    return;
  }
});

// Re-enable buttons after each card render (Phase 1/2 set them disabled).
// Wrapping renderApptCard keeps Phase 3 additive — we don't surgery the
// template strings produced by earlier phases.
(function () {
  const orig = (typeof renderApptCard === 'function') ? renderApptCard : null;
  if (!orig) return;
  window.renderApptCard = function (host, payload, scope) {
    orig(host, payload, scope);
    if (!host) return;
    const sb = host.querySelector('#apptScheduleBtn');
    if (sb) {
      sb.disabled = false;
      sb.removeAttribute('title');
    }
    const eb = host.querySelector('#apptEmptyScheduleBtn');
    if (eb) {
      eb.disabled = false;
      eb.removeAttribute('title');
    }
  };
})();

// Enable Reschedule menu item after each kebab open. apptOpenRowMenu builds
// the menu DOM on demand; we patch the disabled item just after build.
(function () {
  const orig = (typeof apptOpenRowMenu === 'function') ? apptOpenRowMenu : null;
  if (!orig) return;
  window.apptOpenRowMenu = function (apptId, kebabBtn) {
    orig(apptId, kebabBtn);
    // Find the just-opened menu and unlock the Reschedule item.
    const menu = document.querySelector('.appt-row-menu');
    if (!menu) return;
    // Tag the menu with the apptId so the click delegation can recover it.
    menu.dataset.apptId = apptId || '';
    const rs = menu.querySelector('button[data-action="reschedule"]');
    if (rs) {
      rs.disabled = false;
      rs.removeAttribute('title');
      rs.dataset.apptId = apptId || '';
    }
  };
})();


// =============================================================================
// CSR Inbox — Generate contract from appointment (PR 2)
//
// Kebab → "Generate contract" → modal with template picker + fee fields →
//   POST /api/v1/contracts/contracts/generate-for-appointment/
//   → toast + open the new contract.
// =============================================================================

const apptGenContract = {
  busy: false,
  templates: null,        // [{id, name, contract_type, default_amount, default_initial_fee, default_recurring_fee}]
  selectedTplId: null,
  apptId: null,
  formState: { initial_treatment_fee: '', recurring_fee: '', one_time_fee: '', tax_rate: '' },
};

// CSR-inbox enhancement: helpers for the Generate-contract modal's
// "also send for signing" toggle and the standalone "preferred day/time form".
function apptGcSyncSubmitLabel(root) {
  const btn = root && root.querySelector('#apptGcSubmit');
  if (!btn) return;
  const ck = root.querySelector('#apptGcSendSign');
  btn.textContent = (ck && ck.checked) ? 'Generate & send' : 'Generate';
}

async function apptGcSendPrefForm(root, btn) {
  const status = root && root.querySelector('#apptGcPrefStatus');
  const a = (typeof apptFindAppt === 'function') ? apptFindAppt(apptGenContract.apptId) : null;
  const custId = (a && (a.customer_id || (a.customer && a.customer.id)))
    || ((typeof apptState !== 'undefined' && apptState && apptState.customerId) || null);
  if (!custId) { if (status) { status.textContent = 'No customer on file for this appointment.'; status.style.color = 'var(--danger, #c0392b)'; } return; }
  const chanEl = root.querySelector('#apptGcChannel');
  const channel = (chanEl && chanEl.value === 'email') ? 'email' : 'sms';
  if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }
  if (status) { status.textContent = ''; status.style.color = 'var(--text-light)'; }
  try {
    const r = await apptApiPost('/customers/' + encodeURIComponent(custId) + '/send-preference-link/', { channel: channel });
    if (status) { status.textContent = 'Sent ' + (r && r.channel === 'email' ? 'email' : 'text') + (r && r.recipient ? ' to ' + r.recipient : '') + ' ✓'; status.style.color = 'var(--success, #1a7f37)'; }
  } catch (e) {
    if (status) { status.textContent = 'Send failed: ' + ((e && e.message) || 'error'); status.style.color = 'var(--danger, #c0392b)'; }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '📅 Send preferred day/time form'; }
  }
}

async function apptOpenGenerateContractModal(apptId) {
  apptGenContract.busy = false;
  apptGenContract.apptId = apptId;
  apptGenContract.selectedTplId = null;
  apptGenContract.formState = { initial_treatment_fee: '', recurring_fee: '', one_time_fee: '', tax_rate: '' };

  const a = (typeof apptFindAppt === 'function') ? apptFindAppt(apptId) : null;
  const subtitle = a
    ? `For ${escHTML((a.service && a.service.name) || 'appointment')} on ${escHTML((typeof apptFmtWhen === 'function' ? apptFmtWhen(a.start_at) : (a.start_at || '')).abs || a.start_at || '')}`
    : '';

  const bodyHtml = `
    ${subtitle ? `<div style="font-size:11px;color:var(--text-light);margin-bottom:10px;line-height:1.4">${subtitle}</div>` : ''}
    <div style="font-size:12px;font-weight:600;color:var(--text);margin-bottom:6px">Template</div>
    <div id="apptGcTplHost" class="appt-gc-loading"><span class="spinner"></span>Loading templates…</div>
    <div id="apptGcFeeHost" style="display:none"></div>
    <div id="apptGcSignHost" style="display:none;margin-top:14px;border-top:1px solid var(--border);padding-top:12px">
      <label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer"><input type="checkbox" id="apptGcSendSign"><span>Also send to customer for signing</span></label>
      <div id="apptGcChanRow" style="display:none;margin:8px 0 0 26px"><span style="font-size:12px;color:var(--text-light);margin-right:6px">via</span><select id="apptGcChannel" style="padding:5px 8px;border:1px solid var(--border);border-radius:6px;font-size:13px"><option value="sms">Text message</option><option value="email">Email</option><option value="both">Both</option></select></div>
    </div>
    <div style="margin-top:14px;border-top:1px dashed var(--border);padding-top:12px">
      <div style="font-size:11px;font-weight:600;color:var(--text-light);letter-spacing:.04em;margin-bottom:6px">OTHER FORMS</div>
      <button type="button" id="apptGcPrefBtn" class="appt-modal-btn" style="font-size:12px">📅 Send preferred day/time form</button>
      <span id="apptGcPrefStatus" style="font-size:12px;color:var(--text-light);margin-left:8px"></span>
    </div>
  `;

  const footerHtml = `
    <button type="button" class="appt-modal-btn" data-appt-modal-close>Cancel</button>
    <button type="button" class="appt-modal-btn appt-modal-btn-primary" id="apptGcSubmit" disabled>Generate</button>
  `;

  apptModalOpen({
    title: 'Generate contract',
    bodyHtml,
    footerHtml,
    onOpen: (root) => {
      const submitBtn = root.querySelector('#apptGcSubmit');
      if (submitBtn) submitBtn.onclick = () => apptDoGenerateContract(root);
      apptLoadGenerateTemplates(root);
      const _ss = root.querySelector('#apptGcSendSign');
      if (_ss) _ss.addEventListener('change', function () {
        const cr = root.querySelector('#apptGcChanRow'); if (cr) cr.style.display = _ss.checked ? '' : 'none';
        if (typeof apptGcSyncSubmitLabel === 'function') apptGcSyncSubmitLabel(root);
      });
      const _pb = root.querySelector('#apptGcPrefBtn');
      if (_pb) _pb.addEventListener('click', function () { apptGcSendPrefForm(root, _pb); });
    },
  });
}

async function apptLoadGenerateTemplates(root) {
  const host = root.querySelector('#apptGcTplHost');
  if (!host) return;
  let data;
  try {
    data = await apptApi('/contracts/templates/?limit=100');
  } catch (e) {
    host.classList.remove('appt-gc-loading');
    host.innerHTML = `<div class="appt-gc-empty">Couldn't load templates: ${escHTML((e && e.message) || 'unknown error')}</div>`;
    return;
  }
  const tpls = (data && (data.results || data)) || [];
  apptGenContract.templates = tpls;

  if (!tpls.length) {
    host.classList.remove('appt-gc-loading');
    host.innerHTML = `<div class="appt-gc-empty">No contract templates found.<br><a href="/contracts/" target="_blank" rel="noopener">Create one in Contracts →</a></div>`;
    return;
  }

  host.classList.remove('appt-gc-loading');
  host.classList.add('appt-gc-template-list');
  host.innerHTML = tpls.map((t, i) => {
    const typeLabel = ({one_time:'One-time', monthly:'Monthly', quarterly:'Quarterly', annual:'Annual', bi_monthly:'Bi-monthly'})[t.contract_type] || t.contract_type || '';
    const meta = [];
    if (t.default_initial_fee && parseFloat(t.default_initial_fee) > 0) meta.push(`Initial $${parseFloat(t.default_initial_fee).toFixed(2)}`);
    if (t.default_recurring_fee && parseFloat(t.default_recurring_fee) > 0) meta.push(`Recurring $${parseFloat(t.default_recurring_fee).toFixed(2)}`);
    if (t.default_amount && parseFloat(t.default_amount) > 0 && (!t.default_initial_fee || parseFloat(t.default_initial_fee) === 0)) meta.push(`Amount $${parseFloat(t.default_amount).toFixed(2)}`);
    return `
      <button type="button" class="appt-gc-tpl-row" data-tpl-idx="${i}" aria-selected="false">
        <div class="appt-gc-tpl-name">${escHTML(t.name)}${typeLabel ? `<span class="appt-gc-tpl-type-pill">${escHTML(typeLabel)}</span>` : ''}</div>
        ${meta.length ? `<div class="appt-gc-tpl-meta">${escHTML(meta.join(' · '))}</div>` : ''}
      </button>
    `;
  }).join('');

  host.querySelectorAll('.appt-gc-tpl-row').forEach(row => {
    row.addEventListener('click', () => {
      const idx = parseInt(row.dataset.tplIdx, 10);
      const tpl = tpls[idx];
      if (!tpl) return;
      apptGenContract.selectedTplId = tpl.id;
      host.querySelectorAll('.appt-gc-tpl-row').forEach(r =>
        r.setAttribute('aria-selected', r === row ? 'true' : 'false'));
      apptRenderGenerateFees(root, tpl);
      const submitBtn = root.querySelector('#apptGcSubmit');
      if (submitBtn) submitBtn.disabled = false;
    });
  });
}

function apptRenderGenerateFees(root, tpl) {
  const host = root.querySelector('#apptGcFeeHost');
  if (!host) return;
  host.style.display = '';
  const _sh = root.querySelector('#apptGcSignHost'); if (_sh) _sh.style.display = '';
  if (typeof apptGcSyncSubmitLabel === 'function') apptGcSyncSubmitLabel(root);
  const isOneTime = tpl.contract_type === 'one_time';
  const init = parseFloat(tpl.default_initial_fee || 0).toFixed(2);
  const recur = parseFloat(tpl.default_recurring_fee || 0).toFixed(2);
  const amt = parseFloat(tpl.default_amount || 0).toFixed(2);

  apptGenContract.formState = {
    initial_treatment_fee: init !== '0.00' ? init : '',
    recurring_fee: recur !== '0.00' ? recur : '',
    one_time_fee: amt !== '0.00' ? amt : '',
    tax_rate: '',
  };

  host.innerHTML = `
    <div style="font-size:12px;font-weight:600;color:var(--text);margin:14px 0 6px">Fees <span style="font-weight:400;color:var(--text-light);font-size:11px">(prefilled from template — override if needed)</span></div>
    <div class="appt-gc-fee-row">
      ${isOneTime ? `
        <div class="appt-gc-fee">
          <label>One-time fee <span class="hint">$</span></label>
          <input type="number" id="apptGcOneTime" min="0" step="0.01" value="${escHTML(apptGenContract.formState.one_time_fee)}" placeholder="0.00">
        </div>
      ` : `
        <div class="appt-gc-fee">
          <label>Initial fee <span class="hint">$</span></label>
          <input type="number" id="apptGcInitial" min="0" step="0.01" value="${escHTML(apptGenContract.formState.initial_treatment_fee)}" placeholder="0.00">
        </div>
        <div class="appt-gc-fee">
          <label>Recurring fee <span class="hint">$</span></label>
          <input type="number" id="apptGcRecurring" min="0" step="0.01" value="${escHTML(apptGenContract.formState.recurring_fee)}" placeholder="0.00">
        </div>
      `}
      <div class="appt-gc-fee">
        <label>Tax rate <span class="hint">%</span> <a href="#" id="apptGcTaxLookup" style="font-size:11px;color:#1976d2;text-decoration:none;margin-left:4px">📍 Lookup</a></label>
        <input type="number" id="apptGcTax" min="0" max="100" step="0.01" value="${escHTML(apptGenContract.formState.tax_rate)}" placeholder="0">
      </div>
    </div>
  `;

  const bind = (id, key) => {
    const el = root.querySelector('#' + id);
    if (el) el.addEventListener('input', () => { apptGenContract.formState[key] = el.value; });
  };
  if (isOneTime) {
    bind('apptGcOneTime', 'one_time_fee');
  } else {
    bind('apptGcInitial', 'initial_treatment_fee');
    bind('apptGcRecurring', 'recurring_fee');
  }
  bind('apptGcTax', 'tax_rate');
  const taxLookupLink = root.querySelector('#apptGcTaxLookup');
  if (taxLookupLink) taxLookupLink.addEventListener('click', (e) => { e.preventDefault(); apptLookupTax(root); });
}

async function apptLookupTax(root) {
  const apptId = apptGenContract.apptId;
  if (!apptId) { apptToast('No appointment context.', 'error'); return; }
  const a = (typeof apptFindAppt === 'function') ? apptFindAppt(apptId) : null;
  if (!a) { apptToast('Could not find that appointment.', 'error'); return; }
  // Get customer ID — apptFindAppt returns the list-API shape, which may
  // expose .customer as an object or a UUID string.
  const cid = (a.customer && (a.customer.id || a.customer)) || a.customer_id || null;
  if (!cid) { apptToast('Appointment has no customer.', 'error'); return; }
  // Service-location may or may not be on the appt object.
  const slid = (a.service_location && (a.service_location.id || a.service_location)) || a.service_location_id || null;
  try {
    let st = '', ci = '';
    if (slid) {
      try {
        const slr = await fetch('/api/v1/service-locations/' + slid + '/', {credentials:'same-origin'});
        if (slr.ok) { const l = await slr.json(); st = l.state || ''; ci = l.city || ''; }
      } catch (_e) {}
    }
    if (!st || !ci) {
      const cr = await fetch('/api/v1/customers/' + cid + '/', {credentials:'same-origin'});
      if (cr.ok) {
        const c = await cr.json();
        if (!st) st = c.service_state || c.billing_state || '';
        if (!ci) ci = c.service_city || c.billing_city || '';
        if (!ci || !st) {
          const addr = (c.service_address || c.billing_address || '').trim();
          const m = /,\s*([^,]+?)\s*,\s*([A-Z]{2})(?:\s+(\d{5}))?(?:\s*,\s*USA)?\s*$/i.exec(addr);
          if (m) { if (!ci) ci = m[1].trim(); if (!st) st = m[2].toUpperCase(); }
        }
      }
    }
    if (!st) { apptToast('Could not determine state for this customer.', 'error'); return; }
    const tr = await fetch('/api/v1/billing/tax-lookup/?state=' + encodeURIComponent(st) + '&city=' + encodeURIComponent(ci), {credentials:'same-origin'});
    if (tr.ok) {
      const t = await tr.json();
      if (t.combined_rate) {
        const input = (root || document).querySelector('#apptGcTax');
        if (input) input.value = t.combined_rate;
        apptGenContract.formState.tax_rate = String(t.combined_rate);
        apptToast('Tax rate set: ' + t.combined_rate + '% (' + (t.city || t.county || t.state) + ')', 'success');
        return;
      }
    }
    apptToast('No tax rate found for ' + (ci || '(no city)') + ', ' + st, 'error');
  } catch (e) {
    apptToast('Tax lookup failed', 'error');
  }
}

async function apptDoGenerateContract(root) {
  if (apptGenContract.busy) return;
  if (!apptGenContract.selectedTplId) {
    if (typeof apptToast === 'function') apptToast('Pick a template first.', 'error');
    return;
  }
  if (!apptGenContract.apptId) {
    if (typeof apptToast === 'function') apptToast('Internal error: appointment id missing.', 'error');
    return;
  }
  const submitBtn = root.querySelector('#apptGcSubmit');
  apptGenContract.busy = true;
  if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Generating…'; }

  const fs = apptGenContract.formState;
  const body = {
    template_id: apptGenContract.selectedTplId,
    appointment_id: apptGenContract.apptId,
  };
  // Only send fee fields the user actually set (BE falls back to template defaults).
  if (fs.initial_treatment_fee !== '') body.initial_treatment_fee = fs.initial_treatment_fee;
  if (fs.recurring_fee !== '')         body.recurring_fee         = fs.recurring_fee;
  if (fs.one_time_fee !== '')          body.one_time_fee          = fs.one_time_fee;
  if (fs.tax_rate !== '')              body.tax_rate              = fs.tax_rate;

  let resp;
  try {
    resp = await apptApiPost('/contracts/contracts/generate-for-appointment/', body);
  } catch (e) {
    apptGenContract.busy = false;
    if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Generate'; }
    const msg = (typeof apptFriendlyErr === 'function') ? apptFriendlyErr(e) : ((e && e.message) || 'Could not generate contract.');
    if (typeof apptToast === 'function') apptToast(msg, 'error');
    return;
  }

  apptGenContract.busy = false;
  let _gcSent = false;
  const _gcSendCk = root.querySelector('#apptGcSendSign');
  if (_gcSendCk && _gcSendCk.checked) {
    const _gcCid = resp && (resp.id || resp.contract_id);
    const _gcChanEl = root.querySelector('#apptGcChannel');
    const _gcChan = (_gcChanEl && _gcChanEl.value) || 'sms';
    if (_gcCid) {
      try { await apptApiPost('/contracts/contracts/' + encodeURIComponent(_gcCid) + '/send_for_signing/', { channel: _gcChan }); _gcSent = true; }
      catch (e) { if (typeof apptToast === 'function') apptToast('Generated, but send failed: ' + ((e && e.message) || 'error'), 'error'); }
    }
  }
  if (typeof apptToast === 'function') apptToast(_gcSent ? 'Contract generated & sent ✓' : 'Contract generated ✓', 'success');
  if (typeof apptModalClose === 'function') apptModalClose();
  // Open the new contract in a new tab so the CSR keeps their inbox flow.
  const url = (resp && resp.id) ? `/contracts/?id=${encodeURIComponent(resp.id)}` : '/contracts/';
  try { window.open(url, '_blank', 'noopener'); }
  catch (e) { /* popup blocked — toast already shown, contract is created */ }
}



// =============================================================================
// CSR Inbox — Schedule from unknown caller (new-customer + drawer)
//
// Click '+ Schedule' on the Unidentified-caller sidebar card  ->
//   Step A: New-customer modal (all fields available, smart defaults,
//           required = type/first/last/phone/service_address)
//   POST /api/v1/customers/  (BE auto-normalizes phone, returns full payload
//     including service_locations)
//   Step B: Modal closes  ->  openScheduleDrawer({mode:'create'}) chains in
//           with the new customerId baked into apptState.
//
// Why this design:
//   - The schedule drawer reads apptState.customerId, so we just have to
//     update that and call the existing function. Zero new drawer code.
//   - The form mirrors the Customer model so a CSR doesn't have to bounce
//     to the customer page mid-call. Optional sections are collapsed by
//     default to keep the on-call cognitive load low.
//
// Required fields (mirrors Customer model + serializer validation):
//   * customer_type (default residential)
//   * first_name, last_name
//   * phone (prefilled from conversation; BE normalizes)
//   * service_address
// Optional but commonly captured during a first call:
//   * email, phone_alt
//   * service_address_2, city, state, zip
//   * preferred_contact_type, contact_title, property_type
//   * Commercial-only: company_name (REQUIRED if customer_type=commercial)
// Hidden behind 'Different billing contact' toggle:
//   * billing_* fields (only sent if billing_same_as_service=false)
// =============================================================================

const apptNewCust = {
  busy: false,
  prefilledPhone: '',
  conversationId: '',
};

// Open the new-customer modal. The schedule drawer chains in on success.
function apptOpenNewCustomerModal(prefilledPhone, conversationId) {
  apptNewCust.busy = false;
  apptNewCust.prefilledPhone = prefilledPhone || '';
  apptNewCust.conversationId = conversationId || '';

  const stateOpts = ['PA','NJ','DE','NY','MD','CT','MA','RI','VT','NH','ME','VA','WV','OH','FL','CA','TX','IL','GA','NC','SC','TN','KY','IN','MI','WI','MN','IA','MO','AR','LA','MS','AL','OK','KS','NE','SD','ND','MT','WY','CO','NM','AZ','UT','NV','ID','OR','WA','AK','HI','DC']
    .map(s => `<option value="${s}"${s === 'PA' ? ' selected' : ''}>${s}</option>`).join('');
  const propTypeOpts = [
    ['house','House'], ['apartment','Apartment'], ['multifamily','Multifamily'],
    ['retail','Retail'], ['office','Office'], ['industrial','Industrial'],
    ['restaurant','Restaurant'], ['hospitality','Hospitality'], ['land','Land'],
  ].map(([v,l]) => `<option value="${v}">${escHTML(l)}</option>`).join('');
  const titleOpts = [
    ['owner','Owner'], ['landlord','Landlord'], ['tenant','Tenant'], ['property_manager','Property Manager'],
  ].map(([v,l]) => `<option value="${v}">${escHTML(l)}</option>`).join('');
  const contactPrefOpts = [
    ['phone','Phone'], ['sms','SMS'], ['email','Email'],
  ].map(([v,l]) => `<option value="${v}">${escHTML(l)}</option>`).join('');

  const bodyHtml = `
    <div class="appt-nc-modal-body">
      <div class="appt-nc-banner">
        <span class="appt-nc-step-pill">Step 1 of 2</span>
        <strong>Create customer</strong>, then pick a slot. The phone number is prefilled from this call.
      </div>

      <!-- Customer type -->
      <div class="appt-nc-section">
        <div class="appt-nc-section-title">Customer</div>
        <div class="appt-nc-row">
          <div class="appt-nc-field">
            <label>Type<span class="req">*</span></label>
            <select id="apptNcType">
              <option value="residential" selected>Residential</option>
              <option value="commercial">Commercial</option>
            </select>
          </div>
          <div class="appt-nc-field flex-2" id="apptNcCompanyWrap" style="display:none">
            <label>Company name<span class="req" id="apptNcCompanyReq">*</span></label>
            <input type="text" id="apptNcCompany" maxlength="200">
            <div class="appt-nc-field-err" id="apptNcCompanyErr"></div>
          </div>
        </div>
        <div class="appt-nc-row">
          <div class="appt-nc-field">
            <label>First name<span class="req">*</span></label>
            <input type="text" id="apptNcFirst" maxlength="100" autocomplete="given-name" required>
            <div class="appt-nc-field-err" id="apptNcFirstErr"></div>
          </div>
          <div class="appt-nc-field">
            <label>Last name<span class="req">*</span></label>
            <input type="text" id="apptNcLast" maxlength="100" autocomplete="family-name" required>
            <div class="appt-nc-field-err" id="apptNcLastErr"></div>
          </div>
        </div>
        <div class="appt-nc-row">
          <div class="appt-nc-field">
            <label>Phone<span class="req">*</span></label>
            <input type="tel" id="apptNcPhone" maxlength="20" value="${escHTML(apptNewCust.prefilledPhone)}" autocomplete="tel" required>
            <div class="appt-nc-field-err" id="apptNcPhoneErr"></div>
          </div>
          <div class="appt-nc-field">
            <label>Alt phone <span class="hint">optional</span></label>
            <input type="tel" id="apptNcPhoneAlt" maxlength="20">
          </div>
        </div>
        <div class="appt-nc-row">
          <div class="appt-nc-field flex-2">
            <label>Email <span class="hint">optional</span></label>
            <input type="email" id="apptNcEmail" maxlength="254" autocomplete="email">
            <div class="appt-nc-field-err" id="apptNcEmailErr"></div>
          </div>
          <div class="appt-nc-field">
            <label>Preferred contact</label>
            <select id="apptNcPrefContact">${contactPrefOpts}</select>
          </div>
        </div>
      </div>

      <!-- Service address -->
      <div class="appt-nc-section">
        <div class="appt-nc-section-title">Service address</div>
        <div class="appt-nc-row">
          <div class="appt-nc-field">
            <label>Street<span class="req">*</span></label>
            <input type="text" id="apptNcAddr" maxlength="300" autocomplete="address-line1" required>
            <div class="appt-nc-field-err" id="apptNcAddrErr"></div>
          </div>
          <div class="appt-nc-field">
            <label>Apt/Suite <span class="hint">optional</span></label>
            <input type="text" id="apptNcAddr2" maxlength="100" autocomplete="address-line2">
          </div>
        </div>
        <div class="appt-nc-row">
          <div class="appt-nc-field flex-2">
            <label>City</label>
            <input type="text" id="apptNcCity" maxlength="100" autocomplete="address-level2">
          </div>
          <div class="appt-nc-field">
            <label>State</label>
            <select id="apptNcState">${stateOpts}</select>
          </div>
          <div class="appt-nc-field">
            <label>ZIP</label>
            <input type="text" id="apptNcZip" maxlength="10" autocomplete="postal-code">
          </div>
        </div>
        <div class="appt-nc-row">
          <div class="appt-nc-field">
            <label>Property type</label>
            <select id="apptNcPropType">${propTypeOpts}</select>
          </div>
          <div class="appt-nc-field">
            <label>Contact title</label>
            <select id="apptNcContactTitle">${titleOpts}</select>
          </div>
        </div>
      </div>

      <!-- Different billing toggle -->
      <div class="appt-nc-section">
        <label class="appt-nc-toggle-row">
          <input type="checkbox" id="apptNcDiffBilling">
          <span>Different billing contact / address</span>
        </label>
        <div id="apptNcBillingHost" class="appt-nc-collapsible is-hidden">
          <div class="appt-nc-row">
            <div class="appt-nc-field">
              <label>Billing first name</label>
              <input type="text" id="apptNcBillFirst" maxlength="100">
            </div>
            <div class="appt-nc-field">
              <label>Billing last name</label>
              <input type="text" id="apptNcBillLast" maxlength="100">
            </div>
          </div>
          <div class="appt-nc-row">
            <div class="appt-nc-field flex-2">
              <label>Billing email</label>
              <input type="email" id="apptNcBillEmail" maxlength="254">
            </div>
            <div class="appt-nc-field">
              <label>Billing phone</label>
              <input type="tel" id="apptNcBillPhone" maxlength="20">
            </div>
          </div>
          <div class="appt-nc-row">
            <div class="appt-nc-field flex-2">
              <label>Billing company</label>
              <input type="text" id="apptNcBillCompany" maxlength="200">
            </div>
          </div>
          <div class="appt-nc-row">
            <div class="appt-nc-field">
              <label>Billing street</label>
              <input type="text" id="apptNcBillAddr" maxlength="300">
            </div>
            <div class="appt-nc-field">
              <label>Billing apt/suite</label>
              <input type="text" id="apptNcBillAddr2" maxlength="100">
            </div>
          </div>
          <div class="appt-nc-row">
            <div class="appt-nc-field flex-2">
              <label>Billing city</label>
              <input type="text" id="apptNcBillCity" maxlength="100">
            </div>
            <div class="appt-nc-field">
              <label>State</label>
              <select id="apptNcBillState"><option value=""></option>${stateOpts}</select>
            </div>
            <div class="appt-nc-field">
              <label>ZIP</label>
              <input type="text" id="apptNcBillZip" maxlength="10">
            </div>
          </div>
        </div>
      </div>

      <div class="appt-nc-form-err" id="apptNcFormErr"></div>
    </div>
  `;

  const footerHtml = `
    <button type="button" class="appt-modal-btn" data-appt-modal-close>Cancel</button>
    <button type="button" class="appt-modal-btn appt-modal-btn-primary" id="apptNcSubmit">Create &amp; Schedule</button>
  `;

  apptModalOpen({
    title: 'New customer',
    bodyHtml,
    footerHtml,
    onOpen: (root) => {
      // Type toggle controls company-name visibility + required-ness.
      const typeSel = root.querySelector('#apptNcType');
      const companyWrap = root.querySelector('#apptNcCompanyWrap');
      const companyReq = root.querySelector('#apptNcCompanyReq');
      const companyInp = root.querySelector('#apptNcCompany');
      const onTypeChange = () => {
        const isComm = typeSel.value === 'commercial';
        companyWrap.style.display = isComm ? '' : 'none';
        companyReq.style.display = isComm ? '' : 'none';
        if (!isComm) companyInp.value = '';
      };
      typeSel.addEventListener('change', onTypeChange);
      onTypeChange();

      // Different-billing toggle.
      const diffBill = root.querySelector('#apptNcDiffBilling');
      const billHost = root.querySelector('#apptNcBillingHost');
      diffBill.addEventListener('change', () => {
        billHost.classList.toggle('is-hidden', !diffBill.checked);
      });

      // Submit.
      root.querySelector('#apptNcSubmit').addEventListener('click', () => apptDoCreateCustomerAndSchedule(root));
      // Google Places autocomplete on the service-address street field —
      // auto-fills city / state / ZIP (parity with the appointment address modal).
      try { _apptWireAddrAutocompleteOn(root, { line1:'#apptNcAddr', line2:'#apptNcAddr2', city:'#apptNcCity', state:'#apptNcState', zip:'#apptNcZip' }); } catch (e) {}

      // Initial focus to first name (phone is already prefilled).
      setTimeout(() => {
        const firstInp = root.querySelector('#apptNcFirst');
        if (firstInp) firstInp.focus();
      }, 60);
    },
  });
}

async function apptDoCreateCustomerAndSchedule(root) {
  if (apptNewCust.busy) return;
  const submitBtn = root.querySelector('#apptNcSubmit');
  const formErr = root.querySelector('#apptNcFormErr');

  // Clear previous errors.
  root.querySelectorAll('.appt-nc-field-err.is-shown').forEach(e => {
    e.classList.remove('is-shown'); e.textContent = '';
  });
  root.querySelectorAll('[aria-invalid="true"]').forEach(e => e.removeAttribute('aria-invalid'));
  formErr.classList.remove('is-shown'); formErr.textContent = '';

  const v = (id) => (root.querySelector('#' + id).value || '').trim();
  const checked = (id) => root.querySelector('#' + id).checked;

  const customer_type = v('apptNcType') || 'residential';
  const company_name = v('apptNcCompany');
  const first_name = v('apptNcFirst');
  const last_name = v('apptNcLast');
  const phone = v('apptNcPhone');
  const phone_alt = v('apptNcPhoneAlt');
  const email = v('apptNcEmail');
  const pref_contact = v('apptNcPrefContact') || 'phone';
  const service_address = v('apptNcAddr');
  const service_address_2 = v('apptNcAddr2');
  const service_city = v('apptNcCity');
  const service_state = v('apptNcState') || 'PA';
  const service_zip = v('apptNcZip');
  const property_type = v('apptNcPropType') || 'house';
  const contact_title = v('apptNcContactTitle') || 'owner';
  const diff_billing = checked('apptNcDiffBilling');

  // Client-side required-field validation. Server is the source of truth, but
  // catching obvious gaps here saves a roundtrip + provides per-field hints.
  const required = [
    ['apptNcFirst', first_name, 'First name is required.'],
    ['apptNcLast',  last_name,  'Last name is required.'],
    ['apptNcPhone', phone,      'Phone is required.'],
    ['apptNcAddr',  service_address, 'Service address is required.'],
  ];
  if (customer_type === 'commercial') {
    required.push(['apptNcCompany', company_name, 'Company name is required for commercial customers.']);
  }
  let firstBadId = null;
  for (const [id, val, msg] of required) {
    if (!val) {
      const inp = root.querySelector('#' + id);
      const errEl = root.querySelector('#' + id + 'Err');
      if (inp) inp.setAttribute('aria-invalid', 'true');
      if (errEl) { errEl.textContent = msg; errEl.classList.add('is-shown'); }
      if (!firstBadId) firstBadId = id;
    }
  }
  // Email format check (loose — server has the real validator).
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    const errEl = root.querySelector('#apptNcEmailErr');
    root.querySelector('#apptNcEmail').setAttribute('aria-invalid', 'true');
    errEl.textContent = 'Email looks invalid.';
    errEl.classList.add('is-shown');
    if (!firstBadId) firstBadId = 'apptNcEmail';
  }
  if (firstBadId) {
    try { root.querySelector('#' + firstBadId).focus(); } catch (e) {}
    return;
  }

  // Build payload — only include billing fields if user opted in.
  const body = {
    customer_type,
    first_name, last_name,
    phone,
    service_address, service_state,
    preferred_contact_type: pref_contact,
    property_type, contact_title,
    billing_same_as_service: !diff_billing,
  };
  if (company_name) body.company_name = company_name;
  if (phone_alt) body.phone_alt = phone_alt;
  if (email) body.email = email;
  if (service_address_2) body.service_address_2 = service_address_2;
  if (service_city) body.service_city = service_city;
  if (service_zip) body.service_zip = service_zip;

  if (diff_billing) {
    body.billing_first_name = v('apptNcBillFirst');
    body.billing_last_name  = v('apptNcBillLast');
    body.billing_email      = v('apptNcBillEmail');
    body.billing_phone      = v('apptNcBillPhone');
    body.billing_company    = v('apptNcBillCompany');
    body.billing_address    = v('apptNcBillAddr');
    body.billing_address_2  = v('apptNcBillAddr2');
    body.billing_city       = v('apptNcBillCity');
    body.billing_state      = v('apptNcBillState');
    body.billing_zip        = v('apptNcBillZip');
  }

  // BE Task-2 polish — these are optional fields the BE may or may not honor
  // yet. Sending them is harmless if unsupported.
  if (apptNewCust.conversationId) body.conversation_id = apptNewCust.conversationId;
  body.source = 'csr_inbox_unknown_caller';

  apptNewCust.busy = true;
  if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Creating…'; }

  let cust;
  try {
    cust = await apptApiPost('/customers/', body);
  } catch (e) {
    apptNewCust.busy = false;
    if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Create & Schedule'; }
    // DRF returns field-level errors as {field: [msgs]} — surface them inline.
    if (e && e.status === 400 && e.data && typeof e.data === 'object') {
      const fieldMap = {
        first_name:'apptNcFirst', last_name:'apptNcLast',
        phone:'apptNcPhone', email:'apptNcEmail',
        service_address:'apptNcAddr', company_name:'apptNcCompany',
      };
      let consumedSomething = false;
      Object.keys(e.data).forEach(k => {
        const dom = fieldMap[k];
        if (!dom) return;
        const errEl = root.querySelector('#' + dom + 'Err');
        const inp = root.querySelector('#' + dom);
        const msg = Array.isArray(e.data[k]) ? e.data[k].join(' ') : String(e.data[k]);
        if (inp) inp.setAttribute('aria-invalid', 'true');
        if (errEl) { errEl.textContent = msg; errEl.classList.add('is-shown'); }
        consumedSomething = true;
      });
      if (!consumedSomething) {
        formErr.textContent = (typeof apptFriendlyErr === 'function') ? apptFriendlyErr(e) : (e.message || 'Could not create customer.');
        formErr.classList.add('is-shown');
      }
    } else {
      formErr.textContent = (typeof apptFriendlyErr === 'function') ? apptFriendlyErr(e) : ((e && e.message) || 'Could not create customer.');
      formErr.classList.add('is-shown');
    }
    return;
  }

  // Success — close the new-customer modal and chain into the schedule drawer.
  apptNewCust.busy = false;
  if (typeof apptToast === 'function') apptToast('Customer created ✓', 'success');
  if (typeof apptModalClose === 'function') apptModalClose();

  // Update apptState so the drawer + appointments card both wire up to the
  // new customer. Phase 1 expects apptState.customerId; the drawer reads
  // it from there in openScheduleDrawer's create-mode branch.
  if (typeof apptState !== 'undefined') {
    apptState.customerId = cust.id;
  }
  // Refresh the customer card (right rail) — selectConversation re-fetches,
  // which is the cheapest way to repaint the whole sidebar with the now-known
  // customer. Falls back to just opening the drawer if we can't.
  if (apptNewCust.conversationId && typeof selectConversation === 'function') {
    try { selectConversation(apptNewCust.conversationId); } catch (e) {}
  }
  // Open the schedule drawer in create mode after a tiny tick so the right
  // rail repaint doesn't fight the modal-close transition.
  setTimeout(() => {
    if (typeof openScheduleDrawer === 'function') openScheduleDrawer({ mode: 'create' });
  }, 100);
}

// ---------------- Wiring: + Schedule on unidentified-caller card ----------------
// The button is rendered into the right rail's customer card every time
// renderCustomerCard runs. Use event delegation on document so we don't have
// to re-bind on every render.
document.addEventListener('click', function (e) {
  const btn = e.target && e.target.closest && e.target.closest('#apptUnknownScheduleBtn');
  if (!btn) return;
  e.preventDefault(); e.stopPropagation();
  const phone = btn.dataset.convPhone || '';
  const convId = btn.dataset.convId || '';
  apptOpenNewCustomerModal(phone, convId);
});

// ---------------- Wiring: Link to Customer on unidentified-caller card ----------------
document.addEventListener('click', function (e) {
  const btn = e.target && e.target.closest && e.target.closest('#linkCustomerBtn');
  if (!btn) return;
  e.preventDefault(); e.stopPropagation();
  openLinkCustomerModal(btn.dataset.convId || '');
});

function openLinkCustomerModal(convId) {
  var selected = null;

  apptModalOpen({
    title: 'Link to Existing Customer',
    bodyHtml: `
      <div class="field">
        <label>Search by name, phone, or email</label>
        <input type="text" id="linkCustSearch" placeholder="e.g. John Smith or 555-1234" autocomplete="off">
      </div>
      <div id="linkCustResults" style="margin-top:8px;max-height:220px;overflow-y:auto"></div>
    `,
    footerHtml: `
      <button type="button" class="btn" onclick="apptModalClose()">Cancel</button>
      <button type="button" class="btn btn-primary" id="linkCustConfirmBtn" disabled>Link</button>
    `,
    onOpen: function (overlay) {
      var inp = overlay.querySelector('#linkCustSearch');
      var results = overlay.querySelector('#linkCustResults');
      var confirmBtn = overlay.querySelector('#linkCustConfirmBtn');
      var debounceTimer;

      inp.addEventListener('input', function () {
        clearTimeout(debounceTimer);
        var q = inp.value.trim();
        if (q.length < 2) { results.innerHTML = ''; selected = null; confirmBtn.disabled = true; return; }
        debounceTimer = setTimeout(function () {
          results.innerHTML = '<div style="color:var(--text-light);font-size:12px;padding:4px 0">Searching…</div>';
          fetch('/api/v1/customer-search/?q=' + encodeURIComponent(q), {
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json', 'X-CSRFToken': csrftoken },
          }).then(function (r) {
            if (!r.ok) throw new Error(r.statusText);
            return r.json();
          }).then(function (data) {
            if (!data.length) {
              results.innerHTML = '<div style="color:var(--text-light);font-size:12px;padding:4px 0">No customers found.</div>';
              return;
            }
            results.innerHTML = data.map(function (c) {
              var sub = [c.phone, c.email].filter(Boolean).join(' · ');
              return '<div class="link-cust-item" data-id="' + escHTML(c.id) + '" data-name="' + escHTML(c.full_name) + '" tabindex="0">'
                + '<strong>' + escHTML(c.full_name) + '</strong>'
                + (sub ? '<span style="color:var(--text-light);font-size:11px;margin-left:6px">' + escHTML(sub) + '</span>' : '')
                + '</div>';
            }).join('');
            results.querySelectorAll('.link-cust-item').forEach(function (item) {
              item.addEventListener('click', function () {
                results.querySelectorAll('.link-cust-item').forEach(function (i) { i.classList.remove('selected'); });
                item.classList.add('selected');
                selected = { id: item.dataset.id, name: item.dataset.name };
                confirmBtn.disabled = false;
              });
              item.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); item.click(); }
              });
            });
          }).catch(function (err) {
            results.innerHTML = '<div style="color:#c62828;font-size:12px;padding:4px 0">Search failed: ' + escHTML(err.message) + '</div>';
          });
        }, 300);
      });

      confirmBtn.addEventListener('click', function () {
        if (!selected) return;
        confirmBtn.disabled = true;
        confirmBtn.textContent = 'Linking…';
        api('/inbox/' + convId + '/link-customer/', {
          method: 'POST',
          body: JSON.stringify({ customer_id: selected.id }),
        }).then(function () {
          var name = selected.name;
          apptModalClose();
          showInboxToast('Conversation linked to ' + name);
          selectConversation(convId);
          loadList();
        }).catch(function (err) {
          confirmBtn.disabled = false;
          confirmBtn.textContent = 'Link';
          results.insertAdjacentHTML('beforeend', '<div style="color:#c62828;font-size:12px;margin-top:6px">Error: ' + escHTML(err.message) + '</div>');
        });
      });
    },
  });
}



// =============================================================================
// CSR Inbox - Create ticket modal
//
// + New ticket button on customer card -> modal -> POST /api/v1/tickets/tickets/
//   BE handles tenant, dept routing (CategoryDepartmentMap), SLA, auto-assign.
// =============================================================================

const TICKET_CATEGORIES = [
  ['service_issue',    'Service Issue',           'field_ops'],
  ['billing',          'Billing Question',        'billing'],
  ['scheduling',       'Scheduling',              'dispatch'],
  ['complaint',        'Complaint',               'csr'],
  ['callback_request', 'Callback Request',        'csr'],
  ['warranty',         'Warranty Claim',          'field_ops'],
  ['damage_claim',     'Damage Claim',            'field_ops'],
  ['cancellation',     'Cancellation Request',    'csr'],
  ['general_inquiry',  'General Inquiry',         'csr'],
  ['other',            'Other',                   'csr'],
];

const TICKET_DEPT_LABELS = {
  field_ops: 'Field Ops',
  billing:   'Billing',
  dispatch:  'Dispatch',
  csr:       'CSR',
  sales:     'Sales',
  office_admin: 'Office Admin',
};

const TICKET_PRIORITIES = [
  ['low',    'Low'],
  ['medium', 'Medium'],
  ['high',   'High'],
  ['urgent', 'Urgent'],
];

const apptTicket = {
  busy: false,
  customerId: '',
  customerName: '',
};

// Pull a sensible default category from the active conversation channel.
//   phone/sms = service_issue (typical first call about a problem)
//   email     = general_inquiry (broader bucket)
function apptTicketDefaultCategory() {
  const conv = (typeof state !== 'undefined' && state.selectedConv) ? state.selectedConv : null;
  if (!conv) return 'service_issue';
  const ch = (conv.channel || '').toLowerCase();
  if (ch === 'email') return 'general_inquiry';
  return 'service_issue';
}

// Pull the last 1-2 customer messages from the rendered thread DOM as a
// description seed. CSR can edit; this just saves typing the gist.
function apptTicketSeedDescription() {
  const msgs = Array.from(document.querySelectorAll('#threadBody .msg, #threadBody .msg-email'))
    .slice(-4)
    .map(el => (el.textContent || '').trim())
    .filter(Boolean);
  if (!msgs.length) return '';
  // Take the last two non-system bits, truncated.
  const tail = msgs.slice(-2).join('\n\n').slice(0, 500);
  return tail ? '— From conversation —\n' + tail : '';
}

function apptOpenCreateTicketModal(customerId, customerName) {
  apptTicket.busy = false;
  apptTicket.customerId = customerId || '';
  apptTicket.customerName = customerName || '';

  if (!apptTicket.customerId) {
    if (typeof apptToast === 'function') apptToast('No customer linked to this conversation.', 'error');
    return;
  }

  const conv = (typeof state !== 'undefined' && state.selectedConv) ? state.selectedConv : null;
  const channel = (conv && conv.channel) || 'phone';
  const conversationId = (conv && conv.id) || (typeof state !== 'undefined' && state.selectedId) || '';

  const defaultCategory = apptTicketDefaultCategory();
  const seedDescription = apptTicketSeedDescription();

  const categoryOpts = TICKET_CATEGORIES
    .map(([v, l]) => `<option value="${escHTML(v)}"${v === defaultCategory ? ' selected' : ''}>${escHTML(l)}</option>`)
    .join('');
  const priorityOpts = TICKET_PRIORITIES
    .map(([v, l]) => `<option value="${escHTML(v)}"${v === 'medium' ? ' selected' : ''}>${escHTML(l)}</option>`)
    .join('');

  const bodyHtml = `
    <div class="appt-tk-modal-body">
      <div class="appt-tk-banner">
        <strong>New ticket for ${escHTML(apptTicket.customerName || 'this customer')}</strong>
        ${conversationId ? '<br>Linked to this conversation.' : ''}
      </div>

      <div class="appt-tk-section">
        <div class="appt-tk-field">
          <label>Subject<span class="req">*</span></label>
          <input type="text" id="apptTkSubject" maxlength="300" placeholder="Brief summary of the issue">
          <div class="appt-tk-field-err" id="apptTkSubjectErr"></div>
        </div>
      </div>

      <div class="appt-tk-section">
        <div class="appt-tk-row">
          <div class="appt-tk-field">
            <label>Category<span class="req">*</span></label>
            <select id="apptTkCategory">${categoryOpts}</select>
            <div class="appt-tk-route-hint" id="apptTkRouteHint"></div>
          </div>
          <div class="appt-tk-field">
            <label>Priority<span class="req">*</span></label>
            <select id="apptTkPriority">${priorityOpts}</select>
          </div>
        </div>
      </div>

      <div class="appt-tk-section">
        <div class="appt-tk-field">
          <label>Assign to <span class="hint">optional</span></label>
          <select id="apptTkAssign"><option value="">\u2014 Unassigned \u2014</option></select>
        </div>
      </div>

      <div class="appt-tk-section">
        <div class="appt-tk-field">
          <label>Description<span class="req">*</span> <span class="hint">what happened, what's needed</span></label>
          <textarea id="apptTkDescription" rows="5" placeholder="Describe the issue or request in detail.">${escHTML(seedDescription)}</textarea>
          <div class="appt-tk-field-err" id="apptTkDescriptionErr"></div>
        </div>
      </div>

      <div class="appt-tk-form-err" id="apptTkFormErr"></div>
    </div>
  `;

  const footerHtml = `
    <button type="button" class="appt-modal-btn" data-appt-modal-close>Cancel</button>
    <button type="button" class="appt-modal-btn appt-modal-btn-primary" id="apptTkSubmit">Create ticket</button>
  `;

  apptModalOpen({
    title: 'New ticket',
    bodyHtml,
    footerHtml,
    onOpen: (root) => {
      // Hidden channel - sourced from conversation, not user-editable.
      root.dataset.channel = channel;
      root.dataset.conversationId = conversationId;

      // Populate the assignee dropdown (staff who can own a ticket).
      fetch('/api/v1/tickets/assignable-staff/', {credentials:'same-origin'})
        .then(r => r.json())
        .then(list => {
          const sel = root.querySelector('#apptTkAssign');
          if (!sel || !Array.isArray(list)) return;
          sel.innerHTML = '<option value="">\u2014 Unassigned \u2014</option>' +
            list.map(u => `<option value="${u.id}">${escHTML(u.name)}</option>`).join('');
        }).catch(() => {});

      // Live-update the route-hint as category changes.
      const catSel = root.querySelector('#apptTkCategory');
      const routeHint = root.querySelector('#apptTkRouteHint');
      const updateHint = () => {
        const code = catSel.value;
        const tuple = TICKET_CATEGORIES.find(t => t[0] === code);
        const slug = tuple ? tuple[2] : 'csr';
        const label = TICKET_DEPT_LABELS[slug] || slug;
        routeHint.innerHTML = `Routes to <span class="route-pill">${escHTML(label)}</span> by default. Tenant admin overrides may apply.`;
      };
      catSel.addEventListener('change', updateHint);
      updateHint();

      // Submit.
      root.querySelector('#apptTkSubmit').addEventListener('click', () => apptDoCreateTicket(root));

      // Initial focus to subject.
      setTimeout(() => {
        const inp = root.querySelector('#apptTkSubject');
        if (inp) inp.focus();
      }, 60);
    },
  });
}

async function apptDoCreateTicket(root) {
  if (apptTicket.busy) return;
  const submitBtn = root.querySelector('#apptTkSubmit');
  const formErr = root.querySelector('#apptTkFormErr');

  // Clear previous errors.
  root.querySelectorAll('.appt-tk-field-err.is-shown').forEach(e => {
    e.classList.remove('is-shown'); e.textContent = '';
  });
  root.querySelectorAll('[aria-invalid="true"]').forEach(e => e.removeAttribute('aria-invalid'));
  formErr.classList.remove('is-shown'); formErr.textContent = '';

  const v = (id) => (root.querySelector('#' + id).value || '').trim();
  const subject = v('apptTkSubject');
  const category = v('apptTkCategory');
  const priority = v('apptTkPriority') || 'medium';
  const description = v('apptTkDescription');
  const channel = root.dataset.channel || 'phone';
  const conversationId = root.dataset.conversationId || '';
  const assignTo = ((root.querySelector('#apptTkAssign') || {}).value || '').trim();

  // Client-side required-field validation.
  const required = [
    ['apptTkSubject',     subject,     'Subject is required.'],
    ['apptTkDescription', description, 'Description is required.'],
  ];
  let firstBadId = null;
  for (const [id, val, msg] of required) {
    if (!val) {
      const inp = root.querySelector('#' + id);
      const errEl = root.querySelector('#' + id + 'Err');
      if (inp) inp.setAttribute('aria-invalid', 'true');
      if (errEl) { errEl.textContent = msg; errEl.classList.add('is-shown'); }
      if (!firstBadId) firstBadId = id;
    }
  }
  if (firstBadId) {
    try { root.querySelector('#' + firstBadId).focus(); } catch (e) {}
    return;
  }

  // Build payload. BE perform_create handles tenant + assignment + SLA.
  const body = {
    customer: apptTicket.customerId,
    subject,
    description,
    category,
    priority,
    channel,
    status: 'open',
  };
  if (assignTo) body.assigned_to = assignTo;
  // conversation_id is informational - BE may use it to write a system event
  // or backfill an audit trail. Sending unconditionally; harmless if ignored.
  if (conversationId) body.conversation_id = conversationId;

  apptTicket.busy = true;
  if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Creating...'; }

  let ticket;
  try {
    ticket = await apptApiPost('/tickets/tickets/', body);
  } catch (e) {
    apptTicket.busy = false;
    if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Create ticket'; }
    // DRF field-level errors -> per-field inline.
    if (e && e.status === 400 && e.data && typeof e.data === 'object') {
      const fieldMap = {
        subject:     'apptTkSubject',
        description: 'apptTkDescription',
        category:    'apptTkCategory',
        priority:    'apptTkPriority',
      };
      let consumed = false;
      Object.keys(e.data).forEach(k => {
        const dom = fieldMap[k];
        if (!dom) return;
        const errEl = root.querySelector('#' + dom + 'Err');
        const inp = root.querySelector('#' + dom);
        const msg = Array.isArray(e.data[k]) ? e.data[k].join(' ') : String(e.data[k]);
        if (inp) inp.setAttribute('aria-invalid', 'true');
        if (errEl) { errEl.textContent = msg; errEl.classList.add('is-shown'); }
        consumed = true;
      });
      if (!consumed) {
        formErr.textContent = (typeof apptFriendlyErr === 'function') ? apptFriendlyErr(e) : (e.message || 'Could not create ticket.');
        formErr.classList.add('is-shown');
      }
    } else {
      formErr.textContent = (typeof apptFriendlyErr === 'function') ? apptFriendlyErr(e) : ((e && e.message) || 'Could not create ticket.');
      formErr.classList.add('is-shown');
    }
    return;
  }

  // Success.
  apptTicket.busy = false;
  // Build a routing message for the toast - BE returns assigned_to_name when
  // auto-assignment succeeded; otherwise we tell CSR which dept it went to.
  const tuple = TICKET_CATEGORIES.find(t => t[0] === category);
  const deptSlug = tuple ? tuple[2] : 'csr';
  const deptLabel = TICKET_DEPT_LABELS[deptSlug] || deptSlug;
  const tn = (ticket && ticket.ticket_number) ? ('#' + ticket.ticket_number) : 'created';
  const assignee = (ticket && ticket.assigned_to_name) ? ` (assigned to ${ticket.assigned_to_name})` : ` -> ${deptLabel}`;
  if (typeof apptToast === 'function') apptToast(`Ticket ${tn} ${assignee}`, 'success');

  if (typeof apptModalClose === 'function') apptModalClose();

  // Open the new ticket in a new tab so CSR keeps inbox flow.
  const url = (ticket && ticket.id) ? `/tickets/?id=${encodeURIComponent(ticket.id)}` : '/tickets/';
  try { window.open(url, '_blank', 'noopener'); }
  catch (e) { /* popup blocker - toast already confirms */ }
}

// Wiring: '+ New ticket' button on the customer card. Card re-renders on
// every selectConversation so use document-level delegation.
document.addEventListener('click', function (e) {
  const btn = e.target && e.target.closest && e.target.closest('#ticketCreateBtn');
  if (!btn) return;
  e.preventDefault(); e.stopPropagation();
  apptOpenCreateTicketModal(btn.dataset.customerId || '', btn.dataset.customerName || '');
});



// =============================================================================
// CSR Inbox - Edit appointment modal
//
// Kebab -> 'Edit' -> modal with ALL editable fields prefilled ->
//   PATCH /api/v1/appointments/{id}/edit/  (only changed fields)
//
// BE notes:
//   - Reason REQUIRED if start_at OR technician_id changed (4-code allowlist:
//     customer_request, tech_unavailable, weather, other - DIFFERENT from
//     cancel codes)
//   - 409 conflict_detected when start_at or duration_min creates an overlap
//   - APPOINTMENT ID MAY CHANGE: when start_at or technician_id change, BE
//     delegates to reschedule pipeline -> returns NEW appt with new UUID.
//     Old appt becomes status='rescheduled'. Always swap to response.id.
// =============================================================================

const APPT_EDIT_REASONS = [
  ['customer_request', 'Customer request'],
  ['tech_unavailable', 'Tech unavailable'],
  ['weather',          'Weather'],
  ['other',            'Other'],
];

const apptEdit = {
  busy: false,
  apptId: null,
  original: null,        // snapshot of starting values for diff
  servicesCache: null,   // shared with apptDrawer (lazy reuse)
  techsCache: null,
};

// ----- helpers -----

// Convert ISO 'Z' timestamp to a value the <input type="datetime-local"> can show.
// Browser expects local-time string 'YYYY-MM-DDTHH:MM' WITHOUT seconds or tz.
function apptEditIsoToLocal(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function apptEditLocalToIso(local) {
  if (!local) return '';
  // §16.1: <input type="datetime-local"> emits a naive wall-clock string.
  // Routing it through new Date() interprets it in the BROWSER's local tz,
  // not the office tz — wrong by hours when those differ. Use the canonical
  // localToUTC helper (hoisted in base.html) so the office tz is the
  // authoritative interpretation. Defensive fallback for older renders that
  // somehow miss the global.
  const tz = window._tenantTz || 'America/New_York';
  if (typeof window.localToUTC === 'function') {
    const iso = window.localToUTC(local.length === 16 ? local + ':00' : local, tz);
    return iso || '';
  }
  const d = new Date(local);
  return isNaN(d.getTime()) ? '' : d.toISOString();
}

async function apptOpenEditModal(apptId) {
  apptEdit.busy = false;
  apptEdit.apptId = apptId;

  const a = (typeof apptFindAppt === 'function') ? apptFindAppt(apptId) : null;
  if (!a) {
    if (typeof apptToast === 'function') apptToast('Could not find that appointment.', 'error');
    return;
  }

  // Snapshot starting state for diffing on submit.
  apptEdit.original = {
    service_id:       (a.service && a.service.id) || '',
    service_ids:      (a.job_types && a.job_types.length) ? a.job_types.map(j => String(j.id))
                        : ((a.service && a.service.id) ? [String(a.service.id)] : []),
    duration_min:     a.duration_min || 60,
    service_address:  (a.location && a.location.address) || '',
    technician_id:    (a.technician && a.technician.id) || '',
    start_at:         a.start_at || '',
    internal_notes:   a.internal_notes || '',
    customer_notes:   a.customer_notes || '',
  };

  // Lazy-load services + techs. The schedule drawer caches them on apptDrawer;
  // try to reuse, otherwise fetch.
  if (typeof apptDrawer !== 'undefined' && apptDrawer.servicesCache) {
    apptEdit.servicesCache = apptDrawer.servicesCache;
    apptEdit.techsCache    = apptDrawer.techsCache;
  } else {
    apptEdit.servicesCache = null;
    apptEdit.techsCache = null;
  }

  // Pull conv id for system-event linkage.
  const conversationId = (typeof state !== 'undefined' && state.selectedId) || '';

  const summary = (typeof apptModalSummary === 'function') ? apptModalSummary(a)
                                                           : escHTML(a.start_at || '');

  // Build the modal body. Services/techs render after lazy-load.
  const bodyHtml = `
    <div class="appt-ed-modal-body">
      <div class="appt-ed-banner">
        <strong>Edit appointment</strong><br>${summary}
      </div>

      <div class="appt-ed-section">
        <div class="appt-ed-section-title first">Service</div>
        <div class="appt-ed-row">
          <div class="appt-ed-field">
            <label id="apptEdServiceLabel">Service(s)</label>
            <div id="apptEdService" class="appt-jt-checks">— Loading —</div>
          </div>
          <div class="appt-ed-field">
            <label id="apptEdDurationLabel">Duration <span class="hint">minutes</span></label>
            <input type="number" id="apptEdDuration" min="15" max="480" step="15" value="${escHTML(String(apptEdit.original.duration_min))}">
            <div class="appt-ed-field-err" id="apptEdDurationErr"></div>
          </div>
        </div>
      </div>

      <div class="appt-ed-section">
        <div class="appt-ed-section-title">When &amp; who</div>
        <div class="appt-ed-row">
          <div class="appt-ed-field">
            <label id="apptEdStartLabel">Start time</label>
            <input type="datetime-local" id="apptEdStart" value="${escHTML(apptEditIsoToLocal(apptEdit.original.start_at))}">
            <div class="appt-ed-field-err" id="apptEdStartErr"></div>
          </div>
          <div class="appt-ed-field">
            <label id="apptEdTechLabel">Technician</label>
            <select id="apptEdTech"><option value="">— Loading —</option></select>
          </div>
        </div>
      </div>

      <div class="appt-ed-section">
        <div class="appt-ed-section-title">Where</div>
        <div class="appt-ed-field">
          <label id="apptEdAddrLabel">Service address</label>
          <input type="text" id="apptEdAddr" maxlength="300" value="${escHTML(apptEdit.original.service_address)}">
        </div>
      </div>

      <div class="appt-ed-section">
        <div class="appt-ed-section-title">Notes</div>
        <div class="appt-ed-field">
          <label id="apptEdInternalLabel">Internal notes <span class="hint">team-only</span></label>
          <textarea id="apptEdInternal" rows="3">${escHTML(apptEdit.original.internal_notes)}</textarea>
        </div>
        <div class="appt-ed-field" style="margin-top:10px">
          <label id="apptEdCustomerLabel">Customer notes <span class="hint">visible to customer</span></label>
          <textarea id="apptEdCustomer" rows="2">${escHTML(apptEdit.original.customer_notes)}</textarea>
        </div>
      </div>

      <div class="appt-ed-reason-block" id="apptEdReasonBlock">
        <div class="field-label">⚠ Reason required</div>
        <div class="field-help">Time or technician change — capture why for the audit log.</div>
        <div class="appt-ed-row">
          <div class="appt-ed-field">
            <label>Reason code<span class="req">*</span></label>
            <select id="apptEdReasonCode">
              ${APPT_EDIT_REASONS.map(([v,l]) => `<option value="${escHTML(v)}">${escHTML(l)}</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="appt-ed-field">
          <label>Comment <span class="hint">required if "Other"</span></label>
          <textarea id="apptEdReasonComment" rows="2" maxlength="500"></textarea>
          <div class="appt-ed-field-err" id="apptEdReasonCommentErr"></div>
        </div>
      </div>

      <div class="appt-ed-section">
        <div class="appt-ed-section-title">Notify</div>
        <div class="appt-ed-field">
          <label>Send confirmation</label>
          <select id="apptEdSendCh">
            <option value="sms" selected>SMS</option>
            <option value="email">Email</option>
            <option value="none">None</option>
          </select>
        </div>
      </div>

      <div class="appt-ed-no-changes" id="apptEdNoChanges">No changes to save.</div>
      <div class="appt-ed-form-err" id="apptEdFormErr"></div>
    </div>
  `;

  const footerHtml = `
    <button type="button" class="appt-modal-btn" data-appt-modal-close>Cancel</button>
    <button type="button" class="appt-modal-btn appt-modal-btn-primary" id="apptEdSubmit" disabled>Save changes</button>
  `;

  apptModalOpen({
    title: 'Edit appointment',
    bodyHtml,
    footerHtml,
    onOpen: (root) => {
      root.dataset.conversationId = conversationId;

      // Lazy-fetch services + techs if not already cached.
      const fetchTasks = [];
      if (!apptEdit.servicesCache) {
        fetchTasks.push(apptApi('/job-types/?limit=200').then(d => {
          const arr = (d && (d.results || d)) || [];
          apptEdit.servicesCache = arr.map(j => ({id: j.id, name: j.name}));
        }).catch(() => { apptEdit.servicesCache = []; }));
      }
      if (!apptEdit.techsCache) {
        fetchTasks.push(apptApi('/technicians/?limit=200').then(d => {
          const arr = (d && (d.results || d)) || [];
          apptEdit.techsCache = arr.map(t => {
            let nm = (t.name || '').trim();
            if (!nm) nm = t.full_name || t.username || t.email || 'Unnamed';
            return {id: t.id, name: nm};
          });
        }).catch(() => { apptEdit.techsCache = []; }));
      }
      Promise.all(fetchTasks).then(() => {
        // Populate selects.
        const svcSel = root.querySelector('#apptEdService');
        const techSel = root.querySelector('#apptEdTech');
        const orig = apptEdit.original;
        const _origSvcIds = orig.service_ids || (orig.service_id ? [orig.service_id] : []);
        svcSel.innerHTML = (apptEdit.servicesCache || []).map(x =>
          `<label class="appt-jt-check"><input type="checkbox" value="${escHTML(x.id)}"${_origSvcIds.indexOf(String(x.id)) !== -1 ? ' checked' : ''}> ${escHTML(x.name)}</label>`
        ).join('');
        techSel.innerHTML = '<option value="">Any</option>' +
          (apptEdit.techsCache || []).map(x =>
            `<option value="${escHTML(x.id)}"${x.id === orig.technician_id ? ' selected' : ''}>${escHTML(x.name)}</option>`
          ).join('');
        // Re-evaluate diff in case the loaded select-values just changed it.
        apptEditEvaluateDiff(root);
      });

      // Wire change listeners for live diff evaluation.
      ['apptEdService','apptEdDuration','apptEdStart','apptEdTech','apptEdAddr','apptEdInternal','apptEdCustomer']
        .forEach(id => {
          const el = root.querySelector('#' + id);
          if (!el) return;
          el.addEventListener('input', () => apptEditEvaluateDiff(root));
          el.addEventListener('change', () => apptEditEvaluateDiff(root));
        });

      root.querySelector('#apptEdSubmit').addEventListener('click', () => apptDoSubmitEdit(root));

      setTimeout(() => {
        const inp = root.querySelector('#apptEdService');
        if (inp) inp.focus();
      }, 60);
    },
  });
}

// Compute the diff vs original. Drives:
//   * Reason-block visibility (only when start_at OR technician_id changed)
//   * "no changes" banner + Submit-button disabled state
//   * 'changed' pill on each field's label
function apptEditEvaluateDiff(root) {
  const orig = apptEdit.original;
  const now = apptEditCurrentValues(root);
  const changed = apptEditChangedFields(orig, now);

  // Mark each label with a 'changed' pill.
  const labelMap = {
    service_id: 'apptEdServiceLabel',  duration_min: 'apptEdDurationLabel',
    service_address: 'apptEdAddrLabel', technician_id: 'apptEdTechLabel',
    start_at: 'apptEdStartLabel', internal_notes: 'apptEdInternalLabel',
    customer_notes: 'apptEdCustomerLabel',
  };
  Object.entries(labelMap).forEach(([field, labelId]) => {
    const lbl = root.querySelector('#' + labelId);
    if (!lbl) return;
    const isChanged = changed.includes(field);
    const existing = lbl.querySelector('.changed');
    if (isChanged && !existing) {
      const pill = document.createElement('span');
      pill.className = 'changed';
      pill.textContent = 'CHANGED';
      lbl.appendChild(pill);
    } else if (!isChanged && existing) {
      existing.remove();
    }
  });

  // Reason block visibility.
  const reasonBlock = root.querySelector('#apptEdReasonBlock');
  const reasonRequired = changed.includes('start_at') || changed.includes('technician_id');
  if (reasonRequired) reasonBlock.classList.add('is-shown');
  else                reasonBlock.classList.remove('is-shown');

  // No-changes banner + submit state.
  const noChanges = root.querySelector('#apptEdNoChanges');
  const submit = root.querySelector('#apptEdSubmit');
  if (changed.length === 0) {
    noChanges.classList.add('is-shown');
    submit.disabled = true;
  } else {
    noChanges.classList.remove('is-shown');
    submit.disabled = false;
  }
}

function apptEditCurrentValues(root) {
  const v = (id) => (root.querySelector('#' + id) ? root.querySelector('#' + id).value : '');
  const svcEl = root.querySelector('#apptEdService');
  const svcIds = svcEl ? Array.prototype.map.call(svcEl.querySelectorAll('input[type=checkbox]:checked'), i => i.value) : [];
  return {
    service_id:      svcIds[0] || '',
    service_ids:     svcIds,
    duration_min:    parseInt(v('apptEdDuration'), 10) || 0,
    service_address: v('apptEdAddr').trim(),
    technician_id:   v('apptEdTech'),
    start_at:        apptEditLocalToIso(v('apptEdStart')),
    internal_notes:  v('apptEdInternal'),
    customer_notes:  v('apptEdCustomer'),
  };
}

function apptEditChangedFields(orig, now) {
  const fields = ['service_ids','duration_min','service_address','technician_id',
                  'start_at','internal_notes','customer_notes'];
  const changed = [];
  for (const f of fields) {
    let a = orig[f], b = now[f];
    if (f === 'start_at') {
      // Compare as Date timestamps to ignore tz/format jitter.
      const ta = a ? new Date(a).getTime() : 0;
      const tb = b ? new Date(b).getTime() : 0;
      if (ta !== tb) changed.push(f);
    } else if (f === 'duration_min') {
      if ((parseInt(a,10) || 0) !== (parseInt(b,10) || 0)) changed.push(f);
    } else if (f === 'service_ids') {
      if ((a || []).join(',') !== (b || []).join(',')) changed.push(f);
    } else {
      if ((a || '') !== (b || '')) changed.push(f);
    }
  }
  return changed;
}

async function apptDoSubmitEdit(root) {
  if (apptEdit.busy) return;
  const submit = root.querySelector('#apptEdSubmit');
  const formErr = root.querySelector('#apptEdFormErr');

  // Reset errors.
  root.querySelectorAll('.appt-ed-field-err.is-shown').forEach(e => {
    e.classList.remove('is-shown'); e.textContent = '';
  });
  root.querySelectorAll('[aria-invalid="true"]').forEach(e => e.removeAttribute('aria-invalid'));
  formErr.classList.remove('is-shown'); formErr.textContent = '';

  const orig = apptEdit.original;
  const now = apptEditCurrentValues(root);
  const changed = apptEditChangedFields(orig, now);
  if (!changed.length) {
    if (typeof apptToast === 'function') apptToast('No changes to save.', 'error');
    return;
  }

  // Build minimal payload — only changed fields.
  const body = {};
  for (const f of changed) {
    if (f === 'start_at')      body.start_at = now.start_at;
    else if (f === 'duration_min') body.duration_min = now.duration_min;
    else if (f === 'service_id')   body.service_id = now.service_id;
    else                          body[f] = now[f];
  }

  // Reason block — required for time/tech changes.
  const reasonRequired = changed.includes('start_at') || changed.includes('technician_id');
  if (reasonRequired) {
    const code = (root.querySelector('#apptEdReasonCode').value || '').trim();
    const comment = (root.querySelector('#apptEdReasonComment').value || '').trim();
    if (code === 'other' && !comment) {
      const errEl = root.querySelector('#apptEdReasonCommentErr');
      root.querySelector('#apptEdReasonComment').setAttribute('aria-invalid', 'true');
      errEl.textContent = 'A comment is required when reason is "Other".';
      errEl.classList.add('is-shown');
      return;
    }
    body.reason = { code, comment };
  }

  // Notify channel + conversation_id (always sent).
  const sendCh = root.querySelector('#apptEdSendCh').value || 'sms';
  body.send_confirmation = { channel: sendCh };
  const conversationId = root.dataset.conversationId || '';
  if (conversationId) body.conversation_id = conversationId;

  apptEdit.busy = true;
  if (submit) { submit.disabled = true; submit.textContent = 'Saving…'; }

  let resp;
  try {
    resp = await apptApiPatch('/appointments/' + encodeURIComponent(apptEdit.apptId) + '/edit/', body);
  } catch (e) {
    apptEdit.busy = false;
    if (submit) { submit.disabled = false; submit.textContent = 'Save changes'; }
    // 409 conflict — distinct UX from /reschedule/ since BE returns alternatives:[]
    if (e && e.status === 409 && e.data && e.data.error === 'conflict_detected') {
      const ct = e.data.conflict_type || 'hard';
      formErr.innerHTML = `<strong>Conflict:</strong> That time conflicts with another appointment (${escHTML(ct)} conflict).<div class="conflict-tip">Pick a different time, or use Reschedule for slot suggestions.</div>`;
      formErr.classList.add('is-shown');
      return;
    }
    // 422 reason_required (defensive — our client-side check should catch this)
    if (e && e.status === 422 && e.data && e.data.error === 'reason_required') {
      const errEl = root.querySelector('#apptEdReasonCommentErr');
      errEl.textContent = 'Reason required for time or technician changes.';
      errEl.classList.add('is-shown');
      // Reveal the block in case it was hidden by a stale diff.
      root.querySelector('#apptEdReasonBlock').classList.add('is-shown');
      return;
    }
    // 400 field-level
    if (e && e.status === 400 && e.data && typeof e.data === 'object') {
      const fieldMap = {
        start_at: 'apptEdStart', duration_min: 'apptEdDuration',
      };
      let consumed = false;
      Object.keys(e.data).forEach(k => {
        const dom = fieldMap[k];
        if (!dom) return;
        const errEl = root.querySelector('#' + dom + 'Err');
        const inp = root.querySelector('#' + dom);
        const msg = Array.isArray(e.data[k]) ? e.data[k].join(' ') : String(e.data[k]);
        if (inp) inp.setAttribute('aria-invalid', 'true');
        if (errEl) { errEl.textContent = msg; errEl.classList.add('is-shown'); }
        consumed = true;
      });
      if (consumed) return;
    }
    formErr.textContent = (typeof apptFriendlyErr === 'function') ? apptFriendlyErr(e) : ((e && e.message) || 'Could not save changes.');
    formErr.classList.add('is-shown');
    return;
  }

  // Success.
  apptEdit.busy = false;

  // CRITICAL: appointment id may have changed (BE delegated to reschedule
  // pipeline if start_at or technician_id changed). Swap our local ref to
  // response.id before any follow-up would happen.
  const idChanged = resp && resp.id && resp.id !== apptEdit.apptId;
  if (idChanged) apptEdit.apptId = resp.id;

  if (typeof apptToast === 'function') apptToast(idChanged ? 'Appointment updated (rescheduled).' : 'Appointment updated.', 'success');
  if (typeof apptModalClose === 'function') apptModalClose();

  // The BE writes appointment.edited (and possibly appointment.rescheduled
  // for time/tech changes). apptDetectSystemEvents() already prefix-matches
  // 'appointment.' so the card will refresh automatically when the message
  // arrives. Belt-and-suspenders: kick a manual reload via the existing
  // optimistic-reload helper.
  if (typeof apptOptimisticReload === 'function') apptOptimisticReload();
}


// ===== CSR self-book: send a booking link to an existing customer or prospect =====
(function(){
  if (typeof apptApi !== 'function') { return; }
  function el(html){ var d=document.createElement('div'); d.innerHTML=html.trim(); return d.firstChild; }
  var st = document.createElement('style');
  st.textContent = [
    '.sbl-fab{position:fixed;right:20px;bottom:20px;z-index:9000;background:#2563eb;color:#fff;border:none;border-radius:999px;padding:12px 18px;font-weight:600;font-size:14px;box-shadow:0 4px 14px rgba(0,0,0,.25);cursor:pointer}',
    '.sbl-fab:hover{background:#1d4ed8}',
    '.sbl-back{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9001;display:none;align-items:flex-start;justify-content:center;overflow:auto;padding:40px 16px}',
    '.sbl-back.open{display:flex}',
    '.sbl-modal{background:#fff;border-radius:12px;max-width:460px;width:100%;padding:22px;box-shadow:0 10px 40px rgba(0,0,0,.3);font-family:inherit}',
    '.sbl-modal h2{margin:0 0 4px;font-size:18px}',
    '.sbl-modal .sub{color:#6b7280;font-size:13px;margin-bottom:14px}',
    '.sbl-row{display:flex;flex-direction:column;gap:5px;margin-bottom:12px}',
    '.sbl-row label{font-size:12px;font-weight:600;color:#374151}',
    '.sbl-row input,.sbl-row select{padding:9px 10px;border:1px solid #d1d5db;border-radius:7px;font-size:14px;width:100%;box-sizing:border-box}',
    '.sbl-2{display:flex;gap:10px}.sbl-2>div{flex:1}',
    '.sbl-seg{display:flex;margin-bottom:14px;border:1px solid #d1d5db;border-radius:8px;overflow:hidden}',
    '.sbl-seg button{flex:1;padding:9px;border:none;background:#fff;cursor:pointer;font-weight:600;font-size:13px;color:#374151}',
    '.sbl-seg button.active{background:#2563eb;color:#fff}',
    '.sbl-results{position:relative}',
    '.sbl-sug{position:absolute;left:0;right:0;top:100%;background:#fff;border:1px solid #d1d5db;border-radius:0 0 7px 7px;max-height:180px;overflow:auto;z-index:5}',
    '.sbl-sug div{padding:8px 10px;cursor:pointer;font-size:13px;border-bottom:1px solid #f1f5f9}',
    '.sbl-sug div:hover{background:#eff6ff}',
    '.sbl-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:8px}',
    '.sbl-btn{padding:10px 16px;border:none;border-radius:8px;font-weight:600;cursor:pointer;font-size:14px}',
    '.sbl-btn.primary{background:#2563eb;color:#fff}.sbl-btn.ghost{background:#f3f4f6;color:#374151}',
    '.sbl-err{color:#b91c1c;font-size:13px;margin-top:6px;min-height:16px}',
    '.sbl-ok{background:#ecfdf5;border:1px solid #a7f3d0;border-radius:8px;padding:12px;margin-top:10px;font-size:13px}',
    '.sbl-ok input{width:100%;padding:8px;border:1px solid #a7f3d0;border-radius:6px;font-size:12px;margin-top:6px;box-sizing:border-box}',
    '.sbl-hide{display:none}'
  ].join('');
  document.head.appendChild(st);

  var fab = el('<button class="sbl-fab" title="Send a self-booking link">+ Booking link</button>');
  document.body.appendChild(fab);

  var back = el(
    '<div class="sbl-back">'+
      '<div class="sbl-modal" role="dialog" aria-modal="true">'+
        '<h2>Send a booking link</h2>'+
        '<div class="sub">Generate a self-scheduling link for an existing customer or a new prospect.</div>'+
        '<div class="sbl-seg">'+
          '<button type="button" id="sblModeExisting" class="active">Existing customer</button>'+
          '<button type="button" id="sblModeProspect">New prospect</button>'+
        '</div>'+
        '<div class="sbl-row sbl-results" id="sblCustRow">'+
          '<label>Find customer</label>'+
          '<input id="sblCustSearch" placeholder="Search by name, phone, or email" autocomplete="off">'+
          '<div class="sbl-sug sbl-hide" id="sblSug"></div>'+
        '</div>'+
        '<div class="sbl-row sbl-hide" id="sblSiteRow"><label>Service location</label><select id="sblSite"></select>'+
          '<div style="font-size:11px;color:#6b7280" id="sblSiteHint"></div></div>'+
        '<div class="sbl-row"><label>Job type</label><select id="sblJobType"></select></div>'+
        '<div class="sbl-2">'+
          '<div class="sbl-row"><label>Duration (min)</label><input id="sblDur" type="number" min="5" step="5"></div>'+
          '<div class="sbl-row"><label>&nbsp;</label><div style="font-size:12px;color:#6b7280;padding-top:9px" id="sblCustName"></div></div>'+
        '</div>'+
        '<div class="sbl-row"><label>Service address</label><input id="sblAddr" placeholder="Street address"></div>'+
        '<div class="sbl-2">'+
          '<div class="sbl-row"><label>City</label><input id="sblCity"></div>'+
          '<div class="sbl-row"><label>State</label><input id="sblState" maxlength="2" value="PA"></div>'+
          '<div class="sbl-row"><label>ZIP</label><input id="sblZip"></div>'+
        '</div>'+
        '<div class="sbl-2">'+
          '<div class="sbl-row"><label>Email (to send)</label><input id="sblEmail" type="email"></div>'+
          '<div class="sbl-row"><label>Phone (to send)</label><input id="sblPhone" type="tel"></div>'+
        '</div>'+
        '<div class="sbl-err" id="sblErr"></div>'+
        '<div class="sbl-ok sbl-hide" id="sblResult"></div>'+
        '<div class="sbl-actions">'+
          '<button type="button" class="sbl-btn ghost" id="sblCancel">Close</button>'+
          '<button type="button" class="sbl-btn primary" id="sblGo">Generate &amp; send</button>'+
        '</div>'+
      '</div>'+
    '</div>'
  );
  document.body.appendChild(back);

  var q = function(id){ return back.querySelector(id); };
  var mode = 'existing', pickedCustId = '', jobTypes = [], custSites = [];

  // Multi-site customers: list their active service locations so the link is
  // sent for the right property (the customer can still switch on the picker).
  function siteAddr(sl){
    return [sl.address, sl.address_2].filter(Boolean).join(' ');
  }
  var GENERIC_SITE = {primary:1, main:1, 'default':1, home:1, 'service address':1, site:1};
  function siteLabel(sl){
    // Prefix the site name only when it tells the sites apart ("Primary" x3 doesn't).
    var a = siteAddr(sl) + (sl.city ? ', '+sl.city : '');
    var n = (sl.location_name||'').trim(), nl = n.toLowerCase();
    var dup = custSites.filter(function(x){ return (x.location_name||'').trim().toLowerCase() === nl; }).length > 1;
    return (n && !GENERIC_SITE[nl] && !dup && a.toLowerCase().indexOf(nl) === -1) ? (n+' \u2014 '+a) : a;
  }
  function hideSites(){ custSites = []; q('#sblSiteRow').classList.add('sbl-hide'); q('#sblSite').innerHTML=''; }
  function fillFromSite(sl){
    q('#sblAddr').value = siteAddr(sl);
    q('#sblCity').value = sl.city || '';
    q('#sblState').value = sl.state || 'PA';
    q('#sblZip').value = sl.zip_code || '';
  }
  function loadSites(custId){
    hideSites();
    apptApi('/service-locations/?customer='+encodeURIComponent(custId)+'&is_active=true&page_size=200').then(function(d){
      if(!d || d._hidden || custId !== pickedCustId) return;
      custSites = (d.results || d || []).filter(function(sl){ return sl && sl.id && sl.address; });
      if(!custSites.length) return;
      var sel = q('#sblSite'), multi = custSites.length > 1;
      sel.innerHTML = (multi ? '<option value="">Choose a location\u2026</option>' : '') +
        custSites.map(function(sl){ return '<option value="'+sl.id+'">'+siteLabel(sl).replace(/</g,'&lt;')+'</option>'; }).join('') +
        '<option value="__other">Other address\u2026</option>';
      q('#sblSiteHint').textContent = multi
        ? (custSites.length+' locations on file. The customer can also switch locations on the booking page.')
        : '';
      if(multi){ ['#sblAddr','#sblCity','#sblZip'].forEach(function(id){ q(id).value=''; }); }
      else { sel.value = custSites[0].id; fillFromSite(custSites[0]); }
      q('#sblSiteRow').classList.remove('sbl-hide');
    }).catch(function(){});
  }

  function setMode(m){
    mode = m;
    q('#sblModeExisting').classList.toggle('active', m==='existing');
    q('#sblModeProspect').classList.toggle('active', m==='prospect');
    q('#sblCustRow').classList.toggle('sbl-hide', m!=='existing');
    if(m==='prospect'){ pickedCustId=''; q('#sblCustName').textContent=''; hideSites(); }
  }
  q('#sblModeExisting').addEventListener('click', function(){ setMode('existing'); });
  q('#sblModeProspect').addEventListener('click', function(){ setMode('prospect'); });

  function loadJobTypes(){
    if(jobTypes.length) return;
    apptApi('/job-types/?limit=200').then(function(d){
      if(d && d._hidden) return;
      var arr = (d && (d.results || d)) || [];
      jobTypes = arr.map(function(j){ return {id:j.id, name:j.name, dur:(j.default_duration_minutes||j.default_duration||0)}; });
      q('#sblJobType').innerHTML = jobTypes.map(function(j){ return '<option value="'+j.id+'">'+j.name+'</option>'; }).join('');
      syncDur();
    }).catch(function(){});
  }
  function syncDur(){
    var v = q('#sblJobType').value;
    var jt = jobTypes.find(function(j){ return j.id===v; });
    if(jt && jt.dur){ q('#sblDur').value = jt.dur; }
  }
  q('#sblJobType').addEventListener('change', syncDur);

  var searchT=null;
  q('#sblCustSearch').addEventListener('input', function(){
    var term = this.value.trim(); pickedCustId=''; hideSites();
    if(searchT) clearTimeout(searchT);
    if(term.length < 2){ q('#sblSug').classList.add('sbl-hide'); return; }
    searchT = setTimeout(function(){
      fetch('/api/v1/customer-search/?q='+encodeURIComponent(term), {credentials:'same-origin', headers:{'Accept':'application/json'}})
        .then(function(r){ return r.json(); })
        .then(function(d){
          var arr = (d && (d.results || d)) || [];
          var sug = q('#sblSug');
          if(!arr.length){ sug.classList.add('sbl-hide'); return; }
          sug.innerHTML='';
          arr.slice(0,8).forEach(function(c){
            var nm = ((c.first_name||'')+' '+(c.last_name||'')).trim() || c.name || c.company_name || '(no name)';
            var addr = c.service_address || c.address || '';
            var div = el('<div>'+nm+(addr?(' &mdash; <span style="color:#6b7280">'+addr+'</span>'):'')+'</div>');
            div.addEventListener('click', function(){
              pickedCustId = c.id || c.customer_id || '';
              q('#sblCustSearch').value = nm;
              q('#sblCustName').textContent = 'Linked: '+nm;
              q('#sblAddr').value = c.service_address || c.address || '';
              q('#sblCity').value = c.service_city || c.city || '';
              q('#sblState').value = c.service_state || c.state || 'PA';
              q('#sblZip').value = c.service_zip || c.zip || '';
              q('#sblEmail').value = c.email || '';
              q('#sblPhone').value = c.phone || c.cell || '';
              sug.classList.add('sbl-hide');
              if(pickedCustId){ loadSites(pickedCustId); }
            });
            sug.appendChild(div);
          });
          sug.classList.remove('sbl-hide');
        }).catch(function(){ q('#sblSug').classList.add('sbl-hide'); });
    }, 250);
  });

  q('#sblSite').addEventListener('change', function(){
    var v = this.value;
    if(v === '__other'){ ['#sblAddr','#sblCity','#sblZip'].forEach(function(id){ q(id).value=''; }); q('#sblAddr').focus(); return; }
    var sl = custSites.find(function(x){ return x.id === v; });
    if(sl){ fillFromSite(sl); }
  });
  // Typing a different street turns the pick into "Other address".
  q('#sblAddr').addEventListener('input', function(){
    var sel = q('#sblSite'), sl = custSites.find(function(x){ return x.id === sel.value; });
    if(sl && this.value.trim() !== siteAddr(sl)){ sel.value = '__other'; }
  });

  function openModal(){ q('#sblErr').textContent=''; q('#sblResult').classList.add('sbl-hide'); back.classList.add('open'); loadJobTypes(); }
  function closeModal(){ back.classList.remove('open'); }
  fab.addEventListener('click', openModal);
  q('#sblCancel').addEventListener('click', closeModal);
  back.addEventListener('click', function(e){ if(e.target===back) closeModal(); });

  q('#sblGo').addEventListener('click', function(){
    var err = q('#sblErr'); err.textContent='';
    var jobTypeId = q('#sblJobType').value;
    if(!jobTypeId){ err.textContent='Pick a job type.'; return; }
    var addr = q('#sblAddr').value.trim();
    if(!addr){ err.textContent='A service address is required.'; return; }
    var email = q('#sblEmail').value.trim(), phone = q('#sblPhone').value.trim();
    if(!email && !phone){ err.textContent='Enter an email or phone to send the link.'; return; }
    var payload = { job_type_id: jobTypeId, duration_minutes: parseInt(q('#sblDur').value,10) || null,
      address: addr, city: q('#sblCity').value.trim(), state: q('#sblState').value.trim(),
      zip: q('#sblZip').value.trim(), email: email, phone: phone, send: true };
    if(mode==='existing'){
      if(!pickedCustId){ err.textContent='Search and pick a customer, or switch to New prospect.'; return; }
      payload.customer_id = pickedCustId;
      if(custSites.length){
        var siteV = q('#sblSite').value;
        if(!siteV){ err.textContent='Pick which location this booking is for.'; return; }
        if(siteV !== '__other'){ payload.service_location_id = siteV; }
      }
    }
    var go = q('#sblGo'); go.disabled=true; go.textContent='Sending\u2026';
    apptApi('/scheduling/send-booking-link/', {method:'POST', body: JSON.stringify(payload)})
      .then(function(res){
        go.disabled=false; go.textContent='Generate & send';
        if(res && res._hidden){ err.textContent='You do not have permission for this action.'; return; }
        if(!res || !res.ok){ err.textContent=(res && (res.detail||res.error)) || 'Could not generate the link.'; return; }
        var box = q('#sblResult');
        var sent = (res.sent_via==='queued') ? 'Sending the link to the customer now. ' : (res.sent_via ? ('Sent via '+res.sent_via+'. ') : 'Copy the link below to share it. ');
        box.innerHTML = '<b>Link ready.</b> '+sent+'<input readonly value="'+(res.booking_url||'')+'" onclick="this.select()">';
        box.classList.remove('sbl-hide');
      })
      .catch(function(e){ go.disabled=false; go.textContent='Generate & send'; err.textContent=(e && e.message) || 'Request failed.'; });
  });
})();

