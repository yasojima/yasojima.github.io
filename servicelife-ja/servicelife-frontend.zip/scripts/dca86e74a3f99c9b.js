(function(){
  var raw = document.getElementById('wtc-data');
  if(!raw || typeof Chart === 'undefined') return;
  var D;
  try { D = JSON.parse(raw.textContent); } catch(e){ return; }
  var PALETTE = ['#2196F3','#E91E63','#4CAF50','#FF9800','#9C27B0','#00BCD4','#FFC107','#795548','#607D8B','#3F51B5','#8BC34A','#F44336'];
  function build(canvasId, series, labels){
    var el = document.getElementById(canvasId);
    if(!el) return;
    var datasets = (series||[]).map(function(s, i){
      var c = PALETTE[i % PALETTE.length];
      return { label: s.label, data: s.data, backgroundColor: c, borderColor: c, borderWidth: 0, borderRadius: 3, maxBarThickness: 22 };
    });
    new Chart(el.getContext('2d'), {
      type: 'bar',
      data: { labels: labels, datasets: datasets },
      options: {
        responsive: true, maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        scales: {
          x: { grid: { display: false }, ticks: { font: { size: 11 } } },
          y: { beginAtZero: true, ticks: { precision: 0, font: { size: 11 } }, grid: { color: 'rgba(0,0,0,0.06)' } }
        },
        plugins: {
          legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 }, usePointStyle: true } }
        }
      }
    });
  }
  build('wtcCompleted', D.completed, D.labels);
  build('wtcCanceled', D.canceled, D.labels);
  build('wtcLate', D.late, D.labels);
})();