const API='/api/v1';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(m)=>{const h={'X-CSRFToken':csrf()};if(m!=='GET')h['Content-Type']='application/json';return h;};
async function api(u,m='GET',b=null){const o={method:m,credentials:'same-origin',headers:hdr(m)};if(b)o.body=JSON.stringify(b);const r=await fetch(API+u,o);if(r.status===204)return null;return r.json();}
const _esc=document.createElement('textarea');
function escHTML(s){_esc.textContent=String(s||'');return _esc.innerHTML;}
function fmtDate(s){if(!s)return'—';return new Date(s).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
function showModal(id){document.getElementById(id).classList.add('show');}
function hideModal(id){document.getElementById(id).classList.remove('show');}

const STAT_BADGE={completed:'green',pending:'orange',failed:'red',refunded:'purple',cancelled:'gray'};
const METHOD_ICON={card:'fa-credit-card',cash:'fa-money-bill-wave',check:'fa-money-check',ach:'fa-university'};
function p(v){return parseFloat(v||0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});}

async function loadKPIs(){
  try{const d=await api('/billing/stats/');
  document.getElementById('kpiStrip').innerHTML=`
    <div class="kpi"><div class="lbl">Collected (Month)</div><div class="val" style="color:#2e7d32">$${(d.month?.total_collected||0).toLocaleString()}</div></div>
    <div class="kpi"><div class="lbl">Payments</div><div class="val">${d.all_time?.payment_count||0}</div></div>
    <div class="kpi"><div class="lbl">All-Time Collected</div><div class="val">$${(d.all_time?.total_collected||0).toLocaleString()}</div></div>`;
  }catch(e){}
}

async function loadData(){
  const tb=document.getElementById('tableBody');
  try{
  let url='/billing/payments/?ordering=-created_at';
  const s=document.getElementById('search').value,st=document.getElementById('filterStatus').value,mt=document.getElementById('filterMethod').value;
  const tech=(document.getElementById('filterTech')||{}).value||'';
  if(st)url+='&status='+st;
  if(mt)url+='&method='+mt;
  if(tech)url+='&appointment__technician='+tech;
  if(s)url+='&search='+encodeURIComponent(s);
  const d=await api(url);const items=d.results||d;
  if(!items.length){tb.innerHTML='<tr><td colspan="9"><div class="empty-state"><i class="fas fa-credit-card"></i><p>No payments yet</p></div></td></tr>';loadKPIs();return;}
  // Make rows globally accessible so the refund modal can read them.
  window._paymentRows = {};
  tb.innerHTML=items.map(p=>{
    window._paymentRows[p.id]=p;
    const method=p.method||p.payment_method_type||'card';
    const refundable = (p.status==='completed' && (p.gateway||'')==='stripe' && p.gateway_payment_id);
    const action = refundable
      ? `<button onclick="showRefundModal(window._paymentRows['${p.id}'])" style="padding:5px 10px;background:#7b1fa2;color:#fff;border:none;border-radius:5px;cursor:pointer;font-size:11px"><i class='fas fa-undo'></i> Refund</button>`
      : '<span style="color:var(--text-light);font-size:11px">—</span>';
    const cardCell = p.card_brand
      ? p.card_brand.toUpperCase() + ' ****' + (p.card_last_four || '')
      : (method === 'card' ? 'Card on file' : '—');
    return `<tr><td>${fmtDate(p.created_at)}</td><td><strong>${escHTML(p.customer_name||'—')}</strong></td><td style="font-weight:700">$${parseFloat(p.amount||0).toLocaleString(undefined,{minimumFractionDigits:2})}</td><td><i class="fas ${METHOD_ICON[method]||'fa-credit-card'}" style="margin-right:4px"></i>${method}</td><td>${cardCell}</td><td><span class="badge badge-${STAT_BADGE[p.status]||'gray'}">${p.status}</span></td><td>${p.invoice?`<a href="/invoices/?id=${p.invoice}" style="color:var(--accent)">View</a>`:'—'}</td><td style="font-size:11px;color:var(--text-light)">${(p.gateway_payment_id||'').slice(0,16)||'—'}</td><td>${action}</td></tr>`;
  }).join('');
  loadKPIs();
  }catch(e){if(e&&e.name==='AbortError')return;tb.innerHTML='<tr><td colspan="9"><div class="empty-state"><i class="fas fa-exclamation-triangle"></i><p>Could not load payments.</p></div></td></tr>';}
}
async function loadDeclinesBanner(){
  try{
    const d=await api('/billing/events/?event_type=charge_failed&ordering=-created_at&page_size=10');
    const items=(d&&d.results)||[];
    if(!items.length){return;}
    const banner=document.getElementById('declineBanner');
    const list=document.getElementById('declineBannerList');
    if(!banner||!list) return;
    list.innerHTML=items.map(e=>{
      const cname=e.customer_name||e.customer||'Unknown customer';
      const ts=e.created_at?new Date(e.created_at).toLocaleDateString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}):'';
      const err=e.payload&&e.payload.errors?` — ${e.payload.errors}`:'';
      const reviewLink=e.customer_id?`<a href="/customers/${e.customer_id}" style="color:#b71c1c;font-size:11px;margin-left:6px">Review &rarr;</a>`:'';
      return `<li style="margin-bottom:4px"><strong>${escHTML(String(cname))}</strong> had a charge declined${ts?' on '+ts:''}${escHTML(err)} ${reviewLink}</li>`;
    }).join('');
    banner.style.display='block';
  }catch(e){}
}
async function loadNewPaymentCustomers(){
  try{
    const d=await api('/customers/?page_size=200');const items=d.results||d;
    document.getElementById('npCustomer').innerHTML='<option value="">Select customer...</option>'+items.map(c=>`<option value="${escHTML(c.id)}">${escHTML(c.first_name+' '+c.last_name+(c.company_name?' ('+c.company_name+')':''))}</option>`).join('');
    document.getElementById('npCustomer').addEventListener('change',loadNewPaymentInvoices);
  }catch(e){}
}
async function loadNewPaymentInvoices(){
  const cid=document.getElementById('npCustomer').value;
  const sel=document.getElementById('npInvoice');
  sel.innerHTML='<option value="">— None —</option>';
  if(!cid)return;
  try{
    const d=await api('/billing/invoices/?customer='+encodeURIComponent(cid)+'&ordering=-created_at&page_size=50');
    const items=d.results||d;
    items.forEach(inv=>{
      const bal=parseFloat(inv.balance_due||0);
      if(bal<=0)return;
      const o=document.createElement('option');
      o.value=inv.id;
      o.textContent=(inv.invoice_number||'Draft')+' — $'+bal.toFixed(2)+' due';
      sel.appendChild(o);
    });
  }catch(e){}
}
function openNewPayment(){
  document.getElementById('npCustomer').value='';
  document.getElementById('npAmount').value='';
  document.getElementById('npMethod').value='cash';
  document.getElementById('npInvoice').innerHTML='<option value="">— None —</option>';
  document.getElementById('npNotes').value='';
  document.getElementById('npError').style.display='none';
  showModal('newPaymentModal');
}
async function saveNewPayment(){
  const errBox=document.getElementById('npError');
  errBox.style.display='none';
  const cid=document.getElementById('npCustomer').value;
  const amount=parseFloat(document.getElementById('npAmount').value);
  if(!cid){errBox.textContent='Please select a customer.';errBox.style.display='block';return;}
  if(!amount||amount<=0){errBox.textContent='Please enter a valid amount greater than zero.';errBox.style.display='block';return;}
  const body={
    customer:cid,
    amount:amount.toFixed(2),
    method:document.getElementById('npMethod').value,
    invoice:document.getElementById('npInvoice').value||null,
    notes:document.getElementById('npNotes').value,
    status:'completed',
  };
  const btn=document.getElementById('npSaveBtn');
  btn.disabled=true;btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> Saving…';
  try{
    const r=await api('/billing/payments/','POST',body);
    if(r&&r.id){hideModal('newPaymentModal');loadData();}
    else{errBox.textContent=(r&&(r.detail||Object.values(r)[0]))||'Could not save payment.';errBox.style.display='block';}
  }catch(e){errBox.textContent='Network error: '+(e.message||e);errBox.style.display='block';}
  finally{btn.disabled=false;btn.innerHTML='<i class="fas fa-save"></i> Save Payment';}
}
document.addEventListener('DOMContentLoaded',()=>{
  const p=new URLSearchParams(window.location.search);
  const st=p.get('status');
  if(st){const sel=document.getElementById('filterStatus');if(sel&&[...sel.options].some(o=>o.value===st))sel.value=st;}
  loadData();
  loadDeclinesBanner();
  loadNewPaymentCustomers();
  loadTechFilter();
});
async function loadTechFilter(){
  try{
    const d=await api('/technicians/');
    const items=(d&&d.results)||d||[];
    const sel=document.getElementById('filterTech');
    if(!sel||!Array.isArray(items))return;
    const cur=sel.value;
    sel.innerHTML='<option value="">All technicians</option>'+items
      .map(t=>`<option value="${escHTML(t.id)}">${escHTML(t.name||((t.first_name||'')+' '+(t.last_name||'')).trim()||'Tech')}</option>`).join('');
    if(cur)sel.value=cur;
  }catch(e){/* leave the "All technicians" default on failure */}
}