const API='/api/v1';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(m)=>{const h={'X-CSRFToken':csrf()};if(m!=='GET')h['Content-Type']='application/json';return h;};
async function api(u,m='GET',b=null){const o={method:m,credentials:'same-origin',headers:hdr(m)};if(b)o.body=JSON.stringify(b);const r=await fetch(API+u,o);if(r.status===204)return null;return r.json();}
function fmtDate(s){if(!s)return'—';return new Date(s).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
function showModal(id){document.getElementById(id).classList.add('show');}
function hideModal(id){document.getElementById(id).classList.remove('show');}

async function loadData(){const d=await api('/forms/templates/');const items=d.results||d;const el=document.getElementById('formsList');if(!items.length){el.innerHTML='<div style="text-align:center;padding:60px;color:var(--text-light)"><i class="fas fa-clipboard-check" style="font-size:48px;opacity:.3;display:block;margin-bottom:12px"></i><p>No form templates yet. Create them in <a href="/admin/forms/formtemplate/" style="color:var(--accent)">Admin → Form Templates</a>.</p></div>';return;}
el.innerHTML=items.map(f=>`<div class="form-card"><div><h4>${f.name}</h4><p>${f.description||'No description'}</p><p style="margin-top:6px">${(f.fields_list||[]).length} fields ${f.is_required?'• <span class="badge badge-orange">Required</span>':''}</p></div><div class="meta">${f.is_active?'<span class="badge badge-green">Active</span>':'<span class="badge badge-gray">Inactive</span>'}<a href="/admin/forms/formtemplate/" class="btn btn-outline" style="padding:6px 12px;font-size:11px;text-decoration:none">Edit</a></div></div>`).join('');}
document.addEventListener('DOMContentLoaded',loadData);