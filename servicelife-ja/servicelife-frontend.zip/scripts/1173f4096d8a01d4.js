const API='/api/v1/contest';
function esc(s){return (s==null?'':String(s)).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function initials(n){return (n||'?').split(' ').map(x=>x[0]).slice(0,2).join('').toUpperCase();}
function fmtDate(s){if(!s)return '';const d=new Date(s+(s.length<=10?'T00:00:00':''));return d.toLocaleDateString('en-US',{month:'short',day:'numeric'});}
function ord(n){const s=['th','st','nd','rd'],v=n%100;return n+(s[(v-20)%10]||s[v]||s[0]);}
function timeAgo(iso){if(!iso)return '';const sec=Math.max(1,Math.floor((Date.now()-new Date(iso).getTime())/1000));if(sec<60)return 'just now';const m=Math.floor(sec/60);if(m<60)return m+'m ago';const h=Math.floor(m/60);if(h<24)return h+'h ago';return Math.floor(h/24)+'d ago';}
function shortLabel(code){return ({done:'Jobs Completed',ontime:'On-Time Arrivals',payment:'Payments Taken',nps10:'Perfect NPS',upsell:'Upsell $',dur30:'Wk Duration Bonus',durwin:'Wk Duration Wins',review5star:'5-Star Reviews',allsubmitted:'Jobs Submitted'})[code]||code;}
let STATE={week:''};

async function load(){
  const el=document.getElementById('mcContent');
  let d;
  try{ const r=await fetch(API+'/my-standing/'+(STATE.week?('?week='+STATE.week):''),{credentials:'same-origin'}); if(!r.ok)throw new Error('HTTP '+r.status); d=await r.json(); }
  catch(e){ el.innerHTML='<div class="empty-state"><i class="fas fa-triangle-exclamation"></i><br>Could not load the contest.</div>'; return; }
  if(!d.contest){ el.innerHTML='<div class="empty-state"><i class="fas fa-trophy"></i><br>No active contest right now.</div>'; return; }
  const me=d.me, lb=d.leaderboard||[], rules=(d.rules||[]).slice().sort((a,b)=>a.sort_order-b.sort_order);

  let h='';
  // hero
  h+='<div class="mc-hero"><div><div class="lbl">My Points</div><div class="big">'+(me?me.total:0)+'</div>'+
     '<div class="sub">'+esc(d.contest.name)+'</div></div>'+
     '<div style="text-align:right"><div class="lbl">My Rank</div><div class="rank">'+(me?ord(me.rank):'—')+'</div>'+
     '<div class="sub">of '+d.total_participants+' techs</div></div></div>';

  // meta: window + freshness
  h+='<div class="mc-meta">'+esc(fmtDate(d.contest.starts_at.slice(0,10)))+' – '+esc(fmtDate(d.contest.ends_at.slice(0,10)))+
     (d.contest.last_recomputed_at?(' · updated '+esc(timeAgo(d.contest.last_recomputed_at))):'')+'</div>';

  // week selector
  h+='<div class="toolbar"><label style="font-size:12px;color:var(--text-light);font-weight:600">View:</label><select id="weekSel"><option value="">Whole contest</option>'+
     (d.weeks||[]).map(w=>`<option value="${w}" ${w===STATE.week?'selected':''}>Week of ${esc(fmtDate(w))}</option>`).join('')+'</select></div>';

  // my breakdown
  h+='<div class="breakdown">';
  rules.forEach(r=>{const v=me&&me.by_rule[r.code]||0;h+=`<div class="bd-card"><div class="v ${v?'':'zero'}">${v||0}</div><div class="l">${esc(shortLabel(r.code))}</div></div>`;});
  h+='</div>';

  // leaderboard
  h+='<div class="card"><h3><i class="fas fa-ranking-star"></i> Leaderboard</h3>';
  if(!lb.length){h+='<div class="empty-state">No standings yet.</div>';}
  else{
    h+='<table class="lb"><thead><tr><th class="num">#</th><th>Technician</th><th class="num">Points</th></tr></thead><tbody>';
    lb.forEach(t=>{
      const mine=me&&t.technician_id===me.technician_id;
      h+=`<tr class="${mine?'me':''}"><td class="num rk r${t.rank}">${t.rank}</td>`;
      h+=`<td><div class="tech-cell"><div class="av" style="background:${esc(t.color)}">${esc(initials(t.name))}</div>${esc(t.name)}${mine?' <span style="color:var(--text-light);font-weight:600">(you)</span>':''}</div></td>`;
      h+=`<td class="num tot">${t.total}</td></tr>`;
    });
    h+='</tbody></table>';
  }
  h+='</div>';

  // 5★ review stream (most recent first)
  const reviews=d.reviews||[];
  h+='<div class="card" style="margin-top:16px"><h3><i class="fas fa-star"></i> Recent 5-Star Reviews</h3>';
  if(!reviews.length){
    h+='<div class="empty-state" style="padding:30px"><i class="fas fa-star"></i><br>No 5-star reviews yet — go earn some!</div>';
  }else{
    h+='<div class="reviews">';
    reviews.forEach(rv=>{
      h+='<div class="rev">';
      h+=`<div class="rev-ava">${esc(initials(rv.reviewer||'?'))}</div>`;
      h+='<div class="rev-body">';
      h+=`<div class="rev-top"><span class="rev-name">${esc(rv.reviewer||'Anonymous')}</span>`;
      h+='<span class="rev-stars">★★★★★</span>';
      h+=`<span class="rev-src">${esc(rv.source||'')}</span>`;
      h+=`<span class="rev-when">${esc(timeAgo(rv.submitted_at))}</span></div>`;
      if(rv.text)h+=`<div class="rev-text">${esc(rv.text)}</div>`;
      if(rv.technician)h+=`<span class="rev-tech"><i class="fas fa-user"></i> ${esc(rv.technician)}</span>`;
      h+='</div></div>';
    });
    h+='</div>';
  }
  h+='</div>';

  el.innerHTML=h;
  const ws=document.getElementById('weekSel');
  if(ws)ws.addEventListener('change',function(){STATE.week=this.value;load();});
}
load();