(function(){
    if (window.__cbpModalCloseBackstop) return;
    window.__cbpModalCloseBackstop = true;

    // Containers we treat as modals. Includes <dialog>, the dominant
    // .modal-overlay/.modal pattern, role="dialog" divs, and a handful of
    // page-prefixed variants seen in customer/scheduling/billing templates.
    var CONTAINER_SEL = 'dialog, div.modal-overlay, div.modal, [role="dialog"]:not(dialog), .b9-modal-overlay, .appt-modal, .bp-modal, .cd-modal-bg';

    function isVisibleModal(el){
      if (!el) return false;
      if (el.tagName === 'DIALOG') return el.hasAttribute('open');
      var cs = window.getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden') return false;
      if (el.offsetParent === null && cs.position !== 'fixed') return false;
      return true;
    }
    function visibleModals(){
      return Array.prototype.filter.call(
        document.querySelectorAll(CONTAINER_SEL),
        isVisibleModal
      );
    }
    function topMost(els){
      if (!els.length) return null;
      return els.reduce(function(a, b){
        var za = parseInt(window.getComputedStyle(a).zIndex, 10) || 0;
        var zb = parseInt(window.getComputedStyle(b).zIndex, 10) || 0;
        // On tie, prefer the later element in DOM order.
        if (zb > za) return b;
        if (zb < za) return a;
        return (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING) ? b : a;
      });
    }
    function closeModalEl(el){
      if (!el) return false;
      // Discard-confirm guard. Opt-in via data-discard-confirm="1" and a
      // _cbpIsDirty() hook on the element (installed per-page). The guard
      // only triggers on close paths that flow through here (backdrop
      // click + ESC + history back + the close-button backstop). Explicit
      // X/Cancel buttons that call hideModal()/closeBook() directly are
      // intentional clicks and bypass the prompt — by design.
      if (el.dataset && el.dataset.discardConfirm === '1' &&
          typeof el._cbpIsDirty === 'function' && el._cbpIsDirty()) {
        if (!window.confirm('You have unsaved changes. Discard them?')) return false;
        if (typeof el._cbpResetDirty === 'function') el._cbpResetDirty();
      }
      if (el.tagName === 'DIALOG') {
        try { el.close(); return true; } catch(_) {}
      }
      // Allow opt-in to a specific close function via attribute.
      var handlerName = el.getAttribute('data-close-fn');
      if (handlerName && typeof window[handlerName] === 'function') {
        try { window[handlerName](); return true; } catch(_) {}
      }
      // Most modals are toggled via .show / .open / .is-open / .active class.
      // Strip those first so we match the CSS that controlled visibility.
      var hadClass = false;
      ['show','open','is-open','active'].forEach(function(c){
        if (el.classList.contains(c)) { el.classList.remove(c); hadClass = true; }
      });
      // Only fall back to inline display:none when no class toggle existed —
      // otherwise we'd shadow the CSS rule that lets the modal reopen later.
      if (!hadClass) {
        el.style.display = 'none';
      }
      try { el.dispatchEvent(new CustomEvent('cbp:modal-closed', {bubbles: true})); } catch(_) {}
      return true;
    }

    window.__cbpCloseTopModal = function(){
      var els = visibleModals();
      if (!els.length) return false;
      return closeModalEl(topMost(els));
    };

    // Esc → close topmost. Bubble phase so inputs / textareas / contenteditable
    // can preempt (they don't currently, but it keeps us non-intrusive).
    document.addEventListener('keydown', function(ev){
      if (ev.key !== 'Escape' && ev.keyCode !== 27) return;
      var els = visibleModals();
      if (!els.length) return;
      closeModalEl(topMost(els));
    });

    // Click backstop. Targets buttons that look like a modal close X. The
    // existing inline onclick="..." (when present) runs first; we defer to the
    // next tick and only close if the owning modal is still visible.
    var CLOSE_BTN_SEL = '[data-close-modal], .modal-close-x, .modal-close, .det-x, .mdl-x, .cbp-modal-close, .b9-modal-close';
    document.addEventListener('click', function(ev){
      var btn = ev.target.closest(CLOSE_BTN_SEL);
      if (!btn) return;
      setTimeout(function(){
        var owner = btn.closest(CONTAINER_SEL);
        if (owner && isVisibleModal(owner)) {
          closeModalEl(owner);
        } else if (!owner) {
          // Stray close button outside any modal — close the topmost open one.
          var els = visibleModals();
          if (els.length) closeModalEl(topMost(els));
        }
      }, 0);
    });

    // Backdrop click. ev.target (not closest) ensures we only fire when the
    // user clicks the dark scrim itself, not elements inside the modal panel.
    document.addEventListener('click', function(ev){
      // .modal-overlay only. .modal-bg (calendar.html) is handled by its own
      // local backdrop handler; matching here would double-fire the prompt.
      if (ev.target.classList.contains('modal-overlay') && isVisibleModal(ev.target)) {
        closeModalEl(ev.target);
      }
    });
  })();