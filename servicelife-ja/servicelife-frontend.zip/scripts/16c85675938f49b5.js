function mdmdaSubmit(ev) {
  ev.preventDefault();
  const form = document.getElementById('mdmda-form');
  const start = form.start.value.trim();
  const end = form.end.value.trim();
  const tech = form.technician_id.value.trim();
  const cust = form.customer_id.value.trim();
  const prod = form.product_id.value.trim();
  const status = document.getElementById('mdmda-status');
  status.className = 'mdmda-status';
  status.textContent = '';

  if (!start || !end) {
    status.className = 'mdmda-status is-error';
    status.textContent = 'Start and end dates are required.';
    return false;
  }
  if (end < start) {
    status.className = 'mdmda-status is-error';
    status.textContent = 'End must be on or after start.';
    return false;
  }

  const params = new URLSearchParams({start: start, end: end});
  if (tech) params.set('technician_id', tech);
  if (cust) params.set('customer_id', cust);
  if (prod) params.set('product_id', prod);

  status.className = 'mdmda-status is-info';
  status.textContent = 'Generating CSV — large date ranges may take a few seconds…';

  const url = '/api/v1/compliance/reports/md-mda/csv/?' + params.toString();
  window.location.href = url;
  return false;
}