(function () {
  if (window._aiFabInit) return;
  window._aiFabInit = true;

  const btn   = document.getElementById('aiFabBtn');
  const panel = document.getElementById('aiFabPanel');
  const closeBtn = document.getElementById('aiFabClose');
  const form  = document.getElementById('aiFabForm');
  const input = document.getElementById('aiFabInput');
  const body  = document.getElementById('aiFabBody');
  let sessionId = sessionStorage.getItem('aiFab.session') || null;

  function csrf() {
    const m = document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/);
    return m ? decodeURIComponent(m[1]) : '';
  }
  function escapeHtml(s) {
    return (s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }
  function formatResponse(text) {
    return escapeHtml(text || '')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\n/g, '<br>')
      .replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener" style="color:#1976d2">$1</a>');
  }
  function addMsg(role, text, asHtml) {
    const d = document.createElement('div');
    d.className = 'aiFab-msg ' + role;
    d.innerHTML = asHtml ? text : escapeHtml(text);
    body.appendChild(d);
    body.scrollTop = body.scrollHeight;
    return d;
  }
  function setTyping(on) {
    let t = document.getElementById('aiFabTyping');
    if (on) {
      if (t) return;
      t = document.createElement('div');
      t.id = 'aiFabTyping';
      t.className = 'aiFab-msg assistant';
      t.innerHTML = '<span class="aiFab-typing"><span></span><span></span><span></span></span>';
      body.appendChild(t);
      body.scrollTop = body.scrollHeight;
    } else if (t) {
      t.remove();
    }
  }

  function openPanel() {
    panel.setAttribute('aria-hidden', 'false');
    btn.setAttribute('aria-expanded', 'true');
    setTimeout(() => input.focus(), 80);
  }
  function closePanel() {
    panel.setAttribute('aria-hidden', 'true');
    btn.setAttribute('aria-expanded', 'false');
  }
  function togglePanel() {
    if (panel.getAttribute('aria-hidden') === 'false') closePanel(); else openPanel();
  }

  btn.addEventListener('click', togglePanel);
  closeBtn.addEventListener('click', closePanel);

  // Make the FAB bubble draggable. cbpMakeDraggable lives in base.html.
  // When the bubble moves, re-anchor the chat panel to the bubble's new
  // position so the panel stays glued to the FAB rather than to bottom-left.
  // We also swallow the synthetic click after a real drag so togglePanel
  // doesn't fire on drop.
  // Position the chat panel relative to the bubble. The panel is 360x500
  // by default (with max-height clamped to viewport via inline CSS). Pick
  // the best of 4 candidate anchor points (above-left, above-right, below-
  // left, below-right) so the panel never overflows the viewport — and if
  // none fit perfectly (panel taller than space), fall back to topping out
  // the panel at the top of the viewport.
  function repositionPanel(){
    var br  = btn.getBoundingClientRect();
    var pw  = 360;
    // Panel CSS has height:500 + max-height:calc(100vh - 120px). Use the
    // narrower of those.
    var ph  = Math.min(500, window.innerHeight - 120);
    var gap = 10, margin = 8;
    // Candidates (preferring above-right of bubble for bottom-left default).
    var candidates = [
      { x: br.left,            y: br.top - ph - gap },     // above-right of bubble
      { x: br.right - pw,      y: br.top - ph - gap },     // above-left  of bubble
      { x: br.left,            y: br.bottom + gap },       // below-right of bubble
      { x: br.right - pw,      y: br.bottom + gap },       // below-left  of bubble
    ];
    var best = null;
    for (var i = 0; i < candidates.length; i++) {
      var c = candidates[i];
      if (c.x >= margin && c.x + pw <= window.innerWidth - margin &&
          c.y >= margin && c.y + ph <= window.innerHeight - margin) {
        best = c;
        break;
      }
    }
    if (!best) {
      // No candidate fits — clamp to viewport bounds (last-resort).
      best = candidates[0];
      best.x = Math.max(margin, Math.min(best.x, window.innerWidth  - pw - margin));
      best.y = Math.max(margin, Math.min(best.y, window.innerHeight - ph - margin));
    }
    panel.style.left   = best.x + 'px';
    panel.style.top    = best.y + 'px';
    panel.style.right  = 'auto';
    panel.style.bottom = 'auto';
  }
  if (window.cbpMakeDraggable) {
    window.cbpMakeDraggable('aiFabBtn', '', 'cbp.aiFab.pos', {
      onMove: repositionPanel,
      onEnd:  function(){
        // After a drag, ensure the bubble itself is fully visible (safety
        // net; cbpMakeDraggable's applyPos already clamps, but this catches
        // any edge case) and re-anchor the panel.
        if (window.cbpEnsureVisible) window.cbpEnsureVisible('aiFabBtn', 'cbp.aiFab.pos');
        repositionPanel();
      },
    });
    // Reposition the panel each time it opens — the bubble may have moved
    // since the last open, and the viewport may have resized.
    var _origOpen = openPanel;
    openPanel = function(){ repositionPanel(); _origOpen(); };
    // Re-anchor on window resize as well (covers mobile rotation).
    window.addEventListener('resize', function(){
      if (panel.getAttribute('aria-hidden') === 'false') repositionPanel();
    });
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && panel.getAttribute('aria-hidden') === 'false') closePanel();
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    addMsg('user', msg);
    setTyping(true);
    try {
      const r = await fetch('/api/v1/chat/send/', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'X-CSRFToken': csrf(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msg, session_id: sessionId }),
      });
      const d = await r.json().catch(() => ({}));
      setTyping(false);
      if (!r.ok || d.error) {
        addMsg('error', d.error || ('Sorry, an error occurred (HTTP ' + r.status + ')'));
        return;
      }
      if (d.session_id) {
        sessionId = d.session_id;
        try { sessionStorage.setItem('aiFab.session', sessionId); } catch (_) {}
      }
      addMsg('assistant', formatResponse(d.response), true);
    } catch (err) {
      setTyping(false);
      addMsg('error', 'Network error — please try again.');
    }
  });
})();