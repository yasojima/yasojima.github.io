(function(){
    if (window.__cbpModalHelpers) return;
    window.__cbpModalHelpers = true;

    // Slice 16.1: canonical naive-local → UTC ISO converter. Mirrors the
    // helper that originated in scheduling/calendar.html:1478. Hoisted here
    // so every page can use it. NEVER strip the trailing 'Z' — Django needs
    // the explicit UTC marker; without it the server-side
    // TenantTzCoercingDateTimeField re-coerces and the offset compounds.
    window.getUTCOffsetMin = function(date, ianaTimezone){
      try{
        const utcStr = date.toLocaleString('en-US',{timeZone:'UTC',hour12:false,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'});
        const tzStr  = date.toLocaleString('en-US',{timeZone:ianaTimezone,hour12:false,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'});
        const parse = s=>{const[dt,tm]=s.split(', ');const[mo,d,y]=dt.split('/');const[h,mi,se]=tm.split(':');return new Date(Date.UTC(y,mo-1,d,h==='24'?0:h,mi,se)).getTime()};
        return (parse(tzStr)-parse(utcStr))/60000;
      }catch(e){return 0}
    };
    window.localToUTC = function(naiveDt, ianaTimezone){
      try{
        const tz = ianaTimezone || window._tenantTz || 'America/New_York';
        const [datePart, timePart] = naiveDt.split('T');
        const [y,mo,d]   = datePart.split('-').map(Number);
        const [h,mi,s]   = (timePart||'00:00:00').split(':').map(Number);
        const utcGuess   = new Date(Date.UTC(y,mo-1,d,h,mi,s||0));
        const offsetMin  = window.getUTCOffsetMin(utcGuess, tz);
        const utcMs      = utcGuess.getTime() - offsetMin*60000;
        return new Date(utcMs).toISOString(); // keep Z — Django needs UTC marker
      }catch(e){
        return naiveDt.slice(0,19);
      }
    };

    // XSS sweep (BUG-014/021/024/037/044/051): global HTML-escaping helper.
    // Use in ALL template-literal innerHTML builders for user-supplied text.
    // R3 BUG-004: TZ-aware local date string (YYYY-MM-DD) for <input type="date">.
    // Uses tenant timezone by default; override with specific tz for tech-scoped dates.
    // Falls back to browser-local date if Intl fails.
    window.localDateStr = function(d, tz) {
      d = d == null ? new Date() : (d instanceof Date ? d : new Date(d));
      tz = tz || window._tenantTz || 'America/New_York';
      try {
        return new Intl.DateTimeFormat('en-CA', {timeZone: tz, year:'numeric', month:'2-digit', day:'2-digit'}).format(d);
      } catch(e) {
        return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
      }
    };
    // R3 BUG-004: TZ-aware local time string (HH:MM) matching localDateStr.
    window.localTimeStr = function(d, tz) {
      d = d == null ? new Date() : (d instanceof Date ? d : new Date(d));
      tz = tz || window._tenantTz || 'America/New_York';
      try {
        return new Intl.DateTimeFormat('en-US', {timeZone: tz, hour:'2-digit', minute:'2-digit', hour12:false}).format(d).padStart(5,'0');
      } catch(e) {
        return String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0');
      }
    };

    window.escHTML = function(s) {
      return (s == null ? '' : String(s)).replace(/[&<>"']/g, function(c) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
      });
    };

    // R3 BUG-005: Generic DRF error response → friendly message mapper.
    // Centralised so every page's showApiError/_parseErr/catch can use it.
    window.cbpFormatApiError = function(errData, fallback) {
      var DEFAULT = fallback || 'Something went wrong. Please try again.';
      if (!errData) return DEFAULT;
      if (typeof errData === 'string') return _cbpSanitize(errData) || DEFAULT;
      if (errData.detail) return _cbpSanitize(String(errData.detail)) || DEFAULT;
      if (typeof errData === 'object') {
        var parts = [];
        try {
          Object.keys(errData).forEach(function(k) {
            var v = errData[k];
            var txt = Array.isArray(v) ? v.map(function(i){return _cbpSanitize(String(i));}).filter(Boolean).join(', ') : _cbpSanitize(String(v));
            if (!txt) return;
            if (k === 'non_field_errors') { parts.push(txt); return; }
            parts.push(_cbpFieldLabel(k) + ': ' + txt);
          });
        } catch(_) {}
        return parts.length ? parts.join(' \u2022 ') : DEFAULT;
      }
      return DEFAULT;
    };
    // Map raw DRF/model field names to user-friendly labels.
    var _cbpFieldLabels = {
      'first_name':'First name','last_name':'Last name','phone':'Phone','email':'Email',
      'company_name':'Company','customer_type':'Type','property_type':'Property type',
      'service_address':'Address','service_city':'City','service_state':'State','service_zip':'ZIP',
      'billing_address':'Billing address','billing_city':'Billing city','billing_state':'Billing state','billing_zip':'Billing ZIP',
      'start_datetime':'Start date/time','end_datetime':'End date/time','start_date':'Start date','end_date':'End date',
      'technician':'Technician','job_type':'Job type','status':'Status','priority':'Priority',
      'subject':'Subject','description':'Description','category':'Category','channel':'Channel',
      'title':'Title','amount':'Amount','contract_type':'Contract type','contract_number':'Contract #',
      'recurring_fee':'Recurring fee','initial_fee':'Initial fee','tax_rate':'Tax rate',
      'customer':'Customer','tenant':'Account','duration':'Duration','notes':'Notes',
      'name':'Name','slug':'Slug','content':'Content','body':'Body','source':'Source',
    };
    function _cbpFieldLabel(raw) {
      if (_cbpFieldLabels[raw]) return _cbpFieldLabels[raw];
      return raw.replace(/_/g, ' ').replace(/^./, function(c){return c.toUpperCase();});
    }
    // Detect and sanitize raw technical error text that should never be user-visible.
    var _cbpTechPatterns = [
      /UNIQUE constraint/i, /IntegrityError/i, /OperationalError/i,
      /ProgrammingError/i, /Traceback/i, /File "\//i, /psycopg2/i,
      /django\.db\./i, /django\.core\./i, /Internal Server Error/i,
      /relation ".*" does not exist/i, /column ".*" does not exist/i,
      /permission denied for/i, /SSL\b.*\berror/i,
    ];
    function _cbpSanitize(msg) {
      if (!msg) return '';
      for (var i = 0; i < _cbpTechPatterns.length; i++) {
        if (_cbpTechPatterns[i].test(msg)) return '';
      }
      // Also strip if it's a raw JSON blob or > 200 chars (likely a traceback)
      if (msg.length > 200) return '';
      return msg;
    }

    window.cbpSubmit = async function(btn, asyncFn) {
      if (typeof asyncFn !== "function") throw new Error("cbpSubmit: asyncFn required");
      if (!btn) { return await asyncFn(); }
      if (btn.dataset.cbpBusy === "1") { return; }
      btn.dataset.cbpBusy = "1";
      var wasDisabled = !!btn.disabled;
      var origHTML = btn.innerHTML;
      btn.dataset.cbpOrigHtml = origHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="cbp-spinner" aria-hidden="true"></span>Saving...';
      try {
        return await asyncFn();
      } catch (err) {
        if (err && err.name === "AbortError") return;
        throw err;
      } finally {
        btn.dataset.cbpBusy = "";
        btn.disabled = wasDisabled;
        btn.innerHTML = btn.dataset.cbpOrigHtml || origHTML;
        try { delete btn.dataset.cbpOrigHtml; } catch(e) {}
      }
    };

    window.cbpAttachClearOnInput = function(modalEl) {
      if (!modalEl) return;
      if (modalEl.dataset.cbpClearAttached === "1") return;
      modalEl.dataset.cbpClearAttached = "1";
      var clear = function(ev){
        var el = ev.target;
        if (!el || !el.classList) return;
        if (el.classList.contains("field-invalid")) {
          el.classList.remove("field-invalid");
          if (el.parentNode) {
            var sib = el.parentNode.querySelector(":scope > .field-error");
            if (sib) sib.remove();
          }
        }
      };
      modalEl.addEventListener("input", clear, true);
      modalEl.addEventListener("change", clear, true);
    };

    window.cbpConfirm = function(message) {
      return Promise.resolve(window.confirm(message));
    };

    // Required cancellation-reason picker. Resolves to {code, comment} when
    // the user confirms, or null if they back out. Codes MUST match the BE
    // allowlist in scheduling/services_csr_inbox.py CANCEL_REASON_CODES.
    window.CBP_CANCEL_REASONS = [
      ["customer_canceled",   "Customer changed their mind / cancelled"],
      ["schedule_conflict",   "Time didn't work / didn't agree to time"],
      ["price_concern",       "Price too high / no pricing given at booking"],
      ["questions_unanswered","Questions not answered before booking"],
      ["agreement_terms",     "Not OK with agreement / contract terms"],
      ["competitor",          "Went with another company"],
      ["dissatisfied",        "Unhappy with prior service"],
      ["no_longer_needed",    "No longer needs service"],
      ["duplicate",           "Duplicate booking"],
      ["tech_unavailable",    "We couldn't staff it"],
      ["weather",             "Weather"],
      ["other",               "Other (add a note)"],
    ];
    window.cbpCancelReason = function(opts){
      opts = opts || {};
      var title = opts.title || "Cancel this appointment?";
      return new Promise(function(resolve){
        var ov = document.createElement("div");
        ov.setAttribute("style",
          "position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.45);"+
          "display:flex;align-items:center;justify-content:center;padding:16px;");
        var opts_html = window.CBP_CANCEL_REASONS.map(function(r){
          return '<option value="'+r[0]+'">'+r[1]+'</option>';
        }).join("");
        var card = document.createElement("div");
        card.setAttribute("style",
          "background:#fff;color:#1a1a1a;max-width:440px;width:100%;border-radius:10px;"+
          "box-shadow:0 12px 40px rgba(0,0,0,.3);padding:20px;font-size:14px;");
        card.innerHTML =
          '<div style="font-weight:700;font-size:16px;margin-bottom:4px;">'+title+'</div>'+
          '<div style="color:#666;margin-bottom:14px;">Pick a reason so we can learn from cancellations.</div>'+
          '<label style="display:block;font-weight:600;margin-bottom:4px;">Reason <span style="color:#E53935">*</span></label>'+
          '<select id="cbpCrCode" style="width:100%;padding:8px;border:1px solid #ccc;border-radius:6px;margin-bottom:12px;">'+
          '<option value="" selected disabled>— Select a reason —</option>'+opts_html+'</select>'+
          '<label style="display:block;font-weight:600;margin-bottom:4px;">Note <span id="cbpCrNoteReq" style="color:#E53935;display:none">*</span></label>'+
          '<textarea id="cbpCrComment" rows="2" placeholder="Optional details" style="width:100%;padding:8px;border:1px solid #ccc;border-radius:6px;margin-bottom:6px;box-sizing:border-box;"></textarea>'+
          '<div id="cbpCrErr" style="color:#E53935;min-height:16px;font-size:12px;margin-bottom:8px;"></div>'+
          '<div style="display:flex;justify-content:flex-end;gap:8px;">'+
          '<button type="button" id="cbpCrBack" style="padding:8px 14px;border:1px solid #ccc;background:#f5f5f5;border-radius:6px;cursor:pointer;">Keep appointment</button>'+
          '<button type="button" id="cbpCrGo" style="padding:8px 14px;border:none;background:#E53935;color:#fff;border-radius:6px;cursor:pointer;font-weight:600;">Cancel appointment</button>'+
          '</div>';
        ov.appendChild(card);
        document.body.appendChild(ov);
        var sel=card.querySelector("#cbpCrCode"), com=card.querySelector("#cbpCrComment"),
            err=card.querySelector("#cbpCrErr"), noteReq=card.querySelector("#cbpCrNoteReq");
        function cleanup(){ try{document.body.removeChild(ov);}catch(_){} }
        function done(v){ cleanup(); resolve(v); }
        sel.addEventListener("change", function(){
          noteReq.style.display = (sel.value==="other") ? "inline" : "none";
          err.textContent="";
        });
        card.querySelector("#cbpCrBack").addEventListener("click", function(){ done(null); });
        ov.addEventListener("click", function(e){ if(e.target===ov) done(null); });
        card.querySelector("#cbpCrGo").addEventListener("click", function(){
          var code=sel.value, comment=(com.value||"").trim();
          if(!code){ err.textContent="Please select a reason."; return; }
          if(code==="other" && !comment){ err.textContent="A note is required when choosing Other."; return; }
          done({code:code, comment:comment});
        });
        setTimeout(function(){ try{sel.focus();}catch(_){} }, 30);
      });
    };
  })();