(function(){
  function esc(s){return String(s).replace(/[&<>"']/g, function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  fetch('/api/v1/ai/upsell-metrics/', {headers:{'Accept':'application/json'}})
    .then(function(r){ if(!r.ok) throw new Error('HTTP '+r.status); return r.json(); })
    .then(function(data){
      var t = data.totals || {};
      var rows = (data.top_recommendation_types || []).map(function(row){
        return '<li>'+esc(row.type)+': '+row.count+' generated, '
          + row.accepted+' accepted ('+(row.rate*100).toFixed(1)+'%)</li>';
      }).join('');
      document.getElementById('upsell-metrics-body').innerHTML =
        '<div>Generated: <strong>'+(t.recommendations_generated||0)+'</strong></div>'
        + '<div>Accepted: <strong>'+(t.recommendations_accepted||0)+'</strong> '
        + '('+(((t.acceptance_rate||0)*100).toFixed(1))+'%)</div>'
        + '<div>Potential value: $'+esc(t.potential_value_total_dollars||'0.00')+'</div>'
        + '<div>Accepted value: $'+esc(t.accepted_value_dollars||'0.00')+'</div>'
        + (rows ? '<ul style="margin-top:10px;padding-left:18px;font-size:12px;color:var(--text-light)">'+rows+'</ul>' : '');
    })
    .catch(function(){
      document.getElementById('upsell-metrics-body').innerHTML =
        '<div style="color:var(--text-light);font-size:12px">Unable to load upsell metrics.</div>';
    });
})();