const API='/api/v1';
const csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
const hdr=(m)=>{const h={'X-CSRFToken':csrf()};if(m!=='GET')h['Content-Type']='application/json';return h;};
async function api(u,m='GET',b=null){const o={method:m,credentials:'same-origin',headers:hdr(m)};if(b)o.body=JSON.stringify(b);const r=await fetch(API+u,o);if(r.status===204)return null;return r.json();}
function fmtDate(s){if(!s)return'—';return new Date(s).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});}
function showModal(id){document.getElementById(id).classList.add('show');}
function hideModal(id){document.getElementById(id).classList.remove('show');}

async function loadKPIs(){try{const d=await api('/inventory/stats/');document.getElementById('kpiStrip').innerHTML=`<div class="kpi"><div class="lbl">Items</div><div class="val">${d.total_items}</div></div><div class="kpi"><div class="lbl">Locations</div><div class="val">${d.total_locations}</div></div><div class="kpi"><div class="lbl">Low Stock</div><div class="val" style="color:#c62828">${d.low_stock_alerts}</div></div><div class="kpi"><div class="lbl">Inventory Value</div><div class="val">$${(d.total_value||0).toLocaleString()}</div></div><div class="kpi"><div class="lbl">Pending POs</div><div class="val">${d.pending_pos}</div></div>`;}catch(e){}}
let editId=null;
async function loadData(){let url='/inventory/items/?ordering=name';const s=document.getElementById('search').value;if(s)url+='&search='+encodeURIComponent(s);const d=await api(url);const items=d.results||d;const tb=document.getElementById('tableBody');if(!items.length){tb.innerHTML='<tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-light)">No inventory items yet</td></tr>';loadKPIs();return;}
tb.innerHTML=items.map(i=>{const ts=i.total_stock||0;const low=ts<=i.reorder_level;return `<tr><td><strong>${i.sku||'—'}</strong></td><td>${i.name}</td><td>${i.unit}</td><td>$${parseFloat(i.cost||0).toFixed(2)}</td><td style="font-weight:700;color:${low?'#c62828':'var(--text)'}">${ts}</td><td>${i.reorder_level}</td><td>${low?'<span class="badge badge-red">Low Stock</span>':'<span class="badge badge-green">OK</span>'}</td></tr>`;}).join('');loadKPIs();}
function openNew(){
  document.getElementById('i-name').value='';
  document.getElementById('i-sku').value='';
  document.getElementById('i-unit').value='each';
  document.getElementById('i-cost').value='0';
  document.getElementById('i-reorder').value='5';
  document.getElementById('i-error').style.display='none';
  document.getElementById('i-submit-btn').disabled=false;
  document.getElementById('i-submit-btn').textContent='Add Item';
  showModal('addItemModal');
}
async function submitNewItem(){
  const name=document.getElementById('i-name').value.trim();
  const sku=document.getElementById('i-sku').value.trim();
  const unit=document.getElementById('i-unit').value.trim()||'each';
  const cost=document.getElementById('i-cost').value||'0';
  const reorder=document.getElementById('i-reorder').value||'5';
  const errDiv=document.getElementById('i-error');
  errDiv.style.display='none';
  if(!name){errDiv.textContent='Name is required.';errDiv.style.display='block';return;}
  const btn=document.getElementById('i-submit-btn');
  btn.disabled=true;btn.textContent='Saving…';
  try{
    const r=await fetch(API+'/inventory/items/',{method:'POST',credentials:'same-origin',headers:hdr('POST'),body:JSON.stringify({name,sku,unit,cost,reorder_level:parseInt(reorder,10)||5})});
    if(!r.ok){const e=await r.json();throw new Error(JSON.stringify(e));}
    hideModal('addItemModal');
    loadData();
  }catch(err){
    errDiv.textContent='Failed to add item: '+err.message;
    errDiv.style.display='block';
    btn.disabled=false;btn.textContent='Add Item';
  }
}
document.addEventListener('DOMContentLoaded',loadData);