const API='/api/v1',csrf=()=>document.cookie.match(/csrftoken=([^;]+)/)?.[1]||'';
let editId=null;
function toast(m,t='success'){const e=document.getElementById('toast');e.textContent=m;e.className='toast '+t;setTimeout(()=>e.className='toast',3000)}
async function apiFetch(u,m='GET',b=null){return fetch(API+u,{method:m,credentials:'same-origin',headers:{'X-CSRFToken':csrf(),'Content-Type':'application/json'},body:b?JSON.stringify(b):null})}
async function api(u,m='GET',b=null){return(await apiFetch(u,m,b)).json()}
async function loadData(){
  let u='/communications/canned-responses/?ordering=title';
  const s=document.getElementById('search').value,c=document.getElementById('fCat').value;
  if(s)u+='&search='+encodeURIComponent(s);if(c)u+='&category='+c;
  const d=await api(u);const items=d.results||d;
  const g=document.getElementById('grid');
  if(!items.length){g.innerHTML='<div style="text-align:center;padding:40px;color:var(--text-light);grid-column:1/-1"><i class="fas fa-comment-dots" style="font-size:32px;opacity:.2;display:block;margin-bottom:8px"></i>No canned responses yet — click New Response to add one.</div>';return}
  g.innerHTML=items.map(r=>`<div class="resp-card">
    <h4>${escHTML(r.title)}</h4><div class="cat"><span class="badge">${(r.category||'general').replace(/_/g,' ')}</span> ${r.channel?'<span class="badge" style="background:#f3e5f5;color:#7b1fa2">'+escHTML(r.channel)+'</span>':''}</div>
    <div class="body">${escHTML(r.body||'').replace(/\n/g,'<br>')}</div>
    <div class="actions">
      <button type="button" class="btn-sm copy" onclick="copyText('${r.id}')"><i class="fas fa-copy"></i> Copy</button>
      <button type="button" class="btn-sm" onclick="openEdit('${r.id}')"><i class="fas fa-edit"></i> Edit</button>
      <button type="button" class="btn-sm danger" onclick="deleteResp('${r.id}')"><i class="fas fa-trash"></i></button>
    </div></div>`).join('')}
function copyText(id){api('/communications/canned-responses/'+id+'/').then(r=>{navigator.clipboard.writeText(r.body);toast('Copied!')})}
function openNew(){editId=null;document.getElementById('modalTitle').textContent='New Response';['fTitle','fBody'].forEach(i=>document.getElementById(i).value='');document.getElementById('respModal').classList.add('open')}
async function openEdit(id){editId=id;const r=await api('/communications/canned-responses/'+id+'/');document.getElementById('modalTitle').textContent='Edit Response';document.getElementById('fTitle').value=r.title;document.getElementById('fBody').value=r.body;document.getElementById('fRCat').value=r.category||'general';document.getElementById('fRChan').value=r.channel||'all';document.getElementById('respModal').classList.add('open')}
function closeModal(){document.getElementById('respModal').classList.remove('open')}
async function saveResp(){const b={title:document.getElementById('fTitle').value.trim(),body:document.getElementById('fBody').value.trim(),category:document.getElementById('fRCat').value,channel:document.getElementById('fRChan').value};
  if(!b.title||!b.body){toast('Title and body required','error');return}
  try{let r;if(editId)r=await apiFetch('/communications/canned-responses/'+editId+'/','PATCH',b);else r=await apiFetch('/communications/canned-responses/','POST',b);if(r.ok){toast(editId?'Updated':'Created');closeModal();loadData()}else{toast('Error saving','error')}}catch(e){toast('Error','error')}}
async function deleteResp(id){if(!confirm('Delete this response?'))return;try{await apiFetch('/communications/canned-responses/'+id+'/','DELETE');toast('Deleted');loadData()}catch(e){}}
document.addEventListener('DOMContentLoaded',loadData);