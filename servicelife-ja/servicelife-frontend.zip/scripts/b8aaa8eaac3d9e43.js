(function () {
  const LIST_EL = document.getElementById('rrList');
  const UPDATED_EL = document.getElementById('rrUpdated');
  const COUNT_ELS = {
    pending: document.getElementById('rrCountPending'),
    approved: document.getElementById('rrCountApproved'),
    rejected: document.getElementById('rrCountRejected'),
    expired: document.getElementById('rrCountExpired'),
    all: document.getElementById('rrCountAll'),
  };
  const TABS = Array.from(document.querySelectorAll('.rr-tab'));

  // Current selected status filter. '' means all.
  let currentStatus = 'pending';
  let pendingReject = null; // {id, originalCard}

  function csrfCookie() {
    const m = document.cookie.match(/(?:^|;)\s*csrftoken=([^;]+)/);
    return m ? m[1] : '';
  }

  function fmtDateTime(iso) {
    if (!iso) return '—';
    try {
      const d = new Date(iso);
      return d.toLocaleString(undefined, {
        weekday: 'short', month: 'short', day: 'numeric',
        hour: 'numeric', minute: '2-digit',
      });
    } catch (e) { return iso; }
  }

  function fmtRelative(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    const diffMs = d.getTime() - Date.now();
    const abs = Math.abs(diffMs);
    const mins = Math.round(abs / 60000);
    const hours = Math.round(abs / 3600000);
    const days = Math.round(abs / 86400000);
    const future = diffMs > 0;
    if (abs < 60000) return future ? 'in a moment' : 'just now';
    if (mins < 60) return future ? `in ${mins}m` : `${mins}m ago`;
    if (hours < 24) return future ? `in ${hours}h` : `${hours}h ago`;
    return future ? `in ${days}d` : `${days}d ago`;
  }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    })[c]);
  }

  function renderEmpty(status) {
    const map = {
      pending: { icon: 'fa-inbox', text: 'No pending reschedule requests. Customers can submit one from their appointment confirmation link.' },
      approved: { icon: 'fa-check-circle', text: 'No approved requests yet.' },
      rejected: { icon: 'fa-times-circle', text: 'No rejected requests.' },
      expired: { icon: 'fa-hourglass-end', text: 'No expired requests.' },
      '': { icon: 'fa-calendar-check', text: 'No reschedule requests yet.' },
    };
    const m = map[status] || map[''];
    return `<div class="rr-empty"><i class="fas ${m.icon}"></i><p>${escapeHtml(m.text)}</p></div>`;
  }

  function renderCard(rr) {
    const expiresAt = new Date(rr.expires_at);
    const isExpiringSoon = rr.status === 'pending' &&
      (expiresAt.getTime() - Date.now()) < 24 * 3600 * 1000;
    const decision = (rr.status === 'approved' || rr.status === 'rejected') ? `
      <div class="rr-decision">
        <strong>${rr.status === 'approved' ? 'Approved' : 'Rejected'}</strong>
        ${rr.decided_at ? '· ' + escapeHtml(fmtDateTime(rr.decided_at)) : ''}
        ${rr.csr_decision_note ? '<br>Note: ' + escapeHtml(rr.csr_decision_note) : ''}
      </div>
    ` : '';
    const actions = rr.status === 'pending' ? `
      <div class="rr-actions">
        <button class="rr-btn rr-approve" data-action="approve" data-id="${escapeHtml(rr.id)}">
          <i class="fas fa-check"></i> Approve & reschedule
        </button>
        <button class="rr-btn rr-reject" data-action="reject" data-id="${escapeHtml(rr.id)}">
          <i class="fas fa-times"></i> Reject
        </button>
      </div>
    ` : '';
    return `
      <div class="rr-card ${escapeHtml(rr.status)}" data-id="${escapeHtml(rr.id)}">
        <div class="rr-card-head">
          <div>
            <div class="rr-customer">${escapeHtml(rr.customer_name || '(unknown customer)')}</div>
            <div class="rr-customer-meta">
              ${rr.customer_phone ? '<span><i class="fas fa-phone" style="font-size:9px"></i> ' + escapeHtml(rr.customer_phone) + '</span>' : ''}
              ${rr.customer_email ? '<span><i class="fas fa-envelope" style="font-size:9px"></i> ' + escapeHtml(rr.customer_email) + '</span>' : ''}
            </div>
          </div>
          <span class="rr-status-badge rr-status-${escapeHtml(rr.status)}">${escapeHtml(rr.status)}</span>
        </div>

        <div class="rr-slots">
          <div class="rr-slot-block">
            <div class="rr-slot-label">Currently scheduled</div>
            <div class="rr-slot-time">${escapeHtml(fmtDateTime(rr.original_start_at))}</div>
            <div class="rr-slot-tech">${rr.original_technician_name ? 'with ' + escapeHtml(rr.original_technician_name) : ''}</div>
          </div>
          <div class="rr-arrow"><i class="fas fa-arrow-right"></i></div>
          <div class="rr-slot-block">
            <div class="rr-slot-label">Customer proposes</div>
            <div class="rr-slot-time">${escapeHtml(fmtDateTime(rr.proposed_start_at))}</div>
            <div class="rr-slot-tech">${rr.proposed_technician_name ? 'with ' + escapeHtml(rr.proposed_technician_name) : 'same technician'}</div>
          </div>
        </div>

        <div class="rr-reason">${escapeHtml(rr.customer_reason || '')}</div>

        <div class="rr-meta-row">
          <span>Submitted ${escapeHtml(fmtRelative(rr.created_at))}</span>
          ${rr.status === 'pending'
            ? `<span class="rr-expires${isExpiringSoon ? ' urgent' : ''}">Expires ${escapeHtml(fmtRelative(rr.expires_at))}</span>`
            : ''}
        </div>

        ${actions}
        ${decision}
      </div>
    `;
  }

  function setCounts(counts) {
    const total = (counts.pending || 0) + (counts.approved || 0)
                + (counts.rejected || 0) + (counts.expired || 0);
    COUNT_ELS.pending.textContent = counts.pending || 0;
    COUNT_ELS.approved.textContent = counts.approved || 0;
    COUNT_ELS.rejected.textContent = counts.rejected || 0;
    COUNT_ELS.expired.textContent = counts.expired || 0;
    COUNT_ELS.all.textContent = total;
    // Highlight pending count when > 0.
    if (counts.pending > 0) COUNT_ELS.pending.classList.add('has-rows');
    else COUNT_ELS.pending.classList.remove('has-rows');
  }

  async function loadList() {
    LIST_EL.innerHTML = '<div class="rr-loading"><i class="fas fa-spinner fa-spin"></i>Loading…</div>';
    const params = new URLSearchParams();
    if (currentStatus) params.set('status', currentStatus);
    try {
      const res = await fetch('/api/v1/scheduling/reschedule-requests/?' + params.toString(), {
        credentials: 'same-origin',
        headers: { 'Accept': 'application/json' },
      });
      if (!res.ok) {
        LIST_EL.innerHTML = `<div class="rr-empty"><i class="fas fa-exclamation-triangle"></i><p>Failed to load (${res.status})</p></div>`;
        return;
      }
      const data = await res.json();
      setCounts(data.counts || {});
      const rows = data.results || [];
      if (rows.length === 0) {
        LIST_EL.innerHTML = renderEmpty(currentStatus);
      } else {
        LIST_EL.innerHTML = rows.map(renderCard).join('');
      }
      UPDATED_EL.textContent = 'Updated ' + new Date().toLocaleTimeString();
    } catch (e) {
      LIST_EL.innerHTML = `<div class="rr-empty"><i class="fas fa-exclamation-triangle"></i><p>Network error: ${escapeHtml(String(e))}</p></div>`;
    }
  }

  async function approve(id, btn) {
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Approving…'; }
    try {
      const res = await fetch(`/api/v1/scheduling/reschedule-requests/${encodeURIComponent(id)}/approve/`, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': csrfCookie(),
          'Accept': 'application/json',
        },
        body: JSON.stringify({}),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const msg = data.error === 'slot_conflict'
          ? "That slot is no longer available — the customer's proposed time conflicts with another appointment."
          : (data.error || ('Approve failed (' + res.status + ')'));
        alert(msg);
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-check"></i> Approve & reschedule'; }
        return;
      }
      // Refresh the list and counts.
      loadList();
    } catch (e) {
      alert('Network error: ' + e);
      if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-check"></i> Approve & reschedule'; }
    }
  }

  function openRejectModal(id) {
    pendingReject = { id };
    document.getElementById('rrRejectNote').value = '';
    document.getElementById('rrRejectErr').textContent = '';
    document.getElementById('rrRejectOverlay').classList.add('open');
    setTimeout(() => document.getElementById('rrRejectNote').focus(), 50);
  }

  function closeRejectModal() {
    document.getElementById('rrRejectOverlay').classList.remove('open');
    pendingReject = null;
  }

  async function confirmReject() {
    if (!pendingReject) return;
    const note = document.getElementById('rrRejectNote').value.trim();
    const btn = document.getElementById('rrRejectConfirm');
    const err = document.getElementById('rrRejectErr');
    err.textContent = '';
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Rejecting…';
    try {
      const res = await fetch(`/api/v1/scheduling/reschedule-requests/${encodeURIComponent(pendingReject.id)}/reject/`, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': csrfCookie(),
          'Accept': 'application/json',
        },
        body: JSON.stringify({ csr_decision_note: note }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        err.textContent = data.error || ('Reject failed (' + res.status + ')');
        btn.disabled = false;
        btn.innerHTML = 'Reject';
        return;
      }
      closeRejectModal();
      loadList();
    } catch (e) {
      err.textContent = 'Network error: ' + e;
      btn.disabled = false;
      btn.innerHTML = 'Reject';
    }
  }

  // Tab clicks change filter.
  TABS.forEach(tab => {
    tab.addEventListener('click', () => {
      TABS.forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');
      currentStatus = tab.dataset.status || '';
      loadList();
    });
  });

  // Per-card action clicks (delegation).
  LIST_EL.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;
    const id = btn.dataset.id;
    if (!id) return;
    if (action === 'approve') return approve(id, btn);
    if (action === 'reject') return openRejectModal(id);
  });

  // Modal wiring.
  document.getElementById('rrRejectCancel').addEventListener('click', closeRejectModal);
  document.getElementById('rrRejectConfirm').addEventListener('click', confirmReject);
  document.getElementById('rrRejectOverlay').addEventListener('click', (e) => {
    if (e.target.id === 'rrRejectOverlay') closeRejectModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && document.getElementById('rrRejectOverlay').classList.contains('open')) {
      closeRejectModal();
    }
  });

  // Initial load.
  loadList();
})();