const API='/api/v1';
const api=async u=>(await fetch(API+u,{credentials:'same-origin'})).json();
function fmtTime(s){if(!s)return'';return new Date(s).toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'})}
// F-026 R13: replace silent catch blocks with a panel-level error state so
// the user sees "Could not load" instead of an indefinite "Loading..."
// spinner when an API call throws (auth lapse, transient 5xx, JSON parse).
function panelError(id, msg){
  const el=document.getElementById(id);
  if(el) el.innerHTML='<div class="empty">'+(msg||'Could not load.')+'</div>';
}
async function loadDashboard(){
  document.getElementById('dashTime').textContent='Updated: '+new Date().toLocaleTimeString();
  // KPIs
  try{const ts=await api('/tickets/stats/');document.getElementById('kOpenTickets').textContent=(ts.open||0)+(ts.in_progress||0)}catch(e){}
  try{const rs=await api('/communications/stats/');document.getElementById('kTodayCalls').textContent=rs.calls_today||0;document.getElementById('kCallbacks').textContent=rs.callbacks_due||0}catch(e){}
  try{const ss=await api('/routing/stats/');document.getElementById('kTodayAppts').textContent=ss.today_appointments||0}catch(e){}
  // Ticket queue
  try{const td=await api('/tickets/tickets/?status=open&status=in_progress&ordering=priority,-created_at&page_size=10');const items=td.results||td;
    document.getElementById('ticketQueue').innerHTML=items.length?items.map(t=>`<div class="q-item" onclick="window.location='/tickets/'"><div class="pri pri-${t.priority}"></div><div style="flex:1"><strong>${escHTML(t.subject)}</strong><div style="color:var(--text-light)">${escHTML(t.customer_name)||'Unknown'} \u2022 ${escHTML((t.category||'').replace(/_/g,' '))}</div></div><span class="badge badge-${t.priority==='urgent'?'red':t.priority==='high'?'orange':'blue'}">${escHTML(t.priority)}</span></div>`).join(''):'<div class="empty">No open tickets</div>'}catch(e){panelError('ticketQueue')}
  // Today's schedule
  try{const sd=await api('/routing/daily-routes/');const routes=sd.routes||[];
    let html='';routes.forEach(r=>{(r.stops||[]).filter(s=>s.type==='appointment').forEach(s=>{html+=`<div class="upcoming-item"><div><strong>${escHTML(s.label)}</strong><div style="color:var(--text-light)">${escHTML(s.address)}</div></div><div style="text-align:right"><span class="badge badge-blue">${escHTML(s.time||'')}</span><div style="color:var(--text-light);font-size:11px">${escHTML((r.technician||{}).name||'')}</div></div></div>`})});
    document.getElementById('todaySchedule').innerHTML=html||'<div class="empty">No appointments today</div>'}catch(e){panelError('todaySchedule')}
  // Recent calls
  try{const cd=await api('/communications/call-logs/?ordering=-call_datetime&page_size=8');const items=cd.results||cd;
    document.getElementById('recentCalls').innerHTML=items.length?items.map(c=>`<div class="call-item"><i class="fas fa-phone${c.direction==='inbound'?'-alt':''}" style="color:${c.direction==='inbound'?'#2e7d32':'#1565c0'}"></i><div style="flex:1"><strong>${escHTML(c.customer_name||c.phone_number||'Unknown')}</strong><div style="color:var(--text-light)">${escHTML((c.outcome||'').replace(/_/g,' '))} \u2022 ${c.duration_minutes||0}m</div></div><span style="font-size:11px;color:var(--text-light)">${fmtTime(c.call_datetime)}</span></div>`).join(''):'<div class="empty">No calls today</div>'}catch(e){panelError('recentCalls')}
  // Callbacks
  try{const cb=await api('/communications/call-logs/?outcome=callback_scheduled&ordering=-call_datetime&page_size=8');const items=cb.results||cb;
    document.getElementById('callbacksDue').innerHTML=items.length?items.map(c=>`<div class="q-item"><i class="fas fa-reply" style="color:var(--accent)"></i><div style="flex:1"><strong>${escHTML(c.customer_name||c.phone_number||'Unknown')}</strong><div style="color:var(--text-light)">${escHTML(c.notes||'No notes')}</div></div></div>`).join(''):'<div class="empty">No callbacks pending</div>'}catch(e){panelError('callbacksDue')}
  // CSR Inbox Performance tiles (Phase 4c.3) — single fetch, 8 tiles
  loadInboxStats();
}
// fmtNum: render N if it's a number, else dash. Keeps the tile labels clean
// for "no data yet" states (e.g. latency before any inbox bookings exist).
function fmtNum(v,suffix=''){return (v===null||v===undefined)?'—':v+suffix}
async function loadInboxStats(){
  try{
    const s=await api('/scheduling/csr-inbox/stats/');
    // F-027 R13: per-tile try blocks so a malformed/missing section doesn't
    // bail out partway and leave the remaining tiles stuck at em-dash.
    const ib=s.inbox_bookings||{};
    try{
      document.querySelector('#iboxBookings .tile-val').textContent=fmtNum(ib.today);
      document.querySelector('#iboxBookings .tile-sub').textContent='7d: '+fmtNum(ib.last_7d);
    }catch(_){ }
    try{
      const c=s.inbox_conversion||{};
      document.querySelector('#iboxConversion .tile-val').textContent=fmtNum(c.last_7d_pct,'%');
      document.querySelector('#iboxConversion .tile-sub').textContent=fmtNum(c.bookings_7d)+' bookings / '+fmtNum(c.suggest_calls_7d)+' suggests';
    }catch(_){ }
    try{
      const l=s.suggest_to_book_latency||{};
      document.querySelector('#iboxLatency .tile-val').textContent=(l.p50_seconds!==null&&l.p50_seconds!==undefined)?l.p50_seconds+'s':'—';
      document.querySelector('#iboxLatency .tile-sub').textContent='p95 '+((l.p95_seconds!==null&&l.p95_seconds!==undefined)?l.p95_seconds+'s':'—')+' · n='+fmtNum(l.sample_size);
    }catch(_){ }
    try{
      const o=s.override_usage||{};
      document.querySelector('#iboxOverride .tile-val').textContent=fmtNum(o.last_7d_pct,'%');
      document.querySelector('#iboxOverride .tile-sub').textContent=fmtNum(o.count_7d)+' bookings used override';
    }catch(_){ }
    try{
      const r=s.reschedule_rate||{};
      document.querySelector('#iboxReschedule .tile-val').textContent=fmtNum(r.last_7d_pct,'%');
      document.querySelector('#iboxReschedule .tile-sub').textContent=fmtNum(r.count_7d)+' rescheduled';
    }catch(_){ }
    try{
      const reasons=((s.cancel_by_reason||{}).top_reasons)||[];
      const reasonHtml=reasons.length
        ? reasons.map(x=>`<div class="tile-list-row"><span class="nm">${(x.code||'').replace(/_/g,' ')}</span><span class="ct">${x.count}</span></div>`).join('')
        : `<div class="tile-list-row"><span class="nm" style="color:var(--text-light)">No cancellations</span></div>`;
      document.getElementById('iboxCancelReasonsList').innerHTML=reasonHtml;
    }catch(_){ }
    try{
      const n=s.notes_per_appt||{};
      document.querySelector('#iboxNotes .tile-val').textContent=fmtNum(n.last_7d_avg);
      document.querySelector('#iboxNotes .tile-sub').textContent=fmtNum(n.events_7d)+' total notes events';
    }catch(_){ }
    try{
      const csrs=((s.top_csrs||{}).last_7d)||[];
      const csrHtml=csrs.length
        ? csrs.map(x=>`<div class="tile-list-row"><span class="nm">${x.name||''}</span><span class="ct">${x.bookings}</span></div>`).join('')
        : `<div class="tile-list-row"><span class="nm" style="color:var(--text-light)">No bookings yet</span></div>`;
      document.getElementById('iboxTopCsrsList').innerHTML=csrHtml;
    }catch(_){ }
  }catch(e){/* swallow — tiles remain at last known values or em-dash */}
}
document.addEventListener('DOMContentLoaded',loadDashboard);setInterval(loadDashboard,60000);