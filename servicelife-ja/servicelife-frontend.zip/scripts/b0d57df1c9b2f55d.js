function parSubmit(ev) {
  ev.preventDefault();
  var form = document.getElementById('par-form');
  var btn = document.getElementById('par-btn');
  var status = document.getElementById('par-status');
  var year = document.getElementById('par-year').value;
  var quarter = document.getElementById('par-quarter').value;
  var fmt = form.querySelector('input[name="format"]:checked').value;

  status.className = 'par-status is-info';
  status.textContent = 'Generating report — this may take a few seconds…';
  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin" style="margin-right:6px"></i> Generating…';

  fetch('', {
    method: 'POST',
    credentials: 'same-origin',
    body: new FormData(form),
  })
  .then(function(r) {
    if (!r.ok) {
      throw new Error('HTTP ' + r.status);
    }
    return r.blob();
  })
  .then(function(blob) {
    var ext = fmt === 'csv' ? 'csv' : 'pdf';
    var fname = 'pa-quarterly-report-' + year + '-Q' + quarter + '.' + ext;
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = fname;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    status.className = 'par-status is-success';
    status.textContent = 'Report downloaded successfully.';
  })
  .catch(function() {
    status.className = 'par-status is-error';
    status.textContent = 'Report generation failed. Please try again or contact support.';
  })
  .finally(function() {
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-download" style="margin-right:6px"></i> Download report';
  });
  return false;
}